﻿using Fcmb.Shared.Auth.Services;
using Microsoft.Extensions.DependencyInjection;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Common;
using ORM.Application.Interfaces.User;
using ORM.Application.Interfaces.Role;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.Services.Auth;
using ORM.Infrastructure.Services.Common;
using ORM.Application.Interfaces;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Infrastructure
{
    [ExcludeFromCodeCoverage]
    public static class ConfigureDependenciesServices
    {
        /// <summary>
        /// Configure other services in which app services rely upon (e.g. Token Manager) 
        /// </summary>
        /// <param name="services"></param>
        public static void ConfigureThirdPartyServices(this IServiceCollection services)
        {
            services.AddTransient<IMailService, MailService>();
            services.AddTransient<IAuthService, AuthService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IAuthTokenGenerator, JwtTokenGenerator>();
            services.AddTransient<IRoleService, RoleService>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<IKeyVaultHelper, KeyVaultHelper>();

        }
    }
}
