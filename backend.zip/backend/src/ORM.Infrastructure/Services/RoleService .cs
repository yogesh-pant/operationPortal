﻿using Azure;
using Fcmb.Shared.Auth.Models.Responses;
using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using System.Drawing;
using System;
using System.Reflection.Metadata.Ecma335;
using ORM.Application.Interfaces.User;
using System.Data;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using static System.Collections.Specialized.BitVector32;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Infrastructure.Services
{
    public class RoleService : IRoleService
    {
        private readonly ILogger<RoleService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;

        public RoleService(ILogger<RoleService> logger, ISessionService sessionService, IUnitOfWork unitOfWork)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
        }
        /// <summary>
        /// This function is used to get the list of users
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<RoleGridResponse>> GetAllRoleAsync(FilterRoleRequest filterRoleRequest)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<RoleGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var roleListQuery = unitOfWork.ORMRoles
               .GetAll().AsQueryable()
               .Select(role => new
               {
                   RoleId = role.RoleId,
                   RoleTitle = role.RoleTitle,
                   Status = role.RoleStatus,
                   RoleUpdatedBy = role.RoleUpdatedBy,
                   RoleUpdatedDate = role.RoleUpdationTime,
                   RoleCreatedBy = role.RoleCreatedBy,
                   RoleCreatedDate = role.RoleCreationTime,
                   TotalCount = unitOfWork.ORMUsers
                       .GetAll()
                       .Count(user => user.RoleId == role.RoleId)
               })
               .Select(roleInfo => new RoleGridResponse
               {
                   RoleId = roleInfo.RoleId,
                   RoleTitle = roleInfo.RoleTitle,
                   Status = roleInfo.Status,
                   RoleUpdatedBy = roleInfo.RoleUpdatedBy,
                   RoleUpdatedDate = roleInfo.RoleUpdatedDate,
                   RoleCreatedBy = roleInfo.RoleCreatedBy,
                   RoleCreatedDate = roleInfo.RoleCreatedDate,
                   TotalCount = roleInfo.TotalCount
               });


            if (filterRoleRequest?.roleTitle is not null)
                roleListQuery = roleListQuery.Where(p => p.RoleTitle == filterRoleRequest.roleTitle);

            if (filterRoleRequest?.status is not null)
                roleListQuery = roleListQuery.Where(p => p.Status == filterRoleRequest.status);


            var totalCount = roleListQuery.Count();

            if (filterRoleRequest is not null)
                roleListQuery = roleListQuery.Paginate(filterRoleRequest);

            var response = await Task.Run(() => roleListQuery);

            logger.LogInformation("Successfully Retrieved Users");

            return new ListResponse<RoleGridResponse>("Successfully Retrieved Users")
            {
                Data = response,
                Total = totalCount
            };

        }

    }
}






