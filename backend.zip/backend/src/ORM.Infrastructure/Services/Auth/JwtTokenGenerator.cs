﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Auth;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ORM.Infrastructure.Services.Auth
{
    public class JwtTokenGenerator : IAuthTokenGenerator
    {
        private readonly ILogger<JwtTokenGenerator> logger;
        private readonly string jwtKey;
        private readonly string apiIssuer;
        private readonly string apiAudience;


        public JwtTokenGenerator(ILogger<JwtTokenGenerator> logger, IConfiguration configuration)
        {
            this.logger = logger;
            jwtKey = configuration["orm-jwt-key"]!;
            apiIssuer = configuration["JWTConfig:Issuer"]!;
            apiAudience= configuration["JWTConfig:Audience"]!;
        }
        /// <summary>
        /// This function is used to generate the token using JwtSecurityTokenHandler
        /// </summary>
        /// <param name="isAutherizedUser"></param>
        /// <param name="session"></param>
        /// <param name="validity"></param>
        /// <returns></returns>
        public string Generate(bool isAutherizedUser,StaffSession session, TimeSpan validity)
        {
            logger.LogInformation("Generating Staff Auth JWT Token...");
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(jwtKey);
            if (isAutherizedUser)
            {
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(CreateClaims(session)),
                    Expires = DateTime.UtcNow.Add(validity),
                    Issuer = apiIssuer,
                    Audience = apiAudience,
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                return tokenString;
            }
            else
            {
                return string.Empty;
            }

        }
        /// <summary>
        /// This is supporting function which is used to generate token
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        private static Claim[] CreateClaims(StaffSession session)
        {
            return new Claim[]
            {
            new Claim(nameof(StaffSession.UserId), session.UserId.ToString()),
            new Claim(nameof(StaffSession.UserName), session.UserName ?? string.Empty),
            new Claim(nameof(StaffSession.RoleId), session.RoleId.ToString()!),
            new Claim(nameof(StaffSession.StaffId), session.StaffId ?? string.Empty),
            new Claim(nameof(StaffSession.Email), session.Email ?? string.Empty),
            };
        }
    }
}
