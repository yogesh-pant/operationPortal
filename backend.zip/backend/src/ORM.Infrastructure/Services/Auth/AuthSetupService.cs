﻿using Fcmb.Shared.Auth.Models.Requests;
using Fcmb.Shared.Auth.Models.Responses;
using Fcmb.Shared.Auth.Services;
using Fcmb.Shared.Models.Responses;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.Services.Common;
using ORM.Application.Interfaces.Common;
using ORM.Infrastructure.UOW;
using System.Data;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace ORM.Infrastructure.Services.Auth
{
    public class AuthSetupService : IAuthSetupService
    {
        private readonly IAuthService authService;
        private readonly IAuthTokenGenerator authTokenGenerator;
        private readonly ILogger<AuthSetupService> logger;
        private readonly IUnitOfWork unitOfWork;
        private readonly ISessionService sessionService;
        private readonly IKeyVaultHelper keyvaulthelper;


        public AuthSetupService(ILogger<AuthSetupService> logger, IAuthService authService, IAuthTokenGenerator authTokenGenerator,
             IUnitOfWork unitOfWork, ISessionService sessionService, IKeyVaultHelper keyvaulthelper)

        {
            this.logger = logger;
            this.authService = authService;
            this.authTokenGenerator = authTokenGenerator;
            this.unitOfWork = unitOfWork;
            this.sessionService = sessionService;
            this.keyvaulthelper = keyvaulthelper;

        }
        /// <summary>
        /// This service functions checks the user exists in AD
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public async Task<ObjectResponse<LoginResponse>> CheckUserInAdAsync(string username, string ip)
        {
            if (username == "" || username == null)
                return new ObjectResponse<LoginResponse>("Error - User Name is blank!", ResponseCodes.InvalidCredentials);

            var result = new ObjectResponse<LoginResponse>("Account exists with this username in Ad", ResponseCodes.Success)
            {   ///send response for failed

                Data = new LoginResponse
                {
                    Token = String.Empty,
                    RefreshToken = String.Empty,
                    FailLoginCount = 0,
                    IsAccountLocked = false
                }
            };

            //var result = await authService.GetUserAdFullDetailsWLoginName(username);

            if (result.Code == ResponseCodes.Success)
            {
                var ormUser = await (from au in unitOfWork.ORMUsers.GetAll()
                                     where au.UserName == username
                                     select au).FirstOrDefaultAsync<ORMUser>();


                if (ormUser is not null && ormUser.Status == "Locked")
                {
                    logger.LogWarning("Account for {Username} is locked. ip: {ip}", username,ip);

                    return CreateFailedLoginResponse("Account is locked. Please contact an admin", ormUser);
                }
                if (ormUser is not null)
                {
                    logger.LogInformation("{Username} exists in Active Directory, ip: {ip}", username, ip);

                    return new ObjectResponse<LoginResponse>("Account exists with this username in Ad", ResponseCodes.Success)
                    {   ///send response for failed attempt
                        Data = new LoginResponse
                        {
                            Token = String.Empty,
                            RefreshToken = String.Empty,
                            FailLoginCount = ormUser.FailedLoginCount is not null ? Int32.Parse(ormUser.FailedLoginCount) : 0,
                            IsAccountLocked = ormUser.Status == "Locked"
                        }
                    };
                }
                else
                {
                    return new ObjectResponse<LoginResponse>($"{username} not found in ORM Database", ResponseCodes.DataNotFound);
                }
            }
            if (result.Code == ResponseCodes.ServiceError)
            {
                return new ObjectResponse<LoginResponse>($"{username} network error occurred", ResponseCodes.ServiceError);
            }

            return new ObjectResponse<LoginResponse>($"{username} not found in Ad", ResponseCodes.DataNotFound);
        }
        /// <summary>
        /// This function checks the eligibility of user when when logging in
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<ObjectResponse<LoginResponse>> LoginAsync(LoginRequest request, string ip)
        {
            var iv     = await keyvaulthelper.GetSecretAsync("orm-encryption-iv");
            var secret = await keyvaulthelper.GetSecretAsync("orm-encryption-key");

            var decryptionResult = ValidateandDecrypt(request,iv!,secret!);

            if (decryptionResult.Response!.Code != ResponseCodes.Success)
            {
                return decryptionResult.Response;
            }
            //var result = await authService.LoginAsync(decryptionResult.UpdatedRequest!);

            var result = new ObjectResponse<AdLoginResponse>("Account exists with this username in Ad", ResponseCodes.Success)
            {   ///send response for failed attempt
                Data = new AdLoginResponse
                {
                    ManagerDepartment = "qqq",
                    ManagerName = "www",
                    StaffName = request.Email,
                    DisplayName = request.Email,
                    Email = request.Email,
                    Department = "rrr",
                    Groups = "TestUser | NAPSSuper ",
                    MobileNo = "333333",
                    StaffId = "FCMB",
                }
            };
            var ormUser = await unitOfWork.ORMUsers.GetAll()
                                    .FirstOrDefaultAsync(au => au.UserName == request.Email);

            if (result.Code == ResponseCodes.InvalidCredentials)
            {                
                return ProcessIncorrectCredentials(ormUser!); 
            }
            if (result.Code != ResponseCodes.Success)
            {
                return new ObjectResponse<LoginResponse>("AuthService failed in AD!", ResponseCodes.ServiceError)
                {
                    Data = new LoginResponse
                    {
                        Token = String.Empty,
                        RefreshToken = String.Empty,
                        FailLoginCount = 0,
                        IsAccountLocked = true
                    }
                };
            }

                var uservalidationResponse = ValidateOrmUserStatus(ormUser!, decryptionResult.UpdatedRequest!.Email,ip);

                if (uservalidationResponse.Code != ResponseCodes.Success)
                {
                    return uservalidationResponse;
                }

                var userLocationType = "B";
                var ormUserLocationMaps = unitOfWork.ORMUserLocationMap.GetAll()
                        .Where(au => au.UserId == ormUser!.Id)
                        .Where(au => au.ORMLocation.Status == "Active")
                        .Select(au => new
                        {
                            LocationId = au.LocationId,
                            LocationType = au.ORMLocation.LocationType,
                            Region = au.ORMLocation.Region!,
                            Branch = au.ORMLocation.Branch!,
                            Department = au.ORMLocation.Department!
                        })
                        .ToList();

                var UserRole = unitOfWork.ORMRoles.GetAll().FirstOrDefault(p => p.RoleId == ormUser!.RoleId);

                var userRoleLocResponse = ValidateUserRoleLoc(ormUserLocationMaps.Count, UserRole!,request.Email);

                if (userRoleLocResponse.Code != ResponseCodes.Success)
                {
                    return userRoleLocResponse;
                }
                var RoleTitle = UserRole!.RoleTitle;

                if (RoleTitle.ToLower() != "admin")
                {
                    userLocationType = ormUserLocationMaps[0]?.LocationType;
                }
                var userLocationData = ormUserLocationMaps.Select(au => new LocationData
                {
                    LocationId = au.LocationId,
                    Branch = userLocationType == "B" ? au.Branch : null,
                    Department = au.Department,
                    Region = userLocationType == "B" ? au.Region : null,

                })
                .ToList();


                logger.LogInformation("{Email} successfully logged, user Ip: {ip}", request.Email,ip);
                var staffSession = GenerateStaffSession(ormUser!);
                var token = authTokenGenerator.Generate(true, staffSession, TimeSpan.FromMinutes(30));
                
            var ormUserT = await unitOfWork.ORMUsers.GetAll()
                                  .FirstOrDefaultAsync(au => au.UserName == request.Email);

                ResetFailedLoginInfo(ormUserT!, token);
                unitOfWork.Save();
            return new ObjectResponse<LoginResponse>("Successfully Logged In User")
                {
                    Data = new LoginResponse
                    {
                        Token = token,
                        UserRoleId = ormUser!.RoleId,
                        UserRole = RoleTitle,
                        UserSubRoleId = ormUser!.SubRoleId,
                        UserName = staffSession.UserName,
                        Email = ormUser.Email,
                        LastLoginTime = ormUser.LastLoginTime,
                        UserId = ormUser.Id,
                        LocationType = userLocationType,
                        LocationData = userLocationData,
                    }
                };
            

        }
        /// <summary>
        /// Validate and Decrypt the Password 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private DecryptionResult ValidateandDecrypt(LoginRequest request,string ivCode, string secretCode)
        {
            var response = new ObjectResponse<LoginResponse>(string.Empty, ResponseCodes.Success);
            var updatedRequest = request;

            if (request == null || string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
            {
                response = new ObjectResponse<LoginResponse>("Please provide valid user name and/or Password", ResponseCodes.InvalidCredentials);
                return new DecryptionResult { Response = response, UpdatedRequest = updatedRequest };
            }
            var iv = ivCode;
            var secret = secretCode;
            if (string.IsNullOrEmpty(iv))
            {
                logger.LogError("orm-encryption-iv is missing in appsettings.json.");
                response = new ObjectResponse<LoginResponse>("orm-encryption-iv is missing in appsettings file", ResponseCodes.RequestValidationError);
                return new DecryptionResult { Response = response, UpdatedRequest = updatedRequest };
            }

            if (string.IsNullOrEmpty(secret))
            {
                logger.LogError("orm-encryption-key is missing in appsettings.json.");
                response = new ObjectResponse<LoginResponse>("orm-encryption-secret is missing in appsettings file", ResponseCodes.RequestValidationError);
                return new DecryptionResult { Response = response, UpdatedRequest = updatedRequest };
            }

            var decryptedResponse = DecryptData(request.Password, iv, secret);

            if (decryptedResponse.Code != ResponseCodes.Success)
            {
                response = new ObjectResponse<LoginResponse>(decryptedResponse.Description, decryptedResponse.Code);
                return new DecryptionResult { Response = response, UpdatedRequest = updatedRequest };
            }

            // Create a new request object with the decrypted password
            updatedRequest = new LoginRequest
            {
                Email = request.Email,
                Password = decryptedResponse.Description
            };

            return new DecryptionResult { Response = response, UpdatedRequest = updatedRequest };
        }
        private ObjectResponse<LoginResponse> ValidateOrmUserStatus(ORMUser ormUser, string email,string ip)
        {
            if (ormUser == null)
            { 
                return new ObjectResponse<LoginResponse>("User not found in ORM!", ResponseCodes.ServiceError)
                {
                Data = new LoginResponse
                    {
                        Token = String.Empty,
                        RefreshToken = String.Empty,
                        FailLoginCount = 0,
                        IsAccountLocked = true
                    }
                };
            }
            if (ormUser.Status == "Locked")
            {
                logger.LogWarning("{Email} login rejected- Account locked out. user IP: {ip}", email,ip);
                return new ObjectResponse<LoginResponse>("Account is locked. Please contact admin", ResponseCodes.NoPermission)
                {
                    Data = CreateFailedLoginResponse(ormUser)
                };
            }

            if (ormUser.Status != "Active")
            {
                logger.LogWarning("{Email} login rejected- Account Inactive in ORM. user Ip:{ip} ", email, ip);
                return new ObjectResponse<LoginResponse>("Account is Inactive. Please contact ORM admin", ResponseCodes.NoPermission)
                {
                    Data = CreateFailedLoginResponse(ormUser)
                };
            }

            return new ObjectResponse<LoginResponse>(string.Empty, ResponseCodes.Success);
        }
        /// <summary>
        /// Validate user when invalid credentials are provided/ authentication failure
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private ObjectResponse<LoginResponse> ProcessIncorrectCredentials(ORMUser ormUser)
        {
            if (ormUser == null)
            {
                return new ObjectResponse<LoginResponse>("Unauthenticated New User", ResponseCodes.InvalidCredentials)
                {
                    Data = new LoginResponse
                    {
                        Token = String.Empty,
                        RefreshToken = String.Empty,
                        FailLoginCount = 0,
                        IsAccountLocked = false
                    }
                };
            }
            else
            {
                UpdateFailedLoginInfo(ormUser);
                return new ObjectResponse<LoginResponse>("Unauthenticated User", ResponseCodes.InvalidCredentials)
                {
                    Data = new LoginResponse
                    {
                        Token = String.Empty,
                        RefreshToken = String.Empty,
                        FailLoginCount = ormUser.FailedLoginCount is not null ? int.Parse(ormUser.FailedLoginCount) : 0,
                        IsAccountLocked = ormUser.Status == "Locked"

                    }
                };
            }
        }
        /// <summary>
        /// Validate user Role and Location mapping after successful authentication  
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private ObjectResponse<LoginResponse> ValidateUserRoleLoc(long ormUserLocationMapCount, ORMAppRole UserRole,string Email)
        {
            if (UserRole == null)
            {
                logger.LogWarning("{Email} login rejected- No Role Assigned to User. Please contact Admin ", Email);
                return new ObjectResponse<LoginResponse>("No Role Assigned to User", ResponseCodes.ServiceError)
                {
                    Data = new LoginResponse
                    {
                        Token = String.Empty,
                        RefreshToken = String.Empty,
                        FailLoginCount = 0,
                        IsAccountLocked = true
                    }
                };
            }
            if ((ormUserLocationMapCount == 0) && (UserRole.RoleTitle.ToLower() != "admin"))
            {
                logger.LogWarning("{Email} login rejected- No Location Assigned to User. Please contact Admin ", Email);

                return new ObjectResponse<LoginResponse>("Login rejected- No Location Assigned to User. Please contact Admin", ResponseCodes.NoPermission)
                {
                    Data = new LoginResponse
                    {
                        Token = String.Empty,
                        RefreshToken = String.Empty,
                        FailLoginCount = 0,
                        IsAccountLocked = true
                    }
                };
            }

            return new ObjectResponse<LoginResponse>(string.Empty, ResponseCodes.Success);
        }


        /// <summary>
        /// This function is used to get user logged out
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public async Task<ObjectResponse<string>> LogoutAsync(string UserName,string ip)
        {
            if (UserName == "" || UserName == null)
                return new ObjectResponse<string>("Error - User Name is blank!.", ResponseCodes.DataNotFound);

            var session = sessionService.GetStaffSession();
            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (session.UserName != UserName)
            {
                return new ObjectResponse<string>("This user does not belong to existing session.", ResponseCodes.Unauthenticated);
            }


            var username = UserName;

            var ormAppUser = await (from au in unitOfWork.ORMUsers.GetAll()
                                    where au.UserName == username
                                    select au).FirstOrDefaultAsync<ORMUser>();
            if (ormAppUser is not null)
            {
                logger.LogWarning("{username} loged out- ipaddress:{ip} ", username, ip);
                return new ObjectResponse<string>("You have been successfully logged out", ResponseCodes.Success);
            }
            else
                return new ObjectResponse<string>("User Not Found", ResponseCodes.DataNotFound)
                {
                    Data = "Please provide valid User name"
                };
        }
        /// <summary>
        /// This function is used to to generate session for the user/staff 
        /// </summary>
        /// <param name="loginResponse"></param>
        /// <returns></returns>
        private static StaffSession GenerateStaffSession(ORMUser loginResponse)
        {
            return new(loginResponse.Id, loginResponse.UserName, loginResponse.Email, loginResponse.StaffId!, loginResponse.RoleId);
        }

        /// <summary>
        /// This function is used to generate failed login response
        /// </summary>
        /// <param name="ormUser"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public static LoginResponse CreateFailedLoginResponse(ORMUser? ormUser, int count = 0)
        {
            return new LoginResponse
            {
                Token = String.Empty,
                RefreshToken = String.Empty,
                FailLoginCount = count,
            };
        }
        /// <summary>
        /// This function is used to generate failed login response
        /// </summary>
        /// <param name="message"></param>
        /// <param name="ormUser"></param>
        /// <returns></returns>
        public static ObjectResponse<LoginResponse> CreateFailedLoginResponse(string message, ORMUser ormUser)
        {
            return new ObjectResponse<LoginResponse>(message, ResponseCodes.LockedOutUser)
            {
                Data = new LoginResponse
                {
                    Token = string.Empty,
                    RefreshToken = string.Empty,
                    FailLoginCount = ormUser.FailedLoginCount is not null ? int.Parse(ormUser.FailedLoginCount) : 0,
                    //IsAccountLocked = ormUser.IsAccountLocked
                }
            };
        }

        /// <summary>
        /// This function is used to add new user into orm
        /// </summary>
        /// <param name=""- ></param>
        /// <returns>
        /// int role id
        /// </returns>
        /// <summary>
        /// This function is used to reset the failed login info
        /// </summary>
        /// <param name="ormUser"></param>
        public static void ResetFailedLoginInfo(ORMUser ormUser, string token)
        {
            ormUser.FailedLoginCount = "0";
            ormUser.LastLoginTime = ormUser.CurrentLoginTime ?? DateTime.Now;
            ormUser.CurrentLoginTime = DateTime.Now;
            ormUser.CurrentToken = token;
        }
        /// <summary>
        /// This function is used to update the failed login count
        /// </summary>
        /// <param name="ormUser"></param>
        /// <returns></returns>
        private void UpdateFailedLoginInfo(ORMUser? ormUser)
        {
            var count = ormUser?.FailedLoginCount is not null ? Int32.Parse(ormUser.FailedLoginCount) : 0;
            count++;
            if (ormUser is not null)
            {
                ormUser.FailedLoginCount = count.ToString();

                if (count >= 3)
                {
                    ormUser.Status = "Locked";
                    
                }
                else
                {
                    ormUser.Status = "Active";
                }
                unitOfWork.Save();
            }
        }



        private static ObjectResponse<string> DecryptData(string encryptedData, string iv, string key)
        {
            try
            {
                byte[] encryptedBytes = Convert.FromBase64String(encryptedData);

                using (Aes aesAlg = Aes.Create())
                {
                    aesAlg.Key = Encoding.UTF8.GetBytes(key);
                    aesAlg.IV = Encoding.UTF8.GetBytes(iv);

                    ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                    using (MemoryStream msDecrypt = new MemoryStream(encryptedBytes))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                return new ObjectResponse<string>(srDecrypt.ReadToEnd(), ResponseCodes.Success)
                                {
                                    Code = "00"
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return new ObjectResponse<string>("Error in decrypting the password, please ensure valid Entrypted String is provided ", ResponseCodes.RequestValidationError)
                {
                    Data = ResponseCodes.RequestValidationError + " -- " + ex.Message
                };
            }
        }
    }
}
