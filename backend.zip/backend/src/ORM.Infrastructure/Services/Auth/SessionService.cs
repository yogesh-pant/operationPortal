﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Responses;
using System.Security.Claims;

namespace ORM.Infrastructure.Services.Auth
{
    public class SessionService : ISessionService
    {
        
        private readonly ILogger<SessionService> logger;
        private readonly IHttpContextAccessor contextAccessor;
        private readonly object claimsLocker = new();
        
        private StaffSession? staffSession;
        private Dictionary<string, Claim>? claimsDictionary;
        
        
        public SessionService(ILogger<SessionService> logger, IHttpContextAccessor contextAccessor)
        {
            this.logger = logger;
            this.contextAccessor = contextAccessor;
        }
        /// <summary>
        /// This function is used to provide new sessiom for user 
        /// </summary>
        /// <returns></returns>
        public StaffSession? GetStaffSession()
        {
            try
            {
                if (staffSession is not null) return staffSession;

                staffSession = ProcessStaffSession() ?? null;
                if (staffSession is not null)
                    logger.LogInformation("Resolved New Session For Staff {User}", staffSession!.UserName);

                return staffSession;
            }
            catch (Exception e)
            {
                logger.LogError(e, "Unable to resolve session");
                return null;
            }
        }
        /// <summary>
        /// This function uses the staff details to process session
        /// </summary>
        /// <returns></returns>
        private StaffSession? ProcessStaffSession()
        {
            if (contextAccessor.HttpContext is null || !contextAccessor.HttpContext.User.Claims.Any()) return null;
            if (claimsDictionary is null)
            {
                claimsDictionary= InitClaimsDict();

            }
            var userIdClaim = claimsDictionary[nameof(StaffSession.UserId)];
            long UserId = Int32.Parse(userIdClaim.Value);

            var userNameClaim = claimsDictionary[nameof(StaffSession.UserName)];
            var UserName = userNameClaim.Value;
            if (string.IsNullOrEmpty(UserName)) UserName = string.Empty;

            var emailClaim = claimsDictionary[nameof(StaffSession.Email)];
            var Email = emailClaim.Value;
            if (string.IsNullOrEmpty(Email)) Email = string.Empty;

            var staffIdClaim = claimsDictionary[nameof(StaffSession.StaffId)];
            var StaffId = staffIdClaim.Value;
            if (string.IsNullOrEmpty(StaffId)) StaffId = string.Empty;

            var roleIdClaim = claimsDictionary[nameof(StaffSession.RoleId)];
            long RoleId = Int32.Parse(roleIdClaim.Value);

            return new StaffSession(UserId,UserName,Email,StaffId,RoleId);
        }
      
        /// <summary>
        /// This is the supporting fucnton for staff session
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, Claim> InitClaimsDict()
        {
            var claims = contextAccessor.HttpContext!.User.Claims;
            claimsDictionary = new Dictionary<string, Claim>();
            foreach (var claim in claims)
            {
                lock (claimsLocker)
                {
                    claimsDictionary[claim.Type] = claim;
                }
            }
            return claimsDictionary;
        }
    }
}
