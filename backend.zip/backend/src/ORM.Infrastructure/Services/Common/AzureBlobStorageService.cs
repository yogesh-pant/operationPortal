﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ORM.Application.Interfaces.Common;
using ORM.Domain.Common;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Infrastructure.Services.Common
{

    [ExcludeFromCodeCoverage]
    public class AzureBlobStorageService : IAzueBlobStorageService
    {
        public  BlobServiceClient _blobServiceClient=null!;
        public  string _containerName=null!;
        private readonly ILogger<AzureBlobStorageService> _logger;
        private readonly IKeyVaultHelper keyvaulthelper;
        public AzureBlobStorageService(
              ILogger<AzureBlobStorageService> logger,
              IConfiguration configuration,
              IOptions<AzureBlobSettings> azureBlobSettingsOptions,
               IKeyVaultHelper keyvaulthelper
            )
        {
            this.keyvaulthelper = keyvaulthelper;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            var containerName = configuration.GetValue<string>("AzureBlobSettings:ContainerName");


            ValidateAndInitializeConfigurationAsync(containerName).GetAwaiter().GetResult();

        }
        private async Task ValidateAndInitializeConfigurationAsync( string? containerName)
        {
            // Retrieve connection string from Key Vault
            var connectionString = await keyvaulthelper.GetSecretAsync("orm-blob-connectionstring");

                if (string.IsNullOrEmpty(connectionString))
                {
                    _logger.LogError("Failed to retrieve orm-blob-connectionstring from Key Vault.");
                    throw new InvalidOperationException("orm-blob-connectionstring is missing in both appsettings.json and Key Vault.");
                }

            if (string.IsNullOrEmpty(containerName))
            {
                _logger.LogError("AzureBlobSettings:ContainerName is missing in appsettings.json.");
                throw new InvalidOperationException("AzureBlobSettings:ContainerName is missing in appsettings.json.");
            }

            // Initialize BlobServiceClient with the validated/retrieved connection string
            _blobServiceClient = new BlobServiceClient(connectionString);
            _containerName = containerName;
        }
        public async Task<string> UploadFileAsync(IFormFile file)
        {
            _logger.LogInformation($"File upload begins at {DateTime.Now} ");
            string fileName = string.Empty;
            try
            {
                var blobContainerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                await blobContainerClient.CreateIfNotExistsAsync();

                fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                var blobClient = blobContainerClient.GetBlobClient(fileName);

                using (var stream = file.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, true);
                    _logger.LogInformation($"File uploaded at {DateTime.Now} ");
                }


            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while uploading file: {fileName} with errormessage: {ex.Message}");
            }
            _logger.LogInformation($"File upload ended at {DateTime.Now} ");
            return fileName;
        }

        public async Task<byte[]> GetFileAsBytesAsync(string fileName)
        {
            try
            {
                _logger.LogInformation($"File retrieval begins at {DateTime.Now} ");
                var blobContainerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient(fileName);

                if (await blobClient.ExistsAsync())
                {
                    _logger.LogInformation($"File found and download begins at {DateTime.Now} ");
                    using (var ms = new MemoryStream())
                    {
                        await blobClient.DownloadToAsync(ms);
                        _logger.LogInformation($"File downloaded at {DateTime.Now} ");
                        return ms.ToArray();
                    }
                }
                _logger.LogInformation($"File name {fileName} not found {DateTime.Now} ");
                return Array.Empty<byte>();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while getting file: {fileName} with errormessage: {ex.Message}");
                throw;
            }
        }

        public async Task<string> GetFileAsBase64Async(string fileName)
        {
            try
            {
                var bytes = await GetFileAsBytesAsync(fileName);
                _logger.LogInformation($"File converted to base 64 string at {DateTime.Now} ");
                return Convert.ToBase64String(bytes);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while getting file: {fileName} with errormessage: {ex.Message}");
                throw;
            }
        }
    }
}
