﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Services.Common
{
    public static class EmailUtils
        {
            public static string UpdatePlaceHolders(this string text, List<KeyValuePair<string, string>> keyValuePairs)
            {
                if (!string.IsNullOrWhiteSpace(text) && keyValuePairs != null)
                {
                    keyValuePairs.ForEach(keyValue =>
                    {
                        if (text.Contains(keyValue.Key))
                        {
                            text = text.Replace(keyValue.Key, keyValue.Value);
                        }
                    });
                }
                return text;
            }
        }
    
}
