﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORM.Application.Interfaces.Common;
using ORM.Application.Models.Requests.Mails;
using Azure.Identity;
using System.Configuration;
using Azure.Security.KeyVault.Secrets;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
namespace ORM.Infrastructure.Services.Common
{
    public class EmailService : IEmailService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<EmailService> _logger;
        private readonly IConfiguration configuration;
        private readonly IKeyVaultHelper keyvaulthelper;

        public EmailService(IHttpClientFactory httpClientFactory,
            ILogger<EmailService> logger, IConfiguration configuration, IKeyVaultHelper keyvaulthelper)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            this.configuration = configuration;
            this.keyvaulthelper=keyvaulthelper;
        }
        public async Task<bool> SendEmailAsync(SendEmailRequest sendEmailRequest)
        {
            var client = _httpClientFactory.CreateClient("emailClient");
            var emailUrl = configuration.GetValue<string>("FCMBConfig:EmailConfig:EmailUrl");
            client.BaseAddress = new Uri(emailUrl!);
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            var cl_Id = await keyvaulthelper.GetSecretAsync("orm-fcmbconfig-clientid");
            
            client.DefaultRequestHeaders.Add("client_id", cl_Id);
            var requestContent = new MultipartFormDataContent
            {
                { new StringContent(sendEmailRequest.From), "From" },
                { new StringContent(sendEmailRequest.To), "To" },
                { new StringContent(sendEmailRequest.Subject), "Subject" },
                { new StringContent(sendEmailRequest.Body), "Body" }
            };

            if (sendEmailRequest.Bcc?.Any() == true)
            {
                sendEmailRequest.Bcc.ForEach(x => requestContent.Add(new StringContent(x), "Bcc"));
            }
            if (sendEmailRequest.Cc?.Any() == true)
            {
                sendEmailRequest.Cc.ForEach(x => requestContent.Add(new StringContent(x), "Cc"));
            }

            // Construct the relative URL based on the BaseAddress
            var relativeUrl = "/fcmb/api/Mail/SendMail";

            using var response = await client.PostAsync(relativeUrl, requestContent);

            var responseContent = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Response from calling send email endpoint: {responseContent}", responseContent);
                return true;

            }

            return false;
        }


    }
}
