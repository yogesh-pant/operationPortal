﻿using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;
using ORM.Application.Interfaces.Common;
using ORM.Application.Models.Requests.Mails;
using ORM.Domain.Common;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Infrastructure.Services.Common
{
    
    //[ExcludeFromCodeCoverage]
    public class MailService : IMailService
    {
        private readonly MailSettings _mailSettings;
        public MailService(IOptions<MailSettings> mailSettingsOptions)
        {
            _mailSettings = mailSettingsOptions.Value;
        }

        /// <summary>
        /// This function is used to send mail
        /// </summary>
        /// <param name="mailData"></param>
        /// <returns></returns>
        public async Task<bool> SendMailAsync(MailDataRequest mailData)
        {
            try
            {
                using (MimeMessage emailMessage = new MimeMessage())
                {
                    MailboxAddress emailFrom = new MailboxAddress(_mailSettings.SenderName, _mailSettings.SenderEmail);
                    emailMessage.From.Add(emailFrom);
                    MailboxAddress emailTo = new MailboxAddress(mailData.EmailToName, mailData.EmailToId);
                    emailMessage.To.Add(emailTo);

                    emailMessage.Subject = mailData.EmailSubject;
                    BodyBuilder emailBodyBuilder = new BodyBuilder();
                    emailBodyBuilder.TextBody = mailData.EmailBody;

                    emailMessage.Body = emailBodyBuilder.ToMessageBody();
                    //this is the SmtpClient from the Mailkit.Net.Smtp namespace, not the System.Net.Mail one
                    return await SendSMTPMailAsync(emailMessage);
                }
            }
            catch (Exception ex) {
                Console.WriteLine($"Failed to send email: {ex.Message}");
                return false;
            }
        }
        [ExcludeFromCodeCoverage]
        /// <summary>
        /// This supporting function for smtp request used in mailing
        /// </summary>
        /// <param name="emailMessage"></param>
        /// <returns></returns>
        public async Task<bool> SendSMTPMailAsync(MimeMessage emailMessage)
        {
            using (SmtpClient mailClient = new SmtpClient())
            {
                try
                {
                    await mailClient.ConnectAsync(_mailSettings.Server, _mailSettings.Port, MailKit.Security.SecureSocketOptions.StartTls);
                    await mailClient.AuthenticateAsync(_mailSettings.UserName, _mailSettings.Password);
                    await mailClient.SendAsync(emailMessage);
                    await mailClient.DisconnectAsync(true);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message.ToString());
                    return false;
                }
            }
        }

    }
}
