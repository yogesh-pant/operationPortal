﻿using Azure;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
namespace ORM.Application.Interfaces.Common
{

    public class KeyVaultHelper : IKeyVaultHelper
    {

        private readonly IConfiguration configuration;
        private readonly ILogger<KeyVaultHelper> logger;

        public KeyVaultHelper(ILogger<KeyVaultHelper> logger, IConfiguration configuration)

        {
            this.logger = logger;
            this.configuration = configuration;

        }
        /// <summary>
        /// This function is used to read secreat from azure key vault
        /// </summary>
        /// <method>        /// 
        /// Try to fetch secret value from appsettings.Development.json configuration 
        /// incase it is not found there then try to read it via test azure key vault from url AzureKeyVaultURLDev
        /// in appsettings.Development.json configuration.
        /// This connection to key vault from url AzureKeyVaultURLDev for dev/test purpose is made using app registration 
        /// AzureClientId,AzureClientSecret and AzureClientTenantId
        ///
        /// both of the above methods are intended for development and testing purposes only
        ///
        /// if secret key is not enabled in appsettings.Development.json and AzureKeyVaultURLDev is also disabled 
        /// then it would read secret value from AzureKeyVault:AzureKeyVaultURL in appsettings.json
        /// This call to azure key vault usages default authentication assuming azure webapp is granted accesss to key vault
        /// </method>
        /// <returns></returns>
        public async Task<string?> GetSecretAsync(string secretName)
        {

            SecretClient _secretClient;
            string result = configuration.GetValue<string>(secretName) ?? string.Empty;
            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    string keyVaultUrlDev = configuration.GetValue<string>("AzureKeyVaultURLDev")!;

                    if (keyVaultUrlDev != "")
                    {
                        string clientId = configuration.GetValue<string>("AzureClientId")!;
                        string clientSecret = configuration.GetValue<string>("AzureClientSecret")!;
                        string tenantId = configuration.GetValue<string>("AzureClientTenantId")!;
                        _secretClient = new SecretClient(new Uri(keyVaultUrlDev), new ClientSecretCredential(tenantId, clientId, clientSecret))!;

                        logger.LogInformation("Azure vault SecretClient successfully initialized from local.");
                        KeyVaultSecret secret = await _secretClient.GetSecretAsync(secretName);
                        return secret.Value;
                    }
                    else
                    {

                        var keyVaultUrl = configuration["AzureKeyVault:AzureKeyVaultURL"]!;
                        if (string.IsNullOrEmpty(keyVaultUrl))
                        {
                            logger.LogError("AzureKeyVault:AzureKeyVaultURL key missing in appSetting.");

                            throw new InvalidOperationException("Azure Key Vault URL is not configured.");
                        }

                        _secretClient = new SecretClient(new Uri(keyVaultUrl), new DefaultAzureCredential());
                        logger.LogInformation("Azure Vault SecretClient  with DefaultAzureCredentialsuccessfully initialized.");
                        KeyVaultSecret secret = await _secretClient.GetSecretAsync(secretName);
                        return secret.Value;
                    }
                }
                catch (RequestFailedException ex) when (ex.Status == 404)
                {
                    // Handle the case where the secret is not found
                    logger.LogError("Secret '{secretName}' not found in Azure Vault.", secretName);
                    throw;
                }
                catch (RequestFailedException ex)
                {
                    // Handle other exceptions related to Azure Key Vault
                    logger.LogError("An error occurred while retrieving the secret from Azure Vault: {ex.Message}", ex.Message);
                    throw; // Re-throw the exception if you want to handle it further up the call stack
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Error fetching secret from Azure Key Vault:{secretName}", secretName);
                    throw;
                }
            }
            return result;
        }
    }

}
