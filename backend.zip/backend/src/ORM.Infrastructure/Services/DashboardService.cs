﻿using Fcmb.Shared.Models.Responses;
using Microsoft.EntityFrameworkCore;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Dashboard;
using ORM.Application.Models.constants;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using System.Globalization;

namespace ORM.Infrastructure.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;

        public DashboardService(ISessionService sessionService, IUnitOfWork unitOfWork)
        {
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
        }
        public async Task<ListResponse<LossTrendResponse>> GetLossDataTrend(BaseDashboardChartsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<LossTrendResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterLossReports(request);

            var lossTrendResponses = query.GroupBy(x => x.DateReported.Month).OrderBy(x => x.Key).Select(x => new LossTrendResponse
               {
                    Name = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(x.Key),
                    Frequency =  x.Count(),
                    Value = x.Sum(x => x.NetActualLossAmount) ?? 0
                });

            var total = await lossTrendResponses.CountAsync();
            var response = await lossTrendResponses.ToListAsync();
            

            return new ListResponse<LossTrendResponse>("Successfully Fetched Loss Data Trends")
            {
                Data = response,
                Total = total
            };

        }

        public async Task<ListResponse<OperationalRiskLossVsFraudLossResponse>> GetOperationalRiskLossesVsFraudLoss(BaseDashboardChartsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<OperationalRiskLossVsFraudLossResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterLossReports(request);
            var groupedlosses = query.GroupBy(x => x.DateReported.Month).OrderBy(x => x.Key).Select(x => new OperationalRiskLossVsFraudLossResponse
            {
                Month = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(x.Key),
                ClientProductBusinessPractices = x.Where(x => x.BaselEventTypeI!.ToLower().Contains("client product & business practices")).Sum(x => x.NetActualLossAmount),
                ExecutionDeliveryProcessManagement = x.Where(x => x.BaselEventTypeI!.ToLower().Contains("execution delivery & process management")).Sum(x => x.NetActualLossAmount),
                EmploymentPracticesWorkplaceSafety = x.Where(x => x.BaselEventTypeI!.ToLower().Contains("employment practices & workplace safety")).Sum(x => x.NetActualLossAmount),
                Fraud = x.Where(x => x.BaselEventTypeI!.ToLower().Contains("fraud")).Sum(x => x.NetActualLossAmount)
            });
            var response = await groupedlosses.ToListAsync();  
            var total = response.Count;

            return new ListResponse<OperationalRiskLossVsFraudLossResponse>("Successfully Fetched Operational Risk Losses vs fraud loss")
            {
                Data = response,
                Total = total
            };
        }

        public async Task<ListResponse<RegionalInternalFraudResponse>> GetRegionalInternalFraudChart(BaseDashboardChartsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<RegionalInternalFraudResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterLossReports(request);
            query = query.Where(x => x.LocationType=="B");

            var regionGroupedResponse = GetRegionGroupedInternalFraudQuery(query);

            var total = await regionGroupedResponse.CountAsync();
            var response = await regionGroupedResponse.ToListAsync();

            return new ListResponse<RegionalInternalFraudResponse>("Successfully Fetched Regional Internal Frauds")
            {
                Data = response,
                Total = total
            };
        }

        public async Task<ListResponse<OperationalRiskLossResponse>> GetOperationalRiskLosses(BaseDashboardChartsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<OperationalRiskLossResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterLossReports(request);
            var groupedOperationalRiskLoses =   await GetGroupedOperationalLossesList(query);
            var total = groupedOperationalRiskLoses.Count;
           
            return new ListResponse<OperationalRiskLossResponse>("Successfully Fetched Operational Risk Losses")
            {
                Data = groupedOperationalRiskLoses,
                Total = total
            };
        }

        public async Task<ListResponse<RootCauseAnalysisResponse>> GetRootCauseAnalysisForActualLoss(BaseDashboardChartsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<RootCauseAnalysisResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterLossReportRootCause(request);
            var groupedRootCauseAnalysisList = await GetGroupedRootCauseAnalysisQuery(query);
            var total = groupedRootCauseAnalysisList.Count;

            return new ListResponse<RootCauseAnalysisResponse>("Successfully Fetched Root Cause Analysis")
            {
                Data = groupedRootCauseAnalysisList,
                Total = total
            };

        }

        public async Task<ListResponse<GrossVsRecoveryVsNetLossResponse>> GetGrossVsRecoveryVsNetLoss(BaseDashboardChartsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<GrossVsRecoveryVsNetLossResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterLossReports(request);
            var groupedRootCauseAnalysis = await GetGroupedGrossVsRecoveryVsNetLossQuery(query).FirstOrDefaultAsync();

            if (groupedRootCauseAnalysis is null)
            {
                return new ListResponse<GrossVsRecoveryVsNetLossResponse>("No Data Found", ResponseCodes.Success);
            }

            var response = CreateGrossVsRecoveryVsNetLossResponse(groupedRootCauseAnalysis);

            var total = response.Count;

            return new ListResponse<GrossVsRecoveryVsNetLossResponse>("Successfully Fetched Gross Vs Recovery Vs Net Loss")
            {
                Data = response,
                Total = total
                
            };
        }

        public async Task<ListResponse<TrendOfOperationalRiskSourceResponse>> GetTrendOfOperationalRiskSource(FilterRiskReportRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<TrendOfOperationalRiskSourceResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterRiskReport(request);
            var response = await CreateOperationalRiskSourceResponse(query, request.Year);

            var total = response.Count;

            return new ListResponse<TrendOfOperationalRiskSourceResponse>("Successfully Fetched Trend Of Operaetional Risk Sources")
            {
                Data = response,
                Total = total

            };

        }
        public async Task<ListResponse<RiskChartReportResponse>> GetRiskOccurenceCharts(FilterRiskReportRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<RiskChartReportResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var query = FilterRiskReport(request);
            var groupedRiskOcurrence = await GetRiskGroups(query);
            var response = new List<RiskChartReportResponse>
            {
                new RiskChartReportResponse {Title = "Risk Source", Charts = groupedRiskOcurrence.RiskSource},
                new RiskChartReportResponse {Title = "Risk Direction", Charts = groupedRiskOcurrence.RiskDirection},
                new RiskChartReportResponse {Title = "Risk Rating", Charts =groupedRiskOcurrence.RiskRating },
                new RiskChartReportResponse {Title = "Risk Residual Rating", Charts = groupedRiskOcurrence.RiskResidualRating},
                new RiskChartReportResponse {Title = "Risk Control Design", Charts =groupedRiskOcurrence.RiskControlDesign},
                new RiskChartReportResponse {Title = "Risk Control Assessment", Charts = groupedRiskOcurrence.RiskControlAssessment},
                new RiskChartReportResponse {Title = "Risk Control Type", Charts =groupedRiskOcurrence.RiskControlType },
                new RiskChartReportResponse {Title = "Risk Control Quality", Charts = groupedRiskOcurrence.RiskControlQuality},
            };

            var total = response.Count;

            return new ListResponse<RiskChartReportResponse>("Successfully Fetched Risk Occurence Charts")
            {
                Data = response,
                Total = total

            };

        }

        public async Task<ListResponse<KeyRiskIndicatorResponse>> GetKeyRiskIndicator(FilterKeyRiskIndicatorRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<KeyRiskIndicatorResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var filteredKRIReport = await FilterKriReportMetrics(request);
            var response = filteredKRIReport.Select( x => new KeyRiskIndicatorResponse
            {
                MetricMasterId = x.KRIMetricMasterId,
                MetricName = x.ORMKRIMetricMaster.MetricName,
                Threshold = x.RiskAppetiteThreshold
            });
           
            var total = response.Count();

            return new ListResponse<KeyRiskIndicatorResponse>("Successfully Fetched Key risk Indicators")
            {
                Data = response,
                Total = total
            };

        }
        public async Task<ListResponse<KycComplianceResponse>> GetKYCComplianceChart(FilterKriReportMetricsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<KycComplianceResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var filteredKYCReport = await FilterKRIReportMetrics(request);
            var response = filteredKYCReport.GroupBy(x => DateTime.Parse(x.ORMKRIReport.ReportingPeriod).Month).Select(x => new KycComplianceResponse
            {
                Name = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(x.Key),
                count = x.Where(x => x.KRIData != null && x.KRIData != "undefined").Sum(x => Convert.ToInt64(x.KRIData)),
                Value = x.Sum(x => x.AmountInvolved != "" ? Convert.ToDecimal(x.AmountInvolved) : 0)
            });
        
            var total = response.Count();

            return new ListResponse<KycComplianceResponse>("Successfully Fetched KYC Compliance chart")
            {
                Data = response,
                Total = total
            };

        }

        public async Task<ListResponse<NonFunctionalCctvAndPatchesResponse>> GetNonFunctionalCCTVAndPatches(FilterKriReportMetricsRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<NonFunctionalCctvAndPatchesResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var filteredKYCReport = await FilterKRIReportMetrics(request);
            var response = filteredKYCReport.GroupBy(x => DateTime.Parse(x.ORMKRIReport.ReportingPeriod).Month).Select(x => new NonFunctionalCctvAndPatchesResponse
            {
                Name = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(x.Key),
                Value = x.Where(x => x.KRIData != null && x.KRIData != "undefined").Sum(x => Convert.ToInt64(x.KRIData)),
            });


            var total = response.Count();

            return new ListResponse<NonFunctionalCctvAndPatchesResponse>("Successfully Fetched Data")
            {
                Data = response,
                Total = total 
            };
        }
       
        private IQueryable<ORMLossReport> FilterLossReports(BaseDashboardChartsRequest request)
        {
            var query = unitOfWork.ORMLossReport.GetAll().AsQueryable()
                .Where(x => x.ReportStatus.ToLower() == "approved-updatedbyborm");

            if (query.Any())
                query = query.Where(x => x.DateReported.Date.Year == request.Year);

            if (request.Months is not null && request.Months?.Count > 0)
                query = query.Where(x => request.Months.Contains(x.DateReported.Month));

            if (request.BaselEventType1 is not null && request.BaselEventType1 is not "undefined")
                query = query.Where(x => x.BaselEventTypeI!.ToLower().Contains(request.BaselEventType1.ToLower()));
            return query;   
        }

        private IQueryable<ORMLossReport> FilterLossReportRootCause(BaseDashboardChartsRequest request)
        {
            var query = unitOfWork.ORMLossReport.GetAll().AsQueryable()
                .Where(x => x.ReportStatus.ToLower() == "approved-updatedbyborm");

            if (query.Any())
                query = query.Where(x => x.DateReported.Date.Year == request.Year);

            if (request.Months is not null && request.Months?.Count > 0)
                query = query.Where(x => request.Months.Contains(x.DateReported.Month));
            return query;
        }


        private static async Task<List<TrendOfOperationalRiskSourceResponse>>CreateOperationalRiskSourceResponse(IQueryable<ORMRiskReport> query, int year)
        {
            var peoplequery = query.Where(x => x.RiskClassification!.ToLower().Contains("people"));
            var processquery = query.Where(x => x.RiskClassification!.ToLower().Contains("process"));
            var systemsquery = query.Where(x => x.RiskClassification!.ToLower().Contains("systems"));
            var externalEventquery = query.Where(x => x.RiskClassification!.ToLower().Contains("external event"));

            var response = new List<TrendOfOperationalRiskSourceResponse>
            {
                new TrendOfOperationalRiskSourceResponse
                {
                    Title = "People",
                    CurrentYear = await peoplequery.Where(x => x.CreatedDate!.Value.Date.Year == year).CountAsync(),
                    CurrentYearMinus1 = await peoplequery.Where(x => x.CreatedDate!.Value.Date.Year == year-1).CountAsync(),
                    CurrentYearMinus2 = await peoplequery.Where(x => x.CreatedDate!.Value.Date.Year == year-2).CountAsync(),
                },
                  new TrendOfOperationalRiskSourceResponse
                {
                    Title = "Process",
                    CurrentYear = await processquery.Where(x => x.CreatedDate!.Value.Date.Year == year).CountAsync(),
                    CurrentYearMinus1 = await processquery.Where(x => x.CreatedDate!.Value.Date.Year == year-1).CountAsync(),
                    CurrentYearMinus2 = await processquery.Where(x => x.CreatedDate!.Value.Date.Year == year-2).CountAsync(),
                },
                  new TrendOfOperationalRiskSourceResponse
                {
                    Title = "Systems",
                    CurrentYear = await systemsquery.Where(x => x.CreatedDate!.Value.Date.Year == year).CountAsync(),
                    CurrentYearMinus1 = await systemsquery.Where(x => x.CreatedDate!.Value.Date.Year == year-1).CountAsync(),
                    CurrentYearMinus2 = await systemsquery.Where(x => x.CreatedDate!.Value.Date.Year == year-2).CountAsync(),
                },
                  new TrendOfOperationalRiskSourceResponse
                {
                    Title = "External Event",
                    CurrentYear = await externalEventquery.Where(x => x.CreatedDate!.Value.Date.Year == year).CountAsync(),
                    CurrentYearMinus1 = await externalEventquery.Where(x => x.CreatedDate!.Value.Date.Year == year-1).CountAsync(),
                    CurrentYearMinus2 = await externalEventquery.Where(x => x.CreatedDate!.Value.Date.Year == year-2).CountAsync(),
                },

            };
            return response;
        }
        private IQueryable<RegionalInternalFraudResponse> GetRegionGroupedInternalFraudQuery(IQueryable<ORMLossReport> query)
        {
            var queryResult = from lossReport in query
                              join location in unitOfWork.ORMLocation.GetAll().AsQueryable() on lossReport.LocationId equals location.Id
                              group lossReport by location.Region into regionGroup
                              select new RegionalInternalFraudResponse
                              {
                                  Region = regionGroup.Key,
                                  Value = regionGroup.Sum(x => x.NetActualLossAmount)
                              };
            return queryResult;
        }

        private static async Task<List<OperationalRiskLossResponse>> GetGroupedOperationalLossesList(IQueryable<ORMLossReport> query)
        {
            var actualCount = await query.Where(x => x.LossType!.ToLower().Contains("actual")).CountAsync();
            var potentialCount = await query.Where(x => x.LossType!.ToLower().Contains("potential")).CountAsync();
            var nearMissCount = await query.Where(x => x.LossType!.ToLower().Contains("near miss")).CountAsync();



            var lossTypeGroupedList = new List<OperationalRiskLossResponse>
            {
                new OperationalRiskLossResponse
                {
                    Id = 0,
                    Label = "Actual",
                    Value = actualCount
                },
                new OperationalRiskLossResponse
                {
                    Id = 1,
                    Label = "Potential",
                    Value = potentialCount
                },
                new OperationalRiskLossResponse
                {
                    Id = 2,
                    Label = "Near Miss",
                    Value = nearMissCount
                }
            };
            return lossTypeGroupedList;

        }

        private static async Task<List<RootCauseAnalysisResponse>> GetGroupedRootCauseAnalysisQuery(IQueryable<ORMLossReport> query)
        {
            var processBreach =await  query.Where(x=>x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.ProcessBreach)).CountAsync();
            var weakControls = await query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.WeakControls)).CountAsync();
            var policyViolation = await query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.PolicyViolation)).CountAsync();
            var poorconfigurationofsuspenseaccounts = await query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.Poorconfigurationofsuspenseaccounts)).CountAsync();
            var systemFailure =await  query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.SystemFailure)).CountAsync();
            var externalFraud = await  query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.ExternalFraud)).CountAsync();
            var poorCustomerService = await  query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.PoorCustomerService)).CountAsync();
            var businessDecision = await  query.Where(x => x.RootCauseTypeBORM!.ToLower().Contains(RootCauseAnalysisConstants.BusinessDecision)).CountAsync();

            var RootCauseTypeGroupedQuery = new List<RootCauseAnalysisResponse>
            {
                new ()
                {
                    Id = 0,
                    Label = "Process Breach",
                    Value = processBreach
                },
                new ()
                {
                    Id = 1,
                    Label = "Weak Controls",
                    Value = weakControls
                },
                new ()
                {
                    Id = 2,
                    Label = "Policy Violation",
                    Value = policyViolation
                },
               
                new ()
                {
                    Id = 3,
                    Label = "System Failure",
                    Value = systemFailure
                },
                 new ()
                {
                    Id = 4,
                    Label = "External Fraud",
                    Value = externalFraud
                },
                  new ()
                {
                    Id = 5,
                    Label = "Poor Customer Service",
                    Value = poorCustomerService
                },
                      new ()
                {
                    Id = 6,
                    Label = "Business Decision",
                    Value = businessDecision
                },
                   new ()
                {
                    Id = 7,
                    Label = "Poor configuration of suspense accounts",
                    Value = poorconfigurationofsuspenseaccounts
                },

            };
            return RootCauseTypeGroupedQuery;
        }

        private static IQueryable<GrossVsRecoveryVsNetLoss> GetGroupedGrossVsRecoveryVsNetLossQuery(IQueryable<ORMLossReport> query)
        {
            var response = query
            .GroupBy(
                x => 1,
                (key, group) => new GrossVsRecoveryVsNetLoss
                {
                    GrossActualAmount = group.Sum(x => x.GrossActualAmount.GetValueOrDefault()),
                    RecoveredAmount = group.Sum(x => x.RecoveredAmount.GetValueOrDefault()),
                    FurtherRecoveredAmount = group.Sum(x => x.FurtherRecoveredAmount.GetValueOrDefault()),
                    NetActualLossAmount = group.Sum(x => x.NetActualLossAmount.GetValueOrDefault())
                });

            return response;
        }

        private static List<GrossVsRecoveryVsNetLossResponse> CreateGrossVsRecoveryVsNetLossResponse(GrossVsRecoveryVsNetLoss model)
        {
            var response = new List<GrossVsRecoveryVsNetLossResponse>
            {
                new GrossVsRecoveryVsNetLossResponse
                {
                    Id=0,
                    Label = "Gross Loss",
                    Value = model.GrossActualAmount,
                },
                new GrossVsRecoveryVsNetLossResponse
                {
                    Id=1,
                    Label = "Recovery",
                    Value = model.RecoveredAmount,
                },
                new GrossVsRecoveryVsNetLossResponse
                {
                    Id=2,
                    Label = "Further Recovery",
                    Value = model.FurtherRecoveredAmount,
                },
                new GrossVsRecoveryVsNetLossResponse
                {
                    Id=3,
                    Label = "Net Loss",
                    Value = model.NetActualLossAmount,
                }
            };
            return response;
        }

        private IQueryable<ORMRiskReport> FilterRiskReport(FilterRiskReportRequest request)
        {
            var query = unitOfWork.ORMRiskReport.GetAll().AsQueryable()
                .Where(x => x.ReportStatus!.ToLower() == "approved");

            if (query.Any())
                query = query.Where(x => x.CreatedDate!.Value.Date.Year == request.Year);

            if (request.Months?.Count > 0)
                query = query.Where(x => request.Months.Contains(x.CreatedDate!.Value.Date.Month));

            if (request.LocationType is not null && request.LocationType is not "undefined")
                query = query.Where(x => x.LocationType!.ToLower().Contains(request.LocationType.ToLower()));

            if(request.LocationId is not 0 && request.LocationId is not null)
                query = query.Where(x => x.LocationId == request.LocationId);

            return query;
        }
        private async Task<List<ORMKRIReportMetrics>> FilterKriReportMetrics(FilterKeyRiskIndicatorRequest request)
        {
            var query = await unitOfWork.ORMKRIReportMetrics.GetAll().AsQueryable()
            .Include(x => x.ORMKRIMetricMaster).Include(x => x.ORMKRIReport)
            .Where(x => x.ORMKRIReport.ReportingFrequency == "Monthly")
            .Where(x => x.ORMKRIReport.Status == "Approved")
            .ToListAsync();
            var queryAsEnumerable = query.Where(x => DateTime.Parse(x.ORMKRIReport.ReportingPeriod).Year == request.Year);

            if (request.Months?.Count > 0)
                queryAsEnumerable = queryAsEnumerable.Where(x => request.Months.Contains(DateTime.Parse(x.ORMKRIReport.ReportingPeriod).Month));

            if (request.LocationType is not null && request.LocationType is not "undefined")
                queryAsEnumerable = queryAsEnumerable.Where(x => x.ORMKRIReport.LocationType!.ToLower().Contains(request.LocationType.ToLower()));

            if (request.LocationId is not 0 && request.LocationId is not null)
                queryAsEnumerable = queryAsEnumerable.Where(x => x.ORMKRIReport.LocationId == request.LocationId);

            return queryAsEnumerable.ToList();
        }
        private async Task<List<ORMKRIReportMetrics>> FilterKRIReportMetrics(FilterKriReportMetricsRequest request)
        {
            var query = await unitOfWork.ORMKRIReportMetrics.GetAll().AsQueryable()
            .Include(x => x.ORMKRIMetricMaster).Include(x => x.ORMKRIReport)
            .Where(x => x.ORMKRIReport.ReportingFrequency == "Monthly")
            .Where(x => x.ORMKRIReport.Status == "Approved")
            .OrderBy(x => x.ORMKRIReport.ReportingPeriod)
            .ToListAsync();
            var queryAsEnumerable = query.Where(x => DateTime.Parse(x.ORMKRIReport.ReportingPeriod).Year == request.Year);

            if (request.Months?.Count > 0)
                queryAsEnumerable = queryAsEnumerable.Where(x => request.Months.Contains(DateTime.Parse(x.ORMKRIReport.ReportingPeriod).Month));
            if (request.MetricMasterIds?.Count > 0)
                queryAsEnumerable = queryAsEnumerable.Where(x => request.MetricMasterIds.Contains(x.KRIMetricMasterId));

            return queryAsEnumerable.ToList();
        }
        private static async Task<GroupedRiskOccurenceResponse>GetRiskGroups(IQueryable<ORMRiskReport> query)
        {
            var riskSourcePeopleCount = await query.Where(x => x.RiskClassification!.ToLower().Contains("people")).CountAsync();
            var riskSourceProcessCount = await query.Where(x => x.RiskClassification!.ToLower().Contains("process")).CountAsync();
            var riskSourceSystemCount = await query.Where(x => x.RiskClassification!.ToLower().Contains("systems")).CountAsync();
            var riskSourceExternalEventCount = await query.Where(x => x.RiskClassification!.ToLower().Contains("external event")).CountAsync();


            var riskDirectionIncreasingCount = await query.Where(x => x.RiskDirection!.ToLower().Contains("increasing")).CountAsync();
            var riskDirectionStaticCount = await query.Where(x => x.RiskDirection!.ToLower().Contains("static")).CountAsync();
            var riskDirectionDecreasingCount = await query.Where(x => x.RiskDirection!.ToLower().Contains("decreasing")).CountAsync();

            var riskRatingLowCount = await query.Where(x => x.RiskRating!.ToLower().Contains("low")).CountAsync();
            var riskRatingMediumCount = await query.Where(x => x.RiskRating!.ToLower().Contains("medium")).CountAsync();
            var riskRatingHighCount =  await query.Where(x => x.RiskRating!.ToLower().Contains("high")).CountAsync();

            var residualRiskRatingLowCount = await query.Where(x => x.RiskResidualRating!.ToLower().Contains("low")).CountAsync();
            var residualRiskRatingMediumCount = await query.Where(x => x.RiskResidualRating!.ToLower().Contains("medium")).CountAsync();
            var residualRiskRatingHighCount = await query.Where(x => x.RiskResidualRating!.ToLower().Contains("high")).CountAsync();

            var riskControlDesignManualCount = await query.Where(x => x.RiskControlDesign!.ToLower().Contains("manual")).CountAsync();
            var riskControlDesignAutomatedCount = await query.Where(x => x.RiskControlDesign!.ToLower().Equals("automated")).CountAsync();
            var riskControlDesignSemiAutomatedCount = await query.Where(x => x.RiskControlDesign!.ToLower().Contains("semi-automated")).CountAsync();

            var riskAssessmentAdequateCount = await query.Where(x => x.RiskControlAssessment!.ToLower().Equals("adequate")).CountAsync();
            var riskAssessmentInadequateCount = await query.Where(x => x.RiskControlAssessment!.ToLower().Contains("inadequate")).CountAsync();
            var riskAssessmentNeedsImprovementCount = await query.Where(x => x.RiskControlAssessment!.ToLower().Contains("needs improvement")).CountAsync();

            var riskControlTypePreventiveCount = await query.Where(x => x.RiskControlType!.ToLower().Contains("preventive")).CountAsync();
            var riskControlTypeDetectiveCount = await query.Where(x => x.RiskControlType!.ToLower().Contains("detective")).CountAsync();
            var riskControTypeCorrectiveCount = await query.Where(x => x.RiskControlType!.ToLower().Contains("corrective")).CountAsync();

            var riskControlQualityLowCount = await query.Where(x => x.RiskControlQuality!.ToLower().Contains("low")).CountAsync();
            var riskControlQualityMediumCount = await query.Where(x => x.RiskControlQuality!.ToLower().Contains("medium")).CountAsync();
            var riskControlQualityHighCount = await query.Where(x => x.RiskControlQuality!.ToLower().Contains("high")).CountAsync();




            var riskSourceList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                   Id = 0,
                   Label = "People",
                   Value = riskSourcePeopleCount
                },
                new BaseChartsResponse
                {
                   Id = 1,
                   Label = "Process",
                   Value = riskSourceProcessCount
                },
                new BaseChartsResponse
                {
                   Id = 2,
                   Label = "Systems",
                   Value = riskSourceSystemCount
                },
                new BaseChartsResponse
                {
                   Id = 3,
                   Label = "External Event",
                   Value = riskSourceExternalEventCount
                }
            };
            var riskDirectionList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                   Id = 0,
                   Label = "Increasing",
                   Value = riskDirectionIncreasingCount
                },
                new BaseChartsResponse
                {
                   Id = 1,
                   Label = "Static",
                   Value = riskDirectionStaticCount
                },
                new BaseChartsResponse
                {
                   Id = 2,
                   Label = "Decreasing",
                   Value = riskDirectionDecreasingCount
                }
            };
            var riskRatingList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                    Id = 0,
                    Label = "Low",
                    Value =  riskRatingLowCount
                },
                new BaseChartsResponse
                {
                    Id = 1,
                    Label = "Medium",
                    Value =  riskRatingMediumCount
                },
                new BaseChartsResponse
                {
                    Id = 2,
                    Label = "High",
                    Value =  riskRatingHighCount
                },

            };
            var riskResidualRatingList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                    Id = 0,
                    Label = "Low",
                    Value = residualRiskRatingLowCount
                },
                new BaseChartsResponse
                {
                    Id = 1,
                    Label = "Medium",
                    Value = residualRiskRatingMediumCount
                },
                 new BaseChartsResponse
                {
                    Id = 2,
                    Label = "High",
                    Value = residualRiskRatingHighCount
                }
            };
            var riskControlDesignList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                    Id = 0,
                    Label = "Manual",
                    Value = riskControlDesignManualCount
                },
                new BaseChartsResponse
                {
                    Id = 1,
                    Label = "Automated",
                    Value = riskControlDesignAutomatedCount
                },
                 new BaseChartsResponse
                {
                    Id = 2,
                    Label = "Semi Automated",
                    Value = riskControlDesignSemiAutomatedCount
                }
            };
            var riskControlAssessmentList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                    Id = 0,
                    Label = "Adequate",
                    Value = riskAssessmentAdequateCount
                },
                new BaseChartsResponse
                {
                    Id = 1,
                    Label = "Inadequate",
                    Value = riskAssessmentInadequateCount
                },
                 new BaseChartsResponse
                {
                    Id = 2,
                    Label = "Needs Improvement",
                    Value = riskAssessmentNeedsImprovementCount
                }
            };
            var riskControlTypeList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                    Id = 0,
                    Label = "Preventive",
                    Value = riskControlTypePreventiveCount
                },
                new BaseChartsResponse
                {
                    Id = 1,
                    Label = "Detective",
                    Value = riskControlTypeDetectiveCount
                },
                 new BaseChartsResponse
                {
                    Id = 2,
                    Label = "Corrective",
                    Value = riskControTypeCorrectiveCount
                }
            };
            var riskControlQualityList = new List<BaseChartsResponse>
            {
                new BaseChartsResponse
                {
                    Id = 0,
                    Label = "Low",
                    Value = riskControlQualityLowCount
                },
                new BaseChartsResponse
                {
                    Id = 1,
                    Label = "Medium",
                    Value = riskControlQualityMediumCount
                },
                 new BaseChartsResponse
                {
                    Id = 2,
                    Label = "High",
                    Value = riskControlQualityHighCount
                }
            };

            var response = new GroupedRiskOccurenceResponse
            {
                RiskSource = riskSourceList,
                RiskDirection = riskDirectionList,
                RiskRating = riskRatingList,
                RiskResidualRating = riskResidualRatingList,
                RiskControlDesign = riskControlDesignList,
                RiskControlAssessment = riskControlAssessmentList,
                RiskControlType = riskControlTypeList,
                RiskControlQuality = riskControlQualityList
            };
            return response;
        }
    }

}

        
