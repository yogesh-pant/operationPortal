﻿using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using ORM.Domain.Common;

namespace ORM.Infrastructure.Services
{
    public class KriService : IKriService
    {
        private readonly ILogger<KriService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;

        public KriService(ILogger<KriService> logger, ISessionService sessionService, IUnitOfWork unitOfWork)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
        }
        /// <summary>
        /// This function is used to get the list of users kri grid export
        /// </summary>   "export kri data "-------- used
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<KriPreviewResponse>> GetKriGridAsync(KriGridRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<KriPreviewResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<KriPreviewResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var kriListQuery = unitOfWork.ORMKRIReportMetrics
                       .GetAll().AsQueryable()
                       .Select(kri => new KriPreviewResponse
                       {
                           MetricId = kri.Id,
                           KRIReportId = kri.ORMKRIReport.Id,
                           reportRefNo = kri.ORMKRIReport.RefNum,
                           ReportingPeriod = kri.ORMKRIReport.ReportingPeriod,
                           dateReported = kri.ORMKRIReport.DateReported,
                           locationType = kri.ORMKRIReport.LocationType,
                           LocationId = kri.ORMKRIReport.LocationId,
                           reportStatus = kri.ORMKRIReport.Status,
                           SubmittedBy = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport.CreatedById)!.UserName,
                           ReviewedBy = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport.ReviewedById)!.UserName,
                           comments = kri.ORMKRIReport.ReviewerComments,
                           KRIMetricMasterId = kri.ORMKRIMetricMaster.Id,
                           KRIMetricTitle = kri.ORMKRIMetricMaster.MetricName,
                           MitigationPlan = kri.MitigationPlan,
                           Currency = kri.Currency,
                           AmountInvolved = kri.AmountInvolved,
                           RiskAppetiteThreshold = kri.RiskAppetiteThreshold,
                           Description = kri.Description,
                           KRIData = kri.KRIData,
                           DateOccurance = kri.DateOccurance,
                           Region = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport!.LocationId)!.Region,
                           LocationName = (kri.ORMKRIReport!.LocationType == "B") ? unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport!.LocationId)!.Branch : unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport.LocationId)!.Department,
                           ValidatorILOUserName = kri.ORMKRIReport.ORMUser.UserName,
                           Frequency= kri.ORMKRIReport.ReportingFrequency,
                           ReviewedDate = kri!.ORMKRIReport.ReviewedDate,
                           ModifiedDate = kri!.ORMKRIReport.ModifiedDate,

                       });

            GetKriGridApplyFilters(ref kriListQuery, input);


            var totalCount = kriListQuery.Count();

            if (totalCount == 0)
            {
                return new ListResponse<KriPreviewResponse>("No record found for given input")
                {
                    Data = { },
                    Total = totalCount
                };
            }

            if (kriListQuery.Any())
                kriListQuery = kriListQuery.Paginate(input);

            var response = await kriListQuery!.ToListAsync();

            logger.LogInformation("Successfully Retrieved KRI grid data");

            return new ListResponse<KriPreviewResponse>("Successfully Retrieved KRI grid data")
            {
                Data = response,
                Total = totalCount
            };

        }

        private static void GetKriGridApplyFilters(ref IQueryable<KriPreviewResponse> kriListQuery, KriGridRequest input)
        {
            if (input.MinDate is not null || input.MaxDate is not null)
                kriListQuery = kriListQuery.Where(p =>
                (input.MinDate == null || p.dateReported >= InputTimeFormat.ConvertTo00AMFormat(input.MinDate.Value)) &&
                (input.MaxDate == null || p.dateReported <= InputTimeFormat.ConvertTo12PMFormat(input.MaxDate.Value))
                ).OrderByDescending(x => x.dateReported);

            if (SearchFilters.IsValidStringFilter(input.RefNo))
                kriListQuery = kriListQuery.Where(p => p.reportRefNo == input.RefNo);

            if (SearchFilters.IsValidStringFilter(input.Branch))
                kriListQuery = kriListQuery.Where(p => p.LocationName!.ToLower().Contains(input.Branch!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Department))
                kriListQuery = kriListQuery.Where(p => p.LocationName!.ToLower().Contains(input.Department!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Status))
                kriListQuery = kriListQuery.Where(p => p.reportStatus == input.Status);

            if (SearchFilters.IsValidStringFilter(input.LocationType))
                kriListQuery = kriListQuery.Where(p => p.locationType == input.LocationType);

            if (SearchFilters.IsValidNumericFilter(input.LocationId))
                kriListQuery = kriListQuery.Where(p => p.LocationId == input.LocationId);

        }
            /// <summary>
            /// This function is used to get the list of users
            /// </summary>"to get the status count for the kri department grid"--used
            /// <param name="filterUserRequest"></param>
            /// <returns></returns>
            public async Task<ListResponse<KriDataGridResponse>> GetKriReportGridAsync(KriGridRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<KriDataGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            if (input == null)
            {
                return new ListResponse<KriDataGridResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var kriListQuery = unitOfWork.ORMKRIReport.GetAll().AsQueryable()
               .Select(kri => new KriGridResponse
               {
                   Id = kri!.Id,
                   ReportRefNo = kri!.RefNum,
                   ValidatorILOUserId = kri!.ValidatorILOUserId,
                   ValidatorILOUserName = kri!.ORMUser.UserName,
                   LocationId = kri!.LocationId,
                   LocationType = kri!.LocationType,
                   ReportingPeriod= kri!.ReportingPeriod,
                   Frequency= kri!.ReportingFrequency,
                   DateReported = kri!.DateReported,
                   Branch      = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri!.LocationId)!.Branch,
                   Department  = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri!.LocationId)!.Department,
                   Region      = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri!.LocationId)!.Region,
                   SubmittedBy = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri!.CreatedById)!.UserName,
                   Status = kri!.Status,
                   ReviewedDate = kri!.ReviewedDate,
                   ModifiedDate = kri!.ModifiedDate,
               });

            GetKriReportApplyFilters(ref kriListQuery, input);

            var StatusCounts = await kriListQuery
                .GroupBy(report => report.Status)
                .Select(group => new
                {
                    Status = group.Key,
                    Count = group.Count()
                })
                .ToDictionaryAsync(x => x.Status!, x => x.Count);

            var recordCount = new RecordCount
            {
                SubmittedCount = StatusCounts.GetValueOrDefault("Submitted", 0),
                DraftCount = StatusCounts.GetValueOrDefault("Draft", 0),
                RejectCount = StatusCounts.GetValueOrDefault("Rejected", 0),
                ApprovedCount = StatusCounts.GetValueOrDefault("Approved", 0),
            };

            if (SearchFilters.IsValidStringFilter(input.Status))
            {
                kriListQuery = kriListQuery.Where(p => p.Status!.ToLower().Contains(input.Status!.ToLower()));
            }

            kriListQuery = kriListQuery.Paginate(input);
            var totalCount = kriListQuery.Count();

            if (totalCount == 0)
            {
                return new ListResponse<KriDataGridResponse>("No record found for given input")
                {
                    Data = { },
                    Total = totalCount
                };
            }
            var responseData = await kriListQuery.ToListAsync();
                var response = new KriDataGridResponse(responseData, recordCount);

                logger.LogInformation("Successfully Retrieved KRI grid data");

                return new ListResponse<KriDataGridResponse>("Successfully Retrieved KRI grid data")
                {
                    Data = new List<KriDataGridResponse> { response },
                    Total = totalCount
                };
        }

        private static void GetKriReportApplyFilters(ref IQueryable<KriGridResponse> kriListQuery, KriGridRequest input)
        {
            if (input.MinDate is not null || input.MaxDate is not null)
                kriListQuery = kriListQuery.Where(p =>
                (input.MinDate == null || p.DateReported >= InputTimeFormat.ConvertTo00AMFormat(input.MinDate.Value)) &&
                (input.MaxDate == null || p.DateReported <= InputTimeFormat.ConvertTo12PMFormat(input.MaxDate.Value))
                ).OrderByDescending(x => x.DateReported);

            if (SearchFilters.IsValidNumericFilter(input.LocationId))
                kriListQuery = kriListQuery.Where(p => p.LocationId == input.LocationId);

            if (SearchFilters.IsValidStringFilter(input.RefNo))
                kriListQuery = kriListQuery.Where(p => p.ReportRefNo!.ToLower().Contains(input.RefNo!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Branch))
                kriListQuery = kriListQuery.Where(p => p.Branch!.ToLower().Contains(input.Branch!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Department))
                kriListQuery = kriListQuery.Where(p => p.Department!.ToLower().Contains(input.Department!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Region))
                kriListQuery = kriListQuery.Where(p => p.Region!.ToLower().Contains(input.Region!.ToLower()));

        }
        // get data to create new KRI -- used
        public async Task<ListResponse<CreateKriResponse>> GetNewKriAsync(GetNewKriRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<CreateKriResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            
            if (input == null)
            {
                return new ListResponse<CreateKriResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var kriListQuery = unitOfWork.ORMKRIMetricMaster
               .GetAll().AsQueryable()
               .Select(kri => new CreateKriResponse
               {
                   Id = kri.Id,
                   KRIMetricId = kri.KRIMetricId,
                   LocationId = kri.LocationId,
                   LocationType = kri.LocationType,
                   MetricName = kri.MetricName,
                   Frequency = kri.Frequency,
                   AppetiteUpperBound = kri.AppetiteUpperBound,
                   AppetiteLowerBound = kri.AppetiteLowerBound,
                   AppetiteType = kri.AppetiteType,
                   ToleranceLowerBound = kri.ToleranceLowerBound,
                   ToleranceUpperBound = kri.ToleranceUpperBound,
                   ToleranceType = kri.ToleranceType,
                   EscalationLowerBound = kri.EscalationLowerBound,
                   EscalationUpperBound = kri.EscalationUpperBound,
                   EscalationType = kri.EscalationType,
                   IsActive = kri.IsActive,
               });

            //in master metric table : all the  Branches have same kri metric data
            // and Department will have different metrics based on location ID

            if (SearchFilters.IsValidStringFilter(input.locationType))
                kriListQuery = kriListQuery.Where(p => p.LocationType == input.locationType);

            if (SearchFilters.IsValidNumericFilter(input.locationId) && input.locationType == "D" ) { 
                kriListQuery = kriListQuery.Where(p => p.LocationId == input.locationId);
            }
            if (SearchFilters.IsValidStringFilter(input.frequecy))
                kriListQuery = kriListQuery.Where(p => p.Frequency == input.frequecy);

            if (input.active is not null)
                kriListQuery = kriListQuery.Where(p => p.IsActive == input.active);


            var totalCount = kriListQuery.Count();

            if (totalCount == 0)
            {
                return new ListResponse<CreateKriResponse>("No record found for given input")
                {
                    Data = {},
                    Total = totalCount
                };
            }

            var response = await kriListQuery.ToListAsync();

            logger.LogInformation("Successfully Retrieved  KRI master data");

            return new ListResponse<CreateKriResponse>("Successfully Retrieved KRI master data")
            {
                Data = response,
                Total = totalCount
            };

        }

        // handle drop down values ---- used
        public async Task<ListResponse<NewKriReportResponse>> AddKriInfo(AddKriRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<NewKriReportResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            if (input == null)
            {
                return new ListResponse<NewKriReportResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.LocationId == 0 || input.ValidatorILOUserId == 0 || input.CreatedById == 0 )
            {
                return new ListResponse<NewKriReportResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            long reportId = 0;
            if (input.Status != "edit" && input.RefNum == 0)
            {
                string? refNum = await  unitOfWork.GetKRIReportRecordCount();
                var newKriReport = new ORMKRIReport
                {
                    RefNum = refNum!,
                    ReportingPeriod = input.ReportingPeriod!,
                    ReportingFrequency = input.ReportingFrequency,
                    ValidatorILOUserId = input.ValidatorILOUserId,
                    LocationId = input.LocationId,
                    LocationType = input.LocationType!,
                    DateReported = DateTime.Now,
                    Status = input.Status!,
                    CreatedById = input.CreatedById,
                    CreatedDate = DateTime.Now,

                };
                reportId = await unitOfWork.SaveAndGetIdKriReportAsync(newKriReport);
            }
            else
            {
                reportId = input.RefNum;
            }
            List<ORMKRIReportMetrics> newKriMetricsList = new List<ORMKRIReportMetrics>();
            foreach (var request in input.kris!)
            {
                var newKriMetric = new ORMKRIReportMetrics
                {
                    DateOccurance = input.DateOfOccurance,
                    KRIData = "0",
                    Description = "",
                    AmountInvolved = "0",
                    RiskAppetiteThreshold = "",
                    Currency = "",
                    MitigationPlan = "",
                    KRIMetricMasterId = request,
                    KRIReportId = reportId,
                };

                newKriMetricsList.Add(newKriMetric);
            }

            // Persist all new metrics to the database in a single call
            List<long> metricIds = await unitOfWork.SaveAllKriReportMetricsAsync(newKriMetricsList);

            NewKriReportResponse result = new NewKriReportResponse
            {
                NewRefNum = unitOfWork.ORMKRIReport
                            .GetAll().AsQueryable()
                            .Where(rep => rep.Id == reportId)
                            .Select(rep => rep.RefNum)
                            .FirstOrDefault()!,
                reportId = reportId,
                metricIds = metricIds
            };
            List<NewKriReportResponse> Response = new List<NewKriReportResponse>
           {
               result
           };


            return new ListResponse<NewKriReportResponse>("Kri report Created!", ResponseCodes.Success)
            {
                Data = Response
            };

        }

        // save kri deatils after selecting new metric from Dropdown  ---used
        public async Task<ListResponse<ReturnId>> AddKrimetric(AddKriReport input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<ReturnId>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.metricId == 0  || input.masterId == 0  || input.reportId == 0)
            {
                return new ListResponse<ReturnId>("KRI report not found for metricId  : " + input.metricId + "," + "report id : " + input.reportId + "," + "master id : " + input.masterId, ResponseCodes.DataNotFound);
            }

            var Krimetrics = unitOfWork.ORMKRIReportMetrics.GetAll().AsQueryable()
                .Where(map => map.Id == input.metricId)
                .ToList();
            if (Krimetrics.Any())
            {
                foreach (var Krimetric in Krimetrics)
                {
                    Krimetric.DateOccurance = input.DateOccurance!;
                    Krimetric.KRIData = input.NumberPercentage;
                    Krimetric.Description = input.Description;
                    Krimetric.AmountInvolved = input.AmountInvolved;
                    Krimetric.Currency = input.Currency;
                    Krimetric.MitigationPlan = input.MitigationPlan;
                    Krimetric.KRIMetricMasterId = input.masterId;
                    Krimetric.KRIReportId = input.reportId;
                    Krimetric.RiskAppetiteThreshold = await (CalculateRiskAppetiteThreshold(input.masterId, input.NumberPercentage!));

                }

                var count = unitOfWork.Save();
                logger.LogInformation("Successfully saved  KRI report metric master data for id {metricId} with response {count}", input.metricId,count);
                ReturnId result = new ()
                {
                    id = input.metricId
                };
                List<ReturnId> Response = new()
                {
                   result
               };


                return new ListResponse<ReturnId>("Kri Metric Saved!", ResponseCodes.Success)
                {
                    Data = Response
                };
            }
            else
            {
                return new ListResponse<ReturnId>("Kri report not found for id  : " + input.metricId, ResponseCodes.DataNotFound);

            }

        }
        private async Task<string?> CalculateRiskAppetiteThreshold(long MetricMasterId, string MetricInputData)
        {
           var metricMasterQuery = unitOfWork.ORMKRIMetricMaster
            .GetAll().AsQueryable()
            .Where(metricMaster => metricMaster.Id == MetricMasterId)  // Filter based on the primary key (ID)
           .Select(metricMaster => new CreateKriResponse
           {
               Id = metricMaster.Id,
               KRIMetricId = metricMaster.KRIMetricId,
               LocationId = metricMaster.LocationId,
               LocationType = metricMaster.LocationType,
               MetricName = metricMaster.MetricName,
               Frequency = metricMaster.Frequency,
               AppetiteUpperBound = metricMaster.AppetiteUpperBound,
               AppetiteLowerBound = metricMaster.AppetiteLowerBound,
               AppetiteType = metricMaster.AppetiteType,
               ToleranceLowerBound = metricMaster.ToleranceLowerBound,
               ToleranceUpperBound = metricMaster.ToleranceUpperBound,
               ToleranceType = metricMaster.ToleranceType,
               EscalationLowerBound = metricMaster.EscalationLowerBound,
               EscalationUpperBound = metricMaster.EscalationUpperBound,
               EscalationType = metricMaster.EscalationType,
               IsActive = metricMaster.IsActive,
           });

            var response = await metricMasterQuery.AsQueryable().FirstOrDefaultAsync(); // Use SingleOrDefaultAsync for a single record

            
            if (response == null)
            {
                logger.LogInformation($"Metric Master with the specified ID not found {MetricMasterId}");
                return "Unknown";
            }
            
            string calculatedThreshold = "Unknown";

            if (!string.IsNullOrEmpty(response.AppetiteType) && response.AppetiteType.EndsWith("A"))
            {
                calculatedThreshold = CalculatedThresholdAscending(response, MetricInputData);
            }

            if (!string.IsNullOrEmpty(response.AppetiteType) && response.AppetiteType.EndsWith("D"))
            {
                calculatedThreshold = CalculatedThresholdDescending(response, MetricInputData);
            }
            if (calculatedThreshold == "Unknown")
            {
                // Handle the case when MetricInputData is not within any of the bounds
                logger.LogInformation($"calculated Threshold would not be determined for {Convert.ToString(MetricMasterId)} at KRI input of {Convert.ToString(MetricInputData)}");
            }            

            return calculatedThreshold;
        }
        private static string CalculatedThresholdAscending(CreateKriResponse response, string MetricInputData)
        {
            string calculatedThreshold = "Unknown";

            if (decimal.Parse(MetricInputData) > decimal.Parse(response.ToleranceLowerBound!) && decimal.Parse(MetricInputData) <= decimal.Parse(response.ToleranceUpperBound!))
            {
                calculatedThreshold = "Tolerance";
            }
            if (decimal.Parse(MetricInputData) >= decimal.Parse(response.AppetiteLowerBound!) && decimal.Parse(MetricInputData) <= decimal.Parse(response.AppetiteUpperBound!))
            {
                calculatedThreshold = "Appetite";
            }
            if (decimal.Parse(MetricInputData) > decimal.Parse(response.EscalationLowerBound!))
            {
                calculatedThreshold = "Escalation";
            }
            return calculatedThreshold;
        }
        private static string CalculatedThresholdDescending(CreateKriResponse response, string MetricInputData)
        {
            string calculatedThreshold = "Unknown";

            if (decimal.Parse(MetricInputData) <= decimal.Parse(response.AppetiteLowerBound!) && decimal.Parse(MetricInputData) >= decimal.Parse(response.AppetiteUpperBound!))
            {
                calculatedThreshold = "Appetite";
            }
            if (decimal.Parse(MetricInputData) < decimal.Parse(response.ToleranceLowerBound!) && decimal.Parse(MetricInputData) >= decimal.Parse(response.ToleranceUpperBound!))
            {
                calculatedThreshold = "Tolerance";
            }
            if (decimal.Parse(MetricInputData) < decimal.Parse(response.EscalationLowerBound!))
            {
                calculatedThreshold = "Escalation";
            }
            return calculatedThreshold;
        }

        public async Task<ListResponse<KriPreviewResponse>> GetPreviewKriAsync(GetPreviewKriMultipleRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<KriPreviewResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request == null )
            {
                return new ListResponse<KriPreviewResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (request!.ids!.FirstOrDefault() == 0 && request!.rids!.FirstOrDefault() == 0)
            {
                return new ListResponse<KriPreviewResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            
            long requestedMetricId = 0;
            long requestedKriReportId = 0;
            if (request.ids is not null && request.ids.Length > 0)
            {
                requestedMetricId = request!.ids!.FirstOrDefault(); // Retrieve the first metric ID from the array
                requestedKriReportId = unitOfWork.ORMKRIReportMetrics
                    .GetAll().AsQueryable()
                    .Where(kri => kri.Id == requestedMetricId)
                    .Select(kri => kri.ORMKRIReport.Id)
                    .FirstOrDefault();
            }
            else
            {
                if (request.rids is not null && request.rids.Length > 0)
                {
                    requestedKriReportId = request!.rids!.AsQueryable().FirstOrDefault();
                }
                else
                {
                    return new ListResponse<KriPreviewResponse>("Invalid input", ResponseCodes.DataNotFound);

                }
            }
            var kriReports = unitOfWork.ORMKRIReportMetrics
                .GetAll().AsQueryable()
                .Where(kri => kri.ORMKRIReport.Id == requestedKriReportId) // Filter by KRIReportId
                .Select(kri => new KriPreviewResponse
                {
                    MetricId = kri.Id,
                    KRIReportId = kri.ORMKRIReport.Id,
                    reportRefNo = kri.ORMKRIReport.RefNum,
                    ValidatorILOUserId = kri.ORMKRIReport.ValidatorILOUserId,
                    ValidatorILOUserName = kri.ORMKRIReport.ORMUser.UserName,
                    ReportingPeriod = kri.ORMKRIReport.ReportingPeriod,
                    dateReported = kri.ORMKRIReport.DateReported,
                    locationType = kri.ORMKRIReport.LocationType,
                    LocationId = kri.ORMKRIReport.LocationId,
                    reportStatus = kri.ORMKRIReport.Status,
                    comments = kri.ORMKRIReport.ReviewerComments,
                    KRIMetricMasterId = kri.ORMKRIMetricMaster.Id,
                    KRIMetricTitle = kri.ORMKRIMetricMaster.MetricName,
                    MitigationPlan = kri.MitigationPlan,
                    Currency = kri.Currency,
                    AmountInvolved = kri.AmountInvolved,
                    RiskAppetiteThreshold = kri.RiskAppetiteThreshold,
                    Description = kri.Description,
                    KRIData = kri.KRIData,
                    DateOccurance = kri.DateOccurance,
                });

            var response = await kriReports.ToListAsync<KriPreviewResponse>();

            if (response.Any())
            {
                logger.LogInformation("Successfully Retrieved  KRI master data");

                return new ListResponse<KriPreviewResponse>("Successfully Retrieved KRI master data")
                {
                    Data = response
                };
            }
            else
            {
                return new ListResponse<KriPreviewResponse>("Kri Master data not found", ResponseCodes.DataNotFound);
            }

        }

        // to get teh data into approve screen based on id----- used but after approve/reject popup design, page will not be needed...
        public async Task<ListResponse<KriPreviewResponse>> GetDetailKriReportAsync(GetPreviewKriRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<KriPreviewResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request == null)
            {
                return new ListResponse<KriPreviewResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var kriReports = unitOfWork.ORMKRIReportMetrics
               .GetAll().AsQueryable()
               .Select(kri => new KriPreviewResponse
               {
                   MetricId = kri.Id,
                   ReportingPeriod = kri.ORMKRIReport.ReportingPeriod,
                   Frequency = kri.ORMKRIReport.ReportingFrequency,
                   KRIReportId = kri.ORMKRIReport.Id,
                   reportRefNo = kri.ORMKRIReport.RefNum,
                   ValidatorILOUserId = kri.ORMKRIReport.ValidatorILOUserId,
                   ValidatorILOUserName = kri.ORMKRIReport.ORMUser.UserName,
                   comments = kri.ORMKRIReport.ReviewerComments,
                   reportStatus = kri.ORMKRIReport.Status,
                   dateReported = kri.ORMKRIReport.DateReported,
                   locationType = kri.ORMKRIReport.LocationType,
                   LocationId = kri.ORMKRIReport.LocationId,
                   LocationName = (kri.ORMKRIReport!.LocationType == "B") ? unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport!.LocationId)!.Branch : unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport.LocationId)!.Department,
                   Region = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == kri.ORMKRIReport.LocationId)!.Region ?? "",
                   KRIMetricMasterId = kri.ORMKRIMetricMaster.Id,
                   KRIMetricTitle = kri.ORMKRIMetricMaster.MetricName,
                   MitigationPlan = kri.MitigationPlan,
                   Currency = kri.Currency,
                   AmountInvolved = kri.AmountInvolved,
                   RiskAppetiteThreshold = kri.RiskAppetiteThreshold,
                   Description = kri.Description,
                   KRIData = kri.KRIData,
                   DateOccurance = kri.DateOccurance,
                   ReviewedDate = kri!.ORMKRIReport.ReviewedDate,

               });


            if (request.ids is not null)
                kriReports = kriReports.Where(p => request.ids.Contains(p.KRIReportId));

            var response = await kriReports.ToListAsync<KriPreviewResponse>();

            logger.LogInformation("Successfully Retrieved  KRI Report data");

            return new ListResponse<KriPreviewResponse>("Successfully Retrieved KRI Report data")
            {
                Data = response
            };

        }

        //to update the submit status from preview screen----used
        public async Task<ListResponse<string>> UpdatePreviewKriAsync(UpdatePreviewKriRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<string>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<string>("Kri report data not found for id : " + input.id, ResponseCodes.DataNotFound);
            }

            var kriReport = await (from au in unitOfWork.ORMKRIReport.GetAll().AsQueryable()
                                   where au.Id == input.id
                                   select au).FirstOrDefaultAsync<ORMKRIReport>();
            if (kriReport is not null)
            {
                kriReport.Status = "Submitted";


                var count = unitOfWork.Save();

                logger.LogInformation("Successfully Submitted KRI report  id {id} with response {count}", input.id, count);

                return new ListResponse<string>("Kri report Submitted!", ResponseCodes.Success)
                {
                    Data = { }
                };
            }
            else
            {
                logger.LogError("Kri report data not found for id {id}", input.id);
                return new ListResponse<string>("Kri report data not found for id : " + input.id, ResponseCodes.DataNotFound);


            }

        }

        // to update approve status
        public async Task<ListResponse<string>> updateKriApproval(FinalKriReport input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            DateTime currentDate = DateTime.Now;

            if (input == null)
            {
                return new ListResponse<string>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<string>("Kri report data not found for id : " + input.id, ResponseCodes.DataNotFound);
            }

            var kriReport = await (from au in unitOfWork.ORMKRIReport.GetAll().AsQueryable()
                                   where au.Id == input.id
                                   select au).FirstOrDefaultAsync<ORMKRIReport>();
            if (kriReport is not null)
            {
                kriReport.Status = input.status!;
                kriReport.ReviewedById = input.approvedByid;
                kriReport.ReviewerComments = input.comments;
                kriReport.ReviewedDate = currentDate;

                var count = unitOfWork.Save();
                logger.LogInformation("Successfully Submitted KRI report  id {id} with response {count}", input.id, count);
                return new ListResponse<string>("Kri report Approved/Rejected!", ResponseCodes.Success)
                {
                    Data = { }
                };
            }
            else
            {
                logger.LogError("Kri report data not found for id {id}", input.id);
                return new ListResponse<string>("Kri report data not found for id : " + input.id, ResponseCodes.DataNotFound);

            }


        }

        // after creating new kri, it fetches the data to show in the card------used
        public async Task<ListResponse<KriPreviewResponse>> GetDetailKriMetricAsync(UpdatePreviewKriRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<KriPreviewResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request == null)
            {
                return new ListResponse<KriPreviewResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var kriReports = unitOfWork.ORMKRIReportMetrics
               .GetAll().AsQueryable()
               .Select(kri => new KriPreviewResponse
               {
                   MetricId = kri.Id,
                   KRIReportId = kri.ORMKRIReport.Id,
                   reportRefNo = kri.ORMKRIReport.RefNum,
                   ValidatorILOUserId = kri.ORMKRIReport.ValidatorILOUserId,
                   ValidatorILOUserName = kri.ORMKRIReport.ORMUser.UserName,
                   comments = kri.ORMKRIReport.ReviewerComments,
                   dateReported = kri.ORMKRIReport.DateReported,
                   locationType = kri.ORMKRIReport.LocationType,
                   LocationId = kri.ORMKRIReport.LocationId,
                   KRIMetricMasterId = kri.ORMKRIMetricMaster.Id,
                   KRIMetricTitle = kri.ORMKRIMetricMaster.MetricName,
                   KRIMetricIsActive = kri.ORMKRIMetricMaster.IsActive,
                   Frequency = kri.ORMKRIReport.ReportingFrequency,
                   ReportingPeriod = kri.ORMKRIReport.ReportingPeriod,
                   AppetiteLowerBound = kri.ORMKRIMetricMaster.AppetiteLowerBound,
                   AppetiteUpperBound = kri.ORMKRIMetricMaster.AppetiteUpperBound,
                   AppetiteType = kri.ORMKRIMetricMaster.AppetiteType,
                   ToleranceLowerBound = kri.ORMKRIMetricMaster.ToleranceLowerBound,
                   ToleranceUpperBound = kri.ORMKRIMetricMaster.ToleranceUpperBound,
                   ToleranceType = kri.ORMKRIMetricMaster.ToleranceType,
                   EscalationLowerBound = kri.ORMKRIMetricMaster.EscalationLowerBound,
                   EscalationUpperBound = kri.ORMKRIMetricMaster.EscalationUpperBound,
                   EscalationType = kri.ORMKRIMetricMaster.EscalationType,
                   MitigationPlan = kri.MitigationPlan,
                   Currency = kri.Currency,
                   AmountInvolved = kri.AmountInvolved,
                   RiskAppetiteThreshold = kri.RiskAppetiteThreshold,
                   Description = kri.Description,
                   KRIData = kri.KRIData,
                   DateOccurance = kri.DateOccurance,
               });

            kriReports = kriReports.Where(p => p.KRIMetricIsActive == true);

            if (request is not null)
                kriReports = kriReports.Where(p => request.id == p.MetricId);


            var response = await kriReports.ToListAsync<KriPreviewResponse>();

            logger.LogInformation("Successfully Retrieved  KRI master data");

            return new ListResponse<KriPreviewResponse>("Successfully Retrieved KRI master data")
            {
                Data = response
            };

        }

        // to fetch the edit data ---------used
        public async Task<ListResponse<EditKriResponse>> GetEditKriReportAsync(EditKriRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<EditKriResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request == null)
            {
                return new ListResponse<EditKriResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (request.id == 0)
            {
                return new ListResponse<EditKriResponse>("Kri master data not found for id : " + request.id, ResponseCodes.DataNotFound);
            }

            var kriListQuery = unitOfWork.ORMKRIReportMetrics
               .GetAll().AsQueryable()
               .Select(kri => new EditKriResponse
               {
                   id = kri.KRIMetricMasterId,
                   reportIds = kri.KRIReportId,
                   reportingFrequency = kri.ORMKRIReport.ReportingFrequency,
                   reportingPeriod = kri.ORMKRIReport.ReportingPeriod
               });

            kriListQuery = kriListQuery.Where(p => p.reportIds == request.id);

            if (kriListQuery.Any())
            {

                var totalCount = kriListQuery.Count();

                if (totalCount == 0)
                {
                    return new ListResponse<EditKriResponse>("No record found for given input")
                    {
                        Data = { },
                        Total = totalCount
                    };
                }

                var response = await kriListQuery.ToListAsync<EditKriResponse>();

                logger.LogInformation("Successfully Retrieved  KRI master data");

                return new ListResponse<EditKriResponse>("Successfully Retrieved KRI master data")
                {
                    Data = response,
                    Total = totalCount
                };
            }
            else
            {
                return new ListResponse<EditKriResponse>("Kri master data not found for id : " + request.id, ResponseCodes.DataNotFound);

            }

        }


        // deleting a metric-------------used
        public async Task<ObjectResponse<string>> DeleteKriReportAsync(UpdatePreviewKriRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request == null)
            {
                return new ObjectResponse<string>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (request.id == 0)
            {
                return new ObjectResponse<string>("Kri report data not found for id : " + request.id, ResponseCodes.DataNotFound);
            }
            // Delete entries in ORMKRIReportMetrics
            var metricsToDelete = unitOfWork.ORMKRIReportMetrics.GetAll().AsQueryable()
                                    .Where(metric => metric.KRIReportId == request.id);
            if (metricsToDelete.Any())
            {
                unitOfWork.ORMKRIReportMetrics.DeleteRange(metricsToDelete);

                // Delete all entries in ORMKRIReport with the matching id
                var reportsToDelete = unitOfWork.ORMKRIReport
                                        .GetAll().AsQueryable()
                                        .Where(report => report.Id == request.id);

                if (reportsToDelete.Any())
                {
                    unitOfWork.ORMKRIReport.DeleteRange(reportsToDelete);

                    var count = await unitOfWork.SaveAsync(); // Save changes to the database

                    logger.LogInformation("Successfully Deleted KRI report and Metrics {id} with response {count}", request.id, count);

                    return new ObjectResponse<string>("Successfully Deleted KRI report and Metrics")
                    {
                        Data = { }
                    };
                }
                else
                {
                    logger.LogError("Kri report data not found for id {id}", request.id);
                    return new ObjectResponse<string>("Kri report not found for report id : " + request.id, ResponseCodes.DataNotFound);
                }
            }
            else
            {
                return new ObjectResponse<string>("Kri metric not found for report id : " + request.id, ResponseCodes.DataNotFound);
            }
        }

        // deleting report and respective metrics --------used
        public async Task<ListResponse<string>> RemoveKriMetricAsync(UpdatePreviewKriRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<string>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<string>("Kri metric data not found for id : " + input.id, ResponseCodes.DataNotFound);
            }
            var metricToDelete = unitOfWork.ORMKRIReportMetrics
                .GetAll().AsQueryable()
                .FirstOrDefault(metric => metric.Id == input.id); // Assuming you want a single metric based on ID

            if (metricToDelete != null)
            {
                var reportId = metricToDelete.KRIReportId; // Assuming property name is KRIReportId

                unitOfWork.ORMKRIReportMetrics.Delete(metricToDelete); // Delete the metric

                var count = await unitOfWork.SaveAsync(); // Save changes to the database

                logger.LogInformation("Successfully removed KRI metric id {id} with response {count}", input.id, count);
                var reportStatus = unitOfWork.ORMKRIReportMetrics
                    .GetAll().AsQueryable()
                    .Count(report => report.KRIReportId == reportId); // Corrected the count query

                if (reportStatus == 0)
                {
                    // Delete the report only if there are no associated metrics
                    var reportToDelete = unitOfWork.ORMKRIReport.GetAll().AsQueryable()
                    .Where(report => report.Id == reportId);
                    if (reportToDelete.Any())
                    {
                        unitOfWork.ORMKRIReport.DeleteRange(reportToDelete);
                        unitOfWork.Save(); // Save changes to the database
                    }
                    return new ListResponse<string>("Successfully deleted:  KRI Report")
                    {
                        Data = { },
                    };
                }
                else
                {
                    return new ListResponse<string>("Successfully deleted:  KRI metric data")
                    {
                        Data = { },
                    };
                }
            }

            logger.LogError("Kri metric not found for id {id}", input.id);

            return new ListResponse<string>("KRI metric not found")
            {
                Data = { },
            };

        }

        /// <summary>
        /// Validate if there is a duplicate KRI report for given location and reporting period.
        /// This is with the exception of reports with Status "Rejected".
        /// Report with Status Draft, Submitted and Approved are considered duplicate.
        /// </summary>
        /// <param name="ValidateDuplicateKriReportRequest"></param>
        /// <returns></returns>
        // deleting report and respective metrics --------used
        public async Task<ObjectResponse<string>> ValidateDuplicateKriReportAsync(ValidateDuplicateKriReportRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request is null || request.ReportingPeriod == null)
            {
                return new ObjectResponse<string>("Invalid input provided", ResponseCodes.DataNotFound);
            }
            if (request.LocationId == 0)
            {
                return new ObjectResponse<string>("Kri metric data not found for location id : " + request.LocationId, ResponseCodes.DataNotFound);
            }
            var duplicatekrireports = await unitOfWork.ORMKRIReport
                .GetAll().AsQueryable()
                .FirstOrDefaultAsync(report => report.LocationId == request.LocationId &&
                                report.ReportingPeriod == request.ReportingPeriod &&
                                report.Status != "Rejected");

            if (duplicatekrireports != null)
            {
                return new ObjectResponse<string>("KRI report already present for selected reporting period- " + request.ReportingPeriod)
                {
                    Data = { },
                    Code = ResponseCodes.RequestValidationError
                };
            }
            else
            {
                return new ObjectResponse<string>("No Duplicate KRI Report found for Location id : " + request.LocationId + " and Reporting Period " + request.ReportingPeriod)
                {
                    Data = { },
                    Code = ResponseCodes.Success
                };
            }
        }


    }
}




