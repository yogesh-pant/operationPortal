﻿using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Location;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Domain.Common;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using System.Data;

namespace ORM.Infrastructure.Services
{
    public class LocationService : ILocationService
    {
        private readonly ILogger<LocationService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;

        public LocationService(ILogger<LocationService> logger, ISessionService sessionService, IUnitOfWork unitOfWork)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
        }
        /// <summary>
        /// This function is used to get the list of all Branch locations
        /// </summary>
        /// <param name="FilterBranchListRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<BranchLocationGridResponse>> GetAllBranchLocationsAsync(FilterBranchListRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<BranchLocationGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<BranchLocationGridResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var branchListQuery = unitOfWork.ORMLocation
                       .GetAll().AsQueryable()
                       .Where(branch => branch.LocationType == "B")
                       .Select(branch => new BranchLocationGridResponse
                       {
                           Id           = branch.Id,
                           LocationId   = branch.LocationId,
                           SolId        = branch.SolId,
                           Branch       = branch.Branch,
                           Region       = branch.Region,
                           Status       = branch.Status,
                           CreatedById  = branch.CreatedById,
                           CreatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == branch.CreatedById)!.UserName ?? "",
                           CreatedDate  = branch.CreatedDate,
                           ModifiedById = branch.ModifiedById,
                           ModifiedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == branch.ModifiedById)!.UserName ?? "",
                           ModifiedDate = branch.ModifiedDate,
                           ReviewedById = branch.ReviewedById,
                           ReviewedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == branch.ReviewedById)!.UserName ?? "",
                           ReviewedDate = branch.ReviewedDate,
                           LocationChangeStatus = branch.LocationChangeStatus,
                           LocationChangeData = branch.ChangeRequestData,
                           ChangeReviewComments = branch.ChangeReviewComments,

                       });

        BranchLocationsApplyFilters(ref branchListQuery, input);

            branchListQuery.OrderByDescending(x => x.CreatedDate);            

            var totalCount = branchListQuery!.Count();

            if (totalCount == 0)
            {
                return new ListResponse<BranchLocationGridResponse>("No record found for given input", ResponseCodes.DataNotFound)
                {
                    Data = { },
                    Total = totalCount
                };
            }

            if (branchListQuery.Any())
                branchListQuery = branchListQuery.Paginate(input);


            var response = await branchListQuery!.ToListAsync<BranchLocationGridResponse>();
            response = ExtractBranchChangeRequestData(response);

            logger.LogInformation("Successfully Retrieved Branch grid data");

            return new ListResponse<BranchLocationGridResponse>("Successfully Retrieved Branch grid data")
            {
                Data = response,
                Total = totalCount
            };

        }
        private static void BranchLocationsApplyFilters(ref IQueryable<BranchLocationGridResponse> branchListQuery, FilterBranchListRequest input)
        {
            if (SearchFilters.IsValidNumericFilter(input.id))
                branchListQuery = branchListQuery.Where(p => p.Id == input.id);

            if (SearchFilters.IsValidStringFilter(input.Branch))
                branchListQuery = branchListQuery.Where(p => p.Branch!.ToLower().Contains(input.Branch!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Region))
                branchListQuery = branchListQuery.Where(p => p.Region!.ToLower().Contains(input.Region!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.SolId))
                branchListQuery = branchListQuery.Where(p => p.SolId!.ToLower().Contains(input.SolId!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.LocationId))
                branchListQuery = branchListQuery.Where(p => p.LocationId!.ToLower().Contains(input.LocationId!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Status))
                branchListQuery = branchListQuery.Where(p => p.Status == input.Status);

            if (SearchFilters.IsValidStringFilter(input.LocationChangeStatus))
                branchListQuery = branchListQuery.Where(p => p.LocationChangeStatus == input.LocationChangeStatus);
        }

        private List<BranchLocationGridResponse> ExtractBranchChangeRequestData(List<BranchLocationGridResponse> response)
        {
            foreach (var branch in response)
            {
                if (string.IsNullOrEmpty(branch.LocationChangeData))
                {
                    InitializeEmptyBranchChangeData(branch);
                    continue;
                }

                try
                {
                    var jObject = JObject.Parse(branch.LocationChangeData ?? "{}");
                    var LocationBranchChangeData = jObject.ToObject<LocationBranchChangeData>();

                    if (LocationBranchChangeData != null)
                    {
                        branch.NewLocationBranch = LocationBranchChangeData.NewLocationBranch ?? string.Empty;
                        branch.NewLocationRegion = LocationBranchChangeData.NewLocationRegion ?? string.Empty;
                        branch.NewLocationStatus = LocationBranchChangeData.NewLocationStatus ?? string.Empty;
                        branch.LocationNewFlag   = LocationBranchChangeData.LocationNewFlag ?? "No";
                        branch.NewLocationUpdatedBy = LocationBranchChangeData.LocationNewUpdatedBy;
                        branch.NewLocationUpdatedByName = LocationBranchChangeData.LocationNewUpdatedByName ?? string.Empty;
                        branch.NewLocationChangeRequestDate = LocationBranchChangeData.LocationNewChangeRequestDate;
                    }
                    else
                    {
                        InitializeEmptyBranchChangeData(branch);
                    }
                }
                catch (JsonException ex)
                {
                    logger.LogError(ex, "Error parsing ChangeRequestData JSON for Dept {DeptId}", branch.Id);
                    InitializeEmptyBranchChangeData(branch);
                }
            }

            return response;
        }
        private static void InitializeEmptyBranchChangeData(BranchLocationGridResponse branch)
        {
            branch.NewLocationBranch = string.Empty;
            branch.NewLocationRegion = string.Empty;
            branch.NewLocationStatus = string.Empty;
            branch.LocationNewFlag = "No";
            branch.NewLocationUpdatedBy = null;
            branch.NewLocationUpdatedByName = string.Empty;
            branch.NewLocationChangeRequestDate = null;
        }
        /// <summary>
        /// This function is used to get the list of all Department locations
        /// </summary>
        /// <param name="FilterDepartmentListRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<DepartmentLocationGridResponse>> GetAllDepartmentLocationsAsync(FilterDepartmentListRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<DepartmentLocationGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
                return new ListResponse<DepartmentLocationGridResponse>("Invalid input", ResponseCodes.DataNotFound);

            var departmentListQuery = unitOfWork.ORMLocation
                    .GetAll().AsQueryable()
                    .Where(department => department.LocationType == "D")
                    .Select(department => new DepartmentLocationGridResponse
                    {
                        Id = department.Id,
                        LocationId = department.LocationId,
                        Department = department.Department,
                        Status = department.Status,
                        CreatedById = department.CreatedById,
                        CreatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == department.CreatedById)!.UserName ?? "",
                        CreatedDate = department.CreatedDate,
                        ModifiedById = department.ModifiedById,
                        ModifiedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == department.ModifiedById)!.UserName ?? "",
                        ModifiedDate = department.ModifiedDate,
                        ReviewedById = department.ReviewedById,
                        ReviewedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == department.ReviewedById)!.UserName ?? "",
                        ReviewedDate = department.ReviewedDate,
                        LocationChangeStatus = department.LocationChangeStatus,
                        LocationChangeData   = department.ChangeRequestData,
                        ChangeReviewComments = department.ChangeReviewComments,
                    });

            if (SearchFilters.IsValidNumericFilter(input.id))
                departmentListQuery = departmentListQuery.Where(p => p.Id == input.id);

            if (SearchFilters.IsValidStringFilter(input.Department))
                departmentListQuery = departmentListQuery.Where(p => p.Department!.ToLower().Contains(input.Department!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.LocationId))
                departmentListQuery = departmentListQuery.Where(p => p.LocationId!.ToLower().Contains(input.LocationId!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Status))
                departmentListQuery = departmentListQuery.Where(p => p.Status == input.Status);

            if (SearchFilters.IsValidStringFilter(input.LocationChangeStatus))
                departmentListQuery = departmentListQuery.Where(p => p.LocationChangeStatus == input.LocationChangeStatus);

            departmentListQuery.OrderByDescending(x => x.CreatedDate);

            

            var totalCount = departmentListQuery!.Count();

            if (totalCount == 0)
            {
                return new ListResponse<DepartmentLocationGridResponse>("No record found for given input", ResponseCodes.DataNotFound)
                {
                    Data = { },
                    Total = totalCount
                };
            }

            if (departmentListQuery.Any())
                departmentListQuery = departmentListQuery.Paginate(input);

            var response = await departmentListQuery!.ToListAsync<DepartmentLocationGridResponse>();
            response = ExtractDepartmentChangeRequestData(response);

            logger.LogInformation("Successfully Retrieved Department grid data");

            return new ListResponse<DepartmentLocationGridResponse>("Successfully Retrieved Department grid data")
            {
                Data = response,
                Total = totalCount
            };

        }

        private List<DepartmentLocationGridResponse> ExtractDepartmentChangeRequestData(List<DepartmentLocationGridResponse> response)
        {
            foreach (var department in response)
            {
                if (string.IsNullOrEmpty(department.LocationChangeData))
                {
                    InitializeEmptyDeptChangeData(department);
                    continue;
                }

                try
                {
                    var jObject = JObject.Parse(department.LocationChangeData ?? "{}");
                    var LocationDeptChangeData = jObject.ToObject<LocationDeptChangeData>();

                    if (LocationDeptChangeData != null)
                    {
                        department.NewLocationDepartment = LocationDeptChangeData.NewLocationDepartment ?? string.Empty;
                        department.NewLocationStatus = LocationDeptChangeData.NewLocationStatus ?? string.Empty;
                        department.LocationNewFlag = LocationDeptChangeData.LocationNewFlag ?? "No";
                        department.NewLocationUpdatedBy = LocationDeptChangeData.LocationNewUpdatedBy;
                        department.NewLocationUpdatedByName = LocationDeptChangeData.LocationNewUpdatedByName ?? string.Empty;
                        department.NewLocationChangeRequestDate = LocationDeptChangeData.LocationNewChangeRequestDate;
                    }
                    else
                    {
                        InitializeEmptyDeptChangeData(department);
                    }
                }
                catch (JsonException ex)
                {
                    logger.LogError(ex, "Error parsing ChangeRequestData JSON for Dept {DeptId}", department.Id);
                    InitializeEmptyDeptChangeData(department);
                }
            }

            return response;
        }
        private static void InitializeEmptyDeptChangeData(DepartmentLocationGridResponse department)
        {
            department.NewLocationDepartment = string.Empty;
            department.NewLocationStatus = string.Empty;
            department.LocationNewFlag = "No";
            department.NewLocationUpdatedBy = null;
            department.NewLocationUpdatedByName = string.Empty;
            department.NewLocationChangeRequestDate = null;
        }
        public async Task<ListResponse<ReturnId>> CreateBranchLocationAsync(CreateBranchLocationRequest input)
        {
            if (input == null || string.IsNullOrEmpty(input.Branch) || string.IsNullOrEmpty(input.SolId) || string.IsNullOrEmpty(input.Region))
            {
                return new ListResponse<ReturnId>("invalid input", ResponseCodes.DataNotFound);
            }
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var existingBranch = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(b => b.Branch == input.Branch!);

            if (existingBranch != null)
            {
                return new ListResponse<ReturnId>("Input Branch Name already exists in ORM Database!", ResponseCodes.ServiceError);
            }
            var existingSolId = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(b => b.SolId == input.SolId!);

            if (existingSolId != null)
            {
                return new ListResponse<ReturnId>("A branch with input SolId already exists in ORM Database!", ResponseCodes.ServiceError);
            }

            string? NextLocationId = await unitOfWork.GetNextLocationId("B");

            var LocationBranchChangeData = new LocationBranchChangeData { };
            LocationBranchChangeData.NewLocationBranch = input.Branch;
            LocationBranchChangeData.NewLocationRegion = input.Region;
            LocationBranchChangeData.LocationNewFlag = "Yes";
            LocationBranchChangeData.NewLocationStatus = "Active";
            LocationBranchChangeData.LocationNewUpdatedBy = session.UserId;
            LocationBranchChangeData.LocationNewUpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == session.UserId)!.UserName ?? "";
            LocationBranchChangeData.LocationNewChangeRequestDate = DateTime.Now;
            string LocationBranchChangeDatajsonString = JsonConvert.SerializeObject(LocationBranchChangeData);

            // Create a new Branch Location
            var createBranchLocation = new ORMLocation
            {
                LocationId  = NextLocationId!,
                LocationType= "B",
                Department  = null, 
                Status      = "Inactive",
                SolId       = input.SolId,
                Branch      = input.Branch,
                Region      = input.Region,
                LocationChangeStatus = "Pending",
                ChangeRequestData = LocationBranchChangeDatajsonString,
                CreatedById = input.CreatedById,
                CreatedDate = DateTime.Now
            };

            var response = await unitOfWork.SaveAndGetIdLocationAsync(createBranchLocation);

            logger.LogInformation("Successfully created Branch  - {input.Branch} with response {response} ", input.Branch,response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("New Branch Created!", ResponseCodes.Success)
            {
                Data = Response
            };

        }

        public async Task<ListResponse<ReturnId>> CreateDepartmentLocationAsync(CreateDepartmentLocationRequest input)
        {
            if (input == null || string.IsNullOrEmpty(input.Department))
            {
                return new ListResponse<ReturnId>("invalid input", ResponseCodes.DataNotFound);
            }

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var existingDept = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(b => b.Department == input.Department!);

            if (existingDept != null)
            {
                return new ListResponse<ReturnId>("Input Department Name already exists in ORM Database!", ResponseCodes.ServiceError);
            }

            string? NextLocationId = await unitOfWork.GetNextLocationId("D"); var LocationDeptChangeData = new LocationDeptChangeData { };

            
            LocationDeptChangeData.NewLocationDepartment = input.Department;
            LocationDeptChangeData.NewLocationStatus = "Active";
            LocationDeptChangeData.LocationNewFlag = "Yes";
            LocationDeptChangeData.LocationNewUpdatedBy = session.UserId;
            LocationDeptChangeData.LocationNewUpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == session.UserId)!.UserName ?? "";
            LocationDeptChangeData.LocationNewChangeRequestDate = DateTime.Now;
            string LocationDeptChangeDatajsonString = JsonConvert.SerializeObject(LocationDeptChangeData);

            // Create a new Department Location
            var createDepartmentLocation = new ORMLocation
            {
                LocationId   = NextLocationId!,
                LocationType = "D",
                Department   = input.Department,
                Status       = "Inactive",
                SolId        = null,
                Branch       = null,
                Region       = null,
                LocationChangeStatus = "Pending",
                ChangeRequestData = LocationDeptChangeDatajsonString,
                CreatedById  = input.CreatedById,
                CreatedDate  = DateTime.Now
            };

            var response = await unitOfWork.SaveAndGetIdLocationAsync(createDepartmentLocation);

            logger.LogInformation("Successfully Submitted Request for New Department id - {input.Department} with response {response} ", input.Department, response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("New Department Created!", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        public async Task<ListResponse<ReturnId>> UpdateBranchLocationAsync(UpdateBranchLocationRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var OtherLocationData = await (from au in unitOfWork.ORMLocation.GetAll().AsQueryable()
                                           where au.Id != input.id
                                           where au.LocationType == "B"
                                           where au.Branch == input.Branch
                                           select au).FirstOrDefaultAsync<ORMLocation>();

            if ((OtherLocationData is not null) && (OtherLocationData!.Branch == input.Branch))
            {
                return new ListResponse<ReturnId>("Input Branch Name already exists in ORM Database!", ResponseCodes.ServiceError);
            }

            var LocationData = await (from au in unitOfWork.ORMLocation.GetAll().AsQueryable()
                                      where au.Id == input.id
                                      where au.LocationType == "B"
                                      select au).FirstOrDefaultAsync<ORMLocation>();
            if (LocationData is null)
            {
                logger.LogInformation("Location not found for Branch id - {input.id}", input.id);
                return new ListResponse<ReturnId>("Location not found for Branch id in ORM Database!", ResponseCodes.ServiceError);
            }

            var LocationBranchChangeData = new LocationBranchChangeData { };

            bool ChangeFlag = false;

            if (LocationData!.Branch != input.Branch)
                { 
                LocationBranchChangeData.NewLocationBranch = input.Branch;
                ChangeFlag = true;
            }
            if (LocationData.Region != input.Region)
                {
                LocationBranchChangeData.NewLocationRegion = input.Region;
                ChangeFlag = true;
            }
            
            if (LocationData.Status != input.Status)
                {
                LocationBranchChangeData.NewLocationStatus = input.Status;
                ChangeFlag = true;
            }

            if (!ChangeFlag)
                return new ListResponse<ReturnId>("No changes made in Branch data!", ResponseCodes.ServiceError);

            LocationBranchChangeData.LocationNewUpdatedBy = input.ModifiedById;
            LocationBranchChangeData.LocationNewUpdatedByName =unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == input.ModifiedById)!.UserName ?? "";
            LocationBranchChangeData.LocationNewChangeRequestDate = DateTime.Now;
            LocationBranchChangeData.LocationNewFlag = "No";
            string LocationBranchChangeDatajsonString = JsonConvert.SerializeObject(LocationBranchChangeData);

            LocationData.LocationChangeStatus = "Pending";
            LocationData.ChangeRequestData = LocationBranchChangeDatajsonString;

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully Submitted Update Request for Branch id - {input.id} with response {response} -", input.id,response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("Successfully Submitted Update Request for Branch", ResponseCodes.Success)
            {
                Data = Response
            };


        }
        public async Task<ListResponse<ReturnId>> UpdateDepartmentLocationAsync(UpdateDepartmentLocationRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var OtherLocationData = await (from au in unitOfWork.ORMLocation.GetAll().AsQueryable()
                                           where au.Id != input.id
                                           where au.LocationType == "D"
                                           where au.Department == input.Department
                                           select au).FirstOrDefaultAsync<ORMLocation>();

            if (OtherLocationData is not null)
            {
                return new ListResponse<ReturnId>("Input Department Name already exists in ORM Database!", ResponseCodes.ServiceError);
            }

            var LocationData = await (from au in unitOfWork.ORMLocation.GetAll().AsQueryable()
                                      where au.Id == input.id
                                      where au.LocationType == "D"
                                      select au).FirstOrDefaultAsync<ORMLocation>();
            if (LocationData is null)
            {
                logger.LogInformation("Location not found for Department id - {input.id}", input.id);
                return new ListResponse<ReturnId>("Location not found for Department id in ORM Database!", ResponseCodes.ServiceError);
            }

            var LocationDeptChangeData = new LocationDeptChangeData { };

            bool ChangeFlag = false;

            if (LocationData!.Department != input.Department)
            {
                LocationDeptChangeData.NewLocationDepartment = input.Department;
                ChangeFlag = true;
            }

            if (LocationData.Status != input.Status)
            {
                LocationDeptChangeData.NewLocationStatus = input.Status;
                ChangeFlag = true;
            }

            if (!ChangeFlag)
                return new ListResponse<ReturnId>("No changes made in Department data!", ResponseCodes.ServiceError);

            LocationDeptChangeData.LocationNewUpdatedBy = input.ModifiedById;
            LocationDeptChangeData.LocationNewUpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == input.ModifiedById)!.UserName ?? "";
            LocationDeptChangeData.LocationNewChangeRequestDate = DateTime.Now;
            LocationDeptChangeData.LocationNewFlag = "No";
            string LocationDeptChangeDatajsonString = JsonConvert.SerializeObject(LocationDeptChangeData);

            LocationData.LocationChangeStatus = "Pending";
            LocationData.ChangeRequestData = LocationDeptChangeDatajsonString;

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully Submitted Update Request for Department id - {input.id} with response {response} -", input.id, response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("Successfully Submitted Update Request for Department", ResponseCodes.Success)
            {
                Data = Response
            };


        }


        /// <summary>
        /// This Task is used to Approve the user change request by Maker and update the user record
        /// The requested user info is parked in appuser table in UserChangeData column in json form
        /// </summary>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns>
        /// UserResponse
        /// </returns>

        public async Task<ObjectResponse<string>> ApproveLocationChangeAsync(ReviewUserChangeRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var LocationData = await (from au in unitOfWork.ORMLocation.GetAll().AsQueryable()
                                           where au.Id == request.Id
                                           select au).FirstOrDefaultAsync<ORMLocation>();

            if (LocationData is null)
            {
                return new ObjectResponse<string>("Input location not found in Database  ", ResponseCodes.Success);
            }
            if (LocationData.LocationChangeStatus != "Pending")
                return new ObjectResponse<string>("Location change in not Pending Review ", ResponseCodes.DataNotFound) { Data = "" };

            UpdateApprovedLocation(LocationData, request, session.UserId);
            unitOfWork.Save();

            logger.LogInformation("Approved Location Update request for  Location - {UserName} with Comments {ChangeReviewComments} ", LocationData.LocationId, request.ChangeReviewComments);
            return new ObjectResponse<string>("Location Update request approved and record updated successfully ", ResponseCodes.Success);
        }

        private static void UpdateApprovedLocation(ORMLocation LocationData, ReviewUserChangeRequest request, long ReviewedById)
        {

            if (LocationData.LocationType == "B")
            {
                // Deserialize the JSON string back to UserChangeData object
                LocationBranchChangeData LocationBranchChangeData = JsonConvert.DeserializeObject<LocationBranchChangeData>(LocationData.ChangeRequestData!)!;
                LocationData.Branch = LocationBranchChangeData.NewLocationBranch ?? LocationData.Branch;
                LocationData.Region = LocationBranchChangeData.NewLocationRegion ?? LocationData.Region;
                LocationData.ModifiedDate = LocationBranchChangeData.LocationNewChangeRequestDate ?? LocationData.ModifiedDate;
                LocationData.ModifiedById = LocationBranchChangeData.LocationNewUpdatedBy ?? LocationData.ModifiedById;
                LocationData.Status = LocationBranchChangeData.NewLocationStatus ?? LocationData.Status;
            }
            else
            {
                // Deserialize the JSON string back to UserChangeData object
                LocationDeptChangeData LocationDeptChangeData = JsonConvert.DeserializeObject<LocationDeptChangeData>(LocationData.ChangeRequestData!)!;
                LocationData.Department = LocationDeptChangeData.NewLocationDepartment ?? LocationData.Department;
                LocationData.ModifiedDate = LocationDeptChangeData.LocationNewChangeRequestDate ?? LocationData.ModifiedDate;
                LocationData.ModifiedById = LocationDeptChangeData.LocationNewUpdatedBy ?? LocationData.ModifiedById;
                LocationData.Status = LocationDeptChangeData.NewLocationStatus ?? LocationData.Status;
            }
            LocationData.ReviewedById = ReviewedById;
            LocationData.ReviewedDate = DateTime.Now;
            LocationData.ChangeReviewComments = request.ChangeReviewComments;
            LocationData.LocationChangeStatus = "Approved";

        }
        /// <summary>
        /// This Task is used to Reject the Location change request by Maker and update the Location Change status as Rejected
        /// </summary>
        /// <param>ReviewLocationChangeRequest</param>
        /// <returns>
        /// UserResponse
        /// </returns>

        public async Task<ObjectResponse<string>> RejectLocationChangeAsync(ReviewUserChangeRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var LocationData = await (from au in unitOfWork.ORMLocation.GetAll().AsQueryable()
                                      where au.Id == request.Id
                                      select au).FirstOrDefaultAsync<ORMLocation>();

            if (LocationData is null)
            {
                return new ObjectResponse<string>("Input location not found in Database  ", ResponseCodes.Success);
            }
            if (LocationData.LocationChangeStatus != "Pending")
                return new ObjectResponse<string>("Location change in not Pending Review ", ResponseCodes.DataNotFound) { Data = "UserChangeStatus is not Pending" };

            LocationData.ReviewedById = session.UserId;
            LocationData.ReviewedDate = DateTime.Now;
            LocationData.ChangeReviewComments = request.ChangeReviewComments;
            LocationData.LocationChangeStatus = "Rejected";
            unitOfWork.Save();
            logger.LogInformation("Rejected Location Update request for  Location - {UserName} with Comments {ChangeReviewComments} ", LocationData.LocationId, request.ChangeReviewComments);
            return new ObjectResponse<string>("Location Update request Rejected. ", ResponseCodes.Success);
        }
    }

}