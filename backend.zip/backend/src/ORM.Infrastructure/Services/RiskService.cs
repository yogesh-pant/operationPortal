﻿using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using System.Data;
using ORM.Application.Interfaces.Common;
using ORM.Domain.Common;

namespace ORM.Infrastructure.Services
{
    public class RiskService : IRiskService
    {
        private readonly ILogger<LossService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;
        private readonly IAzueBlobStorageService azueBlobStorageService;


        public RiskService(ILogger<LossService> logger, ISessionService sessionService, IConfiguration configuration, IUnitOfWork unitOfWork, IAzueBlobStorageService azueBlobStorageService)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
            this.azueBlobStorageService = azueBlobStorageService;

        }
        /// <summary>
        /// This function is used to get the list of Risk entries
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<RiskGridResponse>> GetRiskGridAsync(FilterRiskListRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<RiskGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            if (input == null)
            {
                return new ListResponse<RiskGridResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var riskListQuery = unitOfWork.ORMRiskReport
                .GetAll().AsQueryable()
                .Select(riskReport => new RiskDataGrid
                {
                    Id = riskReport!.Id,
                    RefNum = riskReport!.RefNum,
                    LocationType = riskReport!.LocationType,
                    LocationId = riskReport!.LocationId,
                    LocationName= (riskReport!.LocationType == "B") ? unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport!.LocationId)!.Branch : unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.LocationId)!.Department,
                    Region =  unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.LocationId)!.Region ??  "",
                    ValidatorUserId = riskReport!.ValidatorUserId,
                    ValidatorUserName = "",
                    ProcessName = riskReport!.ProcessName,
                    SubProcessName = riskReport!.SubProcessName,
                    InherentThreatRisk = riskReport!.InherentThreatRisk,
                    FrequencyOfOccurance = riskReport!.FrequencyOfOccurance,
                    RiskClassification = riskReport!.RiskClassification,
                    RiskRootCause = riskReport!.RiskRootCause,
                    RiskSeverity = riskReport!.RiskSeverity,
                    RiskDirection = riskReport!.RiskDirection,
                    ImplementedControls = riskReport!.ImplementedControls,
                    RiskControlDesign = riskReport!.RiskControlDesign!,
                    RiskControlType = riskReport!.RiskControlType!,
                    RiskControlEffectiveness = riskReport!.RiskControlEffectiveness!,
                    RiskResidual = riskReport!.RiskResidual!,
                    RiskResponsibility = riskReport!.RiskResponsibility!,
                    Documents = riskReport!.Documents!,
                    DocumentName = riskReport!.DocumentName!,
                    DocumentExtension = riskReport!.DocumentName!.Substring(riskReport!.DocumentName!.LastIndexOf('.') + 1),
                    RiskCategory = riskReport!.RiskCategory!,
                    ReportStatus = riskReport!.ReportStatus!,
                    UpdateRequestStatus = riskReport!.UpdateRequestStatus!,
                    RiskResidualRating = riskReport!.RiskResidualRating!,
                    RiskActionPlan      =   riskReport!.RiskActionPlan!,
                    RiskActionPlanStatus = riskReport!.RiskActionPlanStatus!,
                    RiskExpectedResolutionTime = riskReport!.RiskExpectedResolutionTime!,
                    RiskStrategy = riskReport!.RiskStrategy!,
                    RiskControlAssessment = riskReport!.RiskControlAssessment,
                    RiskControlQuality = riskReport!.RiskControlQuality,
                    RiskRating = riskReport!.RiskRating,
                    ReviewerComments = riskReport!.ReviewerComments,
                    CreatedById = riskReport.CreatedById!,
                    ModifiedById = riskReport.ModifiedById!,
                    ValidatedById = riskReport.ValidatedById!,
                    ApprovedById = riskReport.ApprovedById!,
                    CreatedByName   = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.CreatedById)!.UserName ?? "",
                    ModifiedByName  = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.ModifiedById)!.UserName ?? "",
                    ValidatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.ValidatorUserId)!.UserName ?? "",
                    ApprovedByName  = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.ApprovedById)!.UserName ?? "",
                    CreatedDate = riskReport.CreatedDate!,
                    ModifiedDate = riskReport.ModifiedDate!,
                    ValidationDate = riskReport.ValidationDate!,
                    ApprovedDate = riskReport.ApprovedDate!,
                    Branch = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.LocationId)!.Branch ?? "",
                    Department = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == riskReport.LocationId)!.Department ?? ""
                    
                });

            GetRiskGridApplyFilters(ref riskListQuery, input);

            var totalCount = riskListQuery!.Count();

            if (totalCount == 0)
            {
                return new ListResponse<RiskGridResponse>("No record found for given input")
                {
                    Data = { },
                    Total = totalCount
                };
            }
            var lossStatusCounts = await riskListQuery
                .GroupBy(riskreport => riskreport.ReportStatus)
                .Select(group => new
                {
                    Status = group.Key,
                    Count = group.Count()
                })
                .ToDictionaryAsync(x => x.Status!, x => x.Count);

            var recordCount = new RiskRecordCount
            {
                SubmittedCount = lossStatusCounts.GetValueOrDefault("Submitted", 0),
                DraftCount = lossStatusCounts.GetValueOrDefault("Draft", 0),
                RejectCount = lossStatusCounts.GetValueOrDefault("Rejected", 0),
                ApprovedCount = lossStatusCounts.GetValueOrDefault("Approved", 0),
            };

            if (SearchFilters.IsValidStringFilter(input.ReportStatus))
                riskListQuery = riskListQuery.Where(p => p.ReportStatus == input.ReportStatus);

            if (riskListQuery.Any())
                {
                    riskListQuery = riskListQuery.Paginate(input);

                }
                var response = await riskListQuery!.ToListAsync();

                var responses = new RiskGridResponse(response, recordCount);


                logger.LogInformation("Successfully Retrieved Risk grid data");

                return new ListResponse<RiskGridResponse>("Successfully Retrieved Risk grid data")
                {
                    Data = new List<RiskGridResponse> { responses },
                    Total = totalCount
                };

        }
        /// <summary>
        /// This helper function is used to filter the Risk report records
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>

        private static void GetRiskGridApplyFilters(ref IQueryable<RiskDataGrid> riskListQuery, FilterRiskListRequest input)
        {
            if (input.minDate is not null || input.maxDate is not null)
                riskListQuery = riskListQuery.Where(p =>
                (input.minDate == null || p.CreatedDate >= InputTimeFormat.ConvertTo00AMFormat(input.minDate.Value)) &&
                (input.maxDate == null || p.CreatedDate <= InputTimeFormat.ConvertTo12PMFormat(input.maxDate.Value))
                ).OrderByDescending(x => x.ModifiedDate);

            if (SearchFilters.IsValidNumericFilter(input.Id))
                riskListQuery = riskListQuery.Where(p => p.Id == input.Id);

            if (SearchFilters.IsValidNumericFilter(input.LocationId))
                riskListQuery = riskListQuery.Where(p => p.LocationId == input.LocationId);

            if (SearchFilters.IsValidStringFilter(input.LocationType))
                riskListQuery = riskListQuery.Where(p => p.LocationType == input.LocationType);

            if (SearchFilters.IsValidStringFilter(input.RefNum))
                riskListQuery = riskListQuery.Where(p => p.RefNum!.ToLower().Contains(input.RefNum!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Branch))
                riskListQuery = riskListQuery.Where(p => p.Branch!.ToLower().Contains(input.Branch!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Region))
                riskListQuery = riskListQuery.Where(p => p.Region!.ToLower().Contains(input.Region!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.Department))
                riskListQuery = riskListQuery.Where(p => p.Department!.ToLower().Contains(input.Department!.ToLower()));

        }

        /// <summary>
        /// This function is used to get the create Risk Data 
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<ReturnId>> CreateRiskDataAsync(CreateRiskDataRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            if (input == null)
            {
                return new ListResponse<ReturnId>("Invalid input", ResponseCodes.DataNotFound);
            }

            List<string> documents = new() { };

            if (input!.RiskDocuments != null)
                for (int i = 0; i < input!.RiskDocuments!.Count; i++)
                {
                    documents.Add(await azueBlobStorageService.UploadFileAsync(input!.RiskDocuments![i]));
                }
            string UpdateRequestStatus = "";
            string? refNum = await  unitOfWork.GetRiskReportRecordCount(); 
            var createRiskReport = new ORMRiskReport
            {
                RefNum = refNum!,
                LocationType = input.LocationType,
                LocationId = input!.LocationId,
                ValidatorUserId = input!.ValidatorUserId,
                ProcessName = input!.ProcessName,
                SubProcessName = input!.SubProcessName,
                InherentThreatRisk = input!.InherentThreatRisk,
                FrequencyOfOccurance = input!.FrequencyOfOccurance,
                RiskSeverity = input!.RiskSeverity,
                RiskRating = CalculateRiskRating(input.FrequencyOfOccurance!, input.RiskSeverity!),
                RiskControlAssessment = CalculateControlAssessment(input.RiskControlDesign!, input.RiskControlType!),
                RiskControlQuality = CalculateControlQuality(input.RiskControlDesign!, input.RiskControlType!, "ControlQuality"),
                RiskControlEffectiveness = CalculateControlEffectiveness(input.RiskControlDesign!, input.RiskControlType!),
                RiskDirection = input!.RiskDirection,
                ImplementedControls = input!.ImplementedControls,
                RiskControlDesign = input!.RiskControlDesign!,
                RiskControlType = input!.RiskControlType!,
                RiskResidual = input!.RiskResidual!,
                RiskResidualRating = CalculateControlQuality(input.RiskControlDesign!, input.RiskControlType!, "ResidualRiskRating"),
                RiskResponsibility = input!.RiskResponsibility!,
                RiskActionPlan = input!.RiskActionPlan!,
                CreatedDate = DateTime.Now,
                ModifiedDate = DateTime.Now,
                CreatedById = input!.CreatedById,
                ReportStatus = input!.ReportStatus!,
                UpdateRequestStatus = UpdateRequestStatus,
                Documents= (documents.Count > 0) ? documents[0] : "",
                DocumentName = (documents.Count > 0) ? input!.Documentname : "",
        };

            var response = await unitOfWork.SaveAndGetIdRiskReportAsync(createRiskReport);

            logger.LogInformation("Successfully created Risk Report ref number {refNum} with response - {response}",refNum,response);

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Risk Report Created!", ResponseCodes.Success)
            {
                Data = Response
            };

        }

        public async Task<ListResponse<RiskDoc>> GetRiskReportDoc(GetDocRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<RiskDoc>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<RiskDoc>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.Id == 0)
            {
                return new ListResponse<RiskDoc>("Risk report document not found for id  : " + input.Id, ResponseCodes.DataNotFound);
            }
            var riskData = await unitOfWork.ORMRiskReport
                .GetAll().AsQueryable()
                .Where(data => data.Id == input.Id)
                .Select(data => new RiskDoc
                {
                    Documents = data.Documents!
                }).FirstOrDefaultAsync();

            if (riskData != null)
            {
                var file = await azueBlobStorageService.GetFileAsBase64Async(riskData.Documents!);

                riskData.Documents = file;
            }

            if (riskData != null)
            {
                logger.LogInformation("Successfully Retrieved Risk Data for one Id");

                return new ListResponse<RiskDoc>("Successfully Retrieved Risk Data for one id")
                {
                    Data = new List<RiskDoc> { riskData! }
                };
            }
            else
            {
                // Handle the case where no data is found for the given ID
                logger.LogWarning("No Risk Data found for the specified ID");
                return new ListResponse<RiskDoc>("No Risk Data found for the specified ID");
            }
        }

        public async Task<ListResponse<ReturnId>> EditRiskDataAsync(EditRiskDataRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);


            if (input == null)
            {
                return new ListResponse<ReturnId>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.Id == 0)
            {
                return new ListResponse<ReturnId>("Risk report not found for id  : " + input.Id, ResponseCodes.DataNotFound);
            }

            // Edit a risk report

            List<string> documents = new() { };

            if (input!.RiskDocuments != null)
                for (int i = 0; i < input!.RiskDocuments!.Count; i++)
                {
                    documents.Add(await azueBlobStorageService.UploadFileAsync(input!.RiskDocuments![i]));
                }

            var riskReport = await (from au in unitOfWork.ORMRiskReport.GetAll().AsQueryable()
                                   where au.Id == input.Id
                                   select au).FirstOrDefaultAsync<ORMRiskReport>();

            if (riskReport is not null)
            {
                EditRiskStatusHelper(ref riskReport, input, documents);
            }
            else
            {
                return new ListResponse<ReturnId>("Risk report not found for id  : " + input.Id, ResponseCodes.DataNotFound);
            }

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully updated Risk Report id - {input.id} ", response);

            ReturnId result = new()
            {
                id = input.Id
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Risk Report Updated!", ResponseCodes.Success)
            {
                Data = Response
            };
        }
        /// <summary>
        /// This helper function is used to update Risk report record
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>

        private static void EditRiskStatusHelper(ref ORMRiskReport riskReport, EditRiskDataRequest input, List<string> documents)
        {
            string UpdateRequestStatus = "";

            //Incase report is draft then reset UpdateRequestStatus to blank
            // Correct create date time when report is submitted first time
            if ((riskReport.ReportStatus == "Draft") && (input!.ReportStatus == "Submitted"))
            {
                riskReport.CreatedDate = DateTime.Now;
            }
            // Business Rule - When An Approved report is re-edited on request by BORM , mark the update request as Completed
            if (riskReport!.UpdateRequestStatus == "Requested")
            {
                UpdateRequestStatus = "Completed";
            }
            // Business Rule - When An Approved report is edited on request by BORM, do not change the report Status after editing it.
            if (riskReport!.ReportStatus != "Approved")
            {

                riskReport.ReportStatus = input!.ReportStatus;
            }
            riskReport.ProcessName = input!.ProcessName;
            riskReport.SubProcessName = input!.SubProcessName;
            riskReport.InherentThreatRisk = input!.InherentThreatRisk;
            riskReport.FrequencyOfOccurance = input!.FrequencyOfOccurance;
            riskReport.RiskSeverity = input!.RiskSeverity;
            riskReport.RiskRating = CalculateRiskRating(input.FrequencyOfOccurance!, input.RiskSeverity!);
            riskReport.RiskControlAssessment = CalculateControlAssessment(input.RiskControlDesign!, input.RiskControlType!);
            riskReport.RiskControlQuality = CalculateControlQuality(input.RiskControlDesign!, input.RiskControlType!, "ControlQuality");
            riskReport.RiskDirection = input!.RiskDirection;
            riskReport.ImplementedControls = input!.ImplementedControls;
            riskReport.RiskControlDesign = input!.RiskControlDesign!;
            riskReport.RiskControlType = input!.RiskControlType!;
            riskReport.RiskControlEffectiveness = CalculateControlEffectiveness(input.RiskControlDesign!, input.RiskControlType!);
            riskReport.RiskResidual = input!.RiskResidual!;
            riskReport.RiskResidualRating = CalculateControlQuality(input.RiskControlDesign!, input.RiskControlType!, "ResidualRiskRating");
            riskReport.RiskResponsibility = input!.RiskResponsibility!;
            riskReport.RiskActionPlan = input!.RiskActionPlan;
            riskReport.ModifiedDate = DateTime.Now;
            riskReport.ModifiedById = input!.ModifiedById;
            riskReport.UpdateRequestStatus = UpdateRequestStatus;
            if (documents.Count > 0)
            {
                riskReport.Documents = documents[0];
                riskReport.DocumentName = input!.Documentname;
            }
        }

        public async Task<ListResponse<ReturnId>> UpdateRiskDataAsync(UpdateRiskDataRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<ReturnId>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.Id == 0)
            {
                return new ListResponse<ReturnId>("Risk report not found for id  : " + input.Id, ResponseCodes.DataNotFound);
            }
            // Update a risk report by BORM Admin
            var riskReport = await (from au in unitOfWork.ORMRiskReport.GetAll().AsQueryable()
                                   where au.Id == input.Id
                                   select au).FirstOrDefaultAsync<ORMRiskReport>();
            if (riskReport is not null)
            {

                riskReport.RiskCategory = input!.RiskCategory;
                riskReport.RiskRootCause = input!.RiskRootCause;
                riskReport.RiskClassification = input!.RiskClassification;
                riskReport.RiskActionPlanStatus = input!.RiskActionPlanStatus;
                riskReport.RiskExpectedResolutionTime = input!.RiskExpectedResolutionTime;  
                riskReport.RiskStrategy = input!.RiskStrategy;
                if (riskReport.ReportStatus == "Submitted")
                {
                    riskReport.ReportStatus = input!.ReportStatus;
                    riskReport.ApprovedById = input!.ModifiedById;
                    riskReport.ApprovedDate = DateTime.Now;
                }
                riskReport.ModifiedDate = DateTime.Now;
                riskReport.ModifiedById = input!.ModifiedById;

            }
            else
            {
                return new ListResponse<ReturnId>("Risk report not found for id  : " + input.Id, ResponseCodes.DataNotFound);

            }

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully updated Risk Report id - {input.id} ", response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("Risk Report Updated!", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        public async Task<ListResponse<ReturnId>> UpdateRiskStatusAsync(UpdateRiskStatusRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<ReturnId>("Invalid input", ResponseCodes.DataNotFound);
            }
            if (input.Id == 0)
            {
                return new ListResponse<ReturnId>("Risk report not found for id  : " + input.Id, ResponseCodes.DataNotFound);
            }
            // Update Status of risk report   >> Rejected or Update Requested 

            var riskReport = await (from au in unitOfWork.ORMRiskReport.GetAll().AsQueryable()
                                    where au.Id == input.Id
                                    select au).FirstOrDefaultAsync<ORMRiskReport>();
            if (riskReport is not null)
            {
                UpdateRiskStatusHelper(ref riskReport, input);
            }
            else
            {
                return new ListResponse<ReturnId>("Risk report not found for id  : " + input.Id, ResponseCodes.DataNotFound);
            }

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully updated Risk Status - {input.id} ", response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("Risk Report Status Updated!", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        private static void UpdateRiskStatusHelper(ref ORMRiskReport riskReport, UpdateRiskStatusRequest input)
        {
            if (input.UpdateRequestStatus is not null && input.UpdateRequestStatus is not "")
            {
                riskReport.UpdateRequestStatus = input!.UpdateRequestStatus;
            }

            if (input.ReviewerComments is not null && input.ReviewerComments is not "undefined")
            {
                riskReport.ReviewerComments = input!.ReviewerComments;
            }
            if ((riskReport.ReportStatus == "Submitted") && (input!.ReportStatus == "Rejected"))
            {
                riskReport.ApprovedById = input!.ModifiedById;
                riskReport.ApprovedDate = DateTime.Now;
            }
            if (input.ReportStatus is not null && input.ReportStatus is not "undefined")
            {
                riskReport.ReportStatus = input!.ReportStatus;
            }

            riskReport.ModifiedDate = DateTime.Now;
            riskReport.ModifiedById = input!.ModifiedById;
        }
        private static string CalculateRiskRating(string Frequency, string Severity)
        {
            int FrequencyValue;
            int SeverityValue;

            switch (Frequency)
            {
                case "Certainly/Daily":
                    FrequencyValue = 5;
                    break;
                case "Likely/Weekly":
                    FrequencyValue = 4;
                    break;
                case "Possible/Monthly":
                    FrequencyValue = 3;
                    break;
                case "Unlikely/Quarterly":
                    FrequencyValue = 2;
                    break;
                case "Very Rare/Annually":
                    FrequencyValue = 1;
                    break;
                default:
                    FrequencyValue = 0;
                    break;
            }
            switch (Severity)
            {
                case "Significant":
                    SeverityValue = 5;
                    break;
                case "Major":
                    SeverityValue = 4;
                    break;
                case "Moderate":
                    SeverityValue = 3;
                    break;
                case "Minor":
                    SeverityValue = 2;
                    break;
                case "Insignificant":
                    SeverityValue = 1;
                    break;
                default:
                    SeverityValue = 0;
                    break;
            }
            
            var RiskRatingWeightage = FrequencyValue * SeverityValue;
            
            var RiskRating= "";

            if (RiskRatingWeightage >= 15) 
                {
                RiskRating = "High";
            }
            else if (RiskRatingWeightage >= 5)
                {
                RiskRating = "Medium";
            }
            else   // i.e. (RiskRatingWeightage >= 0)
            {
                RiskRating = "Low";
            }
            return RiskRating;
        }
        private static string CalculateControlAssessment(string ControlDesign, string ControlType)
        {
            string ControlAssessment;

            switch (ControlDesign)
            {
                case "Automated":
                    switch (ControlType)
                    {
                        case "Corrective":
                        case "Detective":
                            ControlAssessment = "Needs Improvement";
                            break;
                        case "Preventive":
                            ControlAssessment = "Adequate";
                            break;
                        default:
                            ControlAssessment = "Unrated";
                            break;
                    }
                    break;
                case "Semi-Automated":
                    switch (ControlType)
                    {
                        case "Corrective":
                            ControlAssessment = "Inadequate";
                            break;
                        case "Detective":
                        case "Preventive":
                            ControlAssessment = "Needs Improvement";
                            break;
                        default:
                            ControlAssessment = "Unrated";
                            break;
                    }
                    break;
                case "Manual":
                    switch (ControlType)
                    {
                        case "Corrective":
                        case "Detective":
                            ControlAssessment = "Inadequate";
                            break;
                        case "Preventive":
                            ControlAssessment = "Needs Improvement";
                            break;
                        default:
                            ControlAssessment = "Unrated";
                            break;
                    }
                    break;
                default:
                    ControlAssessment = "Unrated";
                    break;
            }           


            return ControlAssessment;

        }
        private static string CalculateControlQuality(string ControlDesign, string ControlType,string? OutputType)
        {
            string ControlQuality = "";
            string ResidualRiskRating = "";
            string ReturnValue = "";

            switch (ControlDesign)
            {
                case "Automated":
                    switch (ControlType)
                    {
                        case "Preventive":
                        case "Detective":
                            ControlQuality = "High";
                            break;
                        case "Corrective":
                            ControlQuality = "Medium";
                            break;
                        default:
                            ControlQuality = "Unrated";
                            break;
                    }
                    break;
                case "Semi-Automated":
                    switch (ControlType)
                    {
                        case "Corrective":
                            ControlQuality = "Low";
                            break;
                        case "Detective":
                            ControlQuality = "Medium";
                            break;
                        case "Preventive":
                            ControlQuality = "High";
                            break;
                        default:
                            ControlQuality = "Unrated";
                            break;
                    }
                    break;
                case "Manual":
                    switch (ControlType)
                    {
                        case "Corrective":
                        case "Detective":
                            ControlQuality = "Low";
                            break;
                        case "Preventive":
                            ControlQuality = "Medium";
                            break;
                        default:
                            ControlQuality = "Unrated";
                            break;
                    }
                    break;
                default:
                    ControlQuality = "Unrated";
                    break;
            }

            if (OutputType == "ResidualRiskRating")
            {
                switch (ControlQuality)
                {
                    case "High":
                        ResidualRiskRating = "Low";
                        break;
                    case "Medium":
                        ResidualRiskRating = "Medium";
                        break;
                    case "Low":
                        ResidualRiskRating = "High";
                        break;
                    default:
                        ResidualRiskRating = "Unrated"; 
                        break;
                }

                ReturnValue = ResidualRiskRating;

            }
            else if (OutputType == "ControlQuality")
            {
                ReturnValue = ControlQuality;
            }

            return ReturnValue;

        }
        private static string CalculateControlEffectiveness(string ControlDesign, string ControlType)
        {
            string ControlEffectiveness = "UNRATED";

            switch (ControlDesign)
            {
                case "Automated":
                    switch (ControlType)
                    {
                        case "Preventive":
                        case "Detective":
                            ControlEffectiveness = "Almost Certain";
                            break;
                        case "Corrective":
                            ControlEffectiveness = "Probable";
                            break;
                    }
                    break;
                case "Semi-Automated":
                    switch (ControlType)
                    {
                        case "Corrective":
                            ControlEffectiveness = "Rare";
                            break;
                        case "Detective":
                            ControlEffectiveness = "Probable";
                            break;
                        case "Preventive":
                            ControlEffectiveness = "Almost Certain";
                            break;
                    }
                    break;
                case "Manual":
                    switch (ControlType)
                    {
                        case "Corrective":
                        case "Detective":
                            ControlEffectiveness = "Rare";
                            break;
                        case "Preventive":
                            ControlEffectiveness = "Probable";
                            break;
                    }
                    break;
            }

            return ControlEffectiveness;

        }

    }
}