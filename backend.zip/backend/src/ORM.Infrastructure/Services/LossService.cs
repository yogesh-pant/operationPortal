﻿using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using System.Data;
using ORM.Application.Interfaces.Common;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using ORM.Application.Models.Requests.Mails;
using System.Text;
using ORM.Domain.Common;
using ORM.Infrastructure.Services.Common;
using OtpNet;
using System.Configuration;

namespace ORM.Infrastructure.Services
{
    public class LossService : ILossService
    {
        private readonly ILogger<LossService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;
        private readonly IAzueBlobStorageService azueBlobStorageService;
        private readonly IEmailService mailService;
        private readonly IConfiguration configuration;

        public LossService(ILogger<LossService> logger, ISessionService sessionService, IConfiguration configuration, IUnitOfWork unitOfWork, IAzueBlobStorageService azueBlobStorageService, IEmailService mailService)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
            this.azueBlobStorageService = azueBlobStorageService;
            this.mailService = mailService;
            this.configuration = configuration;
        }
        /// <summary>
        /// This function is used to get the list of users
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<LossDataGridResponse>> GetLossGridAsync(LossGridRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<LossDataGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);
            if (input == null)
            {
                return new ListResponse<LossDataGridResponse>("Invalid input", ResponseCodes.DataNotFound);
            }
            var lossListQuery = unitOfWork.ORMLossReport
                        .GetAll().AsQueryable()
                        .Select(lossreport => new LossDataGrid
                        {
                            Id = lossreport!.Id,
                            RefNum = lossreport!.RefNum,
                            ValidatorILOid = lossreport!.ValidatorILOUserId,
                            ValidatorILOUserName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport!.ValidatorILOUserId)!.UserName ?? "User Not Found",
                            PrevLossReportId = lossreport!.PrevLossReportId,
                            InternalBusinessLineId = lossreport!.InternalBusLine,
                            LossType = lossreport!.LossType,
                            Currency = lossreport!.CurrencyType,
                            DateOfOccurrence = lossreport!.DateOccurance,
                            DateDiscovered = lossreport!.DateDiscovery,
                            DateReported = lossreport!.DateReported,
                            DetailedLossEvent = lossreport!.Description,
                            NearMiss = lossreport!.NearMissAmount,
                            PotentialLoss = lossreport!.PotentialLossAmount,
                            GrossActualLoss = lossreport!.GrossActualAmount,
                            AmountRecovered = lossreport!.RecoveredAmount,
                            FurtherRecovery = lossreport!.FurtherRecoveredAmount,
                            NetActualLoss = lossreport!.NetActualLossAmount,
                            RootCause = lossreport!.RootCauseRLO,
                            RiskSourceId = lossreport!.RiskSource,
                            AmountInvolved = lossreport!.AmountInvolved,
                            ProcessInvolved = lossreport!.ProcessInvolved,
                            RecoveryMode = lossreport!.RecoveryChannel,
                            EventStatus = lossreport!.EventStatus,
                            Branch = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.LocationId)!.Branch ?? "",
                            Region = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.LocationId)!.Region ?? "",
                            Department = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.LocationId)!.Department ?? "",
                            ReportStatus = lossreport!.ReportStatus,
                            StaffInvolvement = lossreport!.StaffInvolvement,
                            ModifiedBy = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.ModifiedById!)!.UserName ?? "User Not Found",
                            ModifiedDate = lossreport!.ModifiedDate,
                            ApprovedDate = lossreport!.ApprovedDate,
                            CreatedBy = lossreport.CreatedById!,
                            CreatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.CreatedById!)!.UserName ?? "User Not Found",
                            ApprovedBy = lossreport.ApprovedById!,
                            ApprovedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.ApprovedById!)!.UserName ?? "User Not Found",
                            LocationId = lossreport.LocationId!,
                            LocationName = (lossreport!.LocationType == "B") ? unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport!.LocationId)!.Branch : unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == lossreport.LocationId)!.Department,
                            LocationType = lossreport.LocationType!,
                            StaffJobRole = lossreport.StaffJobRole,
                            BaselEventTypeI = lossreport.BaselEventTypeI,
                            BaselEventTypeII = lossreport.BaselEventTypeII,
                            BaselEventTypeIII = lossreport.BaselEventTypeIII,
                            BaselLevel1BusinessLine = lossreport.BaselLevel1BusinessLine,
                            BaselLevel2BusinessLine = lossreport.BaselLevel2BusinessLine,
                            RootCauseTypeBORM = lossreport.RootCauseTypeBORM,
                            RiskSource = lossreport.RiskSource,
                            LessonLearnt = lossreport.LessonLearnt,
                            ReviewerComments = lossreport.ReviewerComments,
                            UpdateHistory = lossreport.UpdateHistory,
                        });

            GetLossGridApplyFilters(ref lossListQuery, input);

            var totalCount = lossListQuery!.Count();

            if (totalCount == 0)
            {
                return new ListResponse<LossDataGridResponse>("No record found for given input")
                {
                    Data = { },
                    Total = totalCount
                };
            }

            var lossStatusCounts = await lossListQuery
                .GroupBy(lossreport => lossreport.ReportStatus)
                .Select(group => new
                {
                    Status = group.Key,
                    Count = group.Count()
                })
                .ToDictionaryAsync(x => x.Status!, x => x.Count);

            var recordCount = new RecordCount
            {
                SubmittedCount = lossStatusCounts.GetValueOrDefault("Submitted", 0),
                DraftCount = lossStatusCounts.GetValueOrDefault("Draft", 0),
                RejectCount = lossStatusCounts.GetValueOrDefault("Rejected", 0),
                ApprovedCount = lossStatusCounts.GetValueOrDefault("Approved", 0),
                AUpdatedByBORMCount = lossStatusCounts.GetValueOrDefault("Approved-UpdatedByBORM", 0),
            };

            if (SearchFilters.IsValidStringFilter(input.reportStatus))
                lossListQuery = lossListQuery.Where(p => p.ReportStatus == input.reportStatus);

            lossListQuery = lossListQuery.Paginate(input);

            var responseData = await lossListQuery!.ToListAsync();

            var responses = new LossDataGridResponse(responseData, recordCount);

            logger.LogInformation("Successfully Retrieved Loss grid data");

            return new ListResponse<LossDataGridResponse>("Successfully Retrieved Loss grid data")
            {
                Data = new List<LossDataGridResponse> { responses },
                Total = totalCount
            };
        }

        private static void GetLossGridApplyFilters(ref IQueryable<LossDataGrid> lossListQuery, LossGridRequest input)
        {

            if (input.minDate is not null || input.maxDate is not null)
                lossListQuery = lossListQuery.Where(p =>
                (input.minDate == null || p.DateOfOccurrence >= InputTimeFormat.ConvertTo00AMFormat(input.minDate.Value)) &&
                (input.maxDate == null || p.DateOfOccurrence <= InputTimeFormat.ConvertTo12PMFormat(input.maxDate.Value))
                ).OrderByDescending(x => x.ModifiedDate);

            if (SearchFilters.IsValidNumericFilter(input.LocationId))
                lossListQuery = lossListQuery.Where(p => p.LocationId == input.LocationId);

            if (SearchFilters.IsValidStringFilter(input.LocationType))
                lossListQuery = lossListQuery.Where(p => p.LocationType!.ToLower().Contains(input.LocationType!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.refNo))
                lossListQuery = lossListQuery.Where(p => p.RefNum!.ToLower().Contains(input.refNo!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.branch))
                lossListQuery = lossListQuery.Where(p => p.Branch!.ToLower().Contains(input.branch!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.region))
                lossListQuery = lossListQuery.Where(p => p.Region!.ToLower().Contains(input.region!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.department))
                lossListQuery = lossListQuery.Where(p => p.Department!.ToLower().Contains(input.department!.ToLower()));

            if (SearchFilters.IsValidStringFilter(input.eventStatus))
                lossListQuery = lossListQuery.Where(p => p.EventStatus == input.eventStatus);

        }

            public async Task<ListResponse<ReturnId>> CreateLossDataAsync(CreateLossDataRequest input)
        {
            if(input == null)
            {
                return new ListResponse<ReturnId>(" invalid input ", ResponseCodes.DataNotFound);
            }

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            List<string> documents = new() { };
            if (input!.RegistrationDocuments != null)
                for (int i = 0; i < input!.RegistrationDocuments!.Count; i++)
            {
                documents.Add(await azueBlobStorageService.UploadFileAsync(input!.RegistrationDocuments![i]));
            }
            string? refNum = await unitOfWork.GetLossReportRecordCount();
            // Create a new loss report
            var createLossReport = new ORMLossReport
            {
                RefNum = refNum!,
                PrevLossReportId = null,
                LocationId = Convert.ToInt64( input.LocationId),
                LocationType = input.LocationType!,
                ValidatorILOUserId = Convert.ToInt64(input.ValidatorILOUserId),
                DateOccurance = Convert.ToDateTime(input.DateOccurance),
                DateDiscovery = Convert.ToDateTime(input.DateDiscovery),
                DateReported = DateTime.Now,
                Description = input.Description,
                RootCauseRLO = input.RootCauseRLO,
                LossType = input.LossType,
                CurrencyType = input.CurrencyType,
                AmountInvolved =Convert.ToDecimal( input.AmountInvolved),
                NearMissAmount = Convert.ToDecimal(input.NearMissAmount),
                PotentialLossAmount = Convert.ToDecimal(input.PotentialLossAmount),
                GrossActualAmount = Convert.ToDecimal(input.GrossActualAmount),
                RecoveredAmount = Convert.ToDecimal(input.RecoveredAmount),
                FurtherRecoveredAmount = Convert.ToDecimal(input.FurtherRecoveredAmount),
                // Calculated based on GrossActualAmount,RecoveredAmount and FurtherRecoveredAmount
                NetActualLossAmount = Convert.ToDecimal(input.GrossActualAmount) - (Convert.ToDecimal(input.RecoveredAmount) + Convert.ToDecimal(input.FurtherRecoveredAmount)),
                RecoveryChannel = input.RecoveryChannel,
                StaffInvolvement = input.StaffInvolvement,
                EventStatus = input.EventStatus!,
                ReportStatus = input.ReportStatus!,
                CreatedById = Convert.ToInt64(input.CreatedById),
                CreatedDate = DateTime.Now,
                ModifiedDate = DateTime.Now,
                Documents = input!.RegistrationDocuments != null ? documents[0] : "",
                DocumentName = input!.RegistrationDocuments != null ? input.DocumentName : "",

            };

            var response = await unitOfWork.SaveAndGetIdRLOLossDataAsync(createLossReport);

            logger.LogInformation("Successfully created Loss Report ref no {refNum} with response {response}",refNum,response);

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Loss Report Created!", ResponseCodes.Success)
            {
                Data = Response
            };

        }

        public async Task<ListResponse<ReturnId>> UpdateLossDataRLOAsync(UpdateLossDataRloRequest input)
        {
            var session = sessionService.GetStaffSession();
            string userName = "";
            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<ReturnId>(" invalid input ", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<ReturnId>("Loss report not found for id  : " + input.id, ResponseCodes.DataNotFound);

            }
            List<string> documents = new () { };
            if (input!.RegistrationDocuments != null)
            {
                for (int i = 0; i < input!.RegistrationDocuments!.Count; i++)
                {
                    documents.Add(await azueBlobStorageService.UploadFileAsync(input!.RegistrationDocuments![i]));
                }
            }

            var lossReport = await (from au in unitOfWork.ORMLossReport.GetAll().AsQueryable()
                                   where au.Id == input.id
                                   select au).FirstOrDefaultAsync<ORMLossReport>();
            if (lossReport is not null)
            {

                lossReport.ValidatorILOUserId = input.ValidatorILOUserId;
                lossReport.DateOccurance = input.DateOccurance;
                lossReport.DateDiscovery = input.DateDiscovery;
                lossReport.DateReported = input.DateReported;
                lossReport.Description = input.Description;
                lossReport.RootCauseRLO = input.RootCauseRLO;
                lossReport.LossType = input.LossType;
                lossReport.CurrencyType = input.CurrencyType;
                lossReport.AmountInvolved = input.AmountInvolved;
                lossReport.NearMissAmount = input.NearMissAmount;
                lossReport.PotentialLossAmount = input.PotentialLossAmount;
                lossReport.GrossActualAmount = input.GrossActualAmount;
                lossReport.RecoveredAmount = input.RecoveredAmount;
                lossReport.FurtherRecoveredAmount = input.FurtherRecoveredAmount;
                // Calculated based on GrossActualAmount,RecoveredAmount and FurtherRecoveredAmount
                lossReport.NetActualLossAmount = input.GrossActualAmount - input.RecoveredAmount - input.FurtherRecoveredAmount;
                lossReport.RecoveryChannel = input.RecoveryChannel;
                lossReport.StaffInvolvement = input.StaffInvolvement;
                lossReport.EventStatus = input.EventStatus!;
                if (input.ReportStatus! == "Submitted")
                {
                    lossReport.DateReported = DateTime.Now;
                    userName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == input.ModifiedById!)!.UserName ?? "User Not Found";
                    lossReport.UpdateHistory += "------------" + "\r\n" +
                                                "Submitted on - " + DateTime.Now.ToString("yyyy-MM-dd") + " by - " + userName + "\r\n" +
                                                "------------" + "\r\n";
                }
                lossReport.ReportStatus = input.ReportStatus!;
                lossReport.ModifiedById = input.ModifiedById;
                lossReport.ModifiedDate = DateTime.Now;
                if (documents.Count > 0)
                {
                    lossReport.Documents = documents[0];
                    lossReport.DocumentName = input.DocumentName;
                }
            }
            else
            {
                return new ListResponse<ReturnId>("Can not find requested data", ResponseCodes.DataNotFound);

            }

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully updated Loss Report id - {input.id} ", response);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("Loss Report Updated!", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        public async Task<ListResponse<ReturnId>> UpdateLossDataBORMAsync(UpdateLossDataBormRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<ReturnId>(" invalid input ", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<ReturnId>("Loss report not found for id  : " + input.id, ResponseCodes.DataNotFound);

            }
            
            string userName = ""; 

            var lossReport = await (from au in unitOfWork.ORMLossReport.GetAll().AsQueryable()
                                    where au.Id == input.id
                                    select au).FirstOrDefaultAsync<ORMLossReport>();
            if (lossReport is not null)
            {

                if (lossReport.ReportStatus.Contains("UpdatedByBORM"))
                {
                    string differences = FindDifferences(lossReport, input, logger);
                    if (differences != null)
                    {
                        userName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == input.ModifiedById!)!.UserName ?? "User Not Found";
                        lossReport.UpdateHistory += "------------" + "\r\n" +
                                            "Updates Done on - " + DateTime.Now.ToString("yyyy-MM-dd") + 
                                            " By - " + userName + "\r\n" + differences;
                    }
                }
                lossReport.StaffJobRole = input.StaffJobRole;
                lossReport.InternalBusLine = input.InternalBusLine;
                lossReport.BaselEventTypeI = input.BaselEventTypeI;
                lossReport.BaselEventTypeII = input.BaselEventTypeII;
                lossReport.BaselEventTypeIII = input.BaselEventTypeIII;
                lossReport.BaselLevel1BusinessLine = input.BaselLevel1BusinessLine;
                lossReport.BaselLevel2BusinessLine = input.BaselLevel2BusinessLine;
                lossReport.RootCauseTypeBORM = input.RootCauseTypeBORM;
                lossReport.ProcessInvolved = input.ProcessInvolved;
                lossReport.RiskSource = input.RiskSource;
                lossReport.LessonLearnt = input.LessonLearnt;
                lossReport.ReportStatus = input.ReportStatus!;
                lossReport.ModifiedById = input.ModifiedById;
                lossReport.ModifiedDate = DateTime.Now;
            }
            else
            {
                logger.LogError("Loss Service - Update Loss Report - Unable to find requested data Loss Report id. - {id} ", input.id);
                return new ListResponse<ReturnId>("Unable to find requested data", ResponseCodes.DataNotFound);

            }

            var response = unitOfWork.Save();

            logger.LogInformation("Loss Service - Admin Successfully updated Loss Report No. - {id} ", lossReport.RefNum);

            ReturnId result = new ReturnId
            {
                id = response
            };

            List<ReturnId> Response = new List<ReturnId>
            {
               result
            };


            return new ListResponse<ReturnId>("Loss Report Updated by Admin!", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        public async Task<ListResponse<ReturnId>> ApproveLossDataBORMAsync(ApproveLossDataBormRequest input)
        {
            var session = sessionService.GetStaffSession();
            string userName = "";

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input == null)
            {
                return new ListResponse<ReturnId>(" invalid input ", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<ReturnId>("Loss report not found for id  : " + input.id, ResponseCodes.DataNotFound);

            }
            
            var lossReport = await (from au in unitOfWork.ORMLossReport.GetAll().AsQueryable()
                                    where au.Id == input.id
                                    select au).FirstOrDefaultAsync<ORMLossReport>();
            if (lossReport is not null)
            {

                userName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == input.ApprovedById!)!.UserName ?? "User Not Found";
                lossReport.UpdateHistory += "------------" + "\r\n" +
                                            input.Action + " on - " + DateTime.Now.ToString("yyyy-MM-dd") + " by - " + userName + "\r\n"; 
                lossReport.ReviewerComments += DateTime.Now.ToString("yyyy-MM-dd") + "--" + "\r\n" + input.ReviewerComments + "\r\n";
                lossReport.ReportStatus = input.Action!;
                lossReport.ApprovedById = input.ApprovedById;
                lossReport.ApprovedDate = DateTime.Now;

            }
            else
            {
                return new ListResponse<ReturnId>("Unable to find requested data", ResponseCodes.DataNotFound);

            }

            var response = unitOfWork.Save();

            logger.LogInformation($"Admin {lossReport!.ReportStatus!} Loss Report id - {response}");

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Loss Report {input.Action!} by Admin!", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        public async Task<ListResponse<GetFullLossDataBySingleIdResponse>> GetFullLossDataBySingleIdAsync(GetFullLossDataBySingleIdRequest input)
        {
            if (input == null)
            {
                return new ListResponse<GetFullLossDataBySingleIdResponse>(" invalid input ", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<GetFullLossDataBySingleIdResponse>("Can not find data for input id :" + input.id, ResponseCodes.DataNotFound);

            }
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<GetFullLossDataBySingleIdResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var LossDataById = await unitOfWork.ORMLossReport
               .GetAll().AsQueryable()
               .Where(LossData => LossData.Id == input.id)
               .Select(LossData => new GetFullLossDataBySingleIdResponse
               {
                   RefNum = LossData.RefNum,
                   ValidatorILOUserId = LossData.ValidatorILOUserId,
                   ValidatorILOUserName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.ValidatorILOUserId)!.UserName ?? "User Not Found",
                   DateOccurance = LossData.DateOccurance,
                   DateDiscovery = LossData.DateDiscovery,
                   DateReported = LossData.DateReported,
                   Description = LossData.Description,
                   RootCauseRLO = LossData.RootCauseRLO,
                   LossType = LossData.LossType,
                   CurrencyType = LossData.CurrencyType,
                   AmountInvolved = LossData.AmountInvolved,
                   NearMissAmount = LossData.NearMissAmount,
                   PotentialLossAmount = LossData.PotentialLossAmount,
                   GrossActualAmount = LossData.GrossActualAmount,
                   RecoveredAmount = LossData.RecoveredAmount,
                   FurtherRecoveredAmount = LossData.FurtherRecoveredAmount,
                   NetActualLossAmount = LossData.NetActualLossAmount,
                   RecoveryChannel = LossData.RecoveryChannel,
                   StaffInvolvement = LossData.StaffInvolvement,
                   EventStatus = LossData.EventStatus,
                   ReportStatus = LossData.ReportStatus,
                   StaffJobRole = LossData.StaffJobRole,
                   InternalBusLine = LossData.InternalBusLine,
                   BaselEventTypeI = LossData.BaselEventTypeI,
                   BaselEventTypeII = LossData.BaselEventTypeII,
                   BaselEventTypeIII = LossData.BaselEventTypeIII,
                   BaselLevel1BusinessLine = LossData.BaselLevel1BusinessLine,
                   BaselLevel2BusinessLine = LossData.BaselLevel2BusinessLine,
                   RootCauseTypeBORM = LossData.RootCauseTypeBORM,
                   ProcessInvolved = LossData.ProcessInvolved,
                   RiskSource = LossData.RiskSource,
                   LessonLearnt = LossData.LessonLearnt,
                   ReviewerComments = LossData.ReviewerComments,
                   UpdateHistory = LossData.UpdateHistory,
                   CreatedById = LossData.CreatedById,
                   CreatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.CreatedById!)!.UserName ?? "User Not Found",
                   ModifiedById = LossData.ModifiedById,
                   ModifiedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.ModifiedById!)!.UserName ?? "User Not Found",
                   ValidatedById = LossData.ValidatedById,
                   ApprovedById = LossData.ApprovedById,
                   ApprovedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.ApprovedById!)!.UserName ?? "User Not Found",
                   CreatedDate = LossData.CreatedDate,
                   ModifiedDate = LossData.ModifiedDate,
                   ValidationDate = LossData.ValidationDate,
                   ApprovedDate = LossData.ApprovedDate,
                   Documents = LossData.Documents!,
                   DocumentName = LossData.DocumentName!,
                   FileType = LossData.Documents!.Substring(LossData.Documents!.LastIndexOf('.') + 1),
                   LocationType=LossData.LocationType,
                   LocationId=LossData.LocationId,
                   Branch= unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.LocationId)!.Branch ?? "",
                   Region = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.LocationId)!.Region ?? "",
                   Department = unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == LossData.LocationId)!.Department ?? "",
               }).FirstOrDefaultAsync();

            if (LossDataById != null)
            {
                var file = await azueBlobStorageService.GetFileAsBase64Async(LossDataById.Documents!);

                LossDataById.Documents = file;
            }
            else
            {
                return new ListResponse<GetFullLossDataBySingleIdResponse>("Unable to find requested data", ResponseCodes.DataNotFound);

            }

            logger.LogInformation("Successfully Retrieved  Loss Data for one Id");

            return new ListResponse<GetFullLossDataBySingleIdResponse>("Successfully Retrieved Loss Data for one id")
            {
                Data = new List<GetFullLossDataBySingleIdResponse> { LossDataById! },
                Total = 1
            };

        }
        public async Task<ListResponse<SendLossRpReviewReminderResponse>> SendLossRpReviewReminder(GetFullLossDataBySingleIdRequest input)
        {
            if (input == null)
            {
                return new ListResponse<SendLossRpReviewReminderResponse>(" invalid input ", ResponseCodes.DataNotFound);
            }
            if (input.id == 0)
            {
                return new ListResponse<SendLossRpReviewReminderResponse>("Loss report not found for id  : " + input.id, ResponseCodes.DataNotFound);

            }
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<SendLossRpReviewReminderResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (input != null)
            {
                var LossDataByValidatorId = await unitOfWork.ORMLossReport
                   .GetAll().AsQueryable()
                   .Where(LossData => LossData.Id == input.id)
                   .Select(LossData => new GetFullLossDataBySingleIdResponse
                   {
                       RefNum = LossData.RefNum,
                       ValidatorILOUserName = unitOfWork.ORMUsers.GetAll().FirstOrDefault(p => p.Id == LossData.ValidatorILOUserId)!.UserName ?? "User Not Found",
                   }).FirstOrDefaultAsync();
                var IcoUser = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(user => user.UserName == LossDataByValidatorId!.ValidatorILOUserName);

                if (LossDataByValidatorId != null && IcoUser != null)
                {
                    string emailBody = GetEmailTemplateForUnlockingAccount();

                    List<KeyValuePair<string, string>> keys = new()
                            {
                                new KeyValuePair<string, string>("{{Username}}", LossDataByValidatorId.ValidatorILOUserName! ),
                            };

                    emailBody = emailBody.UpdatePlaceHolders(keys);
                    var emailPayload = new SendEmailRequest
                    {
                        From = configuration.GetValue<string>("FCMBConfig:EmailConfig:SenderEmail")!,
                        To = IcoUser!.Email,
                        Subject = "Loss Report " + LossDataByValidatorId.RefNum + " is waiting for your review",
                        Body = emailBody
                    };

                    bool mailStatus = await mailService.SendEmailAsync(emailPayload);

                    if (mailStatus)
                    { 
                        logger.LogInformation("Email Reminder for Loss Report Send Successfully to user");
                        return new ListResponse<SendLossRpReviewReminderResponse>("Email Reminder for Loss Report Send Successfully to user", ResponseCodes.Success);
                    }
                    else
                    {
                        logger.LogInformation("Email Reminder for Loss Report failed");
                        return new ListResponse<SendLossRpReviewReminderResponse>("Email Reminder for Loss Report failed", ResponseCodes.ServiceError);
                    }
                }
                else
                {
                    return new ListResponse<SendLossRpReviewReminderResponse>("Unable to find requested data", ResponseCodes.DataNotFound);

                }

            }
            logger.LogError("Invalid loss Report id provided for sending reminder to ICO");
            return new ListResponse<SendLossRpReviewReminderResponse>("Invalid loss Report id provided for sending reminder to ICO");           

        }

        public static string GetEmailTemplateForUnlockingAccount()
        {
            const string text = @"
            <html>
            <body>
              <p>Hi {{Username}},</p>
              <p>Please Logon to ORM application to complete the Loss Report review.</p>
              <p>Best regards,</p>
              <p>ORM</p>
            </body>
            </html>

            ";
            return text;
        }

        [ExcludeFromCodeCoverage]
        private static string FindDifferences(object OldObject, object NewObject, ILogger<LossService> logger)
        {
            StringBuilder differences = new StringBuilder();
            List<string> excludedProperties = new() { "ReviewerComments", "ModifiedById" }; // List of properties to exclude

            // Check if oldObject or newObject is null
            if (OldObject == null || NewObject == null)
            {
                logger.LogInformation("No data found!");
                throw new ArgumentNullException(OldObject == null ? nameof(OldObject) : nameof(NewObject), "Object cannot be null.");
            }
            var commonProperties = NewObject.GetType()
                .GetProperties()
                .Where(p => OldObject.GetType().GetProperty(p.Name) != null);

            commonProperties = commonProperties.Where(p => !excludedProperties.Contains(p.Name));

            foreach (var property in commonProperties)
            {
                object oldValue = "";
                object newValue = "";
                try
                {
                    // Attempt to retrieve the value of the property from newObject
                    PropertyInfo OldProperty = OldObject.GetType().GetProperty(property.Name)!;
                    oldValue = OldProperty.GetValue(OldObject)!;
                }
                catch (TargetException)
                {
                    // Handle cases where the property does not exist in newObject
                    // or the object does not match the target type
                    logger.LogError("Loss Service - Property Difference - Exception in old variable {propertyName}", property.Name);
                    continue;
                }

                try
                {
                    // Attempt to retrieve the value of the property from newObject

                    PropertyInfo NewProperty = NewObject.GetType().GetProperty(property.Name)!;
                    newValue = NewProperty.GetValue(NewObject)!;
                }
                catch (TargetException)
                {
                    // Continue and Log the cases where the property does not exist in newObject
                    // or the object does not match the target type
                    logger.LogError("Loss Service - Property Difference - Exception in new variable {propertyName}", property.Name);
                    continue;
                }


                // Ensure that the types of oldValue and newValue are compatible
                if (oldValue != null && newValue != null && oldValue.GetType() != newValue.GetType())
                {
                // Types are not compatible, skip comparison for this property
                    logger.LogError("Loss Service - Property Difference - mismatch in new and old property type  {propertyName}", property.Name);
                    continue;
                }
                // Calculate difference but limit the text tp 1000 characters 
                if (!Equals(oldValue, newValue))
                {
                    differences.Append("\r\n");
                    differences.Append(" Field Name = ");
                    differences.Append(property.Name);
                    differences.Append(" Old Value = ");
                    differences.Append((oldValue?.ToString()?.Substring(0, Math.Min(oldValue!.ToString()!.Length, 1000))));
                    differences.Append(" New Value = ");
                    differences.Append((newValue?.ToString()?.Substring(0, Math.Min(newValue!.ToString()!.Length, 1000))));
                }
            }
            return differences.ToString();
        }

    }


}






