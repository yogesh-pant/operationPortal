﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Services
{
    public class InputTimeFormat
    {

        protected InputTimeFormat() 
        {
        }
        /// <summary>
        /// Create a new DateTime with the same date but time set to 00:00:00 AM
        /// </summary>
        /// <param name="inputDate"></param>
        /// <returns>fromdate in the request-formatted</returns>
        public static DateTime ConvertTo00AMFormat(DateTime inputDate)
        {
            DateTime fromdate = new DateTime(inputDate.Year, inputDate.Month, inputDate.Day, 0, 0, 0, DateTimeKind.Local);
            return fromdate;
        }
        /// <summary>
        /// Create a new DateTime with the same date but time set to 00:00:00 PM
        /// </summary>
        /// <param name="inputDate"></param>
        /// <returns>toDate in the request-formatted</returns>
        public static DateTime ConvertTo12PMFormat(DateTime inputDate)
        {
            DateTime todate = new DateTime(inputDate.Year, inputDate.Month, inputDate.Day, 23, 59, 59, DateTimeKind.Local);
            return todate;
        }
    }
}