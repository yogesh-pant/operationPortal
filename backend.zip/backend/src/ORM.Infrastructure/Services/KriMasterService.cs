﻿using Azure;
using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Domain.Common;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using System.Data;

namespace ORM.Infrastructure.Services
{
    public class KriMasterService : IKriMasterService
    {
        private readonly ILogger<KriMasterService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;

        public KriMasterService(ILogger<KriMasterService> logger, ISessionService sessionService, IUnitOfWork unitOfWork)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
        }
        /// <summary>
        /// This function is used to get the list of users kri grid export
        /// </summary>   "export kri data "-------- used
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<GetKriMasterGridResponse>> GetKriMasterGridAsync(GetKriMasterGridRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<GetKriMasterGridResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var kriMasterListQuery = unitOfWork.ORMKRIMetricMaster
               .GetAll().AsQueryable()
               .Select(krimaster => new GetKriMasterGridResponse
               {
                   Id = krimaster.Id,
                   KRIMetricId = krimaster.KRIMetricId,
                   LocationId = krimaster.LocationId,
                   LocationName = (krimaster!.LocationType == "B") ? "" : unitOfWork.ORMLocation.GetAll().AsQueryable().FirstOrDefault(p => p.Id == krimaster.LocationId)!.Department,
                   Region = "",
                   LocationType = krimaster.LocationType,
                   MetricName = krimaster.MetricName,
                   Frequency = krimaster.Frequency,
                   AppetiteUpperBound = krimaster.AppetiteUpperBound,
                   AppetiteLowerBound = krimaster.AppetiteLowerBound,
                   AppetiteType = krimaster.AppetiteType,
                   ToleranceLowerBound = krimaster.ToleranceLowerBound,
                   ToleranceUpperBound = krimaster.ToleranceUpperBound,
                   ToleranceType = krimaster.ToleranceType,
                   EscalationLowerBound = krimaster.EscalationLowerBound,
                   EscalationUpperBound = krimaster.EscalationUpperBound,
                   EscalationType = krimaster.EscalationType,
                   IsActive = krimaster.IsActive,
                   Status = krimaster.Status,
                   ReviewerComments = krimaster.ReviewerComments,
                   ChangeRequestDataJson = krimaster.ChangeRequestData,
                   CreatedById = krimaster.CreatedById!,
                   ModifiedById = krimaster.ModifiedById!,
                   ApprovedById = krimaster.ApprovedById!,
                   CreatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == krimaster.CreatedById)!.UserName ?? "",
                   ModifiedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == krimaster.ModifiedById)!.UserName ?? "",
                   ApprovedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == krimaster.ApprovedById)!.UserName ?? "",
                   CreatedDate = krimaster.CreatedDate!,
                   ModifiedDate = krimaster.ModifiedDate!,
                   ApprovedDate = krimaster.ApprovedDate!

               });

            if (SearchFilters.IsValidNumericFilter(input.LocationId))
                kriMasterListQuery = kriMasterListQuery.Where(p => p.LocationId == input.LocationId);

            if (SearchFilters.IsValidStringFilter(input.LocationType))
                kriMasterListQuery = kriMasterListQuery.Where(p => p.LocationType == input.LocationType);

            if (SearchFilters.IsValidStringFilter(input.MetricName))
                kriMasterListQuery = kriMasterListQuery.Where(p => p.MetricName == input.MetricName);

            if (SearchFilters.IsValidStringFilter(input.Frequency))
                kriMasterListQuery = kriMasterListQuery.Where(p => p.Frequency == input.Frequency);

            if (SearchFilters.IsValidStringFilter(input.Status))
                kriMasterListQuery = kriMasterListQuery.Where(p => p.Status == input.Status);

            if (input.IsActive is not null)
            {
                kriMasterListQuery = kriMasterListQuery.Where(p => p.IsActive == input.IsActive);
            }
               
            var totalCount = kriMasterListQuery.Count();
            if (totalCount == 0)
            {
                return new ListResponse<GetKriMasterGridResponse>("No record found for given input", ResponseCodes.DataNotFound)
                {
                    Data = { },
                    Total = totalCount
                };
            }
            if (totalCount > 0)
            {
                kriMasterListQuery = kriMasterListQuery.SortBy(x => x.ModifiedDate);

            }
            if (kriMasterListQuery.Any())
            {
                kriMasterListQuery = kriMasterListQuery.Paginate(input);
            }

            var response = await kriMasterListQuery.ToListAsync();
            response = ExtractChangeRequestData(response);
            logger.LogInformation("Successfully Retrieved  KRI master data for Location {input.LocationName} with {response} -", input.LocationName, response);

            return new ListResponse<GetKriMasterGridResponse>("Successfully Retrieved KRI master data")
            {
                Data = response,
                Total = totalCount
            };

        }
        private List<GetKriMasterGridResponse> ExtractChangeRequestData(List<GetKriMasterGridResponse> response)
        {
            foreach (var metric in response)
            {
                if (string.IsNullOrEmpty(metric.ChangeRequestDataJson))
                {
                    InitializeEmptyChangeData(metric);
                    continue;
                }

                try
                {
                    var jObject = JObject.Parse(metric.ChangeRequestDataJson ?? "{}");
                    var ChangeData = jObject.ToObject<KRIMasterChangeData>();

                    if (ChangeData != null)
                    {
                        metric.ChangeRequestData = new KRIMasterChangeData()
                        {
                            MetricNewName = ChangeData.MetricNewName ?? string.Empty,
                            MetricNewFrequency = ChangeData.MetricNewFrequency ?? string.Empty,
                            KRIMasterNewFlag = ChangeData.KRIMasterNewFlag ?? "No",
                            MetricNewActivationStatus = ChangeData.MetricNewActivationStatus,
                            MetricNewAppetiteLowerBound = ChangeData.MetricNewAppetiteLowerBound ?? string.Empty,
                            MetricNewAppetiteUpperBound = ChangeData.MetricNewAppetiteUpperBound ?? string.Empty,
                            MetricNewAppetiteType = ChangeData.MetricNewAppetiteType ?? string.Empty,
                            MetricNewToleranceLowerBound = ChangeData.MetricNewToleranceLowerBound ?? string.Empty,
                            MetricNewToleranceUpperBound = ChangeData.MetricNewToleranceUpperBound ?? string.Empty,
                            MetricNewToleranceType = ChangeData.MetricNewToleranceType ?? string.Empty,
                            MetricNewEscalationLowerBound = ChangeData.MetricNewEscalationLowerBound ?? string.Empty,
                            MetricNewEscalationUpperBound = ChangeData.MetricNewEscalationUpperBound ?? string.Empty,
                            MetricNewEscalationType = ChangeData.MetricNewEscalationType ?? string.Empty,
                            MetricNewUpdatedByName = ChangeData.MetricNewUpdatedByName ?? string.Empty,
                            MetricNewChangeRequestDate = ChangeData.MetricNewChangeRequestDate ?? null,
                        };
                    }
                    else
                    {
                        InitializeEmptyChangeData(metric);
                    }
                }
                catch (JsonException ex)
                {
                    logger.LogError(ex, "Error parsing ChangeRequestData JSON for user {MetricId}", metric.Id);
                    InitializeEmptyChangeData(metric);
                }
            }

            return response;
        }
        private static void InitializeEmptyChangeData(GetKriMasterGridResponse metric)
        {
            // First, check if ChangeRequestData is null and initialize it if necessary
            metric.ChangeRequestData ??= new KRIMasterChangeData();
            metric.ChangeRequestData!.MetricNewName                 = null;
            metric.ChangeRequestData!.MetricNewFrequency            = null;
            metric.ChangeRequestData!.KRIMasterNewFlag              = "No";
            metric.ChangeRequestData!.MetricNewActivationStatus     = null;
            metric.ChangeRequestData!.MetricNewAppetiteLowerBound   = null;
            metric.ChangeRequestData!.MetricNewAppetiteUpperBound   = null;
            metric.ChangeRequestData!.MetricNewAppetiteType         = null;
            metric.ChangeRequestData!.MetricNewToleranceLowerBound  = null;
            metric.ChangeRequestData!.MetricNewToleranceUpperBound  = null;
            metric.ChangeRequestData!.MetricNewToleranceType        = null;
            metric.ChangeRequestData!.MetricNewEscalationLowerBound = null;
            metric.ChangeRequestData!.MetricNewEscalationUpperBound = null;
            metric.ChangeRequestData!.MetricNewEscalationType       = null;
            metric.ChangeRequestData!.MetricNewUpdatedByName        = null;
            metric.ChangeRequestData!.MetricNewChangeRequestDate    = null;
        }

        public async Task<ListResponse<ReturnId>> CreateKriMasterAsync(CreateKriMasterRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            // Create a KRI Master Metric Record 
            string LocationString = input.LocationId.ToString().PadLeft(5, '0');

            string? KRIMetricId = await unitOfWork.GetKRIMasterRecordCount(LocationString);

            var KRIMasterChangeData = new KRIMasterChangeData
            {
                KRIMasterNewFlag = "Yes",
                MetricNewActivationStatus = true,
                MetricNewUpdatedBy = session.UserId,
                MetricNewUpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == session.UserId)!.UserName ?? "",
                MetricNewChangeRequestDate = DateTime.Now
            };
            string KRIMasterChangeDatajsonString = JsonConvert.SerializeObject(KRIMasterChangeData);

            var CreateKriMaster = new ORMKRIMetricMaster
            {
                KRIMetricId = KRIMetricId!,
                LocationId = input.LocationId!,
                LocationType = input.LocationType!,
                MetricName = input.MetricName!,
                Frequency = input.Frequency!,
                AppetiteUpperBound = input.AppetiteUpperBound,
                AppetiteLowerBound = input.AppetiteLowerBound,
                AppetiteType = input.AppetiteType,
                ToleranceLowerBound = input.ToleranceLowerBound,
                ToleranceUpperBound = input.ToleranceUpperBound,
                ToleranceType = input.ToleranceType,
                EscalationLowerBound = input.EscalationLowerBound,
                EscalationUpperBound = input.EscalationUpperBound,
                EscalationType = input.EscalationType,
                IsActive = false,
                CreatedById = input.CreatedById!,
                CreatedDate = DateTime.Now,
                Status = "Pending",
                ChangeRequestData = KRIMasterChangeDatajsonString
            };

            var response = await unitOfWork.SaveAndGetIdKriMasterAsync(CreateKriMaster);

            logger.LogInformation("Successfully Submitted New MetricKRI Master for Location {input.LocationId} with {response} ", input.LocationId,response);

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Successfully Submitted New MetricKRI Master", ResponseCodes.Success)
            {
                Data = Response
            };

        }
        public async Task<ListResponse<ReturnId>> UpdateKriMasterAsync(UpdateKriMasterRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var KRIMetricMasterData = await (from au in unitOfWork.ORMKRIMetricMaster.GetAll().AsQueryable()
                                      where au.Id == input.Id
                                      select au).FirstOrDefaultAsync<ORMKRIMetricMaster>();
            if (KRIMetricMasterData is null)
                return new ListResponse<ReturnId>("KRI Metric Master Data Not Found", ResponseCodes.DataNotFound) { Data = null! };

            if (KRIMetricMasterData.Status == "Pending")
                return new ListResponse<ReturnId>("KRI Metric Master info change is Pending Review, No Change Allowed ", ResponseCodes.DataNotFound) { Data = null! };
            var KRIMasterChangeDatajsonString = PopulateKRIMasterChangeData(KRIMetricMasterData, input);

            if (KRIMasterChangeDatajsonString == null)
                return new ListResponse<ReturnId>("No changes made in KRI Master data!", ResponseCodes.ServiceError);

            KRIMetricMasterData.Status = "Pending";
            KRIMetricMasterData.ChangeRequestData = KRIMasterChangeDatajsonString;

            var response = unitOfWork.Save();

            logger.LogInformation("Successfully Submitted Update Request for KRI Metric Master - {input.Id} with {response} -", input.Id, response);

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Successfully Submitted Update Request for KRI Metric Master", ResponseCodes.Success)
            {
                Data = Response
            };


        }
        private string? PopulateKRIMasterChangeData(ORMKRIMetricMaster KRIMetricMasterData, UpdateKriMasterRequest input)
        {
            var KRIMasterChangeData = new KRIMasterChangeData
            {
                KRIMasterNewFlag = "No",
                MetricNewActivationStatus = null,
                MetricNewUpdatedBy = input.ModifiedById,
                MetricNewUpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == input.ModifiedById)?.UserName ?? "",
                MetricNewChangeRequestDate = DateTime.Now
            };

            bool ChangeFlag = false;

            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.MetricName, input.MetricName,
                newValue => KRIMasterChangeData.MetricNewName = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.Frequency, input.Frequency,
                newValue => KRIMasterChangeData.MetricNewFrequency = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.AppetiteUpperBound, input.AppetiteUpperBound,
                newValue => KRIMasterChangeData.MetricNewAppetiteUpperBound = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.AppetiteLowerBound, input.AppetiteLowerBound,
                newValue => KRIMasterChangeData.MetricNewAppetiteLowerBound = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.AppetiteType, input.AppetiteType,
                newValue => KRIMasterChangeData.MetricNewAppetiteType = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.ToleranceUpperBound, input.ToleranceUpperBound,
                newValue => KRIMasterChangeData.MetricNewToleranceUpperBound = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.ToleranceLowerBound, input.ToleranceLowerBound,
                newValue => KRIMasterChangeData.MetricNewToleranceLowerBound = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.ToleranceType, input.ToleranceType,
                newValue => KRIMasterChangeData.MetricNewToleranceType = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.EscalationUpperBound, input.EscalationUpperBound,
                newValue => KRIMasterChangeData.MetricNewEscalationUpperBound = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.EscalationLowerBound, input.EscalationLowerBound,
                newValue => KRIMasterChangeData.MetricNewEscalationLowerBound = newValue);
            ChangeFlag |= UpdatePropertyIfChanged(KRIMetricMasterData.EscalationType, input.EscalationType,
                newValue => KRIMasterChangeData.MetricNewEscalationType = newValue);

            if (!ChangeFlag)
                return null;

            string KRIMasterChangeDatajsonString = JsonConvert.SerializeObject(KRIMasterChangeData);
            return KRIMasterChangeDatajsonString;
        }

        private static bool UpdatePropertyIfChanged<T>(T currentValue, T newValue, Action<T> updateAction)
        {
            if (!EqualityComparer<T>.Default.Equals(currentValue, newValue))
            {
                updateAction(newValue);
                return true;
            }
            return false;
        }

        public async Task<ListResponse<ReturnId>> ToggleKriMasterStatusAsync(ToggleKriMasterStatusRequest input)
        {

            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var KRIMetricMasterData = await (from au in unitOfWork.ORMKRIMetricMaster.GetAll().AsQueryable()
                                             where au.Id == input.Id
                                             select au).FirstOrDefaultAsync<ORMKRIMetricMaster>();
            if (KRIMetricMasterData is null)
                return new ListResponse<ReturnId>("KRI Metric Master Data Not Found", ResponseCodes.DataNotFound) { Data = null! };

            if (KRIMetricMasterData.Status == "Pending")
                return new ListResponse<ReturnId>("KRI Metric Master info change is Pending Review, No Change Allowed ", ResponseCodes.ServiceError) { Data = null! };

            if (KRIMetricMasterData.IsActive == input.IsActive)
                return new ListResponse<ReturnId>("KRI Metric Master Status Toggling to same value, No Change Applied ", ResponseCodes.ServiceError) { Data = null! };

            var KRIMasterChangeData = new KRIMasterChangeData
            {
                KRIMasterNewFlag = "No",
                MetricNewActivationStatus = input.IsActive,
                MetricNewUpdatedBy = session.UserId,
                MetricNewUpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == session.UserId)!.UserName ?? "",
                MetricNewChangeRequestDate = DateTime.Now
            };
            string KRIMasterChangeDatajsonString = JsonConvert.SerializeObject(KRIMasterChangeData);

            KRIMetricMasterData.Status = "Pending";
            KRIMetricMasterData.ChangeRequestData = KRIMasterChangeDatajsonString;


            var response = unitOfWork.Save();

            logger.LogInformation("Successfully Submitted Toggle Status Request for KRI Metric Master  - {input.Id} with {response} -", input.Id, response);

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("Successfully Submitted Toggle Status Request for KRI Metric Master", ResponseCodes.Success)
            {
                Data = Response
            };


        }
        public async Task<ListResponse<string>> ApproveKRIMasterChangeAsync(ReviewUserChangeRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var KRIMetricMasterData = await (from au in unitOfWork.ORMKRIMetricMaster.GetAll().AsQueryable()
                                             where au.Id == input.Id
                                             select au).FirstOrDefaultAsync<ORMKRIMetricMaster>();
            if (KRIMetricMasterData is null)
                return new ListResponse<string>("KRI Metric Master Data Not Found", ResponseCodes.DataNotFound) { Data = null! };

            if (KRIMetricMasterData.Status != "Pending")
                return new ListResponse<string>("KRI Metric Master info change is Not Pending Review ", ResponseCodes.ServiceError) { Data = null! };

            UpdateApprovedMetric(KRIMetricMasterData, input, session.UserId);
            unitOfWork.Save();

            logger.LogInformation("Approved Metric Master Update request for KRI Master - {MetricName} with Comments {ChangeReviewComments} ", KRIMetricMasterData.KRIMetricId, input.ChangeReviewComments);
            return new ListResponse<string>("KRI Metric Master Update request approved and record updated successfully ", ResponseCodes.Success);
        }

        protected internal static void UpdateApprovedMetric(ORMKRIMetricMaster KRIMetricMasterData, ReviewUserChangeRequest request, long ReviewedById)
        {
            // Deserialize the JSON string back to UserChangeData object
            KRIMasterChangeData KRIMasterChangeData = JsonConvert.DeserializeObject<KRIMasterChangeData>(KRIMetricMasterData.ChangeRequestData!)!;
            KRIMetricMasterData.MetricName         = KRIMasterChangeData.MetricNewName ?? KRIMetricMasterData.MetricName;
            KRIMetricMasterData.Frequency          = KRIMasterChangeData.MetricNewFrequency ?? KRIMetricMasterData.Frequency;
            KRIMetricMasterData.IsActive           = KRIMasterChangeData.MetricNewActivationStatus ?? KRIMetricMasterData.IsActive;
            KRIMetricMasterData.AppetiteUpperBound = KRIMasterChangeData.MetricNewAppetiteUpperBound ?? KRIMetricMasterData.AppetiteUpperBound;
            KRIMetricMasterData.AppetiteLowerBound = KRIMasterChangeData.MetricNewAppetiteLowerBound ?? KRIMetricMasterData.AppetiteLowerBound;
            KRIMetricMasterData.AppetiteType       = KRIMasterChangeData.MetricNewAppetiteType ?? KRIMetricMasterData.AppetiteType;
            KRIMetricMasterData.ToleranceUpperBound = KRIMasterChangeData.MetricNewToleranceUpperBound ?? KRIMetricMasterData.ToleranceUpperBound;
            KRIMetricMasterData.ToleranceLowerBound = KRIMasterChangeData.MetricNewToleranceLowerBound ?? KRIMetricMasterData.ToleranceLowerBound;
            KRIMetricMasterData.ToleranceType       = KRIMasterChangeData.MetricNewToleranceType ?? KRIMetricMasterData.ToleranceType;
            KRIMetricMasterData.EscalationUpperBound = KRIMasterChangeData.MetricNewEscalationUpperBound ?? KRIMetricMasterData.EscalationUpperBound;
            KRIMetricMasterData.EscalationLowerBound = KRIMasterChangeData.MetricNewEscalationLowerBound ?? KRIMetricMasterData.EscalationLowerBound;
            KRIMetricMasterData.EscalationType       = KRIMasterChangeData.MetricNewEscalationType ?? KRIMetricMasterData.EscalationType;
            KRIMetricMasterData.ModifiedDate        = KRIMasterChangeData.MetricNewChangeRequestDate ?? KRIMetricMasterData.ModifiedDate;
            KRIMetricMasterData.ModifiedById        = KRIMasterChangeData.MetricNewUpdatedBy ?? KRIMetricMasterData.ModifiedById;
            KRIMetricMasterData.ApprovedById        = ReviewedById;
            KRIMetricMasterData.ApprovedDate        = DateTime.Now;
            KRIMetricMasterData.ReviewerComments    = request.ChangeReviewComments;
            KRIMetricMasterData.Status = "Approved";
        }
        /// <summary>
        /// This Task is used to Reject the KRI Metric Master change request by Maker and update the Change status as Rejected
        /// </summary>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns>
        /// UserResponse
        /// </returns>

        public async Task<ListResponse<string>> RejectKRIMasterChangeAsync(ReviewUserChangeRequest input)
        {
            var session = sessionService.GetStaffSession();

            if (session is null)
                return new ListResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var KRIMetricMasterData = await (from au in unitOfWork.ORMKRIMetricMaster.GetAll().AsQueryable()
                                             where au.Id == input.Id
                                             select au).FirstOrDefaultAsync<ORMKRIMetricMaster>();
            if (KRIMetricMasterData is null)
                return new ListResponse<string>("KRI Metric Master Data Not Found", ResponseCodes.DataNotFound) { Data = null! };

            if (KRIMetricMasterData.Status != "Pending")
                return new ListResponse<string>("KRI Metric Master info change is Not Pending Review ", ResponseCodes.ServiceError) { Data = null! };

            KRIMetricMasterData.ApprovedById = session.UserId;
            KRIMetricMasterData.ApprovedDate = DateTime.Now;
            KRIMetricMasterData.ReviewerComments = input.ChangeReviewComments;
            KRIMetricMasterData.Status = "Rejected";
            unitOfWork.Save();

            logger.LogInformation("Rejected Metric Master Update request for KRI Master - {MetricName} with Comments {ChangeReviewComments} ", KRIMetricMasterData.KRIMetricId, input.ChangeReviewComments);
            return new ListResponse<string>("KRI Metric Master Update request rejected and record updated successfully ", ResponseCodes.Success);
        }

    }
}
