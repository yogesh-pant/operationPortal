﻿using Fcmb.Shared.Auth.Models.Responses;
using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.User;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.UOW;
using Fcmb.Shared.Auth.Services;
using System.Data;
using ORM.Domain.Common;
using Newtonsoft.Json;
using Azure;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace ORM.Infrastructure.Services
{
    public class UserService : IUserService
    {
        private readonly ILogger<UserService> logger;
        private readonly ISessionService sessionService;
        private readonly IUnitOfWork unitOfWork;
        private readonly IAuthService authService;


        public UserService(ILogger<UserService> logger, ISessionService sessionService, IUnitOfWork unitOfWork, IAuthService authService)
        {
            this.logger = logger;
            this.sessionService = sessionService;
            this.unitOfWork = unitOfWork;
            this.authService = authService;

        }
        /// <summary>
        /// This function is used to get the list of users
        /// </summary>
        /// <param name="filterUserRequest"></param>
        /// <returns></returns>
        public async Task<ListResponse<UserResponse>> GetAllUserAsync(FilterUserRequest filterUserRequest)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<UserResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var userListQuery = unitOfWork.ORMUsers.GetAll().AsQueryable()
                                .Join(unitOfWork.ORMRoles.GetAll().AsQueryable(),
                                    au => au.RoleId ?? -1,
                                    ro => ro.RoleId,
                                    (au, ro) => new { au, ro })
                                .Join(unitOfWork.ORMUserLocationMap.GetAll().AsQueryable(),
                                    join1 => join1.au.Id,
                                    lo => lo.UserId,
                                    (join1, lo) => new { join1.au, join1.ro, lo })
                                .GroupBy(item => new
                                {
                                    item.au.Id,
                                    item.au.UserName,
                                    item.au.Email,
                                    item.au.StaffId,
                                    item.au.Status,
                                    item.au.UserChangeStatus,
                                    item.au.RoleId,
                                    item.ro.RoleTitle,
                                    item.au.SubRoleId,
                                    item.au.FailedLoginCount,
                                    item.au.LastLoginTime,
                                    item.au.CurrentLoginTime,
                                    item.au.ChangeRequestData,
                                    item.au.CreatedBy,
                                    item.au.CreatedDate,
                                    item.au.UpdatedBy,
                                    item.au.ChangeRequestDate,
                                    item.au.ReviewedBy,
                                    item.au.ChangeReviewDate,
                                    item.au.ChangeReviewComments
                                })
                                .Select(group => new UserResponse
                                {
                                    UserId = group.Key.Id,
                                    EmailId = group.Key.Email,
                                    UserName = group.Key.UserName,
                                    StaffId = group.Key.StaffId,
                                    Status = group.Key.Status,
                                    UserChangeStatus = group.Key.UserChangeStatus,
                                    UserRoleId = group.Key.RoleId,
                                    UserRole = group.Key.RoleTitle,
                                    UserSubRoleId = group.Key.SubRoleId,
                                    FailedloginCount = group.Key.FailedLoginCount,
                                    lastLoginTime = group.Key.LastLoginTime,
                                    CurrentLoginTime = group.Key.CurrentLoginTime,
                                    Branch = group.Select(item => item.lo.ORMLocation!.Branch!).Distinct().ToArray(),
                                    Department = group.Select(item => item.lo.ORMLocation!.Department!).Distinct().ToArray(),
                                    locationIds = group.Select(item => item.lo.ORMLocation.Id!).Distinct().ToArray(),
                                    Region = group.Select(item => item.lo.ORMLocation!.Region!).Distinct().ToArray(),
                                    SolId = group.Select(item => item.lo.ORMLocation!.SolId!).Distinct().ToArray(),
                                    ChangeRequestData = group.Key.ChangeRequestData,
                                    CreatedBy = group.Key.CreatedBy,
                                    CreatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == group.Key.CreatedBy)!.UserName ?? "",
                                    CreatedDate = group.Key.CreatedDate,
                                    UpdatedBy = group.Key.UpdatedBy,
                                    UpdatedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == group.Key.UpdatedBy)!.UserName ?? "",
                                    ChangeRequestDate = group.Key.ChangeRequestDate,
                                    ReviewedBy = group.Key.ReviewedBy,
                                    ReviewedByName = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == group.Key.ReviewedBy)!.UserName ?? "",
                                    ChangeReviewDate = group.Key.ChangeReviewDate,
                                    ChangeReviewComments = group.Key.ChangeReviewComments
                                });

            if (SearchFilters.IsValidStringFilter(filterUserRequest.userRole))
                userListQuery = userListQuery.Where(p => p.UserRole!.ToLower().Contains(filterUserRequest.userRole!.ToLower()));

            if (SearchFilters.IsValidStringFilter(filterUserRequest.userName))
                userListQuery = userListQuery.Where(p => p.UserName!.ToLower().Contains(filterUserRequest.userName!.ToLower()));

            if (SearchFilters.IsValidStringFilter(filterUserRequest.status))
                userListQuery = userListQuery.Where(p => p.Status == filterUserRequest.status);

            if (SearchFilters.IsValidStringFilter(filterUserRequest.userchangestatus))
                userListQuery = userListQuery.Where(p => p.UserChangeStatus == filterUserRequest.userchangestatus);

            if (SearchFilters.IsValidNumericFilter(filterUserRequest!.userSubRoleId))
                userListQuery = userListQuery.Where(p => p.UserSubRoleId == filterUserRequest.userSubRoleId);

            var totalCount = await userListQuery.CountAsync();

            if (totalCount == 0)
            {
                return new ListResponse<UserResponse>("No record found for given input", ResponseCodes.DataNotFound)
                {
                    Data = { },
                    Total = totalCount
                };
            }

            if (filterUserRequest is not null)
                userListQuery = userListQuery.Paginate(filterUserRequest);

            var response = await userListQuery.ToListAsync<UserResponse>();
            response = ExtractUserchangeRequestData(response);

            logger.LogInformation("Successfully Retrieved Users");

            return new ListResponse<UserResponse>("Successfully Retrieved Users")
            {
                Data = response,
                Total = totalCount
            };

        }
        private List<UserResponse> ExtractUserchangeRequestData(List<UserResponse> response)
        {
            foreach (var user in response)
            {
                if (string.IsNullOrEmpty(user.ChangeRequestData))
                {
                    InitializeEmptyChangeData(user);
                    continue;
                }

                try
                {
                    var jObject = JObject.Parse(user.ChangeRequestData ?? "{}");
                    var formattedData = jObject["FormattedUserChangeData"]?.ToObject<FormattedUserChangeData>();

                    if (formattedData != null)
                    {
                        user.UserNewFlag = formattedData.UserNewFlag ?? "No";
                        user.UserNewRole = formattedData.UserNewRole ?? string.Empty;
                        user.UserNewSubRole = formattedData.UserNewSubRole ?? string.Empty;
                        user.UserNewStatus = formattedData.UserNewStatus ?? string.Empty;
                        user.UserNewLocations = formattedData.UserNewLocations != null
                            ? string.Join(",", formattedData.UserNewLocations)
                            : string.Empty;
                        user.UserNewUpdatedBy  = formattedData.UserNewUpdatedBy ?? string.Empty;
                        user.UserNewChangeRequestDate = formattedData.UserNewChangeRequestDate ?? string.Empty;
                    }
                    else
                    {
                        InitializeEmptyChangeData(user);
                    }
                }
                catch (JsonException ex)
                {
                    logger.LogError(ex, "Error parsing ChangeRequestData JSON for user {UserId}", user.UserId);
                    InitializeEmptyChangeData(user);
                }
            }

            return response;
        }

        private static void InitializeEmptyChangeData(UserResponse user)
        {
            user.UserNewRole = string.Empty;
            user.UserNewSubRole = string.Empty;
            user.UserNewStatus = string.Empty;
            user.UserNewLocations = string.Empty;
            user.UserNewUpdatedBy = string.Empty;
            user.UserNewChangeRequestDate = string.Empty;
        }

        /// <summary>
        /// This Task is used to validate user name before creating new user
        /// </summary>
        /// <param name=""- ></param>
        /// <returns>
        /// UserResponse
        /// </returns>
        public async Task<ListResponse<UserResponse>> AddUserInfo(string UserName )
        {
            if (UserName == "" || UserName == null)
                return new ListResponse<UserResponse>("Error - User Name is blank!", ResponseCodes.InvalidCredentials);

            //Can we use CheckUserInAdAsync from  Auth Service??
            var existingUser = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(user => user.UserName == UserName && user.UserChangeStatus != "Rejected");
            
            if (existingUser != null)
            {
                return new ListResponse<UserResponse>("User Already Exist in ORM Database!", ResponseCodes.ServiceError);
            }
            var result = await authService.GetUserAdFullDetailsWLoginName(UserName);

            //var result = new ObjectResponse<LoginResponse>("Account exists with this username in Ad", ResponseCodes.Success)
            //{   ///send response for failed

            //    Data = new LoginResponse
            //    {
            //        Token = String.Empty,
            //        RefreshToken = String.Empty,
            //        FailLoginCount = 0,
            //        IsAccountLocked = false
            //    }
            //};
            if (result.Code == ResponseCodes.Success)
            {
                var userInformation = new UserResponse
                {
                    UserName = UserName,
                    EmailId = "",
                    StaffId = "",
                    Status = "",
                    UserRole = "",
                };
                // Create a list containing the single UserResponse object
                var userList = new List<UserResponse> { userInformation };

                return new ListResponse<UserResponse>("Successfully validated User Details", "00")
                {
                    Data = userList,
                    Total = 1
                };
            }
            if (result.Code == ResponseCodes.ServiceError)
            {
                return new ListResponse<UserResponse>("AD is not responding !", ResponseCodes.ServiceError);
            }
            else
            {
                return new ListResponse<UserResponse>("User not found in AD !", ResponseCodes.DataNotFound);

            }
        }


        /// <summary>
        /// This Task is used to add new user into ORM
        /// </summary>
        /// <param name="new user Added to DB"- ></param>
        /// <returns>
        /// UserResponse
        /// </returns>
        public async Task<ListResponse<ReturnId>> AddNewUserInfo(AddNewUserRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<ReturnId>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            if (request.UserName! == "" || request.UserName! == null)
                return new ListResponse<ReturnId>("Error - User Name is blank!", ResponseCodes.InvalidCredentials);

            var existingUser = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(user => user.UserName == request.UserName! && user.UserChangeStatus != "Rejected");

            if (existingUser != null)
            {
                return new ListResponse<ReturnId>("User Already Exist in ORM Database!", ResponseCodes.ServiceError);
            }
            if (request.LocationIds!.Length == 1 && request.LocationIds[0] == 0)
            {
                return new ListResponse<ReturnId>("User must have a location!", ResponseCodes.ServiceError);
            }
            if (request.RoleId == 0)
            {
                return new ListResponse<ReturnId>("User must have a role!", ResponseCodes.ServiceError);
            }
            var UserChangeData = new UserChangeData
            {
                UserNewRole = request.RoleId!,
                UserNewSubRole = request.SubRoleId!,
                UserNewStatus = request.Status!,
                UserNewLocations = null,
                UserNewUpdatedBy = session.UserId,
                UserNewChangeRequestDate = DateTime.Now
            };

            var FormattedUserChangeData = new FormattedUserChangeData
            {
                UserNewRole = unitOfWork.ORMRoles.GetAll().AsQueryable().FirstOrDefault(p => p.RoleId == request.RoleId)!.RoleTitle ?? "",
                UserNewSubRole = GetSubRoleTitle(request.SubRoleId),
                UserNewStatus = request.Status,
                UserNewFlag = "Yes",
                UserNewLocations = GetLocationNames(request.LocationIds!),
                UserNewUpdatedBy = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == session.UserId)!.UserName ?? "",
                UserNewChangeRequestDate = DateTime.Now.ToString("dd-MM-yyyy hh:mm")
            };

            var CombinedUserChangeData = new CombinedUserChangeData
            {
                UserChangeData = UserChangeData,
                FormattedUserChangeData = FormattedUserChangeData
            };

            string UserChangeDatajsonString = JsonConvert.SerializeObject(CombinedUserChangeData);

            var userDetail = new ORMUser()
            {
                UserName = request.UserName!,
                Email = request.UserName + "@fcmb.com",
                StaffId = request.StaffId!,
                Status = "Inactive",
                UserChangeStatus = "Pending",
                RoleId = request.RoleId,
                SubRoleId = request.SubRoleId,
                FailedLoginCount = "0",
                CreatedBy = session.UserId,
                CreatedDate = DateTime.Now,
                ChangeRequestData = UserChangeDatajsonString

            };

            var response = await unitOfWork.SaveAndGetIdORMUserAsync(userDetail);

            var userLocationMaps = new List<ORMUserLocationMap>();

            foreach (var LocationId in request.LocationIds!)
            {
                var locationMap = new ORMUserLocationMap()
                {
                    LocationId = LocationId,
                    UserId = response,
                    CreatedById = session.UserId,
                    CreatedDate = DateTime.Now
                };
                userLocationMaps.Add(locationMap);
            }

            await unitOfWork.SaveAndGetIdORMUserLocationMapAsync(userLocationMaps);

            logger.LogInformation("Successfully submitted newuser request for  User Name - {UserName} with response {response} ", request.UserName, response);

            ReturnId result = new()
            {
                id = response
            };

            List<ReturnId> Response = new()
            {
               result
            };


            return new ListResponse<ReturnId>("New User Created!", ResponseCodes.Success)
            {
                Data = Response,
                Total = 1
            };
        }

        /// <summary>
        /// This Task is used to update user into ORM
        /// </summary>
        /// <param name=""- ></param>
        /// <returns>
        /// UserResponse
        /// </returns>
        
        public async Task<ObjectResponse<string>> UpdateUserInfo(EditUserRequest request)
        {
            var session = sessionService.GetStaffSession();
                        
            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var ormAppUser = await GetORMUserAsync(request.Id);
            if (ormAppUser is null)
                return new ObjectResponse<string>("User Not Found", ResponseCodes.DataNotFound) { Data = "User not found" };

            if (ormAppUser.UserChangeStatus == "Pending")
                return new ObjectResponse<string>("User info change is Pending Review, No Change Allowed ", ResponseCodes.DataNotFound) { Data = "UserChangeStatus is Pending,No Change allowed" };

            var UserChangeData = new UserChangeData
            {
                UserNewRole = request.RoleId,
                UserNewSubRole = request.SubRoleId,
                UserNewStatus = request.Status,
                UserNewLocations = request.LocationIds,
                UserNewUpdatedBy = session.UserId,
                UserNewChangeRequestDate = DateTime.Now
            };

            var FormattedUserChangeData = new FormattedUserChangeData
            {
                UserNewUpdatedBy = unitOfWork.ORMUsers.GetAll().AsQueryable().FirstOrDefault(p => p.Id == session.UserId)!.UserName ?? "",
                UserNewChangeRequestDate = DateTime.Now.ToString("dd-MM-yyyy hh:mm"),
                UserNewFlag = "No",
            };
            bool ChangeFlag = false ;
            if (request.RoleId == ormAppUser.RoleId)
            {
                FormattedUserChangeData.UserNewRole = null;
            }
            else
            {
                var newRole = unitOfWork.ORMRoles.GetAll().AsQueryable().FirstOrDefault(p => p.RoleId == request.RoleId);
                FormattedUserChangeData.UserNewRole = newRole?.RoleTitle;
                ChangeFlag = true;
            }

            if (request.Status == ormAppUser.Status)
            {
                FormattedUserChangeData.UserNewStatus = null;
            }
            else
            {
                FormattedUserChangeData.UserNewStatus = request.Status;
                ChangeFlag = true;
            }

            if (request.SubRoleId == ormAppUser.SubRoleId)
            {
                FormattedUserChangeData.UserNewSubRole = null;
            }
            else
            {
                FormattedUserChangeData.UserNewSubRole = GetSubRoleTitle(request.SubRoleId);
                ChangeFlag = true;
            }
            // Fetch current user location IDs
            var userLocationIds = unitOfWork.ORMUserLocationMap.GetAll().AsQueryable()
                .Where(p => p.UserId == request.Id)
                .Select(p => p.LocationId)
                .ToHashSet();

            // Assign UserNewLocations
            if (request.LocationIds != null && !userLocationIds.SetEquals(request.LocationIds))
            {
                FormattedUserChangeData.UserNewLocations = GetLocationNames(request.LocationIds);
                ChangeFlag = true;
            }
            else
            {
                FormattedUserChangeData.UserNewLocations = null;
            }
            if(!ChangeFlag)
              return new ObjectResponse<string>("No changes made in user data ", ResponseCodes.ServiceError);
            var CombinedUserChangeData = new CombinedUserChangeData
            {
                UserChangeData = UserChangeData,
                FormattedUserChangeData = FormattedUserChangeData
            };

            string UserChangeDatajsonString = JsonConvert.SerializeObject(CombinedUserChangeData);
            ormAppUser.ChangeRequestData = UserChangeDatajsonString ?? ormAppUser.ChangeRequestData;
            ormAppUser.UserChangeStatus = "Pending";
            unitOfWork.Save();

            return new ObjectResponse<string>("User Update Request has been submitted successfully ", ResponseCodes.Success);
        }

        private async Task<ORMUser?> GetORMUserAsync(long userId)
        {
            return await (from au in unitOfWork.ORMUsers.GetAll().AsQueryable()
                          where au.Id == userId
                          select au).FirstOrDefaultAsync<ORMUser>();
        }
        private static string GetSubRoleTitle(long? subRoleId) => subRoleId switch
        {
            1 => "Maker",
            2 => "Checker",
            _ => ""
        }; 
        private IEnumerable<string> GetLocationNames(IEnumerable<long> locationIds)
        {
            if (locationIds == null || !locationIds.Any())
                return Enumerable.Empty<string>();
            var locationMap = unitOfWork.ORMLocation.GetAll()
                .Where(l => locationIds.Contains(l.Id))
                .ToDictionary(
                    l => l.Id,
                    l => l.LocationType switch
                    {
                        "B" => string.IsNullOrEmpty(l.Branch) ? l.LocationId : l.Branch,
                        "D" => string.IsNullOrEmpty(l.Department) ? l.LocationId : l.Department,
                        _ => l.LocationId
                    }
                );
            return locationIds.Select(id => locationMap.TryGetValue(id, out var name) ? name : "Unknown");
        }
        /// <summary>
        /// Get the list of  users for a Role and/or location
        /// Used in populate the ICO dropdown in KRI/Loss report creation
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<ListResponse<GetUsersByRoleLocationResponse>> GetUserByRoleLocationAsync(FilterGetUsersByRoleLocationRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ListResponse<GetUsersByRoleLocationResponse>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var userListQuery = unitOfWork.ORMUserLocationMap.GetAll().AsQueryable()
                                   .Select(ORMUserLocationMap => new GetUsersByRoleLocationResponse
                                   {
                                       Locationid = ORMUserLocationMap.LocationId,
                                       Roleid = ORMUserLocationMap.ORMUser.RoleId,
                                       SubRoleid = ORMUserLocationMap.ORMUser.SubRoleId,
                                       RoleTitle = unitOfWork.ORMRoles.GetAll().AsQueryable().FirstOrDefault(p => p.RoleId == ORMUserLocationMap.ORMUser.RoleId)!.RoleTitle,
                                       UserStatus = ORMUserLocationMap.ORMUser.Status,
                                       UserId = ORMUserLocationMap.ORMUser.Id,
                                       UserName = ORMUserLocationMap.ORMUser.UserName,
                                       LocationType = ORMUserLocationMap.ORMLocation.LocationType,
                                       LocationName = ORMUserLocationMap.ORMLocation.LocationType == "B" ? ORMUserLocationMap.ORMLocation.Branch : ORMUserLocationMap.ORMLocation.Department,
                                   });


            if (SearchFilters.IsValidStringFilter(request.RoleTitle))
                userListQuery = userListQuery.Where(p => p.RoleTitle!.ToLower().Contains(request.RoleTitle!.ToLower()));

            if (SearchFilters.IsValidStringFilter(request.UserStatus))
                userListQuery = userListQuery.Where(p => p.UserStatus!.ToLower() == request.UserStatus!.ToLower());

            if (SearchFilters.IsValidNumericFilter(request.Locationid))
                userListQuery = userListQuery.Where(p => p.Locationid! == request!.Locationid);

            if (SearchFilters.IsValidNumericFilter(request.Roleid))
                userListQuery = userListQuery.Where(p => p.Roleid! == request!.Roleid!);

            if (SearchFilters.IsValidNumericFilter(request.SubRoleid))
                userListQuery = userListQuery.Where(p => p.SubRoleid! == request!.SubRoleid!);

            var totalCount = await userListQuery.CountAsync();

            if (totalCount == 0)
            {
                return new ListResponse<GetUsersByRoleLocationResponse>("No User found for given Role/Location")
                {
                    Data = { },
                    Total = totalCount
                };
            }

            if (request is not null)
                userListQuery = userListQuery.Paginate(request);


            var response = await userListQuery.ToListAsync();

            logger.LogInformation("Successfully Retrieved Users {totalCount}", totalCount);

            return new ListResponse<GetUsersByRoleLocationResponse>("Successfully Retrieved Users")
            {
                Data = response,
                Total = totalCount
            };

        }

        /// <summary>
        /// This Task is used to Approve the user change request by Maker and update the user record
        /// The requested user info is parked in appuser table in UserChangeData column in json form
        /// </summary>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns>
        /// UserResponse
        /// </returns>

        public async Task<ObjectResponse<string>> ApproveUserInfoAsync(ReviewUserChangeRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var ormAppUser = await GetORMUserAsync(request.Id);
            if (ormAppUser is null)
                return new ObjectResponse<string>("User Not Found", ResponseCodes.DataNotFound) { Data = "User not found" };
            if (ormAppUser.UserChangeStatus != "Pending")
                return new ObjectResponse<string>("User info change in not Pending Review ", ResponseCodes.DataNotFound) { Data = "UserChangeStatus is not Pending" };

            // Deserialize the JSON string back to UserChangeData object
            CombinedUserChangeData CombinedUserChangeData = JsonConvert.DeserializeObject<CombinedUserChangeData>(ormAppUser.ChangeRequestData!)!;

            UpdateApprovedORMUser(ormAppUser, request,session.UserId, CombinedUserChangeData.UserChangeData!);
            unitOfWork.Save();

            if (CombinedUserChangeData.UserChangeData!.UserNewLocations?.ToList().Count > 0)
            {
                var response = await UpdateUserLocationsAsync(request, CombinedUserChangeData.UserChangeData);
                if (response.Code != ResponseCodes.Success)
                {
                    return new ObjectResponse<string>(response.Description, response.Code);
                }
            }

            logger.LogInformation("Approved user update request for  User Name - {UserName} with Comments {ChangeReviewComments} ", ormAppUser.UserName, request.ChangeReviewComments);
            return new ObjectResponse<string>("User update request approved and record updated successfully ", ResponseCodes.Success);
        }

        private static void UpdateApprovedORMUser(ORMUser ormAppUser, ReviewUserChangeRequest request, long ReviewedById, UserChangeData UserChangeData)
        {
            ormAppUser.RoleId = UserChangeData.UserNewRole;
            ormAppUser.SubRoleId = UserChangeData.UserNewSubRole;
            ormAppUser.Status = UserChangeData.UserNewStatus!;
            ormAppUser.UpdatedBy = UserChangeData.UserNewUpdatedBy;
            ormAppUser.ChangeRequestDate = UserChangeData.UserNewChangeRequestDate;
            ormAppUser.ReviewedBy = ReviewedById;
            ormAppUser.ChangeReviewDate = DateTime.Now;
            ormAppUser.ChangeReviewComments = request.ChangeReviewComments;
            ormAppUser.FailedLoginCount = "0";
            ormAppUser.UserChangeStatus = "Approved";
        }

        private async Task<ObjectResponse<string>> UpdateUserLocationsAsync(ReviewUserChangeRequest request, UserChangeData UserChangeData)
        {
            var locationMapsToDelete = unitOfWork.ORMUserLocationMap
                .GetAll().AsQueryable()
                .Where(ormUserLocationMap => ormUserLocationMap.UserId == request.Id);

            if (locationMapsToDelete.Any())
            {
                unitOfWork.ORMUserLocationMap.DeleteRange(locationMapsToDelete);
                unitOfWork.Save();
            }

            var userLocationMaps = UserChangeData.UserNewLocations!.Select(locationId => new ORMUserLocationMap
            {
                LocationId = locationId,
                UserId = request.Id,
                CreatedById = UserChangeData.UserNewUpdatedBy,
                CreatedDate = UserChangeData.UserNewChangeRequestDate
            }).ToList();

            var ids = await unitOfWork.SaveAndGetIdORMUserLocationMapAsync(userLocationMaps);

            if (!ids.Any())
            {
                return new ObjectResponse<string>("Server error occurred", ResponseCodes.ServiceError);
            }
            return new ObjectResponse<string>("User Locations Updated", ResponseCodes.Success);
        }        
        /// <summary>
        /// This Task is used to Reject the user change request by Maker and update the userchange status as Rejected
        /// </summary>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns>
        /// UserResponse
        /// </returns>

        public async Task<ObjectResponse<string>> RejectUserInfoAsync(ReviewUserChangeRequest request)
        {
            var session = sessionService.GetStaffSession();

            if (session is null) return new ObjectResponse<string>("User Is Unauthenticated", ResponseCodes.Unauthenticated);

            var ormAppUser = await GetORMUserAsync(request.Id);
            if (ormAppUser is null)
                return new ObjectResponse<string>("User Not Found", ResponseCodes.DataNotFound) { Data = "User not found" };

            if (ormAppUser.UserChangeStatus != "Pending")
                return new ObjectResponse<string>("User info change in not Pending Review ", ResponseCodes.DataNotFound) { Data = "UserChangeStatus is not Pending" };

            ormAppUser.ReviewedBy = session.UserId;
            ormAppUser.ChangeReviewDate = DateTime.Now;
            ormAppUser.ChangeReviewComments = request.ChangeReviewComments;
            ormAppUser.UserChangeStatus = "Rejected";
            unitOfWork.Save();
            logger.LogInformation("Rejected user update request for  User Name - {UserName} with Comments {ChangeReviewComments} ", ormAppUser.UserName, request.ChangeReviewComments);
            return new ObjectResponse<string>("User update request Rejected ", ResponseCodes.Success);
        }

    }
}






