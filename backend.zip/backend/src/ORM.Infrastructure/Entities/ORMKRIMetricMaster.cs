﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ORM.Application.Models.Responses;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for ORM KRI metric master data 
    /// This contains all KRI indicator and Metrics applicable for Departments and Branches
    /// Appetite, tolerance and Escalation data would be empty for Branches
    /// </summary>
    [PrimaryKey(nameof(Id))]
    public partial class ORMKRIMetricMaster
    {
        [Key]
        public long Id { get; set; }

        // Friendly name generated for each KRI metric e.g. KRI-B0001-XXXXXXX, It will not be primary key this table
        [Required]
        public string KRIMetricId { get; set; } = null!;

        // "B" for Branch and "D" for department 
        public string LocationType { get; set; } = null!;

        // Branch or department id from location db
        [Required]
        public int LocationId { get; set; } = 0;

        public string MetricName { get; set; } = null!;

        public string Frequency { get; set; } = null!;

        public string? AppetiteLowerBound { get; set; } = null!;

        public string? AppetiteUpperBound { get; set; } = null!;

        public string? AppetiteType { get; set; } = null!;

        public string? ToleranceLowerBound { get; set; } = null!;

        public string? ToleranceUpperBound { get; set; } = null!;

        public string? ToleranceType { get; set; } = null!;

        public string? EscalationLowerBound { get; set; } = null!;

        public string? EscalationUpperBound { get; set; } = null!;

        public string? EscalationType { get; set; } = null!;

        public bool IsActive { get; set; }

        public string? Status { get; set; }
        public string? ChangeRequestData { get; set; }

        public string? ReviewerComments { get; set; }

        public long? CreatedById { get; set; }

        public long? ModifiedById { get; set; }

        public long? ApprovedById { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public DateTime? ApprovedDate { get; set; }

    }
}
