﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for ORM KRI Report data 
    /// This table has one report for each ref id.
    /// Status field wuld typically contain "Saved", "Submitted", "Approved","Rejected"
    /// </summary>
    [PrimaryKey(nameof(Id))]
    public partial class ORMKRIReport
    {
        [Key]
        public long Id { get; set; }

        // Friendly name generated for each KRI report e.g. KRIRP-YYYYMM-B0001-NN, It will not be primary key this table
        [Required]
        public string RefNum { get; set; } = null!;

        // "B" for Branch and "D" for department 
        public string LocationType { get; set; } = null!;

        // Branch or department id from location db
        public int LocationId { get; set; }

        [Required]
        public long? ValidatorILOUserId { get; set; }
        //Foreign key
        //Navigation property
        public ORMUser ORMUser { get; set; } = null!;
        public string ReportingPeriod { get; set; } = null!;

        public string? ReportingFrequency { get; set; } = null!;

        public DateTime DateReported { get; set; }

        public string Status { get; set; } = "Saved";

        public string? ReviewerComments { get; set; }

        //Meta Data fields populated by system  
        public long? CreatedById { get; set; } = null!;

        public long? ModifiedById { get; set; } = null!;

        public long? ReviewedById { get; set; } = null!;

        public DateTime? CreatedDate { get; set; } = null!;

        public DateTime? ModifiedDate { get; set; } = null!;

        public DateTime? ReviewedDate { get; set; } = null!;

    }


}

