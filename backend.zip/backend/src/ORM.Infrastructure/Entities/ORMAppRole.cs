﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Entities
{
    [PrimaryKey(nameof(RoleId))]

    public partial class ORMAppRole
    {
        public long RoleId { get; set; }

        public string RoleTitle { get; set; } = null!;

        public bool RoleStatus { get; set; } = true!;

        public string? RoleCreatedBy { get; set; }

        public string? RoleUpdatedBy { get; set; }
        public DateTime? RoleCreationTime { get; set; }
        public DateTime? RoleUpdationTime { get; set; }

    }

}
