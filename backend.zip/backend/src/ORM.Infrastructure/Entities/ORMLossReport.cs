﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for ORM Loss Data Report data 
    /// This table has one report for each ref id.
    /// PreReportId would refer back to old report that needs correction
    /// Status field wuld typically contain "Saved", "Submitted", "Approved","Rejected"
    /// </summary>
    [PrimaryKey(nameof(Id))]
    public partial class ORMLossReport
    {
        [Key]
        public long Id { get; set; }

        // Friendly name generated for each KRI report e.g. LOSSRP-YYYYMM-B0001-NN, It will not be primary key this table
        [Required]
        public string RefNum { get; set; } = null!;

        public long? PrevLossReportId { get; set; }
        public virtual ORMLossReport? PrevLossReport { get; set; }

        // "B" for Branch and "D" for department 
        [Required]
        public string? LocationType { get; set; }

        // Branch or department id from location db
        [Required]
        public long LocationId { get; set; }

        [Required]
        public long? ValidatorILOUserId { get; set; }

        public DateTime DateOccurance { get; set; }

        public DateTime DateDiscovery { get; set; }

        public DateTime DateReported { get; set; }

        public string? Description { get; set; }

        public string? RootCauseRLO { get; set; }

        public string? LossType { get; set; }

        public string? CurrencyType { get; set; }

        public decimal? AmountInvolved { get; set; }

        [DataType(DataType.Currency)]
        public decimal? NearMissAmount { get; set; }

        [DataType(DataType.Currency)]
        public decimal? PotentialLossAmount { get; set; }

        [DataType(DataType.Currency)]
        public decimal? GrossActualAmount { get; set; }

        [DataType(DataType.Currency)]
        public decimal? RecoveredAmount { get; set; }

        [DataType(DataType.Currency)]
        public decimal? FurtherRecoveredAmount { get; set; }

        // Calculated based on GrossActualAmount,RecoveredAmount and FurtherRecoveredAmount

        [DataType(DataType.Currency)]
        public decimal? NetActualLossAmount { get; set; }

        public string? RecoveryChannel { get; set; }

        public string? StaffInvolvement { get; set; }

        public string EventStatus { get; set; } = "Saved";

        public string ReportStatus { get; set; } = "Saved";

        // Data fields populated by BORM Admin
        public string? StaffJobRole { get; set; }

        public string? InternalBusLine { get; set; }

        public string? BaselEventTypeI { get; set; }

        public string? BaselEventTypeII { get; set; }

        public string? BaselEventTypeIII { get; set; }

        public string? BaselLevel1BusinessLine { get; set; }

        public string? BaselLevel2BusinessLine { get; set; }

        public string? RootCauseTypeBORM { get; set; }

        public string? ProcessInvolved { get; set; }

        public string? RiskSource { get; set; }

        public string? LessonLearnt { get; set; }

        public string? ReviewerComments { get; set; }

        public string? UpdateHistory { get; set; }

        //Meta Data fields populated by system
        public long? CreatedById { get; set; } = null!;

        public long? ModifiedById { get; set; } = null!;

        public long? ValidatedById { get; set; } = null!;

        public long? ApprovedById { get; set; } = null!;

        public DateTime? CreatedDate { get; set; } = null!;

        public DateTime? ModifiedDate { get; set; } = null!;

        public DateTime? ValidationDate { get; set; } = null!;

        public DateTime? ApprovedDate { get; set; } = null!;

        public string? Documents { get; set; } = null!;

        public string? DocumentName { get; set; } = null!;
    }
}

