﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ORM.Application.Models.Responses;
using System;
using System.Collections.Generic;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for ORM Location containing data for all branches and Departments 
    /// Status field would typically contain "Active", "Inactive"
    /// </summary>
    [PrimaryKey(nameof(Id))]
    public partial class ORMLocation
    {
        [Key]
        public long Id { get; set; }

        // Friendly name generated for each Location e.g. B0001 or D0001, It will not be primary key this table
        [Required]
        public string LocationId { get; set; } = null!;

        // "B" for Branch and "D" for department 
        [Required]
        public string LocationType { get; set; } = null!;

        public string? SolId { get; set; }

        public string? Branch { get; set; }

        public string? Region { get; set; }

        public string? Department { get; set; }

        public string Status { get; set; } = "Active"!;
        public string? LocationChangeStatus { get; set; } = null!;
        public string? ChangeRequestData { get; set; } = null!;
        public string? ChangeReviewComments { get; set; } = null!;

        //Meta Data fields populated by system
        public long? CreatedById { get; set; } = null!;

        public long? ModifiedById { get; set; } = null!;
        public long? ReviewedById { get; set; } = null!;

        public DateTime? CreatedDate { get; set; } = null!;

        public DateTime? ModifiedDate { get; set; } = null!;
        public DateTime? ReviewedDate { get; set; } = null!;



    }
}
