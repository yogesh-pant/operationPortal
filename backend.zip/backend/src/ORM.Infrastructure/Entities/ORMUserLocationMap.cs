﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for ORMUserLocationMap table
    /// One user may be connected to multiple locations
    /// User has same role across all linked locations
    /// This table serves as mapping between one userid with multiple locationids
    /// </summary>
    [PrimaryKey(nameof(Id))]
    public partial class ORMUserLocationMap
    {
        public long Id { get; set; }

        [Required]
        public long LocationId { get; set; }
        //Foreign key
        //Navigation property
        public ORMLocation ORMLocation { get; set; } = null!;

        [Required]
        public long UserId { get; set; }
        //Foreign key
        //Navigation property
        public ORMUser ORMUser { get; set; } = null!;

        //Meta Data fields populated by system
        public long? CreatedById { get; set; } = null!;

        public long? ModifiedById { get; set; } = null!;

        public DateTime? CreatedDate { get; set; } = null!;

        public DateTime? ModifiedDate { get; set; } = null!;

    }
}
