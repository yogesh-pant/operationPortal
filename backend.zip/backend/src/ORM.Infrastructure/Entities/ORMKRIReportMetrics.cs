﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Entities;
/// <summary>
/// Defines the Child table for ORM KRIReport table
/// containing the all metrices reported under one Ref ID
/// Parent Table ORMKRIReport contains meta data for each RefID
/// </summary>
[PrimaryKey(nameof(Id))]
public partial class ORMKRIReportMetrics
{
    [Key]
    public long Id { get; set; }

    //Foreign key
    //Navigation property
    [Required]
    public long KRIReportId { get; set; }
    public ORMKRIReport ORMKRIReport { get; set; } = null!;

    //Foreign key
    //Navigation property
    [Required]
    public long KRIMetricMasterId { get; set; }
    public ORMKRIMetricMaster ORMKRIMetricMaster { get; set; } = null!;

    public DateTime DateOccurance { get; set; }

    public string? KRIData { get; set; }

    public string? Description { get; set; }

    public string? AmountInvolved { get; set; }

    public string? Currency { get; set; }

    public string? MitigationPlan { get; set; }
    public string? RiskAppetiteThreshold { get; set; }
    

}

