﻿using Microsoft.EntityFrameworkCore;
using ORM.Application.Models.Responses;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for NapsUser
    /// </summary>
    [PrimaryKey(nameof(Id))]

    public partial class ORMUser
    {
        public long Id { get; set; }
        public string UserName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? StaffId { get; set; }
        public string Status { get; set; } = "Active"!;
        public string? UserChangeStatus { get; set; }

        // Foreign Key
        public long? RoleId { get; set; }
        //SubRoleid "1" - Maker, SubRoleid "2" - Checker only applicable for admin role
        public long? SubRoleId { get; set; }
        public string? FailedLoginCount { get; set; }
        public DateTime? LastLoginTime { get; set; }
        public DateTime? CurrentLoginTime { get; set; }
        public string? CurrentToken { get; set; }
        public string? ChangeRequestData { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public DateTime? ChangeRequestDate { get; set; }
        public long? ReviewedBy { get; set; }
        public DateTime? ChangeReviewDate { get; set; }
        public string? ChangeReviewComments { get; set; }

        // Navigation property
        [ExcludeFromCodeCoverage]
        public ORMAppRole? ORMAppRole { get; set; }
    }
}
