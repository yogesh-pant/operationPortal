﻿using Azure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Asn1.Crmf;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Entities
{
    /// <summary>
    /// Defines the Fields for ORM Risk Risk Report data 
    /// This table has one report for each ref id.
    /// Status field would typically contain "Saved", "Submitted", "Approved","Rejected"
    /// </summary>
    [PrimaryKey(nameof(Id))]
    public partial class ORMRiskReport
    {
        [Key]
        public long Id { get; set; }

        // Friendly name generated for each Risk report e.g. RiskRP-YYYYMM-B0001-NN, It will not be primary key this table
        [Required]
        public string RefNum { get; set; } = null!;

        // "B" for Branch and "D" for department 
        [Required]
        public string? LocationType { get; set; }

        // Branch or department id from location db
        [Required]
        public long LocationId { get; set; }

        public long ValidatorUserId { get; set; }

        //Data inputs/Fields/Questionnire to be filled by RLO 
        public string? ProcessName { get; set; } //Freeform Text Field

        public string? SubProcessName { get; set; } //Freeform Text Field

        public string? InherentThreatRisk { get; set; } //Freeform Text Field

        public string? FrequencyOfOccurance { get; set; }  //Drop Down Selection - Certainly/Daily,Likely/Weekly,Possible/Monthly,
                                                           //Unlikely/Quarterly,Very Rare/Annually=1)
        public string? RiskSeverity { get; set; }  //Drop Down Selection - SIGNIFICANT,MAJOR,MODERATE,MINOR,INSIGNIFICANT

        public string? RiskDirection { get; set; } //Drop Down Selection - INCREASING,DECREASING,STATIC

        public string? ImplementedControls { get; set; } //Freeform Text Field

        public string? RiskControlDesign { get; set; } //Drop Down Selection - Automated,Semi-Automated,Manual

        public string? RiskControlType { get; set; } //Drop Down Selection - Preventive,Detective,Corrective,

        public string? RiskResidual { get; set; } //Freeform Text Field

        public string? RiskResponsibility { get; set; } //Freeform Text Field

        public string? RiskActionPlan { get; set; } //Freeform Text Field

        public string? Documents { get; set; } = null!; //Blob Storage document Identifier 

        public string? DocumentName { get; set; } = null!;  // Uploaded Document Name 

        //Data fields to be filled by BORM Admin

        public string? RiskClassification { get; set; }  //Drop Down Selection  - PEOPLE,PROCESS,SYSTEM,EXTERNAL EVENT

        public string? RiskCategory { get; set; } //Drop Down Selection - CYBER RISK,TECHNOLOGY RISK,MARKET/ LIQUIDITY RISK,

        //OPERATIONAL RISK,REGULATORY RISK,COMPLIANCE RISK,STRATEGIC RISK,REGULATORY RISK,REPUTATIONAL RISK,ENVIRONMENTAL/SOCIAL RISK,OTHERS

        public string? RiskRootCause { get; set; }  //Freeform Text Field

        public string? RiskActionPlanStatus { get; set; } //Drop Down Selection - Open, Work in Progress, Closed

        public DateTime? RiskExpectedResolutionTime { get; set; }

        public string? RiskStrategy { get; set; } //Drop Down Selection - Accept,Mitigate,Transfer,Avoid

        public string? ReportStatus { get; set; } = ""; // Possible Values Draft , Submitted , Approved , Rejected

        public string? UpdateRequestStatus { get; set; } = ""; // Possible Values are Requested , Completed  

        // Auto calculated Fields 
        public string? RiskControlAssessment { get; set; } // Auto Calculated - ADEQUATE,INADEQUATE,NEEDS IMPROVEMENT

        public string? RiskControlEffectiveness { get; set; } // Auto calculated Fields - Almost Certain,Probable,Rare

        public string? RiskControlQuality { get; set; } // Auto Calculated - High , Medium , Low

        public string? RiskResidualRating { get; set; } // Auto Calculated - High , Medium , Low

        public string? RiskRating { get; set; }  // Auto Calculated - High , Medium , Low

        public string? ReviewerComments { get; set; } = null!;

        //Meta Data fields populated by system
        public long? CreatedById { get; set; } = null!;

        public long? ModifiedById { get; set; } = null!;

        public long? ValidatedById { get; set; } = null!;

        public long? ApprovedById { get; set; } = null!;

        public DateTime? CreatedDate { get; set; } = null!;

        public DateTime? ModifiedDate { get; set; } = null!;

        public DateTime? ValidationDate { get; set; } = null!;

        public DateTime? ApprovedDate { get; set; } = null!;

    }
}

