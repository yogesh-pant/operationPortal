﻿
using Fcmb.Shared.Models.Constants;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Common;
using ORM.Application.Interfaces.Dashboard;
using ORM.Application.Interfaces.Role;
using ORM.Domain.Common;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Repositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.Services.Auth;
using ORM.Infrastructure.Services.Common;
using ORM.Infrastructure.UOW;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace ORM.Infrastructure
{
    [ExcludeFromCodeCoverage]
    public static class ConfigureServices
    {
        /// <summary>
        /// Configure Infrastructure services
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void ConfigureInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AutoInjectService();
            services.ConfigureThirdPartyServices();
            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddScoped<IOrmUserRepository, OrmUserRepository>();
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddTransient<IAuthSetupService, AuthSetupService>();
            services.AddTransient<IRoleService, RoleService>();
            services.AddTransient<IDashboardService, DashboardService>();
            services.AddScoped<IKriReportMetricMasterRepository, KriReportMetricMasterRepository>();
            services.AddScoped<IKriReportMetricsRepository, KriReportMetricsRepository>();
            services.AddScoped<IKriReportRepository, KriReportRepository>();
            services.AddScoped<IOrmLossReportRepository, OrmLossReportRepository>();
            services.AddScoped<IOrmLocationRepository, OrmLocationRepository>();
            services.AddScoped<IOrmRiskRepository, OrmRiskRepository>();
            services.AddScoped<IOrmUserLocationMapRepository, OrmUserLocationMapRepository>();
            services.Configure<AzureBlobSettings>(configuration.GetSection("orm-blob-connectionstring"));
            services.AddScoped<IMailService, MailService>();
            services.AddMediatR(cfg =>
            {
                cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
            });
            services.ConfigureHttpClients(configuration);
        }



        private static void ConfigureHttpClients(this IServiceCollection services, IConfiguration configuration)
        {
            ConfigureAuthHttpClient(services, configuration);
        }

        public static void ConfigureAuthHttpClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClient(HttpConstants.AuthHttpClient, client =>
            {
                var baseUrl = configuration["FCMBConfig:AuthBaseUrl"]!;

                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
            });
        }

        private static void AutoInjectService(this IServiceCollection services)
        {
            //Register Services with Interface
            services.Scan(scan => scan.FromCallingAssembly().AddClasses(classes => classes
                    .Where(type => type.Name.EndsWith("Service") && type.GetInterfaces().Length > 0), false)
                .AsSelfWithInterfaces()
                .WithTransientLifetime());
        }

    }
}



