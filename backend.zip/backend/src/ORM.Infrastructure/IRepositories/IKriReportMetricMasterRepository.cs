﻿using ORM.Infrastructure.Entities;

namespace ORM.Infrastructure.IRepositories
{
    public interface IKriReportMetricMasterRepository : IGenericRepository<ORMKRIMetricMaster>
    {
    }


}

