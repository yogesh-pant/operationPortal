﻿using Microsoft.EntityFrameworkCore;

namespace ORM.Infrastructure.IRepositories
{
    public interface IGenericRepository<T> where T : class
    {
        T GetById(int id);
        DbSet<T> GetAll();
    }
}
