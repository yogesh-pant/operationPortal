﻿using ORM.Infrastructure.Entities;

namespace ORM.Infrastructure.IRepositories
{
    public interface IKriReportMetricsRepository : IGenericRepository<ORMKRIReportMetrics>
    {
        void Delete(ORMKRIReportMetrics entity);
        void DeleteRange(IEnumerable<ORMKRIReportMetrics> entities);
    }


}

