﻿using ORM.Infrastructure.Entities;

namespace ORM.Infrastructure.IRepositories
{
    public interface IKriReportRepository : IGenericRepository<ORMKRIReport>
    {
        void DeleteRange(IEnumerable<ORMKRIReport> entities);
    }


}

