﻿using ORM.Infrastructure.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.IRepositories
{
    public interface IOrmLossReportRepository : IGenericRepository<ORMLossReport>
    {
        void DeleteRange(IEnumerable<ORMLossReport> entities);
    }


}

