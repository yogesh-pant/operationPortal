﻿using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Repositories
{
    public class OrmRiskRepository : GenericRepository<ORMRiskReport>, IOrmRiskRepository
    {
        public OrmRiskRepository(AppDbContext appDbContext) : base(appDbContext)
        {

        }


    }
}
