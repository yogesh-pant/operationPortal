﻿using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Infrastructure.Repositories
{
    public class OrmUserLocationMapRepository : GenericRepository<ORMUserLocationMap>, IOrmUserLocationMapRepository
    {
        public OrmUserLocationMapRepository(AppDbContext appDbContext) : base(appDbContext)
        {

        }
        public void Delete(ORMUserLocationMap entity)
        {
            _dbContext.ORMUserLocationMap.Remove(entity);
            _dbContext.SaveChanges(); // Or use an async save changes method if applicable
        }

        public void DeleteRange(IEnumerable<ORMUserLocationMap> entities)
        {
            _dbContext.ORMUserLocationMap.RemoveRange(entities);
            _dbContext.SaveChanges(); // Or use an async save changes method if applicable
        }
    }
}

