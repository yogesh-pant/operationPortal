﻿using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;

namespace ORM.Infrastructure.Repositories
{
    public class RoleRepository : GenericRepository<ORMAppRole>, IRoleRepository
    {
        public RoleRepository(AppDbContext appDbContext) : base(appDbContext)
        {


        }

    }
}
