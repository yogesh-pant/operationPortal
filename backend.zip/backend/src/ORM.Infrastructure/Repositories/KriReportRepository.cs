﻿using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;

namespace ORM.Infrastructure.Repositories
{
    public class KriReportRepository : GenericRepository<ORMKRIReport>, IKriReportRepository
    {
        public KriReportRepository(AppDbContext appDbContext) : base(appDbContext)
        {
        }
        public void DeleteRange(IEnumerable<ORMKRIReport> entities)
        {
            _dbContext.ORMKRIReport.RemoveRange(entities);
            _dbContext.SaveChanges(); // Or use an async save changes method if applicable
        }

    }
}
