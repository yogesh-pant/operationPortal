﻿using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;
using System.Diagnostics;

namespace ORM.Infrastructure.Repositories
{
    /// <summary>
    /// Provides the method to get the dataset by id
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        protected readonly AppDbContext _dbContext;
        protected readonly DbSet<T>currentEntity;
        protected GenericRepository(AppDbContext context)
        {
            _dbContext = context;
            currentEntity = _dbContext.Set<T>();
        }

        public T GetById(int id)
        {
            var _id = Convert.ToInt64(id);
            var entity = currentEntity.Find(_id);
            Debug.Assert(entity != null, "Entity should not be null here");
            return entity;
        }
        /// <summary>
        /// get all data
        /// </summary>
        /// <returns>The entity with all the data</returns>
        public  DbSet<T> GetAll()
        {
            return currentEntity;
        }

      
    }
}