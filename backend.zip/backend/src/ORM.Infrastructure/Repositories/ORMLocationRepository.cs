﻿using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Repositories;
using ORM.Infrastructure.Persistance;

namespace ORM.Infrastructure.Repositories
{
    public class OrmLocationRepository : GenericRepository<ORMLocation>, IOrmLocationRepository
    {
        public OrmLocationRepository(AppDbContext appDbContext) : base(appDbContext)
        {
           
        }
        

    }
}
