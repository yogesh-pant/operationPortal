﻿using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;
using ORM.Infrastructure.UOW;
using System;

namespace ORM.Infrastructure.Repositories
{
    public class OrmUserRepository : GenericRepository<ORMUser>, IOrmUserRepository
    {
       
        public OrmUserRepository(AppDbContext appDbContext) : base(appDbContext)
        {
        }

      
    }
}
