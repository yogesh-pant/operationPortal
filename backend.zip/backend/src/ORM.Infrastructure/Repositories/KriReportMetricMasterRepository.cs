﻿using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;

namespace ORM.Infrastructure.Repositories
{
    public class KriReportMetricMasterRepository : GenericRepository<ORMKRIMetricMaster>, IKriReportMetricMasterRepository
    {
        public KriReportMetricMasterRepository(AppDbContext appDbContext) : base(appDbContext)
        {


        }

    }
}
