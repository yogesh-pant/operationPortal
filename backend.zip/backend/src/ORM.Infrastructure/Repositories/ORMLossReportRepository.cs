﻿using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;

namespace ORM.Infrastructure.Repositories
{
    public class OrmLossReportRepository : GenericRepository<ORMLossReport>, IOrmLossReportRepository
    {
        public OrmLossReportRepository(AppDbContext appDbContext) : base(appDbContext)
        {

        }
        public void DeleteRange(IEnumerable<ORMLossReport> entities)
        {
            _dbContext.ORMLossReport.RemoveRange(entities);
            _dbContext.SaveChanges(); // Or use an async save changes method if applicable
        }

    }
}
