﻿using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;

namespace ORM.Infrastructure.Repositories
{
    public class KriReportMetricsRepository : GenericRepository<ORMKRIReportMetrics>, IKriReportMetricsRepository
    {
        public KriReportMetricsRepository(AppDbContext appDbContext) : base(appDbContext)
        {

        }

        public void Delete(ORMKRIReportMetrics entity)
        {
            _dbContext.ORMKRIReportMetrics.Remove(entity);
            _dbContext.SaveChanges(); // Or use an async save changes method if applicable
        }

        public void DeleteRange(IEnumerable<ORMKRIReportMetrics> entities)
        {
            _dbContext.ORMKRIReportMetrics.RemoveRange(entities);
            _dbContext.SaveChanges(); // Or use an async save changes method if applicable
        }
    }
}
