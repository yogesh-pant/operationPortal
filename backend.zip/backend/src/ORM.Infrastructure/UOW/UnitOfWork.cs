﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Persistance;
using ORM.Infrastructure.Repositories;
using System;
using System.Diagnostics.CodeAnalysis;
namespace ORM.Infrastructure.UOW
{
    [ExcludeFromCodeCoverage]
    public class UnitOfWork : IUnitOfWork
    {
        private IOrmUserRepository? _ormUsersRepository;
        private IRoleRepository? _roleRepository;
        private IKriReportRepository? _kriReportRepository;
        private IKriReportMetricsRepository? _kriReportMetricsRepository;
        private IKriReportMetricMasterRepository? _kriReportMetricMasterRepository;
        private OrmLossReportRepository? _lossReportRepository;
        private IOrmLocationRepository? _ormLocationRepository;
        private IOrmUserLocationMapRepository? _ormUserLocationMapRepository;
        private IOrmRiskRepository? _ormRiskRepository;



        private readonly AppDbContext _appDbContext;

        /// <summary>
        /// provide appdbcontext access to ORMUserRepository
        /// </summary>
        public IOrmUserRepository ORMUsers
        {
            get
            {
                if (_ormUsersRepository == null)
                {
                    _ormUsersRepository = new OrmUserRepository(_appDbContext);
                }
                return _ormUsersRepository;

            }
        }

        /// <summary>
        /// provide appdbcontext access to RoleRepository
        /// </summary>
        public IRoleRepository ORMRoles
        {
            get
            {
                if (_roleRepository == null)
                {
                    _roleRepository = new RoleRepository(_appDbContext);
                }
                return _roleRepository;

            }
        }
        
        public IKriReportMetricMasterRepository ORMKRIMetricMaster
        {
            get
            {
                if (_kriReportMetricMasterRepository == null)
                {
                    _kriReportMetricMasterRepository = new KriReportMetricMasterRepository(_appDbContext);
                }
                return _kriReportMetricMasterRepository;

            }
        }
        public IKriReportMetricsRepository ORMKRIReportMetrics
        {
            get
            {
                if (_kriReportMetricsRepository == null)
                {
                    _kriReportMetricsRepository = new KriReportMetricsRepository(_appDbContext);
                }
                return _kriReportMetricsRepository;

            }
        }
        public IKriReportRepository ORMKRIReport
        {
            get
            {
                if (_kriReportRepository == null)
                {
                    _kriReportRepository = new KriReportRepository(_appDbContext);
                }
                return _kriReportRepository;

            }

        }

        public IOrmLossReportRepository ORMLossReport
        {
            get
            {
                if (_lossReportRepository == null)
                {
                    _lossReportRepository = new OrmLossReportRepository(_appDbContext);
                }
                return _lossReportRepository;

            }
        }


        public IOrmLocationRepository ORMLocation
        {
            get
            {
                if (_ormLocationRepository == null)
                {
                    _ormLocationRepository = new OrmLocationRepository(_appDbContext);
                }
                return _ormLocationRepository;

            }
        }
        public IOrmUserLocationMapRepository ORMUserLocationMap
        {
            get
            {
                if (_ormUserLocationMapRepository == null)
                {
                    _ormUserLocationMapRepository = new OrmUserLocationMapRepository(_appDbContext);
                }
                return _ormUserLocationMapRepository;

            }
        }
        public IOrmRiskRepository ORMRiskReport
        {
            get
            {
                if (_ormRiskRepository == null)
                {
                    _ormRiskRepository = new OrmRiskRepository(_appDbContext);
                }
                return _ormRiskRepository;

            }
        }


        public UnitOfWork(AppDbContext dbContext)
        {
            _appDbContext = dbContext;
        }
        /// <summary>
        /// provide method to save changes in database
        /// </summary>
        /// <returns>save count</returns>
        public int Save()
        {
            var result = _appDbContext.SaveChanges();
            return result;
        }
        public int Delete<TEntity>(TEntity entity) where TEntity : class
        {
            _appDbContext.Set<TEntity>().Remove(entity);
            return _appDbContext.SaveChanges();
        }
        public async Task<int> SaveAsync()
        {
            var result = await _appDbContext.SaveChangesAsync();
            return result;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _appDbContext.Dispose();
            }
        }

        public async Task<string?> GetKRIReportRecordCount()
        {
            DateTime currentDate = DateTime.Now;
            string yearMonth = currentDate.ToString("yyyyMM");
            // Fetch the maximum RefNum in current yearmonth
            var maxRefNum = await _appDbContext.Set<ORMKRIReport>()
                .Where(r => r.RefNum.Contains(yearMonth))
                .MaxAsync(r => r.RefNum) ?? $"KRIRP-yyyymm-0000";
            ///e.g.KRIRP-YYYYMM-0001

            int? maxNumericValue = int.TryParse(maxRefNum.AsSpan(13), out int numericValue)
            ? numericValue
            : (int?)null;

            if (maxNumericValue.HasValue)
            {
                numericValue++; // Increment the numeric value
            }

            string snumericValue = numericValue.ToString("0000");
            string refNum = "KRIRP-" + yearMonth + "-" + snumericValue;

            return refNum;
        }

        public async Task<string?> GetKRIMasterRecordCount(string LocationString)
        {

            // Fetch the maximum RefNum in current KRIMetricId
            var maxRefNum = await _appDbContext.Set<ORMKRIMetricMaster>()
                .Where(r => r.KRIMetricId.Contains(LocationString))
                .MaxAsync(r => r.KRIMetricId) ?? "KRIMT-00001-00";
            ///e.g.KRIMT-00001-00
            /// Extract the numeric part from the maximum KRIMetricId
            int? maxNumericValue = int.TryParse(maxRefNum.AsSpan(12), out int numericValue)
            ? numericValue
            : (int?)null;

            if (maxNumericValue.HasValue)
            {
                numericValue++; // Increment the numeric value
            }
            string snumericValue = numericValue.ToString("00");
            string KRIMetricId = "KRIMT-" + LocationString + "-" + snumericValue;

            return KRIMetricId;
        }

        public async Task<List<long>> SaveAllKriReportMetricsAsync(List<ORMKRIReportMetrics> entities)
        {
            _appDbContext.ORMKRIReportMetrics.AddRange(entities);
            await _appDbContext.SaveChangesAsync();

            return entities.Select(e => e.Id).ToList();
        }

        public async Task<long> SaveAndGetIdKriMasterAsync(ORMKRIMetricMaster entity)
        {
            _appDbContext.ORMKRIMetricMaster.Add(entity);
            await _appDbContext.SaveChangesAsync();
            return entity.Id;
        }
        public async Task<long> SaveAndGetIdKriReportAsync(ORMKRIReport entity)
        {
            _appDbContext.ORMKRIReport.Add(entity);
            await _appDbContext.SaveChangesAsync();

            return entity.Id;
        }
        public async Task<long> SaveAndGetIdRLOLossDataAsync(ORMLossReport entity)
        {
            _appDbContext.ORMLossReport.Add(entity);
            await _appDbContext.SaveChangesAsync();

            return entity.Id;
        }

        public async Task<string?> GetLossReportRecordCount()
        {
            DateTime currentDate = DateTime.Now;
            string yearMonth = currentDate.ToString("yyyyMM");
            // Fetch the maximum RefNum in current yearmonth
            var maxRefNum = await _appDbContext.Set<ORMLossReport>()
                .Where(r => r.RefNum.Contains(yearMonth))
                .MaxAsync(r => r.RefNum) ?? "LossRP-yyyyMM-0000";
            //e.g.LossRP-YYYYMM-0001
            // Extract the numeric part from the maximum LocationId
            int? maxNumericValue = int.TryParse(maxRefNum.AsSpan(14), out int numericValue)
            ? numericValue
            : null;

            if (maxNumericValue.HasValue)
            {
                numericValue++; // Increment the numeric value
            }

            string snumericValue = numericValue.ToString("0000");
            string refNum = "LossRP-" + yearMonth + "-" + snumericValue;

            return refNum;
        }

        public async Task<string?> GetRiskReportRecordCount()
        {
            DateTime currentDate = DateTime.Now;
            string yearMonth = currentDate.ToString("yyyyMM");
            // Fetch the maximum RefNum in current yearmonth
            var maxRefNum = await _appDbContext.Set<ORMRiskReport>()
                .Where(r => r.RefNum.Contains(yearMonth))
                .MaxAsync(r => r.RefNum) ?? "RiskRP-yyyyMM-0000";
            //e.g.RiskRP-YYYYMM-0001
            // Extract the numeric part from the maximum LocationId
            int? maxNumericValue = int.TryParse(maxRefNum.AsSpan(14), out int numericValue)
            ? numericValue
            : null;

            if (maxNumericValue.HasValue)
            {
                numericValue++; // Increment the numeric value
            }
            string snumericValue = numericValue.ToString("0000");
            string refNum = "RiskRP-" + yearMonth + "-" + snumericValue;

            return refNum;
        }
        public async Task<string?> GetNextLocationId(string locationtype)
        {
            // Fetch the maximum LocationId that matches the LocationType
            var maxLocationId = await _appDbContext.Set<ORMLocation>()
                .Where(r => r.LocationType == locationtype)
                .MaxAsync(r => r.LocationId);

            // Extract the numeric part from the maximum LocationId

            int? maxNumericValue = int.TryParse(maxLocationId.AsSpan(1), out int numericValue)
            ? numericValue
            : null;

            if (maxNumericValue.HasValue)
            {
                numericValue++; // Increment the numeric value
            }
            string snumericValue = numericValue.ToString("0000");
            return locationtype + snumericValue;
        }
        public async Task<long> SaveAndGetIdLocationAsync(ORMLocation entity)
        {
            _appDbContext.ORMLocation.Add(entity);
            await _appDbContext.SaveChangesAsync();

            return entity.Id;
        }
        public string GetUserNameById(long? id)
        {
            var user = ORMUsers.GetAll().AsQueryable()
                .FirstOrDefaultAsync(lo => lo.Id == id);
            if (user != null)
            {
                return user.Result?.UserName!;
            }
            else
            {
                return string.Empty;
            }
        }
        public string GetLocationNameById(long? locationId)
        {
            var LocationInfo = ORMLocation.GetAll().AsQueryable()
                .FirstOrDefaultAsync(lo => lo.Id == locationId);

            if (LocationInfo != null)
            {
                if (LocationInfo.Result?.LocationType == "B")
                    return LocationInfo.Result?.Branch!;
                else
                    return LocationInfo.Result?.Department!;
            }
            else
            {
                return string.Empty;
            }

        }
        public string GetRegionByLocationId(long? locationId)
        {
            var RegionInfo = ORMLocation.GetAll().AsQueryable()
                .FirstOrDefaultAsync(lo => lo.Id == locationId).Result?.Region;

            
            return RegionInfo!;

        }
        public async Task<long> SaveAndGetIdRiskReportAsync(ORMRiskReport entity)
        {
            _appDbContext.ORMRiskReport.Add(entity);
            await _appDbContext.SaveChangesAsync();

            return entity.Id;
        }
        public async Task<long> SaveAndGetIdORMUserAsync(ORMUser entity)
        {
            _appDbContext.ORMUsers.Add(entity);
            await _appDbContext.SaveChangesAsync();

            return entity.Id;
        }
        public async Task<IEnumerable<long>> SaveAndGetIdORMUserLocationMapAsync(IEnumerable<ORMUserLocationMap> entities)
        {
            _appDbContext.ORMUserLocationMap.AddRange(entities);
            await _appDbContext.SaveChangesAsync();

            return entities.Select(e => e.Id);
        }
    }
}
