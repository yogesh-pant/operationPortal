﻿
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;

namespace ORM.Infrastructure.UOW
{
    /// <summary>
    /// This interface will keep the repository
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        public IOrmUserRepository ORMUsers { get; }
        public IRoleRepository ORMRoles { get; }
        public IKriReportMetricMasterRepository ORMKRIMetricMaster { get; }
        public IKriReportMetricsRepository ORMKRIReportMetrics { get; }
        public IKriReportRepository ORMKRIReport { get; }
        public IOrmLossReportRepository ORMLossReport { get; }
        public IOrmLocationRepository ORMLocation { get; }
        public IOrmUserLocationMapRepository ORMUserLocationMap { get; }
        public IOrmRiskRepository ORMRiskReport { get; }


        public int Save();
        public Task<int> SaveAsync();
        Task<string?> GetKRIReportRecordCount();
        Task<string?> GetKRIMasterRecordCount(string LocationString);        
        Task<long> SaveAndGetIdKriReportAsync(ORMKRIReport entity);
        Task<long> SaveAndGetIdKriMasterAsync(ORMKRIMetricMaster entity);
        Task<List<long>> SaveAllKriReportMetricsAsync(List<ORMKRIReportMetrics> entities);
        Task<long> SaveAndGetIdRLOLossDataAsync(ORMLossReport entity);
        Task<string?> GetLossReportRecordCount();
        Task<string?> GetRiskReportRecordCount();
        Task<string?> GetNextLocationId(string locationtype);
        Task<long> SaveAndGetIdLocationAsync(ORMLocation entity);
        public string GetUserNameById(long? id);
        public string GetLocationNameById(long? locationId);
        public string GetRegionByLocationId(long? locationId);
        Task<long> SaveAndGetIdRiskReportAsync(ORMRiskReport entity);
        Task<long> SaveAndGetIdORMUserAsync(ORMUser entity);
        Task<IEnumerable<long>> SaveAndGetIdORMUserLocationMapAsync(IEnumerable<ORMUserLocationMap> entities);
        



    }
}

