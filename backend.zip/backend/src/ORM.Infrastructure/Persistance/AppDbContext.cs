﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.Entities;

namespace ORM.Infrastructure.Persistance;
/// <summary>
/// 
/// </summary>
[ExcludeFromCodeCoverage]
public partial class AppDbContext : DbContext
{

    public AppDbContext()
    {
    }

    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }


    public virtual DbSet<ORMUser> ORMUsers { get; set; }
    public virtual DbSet<ORMAppRole> ORMRoles { get; set; }
    public virtual DbSet<ORMKRIMetricMaster> ORMKRIMetricMaster { get; set; }
    public virtual DbSet<ORMKRIReport> ORMKRIReport { get; set; }
    public virtual DbSet<ORMKRIReportMetrics> ORMKRIReportMetrics { get; set; }
    public virtual DbSet<ORMLossReport> ORMLossReport { get; set; }
    public virtual DbSet<ORMRiskReport> ORMRiskReport { get; set; }
    public virtual DbSet<ORMLocation> ORMLocation { get; set; }
    public virtual DbSet<ORMUserLocationMap> ORMUserLocationMap { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ORMKRIReportMetrics>()
            .HasOne(m => m.ORMKRIReport)
            .WithMany()
            .HasForeignKey(m => m.KRIReportId);

        modelBuilder.Entity<ORMUserLocationMap>()
            .HasOne(m => m.ORMUser)
            .WithMany()
            .HasForeignKey(m => m.UserId); 
        
        modelBuilder.Entity<ORMKRIReport>()
            .HasOne(m => m.ORMUser)
            .WithMany()
            .HasForeignKey(m => m.ValidatorILOUserId);

        modelBuilder.Entity<ORMUserLocationMap>()
           .HasOne(m => m.ORMLocation)
           .WithMany()
           .HasForeignKey(m => m.LocationId);

        modelBuilder.Entity<ORMKRIReportMetrics>()
            .HasOne(m => m.ORMKRIMetricMaster)
            .WithMany()
            .HasForeignKey(m => m.KRIMetricMasterId);

        modelBuilder.Entity<ORMLossReport>()
            .HasOne(m => m.PrevLossReport)
            .WithMany()
            .HasForeignKey(m => m.PrevLossReportId)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.AmountInvolved)
            .HasColumnType("decimal(18, 2)"); // Adjust precision and scale 

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.NearMissAmount)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.PotentialLossAmount)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.GrossActualAmount)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.RecoveredAmount)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.FurtherRecoveredAmount)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ORMLossReport>()
            .Property(x => x.NetActualLossAmount)
            .HasColumnType("decimal(18, 2)");

        modelBuilder.Entity<ORMUser>()
            .HasOne(u => u.ORMAppRole)
            .WithMany()
            .HasForeignKey(u => u.RoleId)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.Restrict);
    }

}
