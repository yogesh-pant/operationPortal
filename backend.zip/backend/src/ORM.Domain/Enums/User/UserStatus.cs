﻿namespace ORM.Domain.Enums.User
{
    public enum UserStatus
    {
        Active, Inactive
    }
}
