﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Domain.Enums.User
{
    public enum UserType
    {
        Admin=1, Supervisor=2, User=3
        
    }
}
