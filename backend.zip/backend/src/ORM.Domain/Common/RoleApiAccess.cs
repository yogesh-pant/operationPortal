﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Domain.Common
{
    public enum AdminMakerApis
    {
        //dashboard graph api
        getkeyriskindicator,
        gettrendofoperationalrisksource,
        riskreports,
        getgrossvsrecoveryvsnetloss,
        getrootcauseanalysisforactualloss,
        getoperationalrisklosses,
        getregionalinternalfraud,
        getoperationalrisklossesvsfraudloss,
        getlossdatatrend,
        getnonfunctionalcctvandpatches,
        getkyccompliance,

        //loss data api
        sendlossrpreviewreminder,
        getfulllossdatabysingleid,
        approvelossdataborm,
        updatelossdataborm,
        createlossdatarlo,
        updatelossdatarlo,
        getlossgriddata,

        //kri api

        getkrigridreportdata,
        getkrigriddata,
        getdetailkriapi,

        //risk api
        updateriskreportstatus,
        getriskdoc,
        updateriskreport,
        getriskreportlist,

        //REPORTs



        //location
        updatedepartmentlocation,
        updatebranchlocation,
        createdepartmentlocation,
        createbranchlocation,
        getdepartmentlist,
        getbranchlist,

        //User 

        getuserbyrolelocation,
        getusers,
        getroles,
        createormuser,
        newuser,
        updateuserdetails,

        //Metric Master 
        getkrimastergriddata,
        createkrimaster,
        updatekrimaster,
        togglekrimasterstatus,

        logout,


    }
    public enum AdminCheckerApis
    {
        //dashboard graph api
        getkeyriskindicator,
        gettrendofoperationalrisksource,
        riskreports,
        getgrossvsrecoveryvsnetloss,
        getrootcauseanalysisforactualloss,
        getoperationalrisklosses,
        getregionalinternalfraud,
        getoperationalrisklossesvsfraudloss,
        getlossdatatrend,
        getnonfunctionalcctvandpatches,
        getkyccompliance,

        //loss data api
        sendlossrpreviewreminder,
        getfulllossdatabysingleid,
        approvelossdataborm,
        updatelossdataborm,
        createlossdatarlo,
        updatelossdatarlo,
        getlossgriddata,

        //kri api

        getkrigridreportdata,
        getkrigriddata,
        getdetailkriapi,

        //risk api
        updateriskreportstatus,
        getriskdoc,
        updateriskreport,
        getriskreportlist,

        //REPORTs



        //location
        getdepartmentlist,
        getbranchlist,
        approvelocationchange,
        rejectlocationchange,

        //User 

        getuserbyrolelocation,
        getusers,
        getroles,
        approveuserinfo,
        rejectuserinfo,

        //Metric Master 
        getkrimastergriddata,
        approvekrimasterchange,
        rejectkrimasterchange,

        logout,


    }
    public enum RloApis
    {
        //Loss Data api

        getfulllossdatabysingleid,
        createlossdatarlo,
        updatelossdatarlo,
        getlossgriddata,

        //kri api
        removemetric,
        deletekrireportapi,
        geteditkridata,
        getmetricdataapi,
        updatepreviewkriapi,
        getdetailkriapi,
        getpreviewkriapi,
        postkrireport,
        getnewkridata,
        getkrigridreportdata,
        getkrigriddata,
        postnewkri,
        validateduplicatekrireport,

        //risk api
        getriskdoc,
        editriskreport,
        createriskreport,
        getriskreportlist,


        //location
        getdepartmentlist,
        getbranchlist,
        getuserbyrolelocation,

        logout,

    }

    public enum IcoApis
    {
        //dashboard graph api
        gettrendofoperationalrisksource,
        riskreports,

        //loss data api
        getfulllossdatabysingleid,
        approvelossdataborm,
        getlossgriddata,

        //kri api
        getpreviewkriapi,
        getkrigridreportdata,
        getkrigriddata,
        getdetailkriapi,
        updatefinalkriapi,

        //location
        getdepartmentlist,
        getbranchlist,

        logout,
    }

    public enum GlaApis
    {
        //dashboard graph api
        gettrendofoperationalrisksource,
        riskreports,

        //loss data api
        getfulllossdatabysingleid,
        getlossgriddata,

        //kri api

        getpreviewkriapi,
        getkrigridreportdata,
        getkrigriddata,
        getdetailkriapi,

        //location
        getdepartmentlist,
        getbranchlist,

        logout,

    }

}
