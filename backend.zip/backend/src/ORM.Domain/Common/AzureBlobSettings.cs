﻿using System;
using System.Diagnostics.CodeAnalysis;
namespace ORM.Domain.Common
{
    [ExcludeFromCodeCoverage]
    public class AzureBlobSettings
    {
        public string ConnectionString { get; set; } = string.Empty;
        public string ContainerName { get; set; } = string.Empty;
    }
}