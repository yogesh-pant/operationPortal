﻿using System;
using System.Diagnostics.CodeAnalysis;
namespace ORM.Domain.Common
{
    [ExcludeFromCodeCoverage]
    public class CombinedUserChangeData
    {
        public UserChangeData? UserChangeData { get; set; }
        public FormattedUserChangeData? FormattedUserChangeData { get; set; }
    }

    public class UserChangeData
    {
        public long? UserNewRole { get; set; }
        public long? UserNewSubRole { get; set; }
        public string? UserNewStatus { get; set; }
        public IEnumerable<long>? UserNewLocations { get; set; }
        public long? UserNewUpdatedBy { get; set; }
        public DateTime? UserNewChangeRequestDate { get; set; } 
    }

    public class FormattedUserChangeData
    {
        public string? UserNewFlag { get; set; } = "No"!;
        public string? UserNewRole { get; set; } = null!;
        public string? UserNewSubRole { get; set; } = null!;
        public string? UserNewStatus { get; set; } = null!;
        public IEnumerable<string>? UserNewLocations { get; set; } = null!;
        public string? UserNewUpdatedBy { get; set; } = null!;
        public String? UserNewChangeRequestDate { get; set; } = null!;  
    }
}