﻿using System;
using System.Diagnostics.CodeAnalysis;
namespace ORM.Domain.Common
{
    [ExcludeFromCodeCoverage]
   

    public class LocationDeptChangeData
    {
        public string? NewLocationDepartment { get; set; } = null!;
        public string? NewLocationStatus { get; set; } = null!;
        public string? LocationNewFlag { get; set; } = "No"!; 
        public long? LocationNewUpdatedBy { get; set; } = null!;
        public string? LocationNewUpdatedByName { get; set; }
        public DateTime? LocationNewChangeRequestDate { get; set; } = null!;
    }

    public class LocationBranchChangeData
    {
        public string? NewLocationBranch { get; set; } = null!;
        public string? NewLocationRegion { get; set; } = null!;
        public string? NewLocationStatus { get; set; } = null!;
        public string? LocationNewFlag { get; set; } = "No"!;
        public long? LocationNewUpdatedBy { get; set; } = null!;
        public string? LocationNewUpdatedByName { get; set; } = null!;
        public DateTime? LocationNewChangeRequestDate { get; set; } = null!;
    }
}