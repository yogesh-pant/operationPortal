using System;
using System.Diagnostics.CodeAnalysis;
namespace ORM.Domain.Common
{
    [ExcludeFromCodeCoverage]
    public class KRIMasterChangeData
    {
        public string?   MetricNewName { get; set; }
        public string?   MetricNewFrequency { get; set; }
        public string?   KRIMasterNewFlag { get; set; }        
        public string? MetricNewAppetiteLowerBound { get; set; }
        public string? MetricNewAppetiteUpperBound { get; set; }
        public string? MetricNewAppetiteType { get; set; }
        public string? MetricNewToleranceLowerBound { get; set; }
        public string? MetricNewToleranceUpperBound { get; set; }
        public string? MetricNewToleranceType { get; set; }
        public string? MetricNewEscalationLowerBound { get; set; }
        public string? MetricNewEscalationUpperBound { get; set; }
        public string? MetricNewEscalationType { get; set; }
        public bool?   MetricNewActivationStatus { get; set; }
        public long?   MetricNewUpdatedBy { get; set; }
        public string?   MetricNewUpdatedByName { get; set; }
        public DateTime? MetricNewChangeRequestDate { get; set; }
    }
}