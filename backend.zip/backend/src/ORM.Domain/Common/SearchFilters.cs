﻿namespace ORM.Domain.Common
{
    public static class SearchFilters
    { 
    public static bool IsValidStringFilter(string? filter)
    {
        return !string.IsNullOrWhiteSpace(filter) && filter != "undefined";
    }
    public static bool IsValidNumericFilter(long? filter)
    {
        return filter.HasValue && filter.Value != 0;
    }
    }
}
