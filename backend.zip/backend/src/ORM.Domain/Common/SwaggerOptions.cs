﻿using System.Diagnostics.CodeAnalysis;
namespace ORM.Domain.Common
{
    [ExcludeFromCodeCoverage]
    public class SwaggerOptions
    {
        public string Title { get; set; } = string.Empty;
        public string Version { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string ContactName { get; set; } = string.Empty;
        public string ContactEmail { get; set; } = string.Empty;
        public string LicenseName { get; set; } = string.Empty;
        public string LicenseUrl { get; set; } = string.Empty;
    }
}