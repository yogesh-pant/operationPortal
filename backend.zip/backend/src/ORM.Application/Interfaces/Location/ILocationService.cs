﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Application.Interfaces.Location
{
    public interface ILocationService
    {
        Task<ListResponse<BranchLocationGridResponse>> GetAllBranchLocationsAsync(FilterBranchListRequest input);
        Task<ListResponse<DepartmentLocationGridResponse>> GetAllDepartmentLocationsAsync(FilterDepartmentListRequest input);
        Task<ListResponse<ReturnId>> CreateBranchLocationAsync(CreateBranchLocationRequest input);
        Task<ListResponse<ReturnId>> CreateDepartmentLocationAsync(CreateDepartmentLocationRequest input);
        Task<ListResponse<ReturnId>> UpdateBranchLocationAsync(UpdateBranchLocationRequest input);
        Task<ListResponse<ReturnId>> UpdateDepartmentLocationAsync(UpdateDepartmentLocationRequest input);
        Task<ObjectResponse<string>> ApproveLocationChangeAsync(ReviewUserChangeRequest request);
        Task<ObjectResponse<string>> RejectLocationChangeAsync(ReviewUserChangeRequest request);


    }
}
