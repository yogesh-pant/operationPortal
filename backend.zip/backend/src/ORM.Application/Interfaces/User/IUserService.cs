﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Application.Interfaces.User
{
    public interface IUserService
    {
        Task<ListResponse<UserResponse>> GetAllUserAsync(FilterUserRequest filterUserRequest);
        Task<ObjectResponse<string>> UpdateUserInfo(EditUserRequest request);
        Task<ListResponse<UserResponse>> AddUserInfo(string UserName);
        Task<ListResponse<ReturnId>> AddNewUserInfo(AddNewUserRequest request);
        Task<ListResponse<GetUsersByRoleLocationResponse>> GetUserByRoleLocationAsync(FilterGetUsersByRoleLocationRequest request);
        Task<ObjectResponse<string>> ApproveUserInfoAsync(ReviewUserChangeRequest request);
        Task<ObjectResponse<string>> RejectUserInfoAsync(ReviewUserChangeRequest request);



    }
}
