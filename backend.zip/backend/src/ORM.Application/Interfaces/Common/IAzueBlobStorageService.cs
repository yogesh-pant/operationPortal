﻿using Microsoft.AspNetCore.Http;

namespace ORM.Application.Interfaces.Common
{
    public interface IAzueBlobStorageService
    {
        Task<string> UploadFileAsync(IFormFile file);
        Task<byte[]> GetFileAsBytesAsync(string fileName);
        Task<string> GetFileAsBase64Async(string fileName);
    }
}
