﻿using ORM.Application.Models.Requests.Mails;

namespace ORM.Application.Interfaces.Common
{
    public interface IMailService
    {
        public Task<bool> SendMailAsync(MailDataRequest mailData);
    }

}
