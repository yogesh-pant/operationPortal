﻿using Microsoft.Extensions.Logging;

namespace ORM.Application.Interfaces.Common
{
    public interface IKeyVaultHelper
    {
        Task<string?> GetSecretAsync(string secretName);
    }
}