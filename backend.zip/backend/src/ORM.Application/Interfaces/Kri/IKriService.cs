﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Application.Interfaces.Role
{
    public interface IKriService
    {
        Task<ListResponse<KriPreviewResponse>> GetKriGridAsync(KriGridRequest input);
        Task<ListResponse<KriDataGridResponse>> GetKriReportGridAsync(KriGridRequest input);
        Task<ListResponse<CreateKriResponse>> GetNewKriAsync(GetNewKriRequest input);
        Task<ListResponse<NewKriReportResponse>> AddKriInfo(AddKriRequest input);
        Task<ListResponse<ReturnId>> AddKrimetric(AddKriReport input);
        Task<ListResponse<KriPreviewResponse>> GetPreviewKriAsync(GetPreviewKriMultipleRequest request);
        Task<ListResponse<string>> UpdatePreviewKriAsync(UpdatePreviewKriRequest input);
        Task<ListResponse<string>> updateKriApproval(FinalKriReport input);
        Task<ListResponse<KriPreviewResponse>> GetDetailKriReportAsync(GetPreviewKriRequest request);
        Task<ListResponse<KriPreviewResponse>> GetDetailKriMetricAsync(UpdatePreviewKriRequest request);
        Task<ListResponse<EditKriResponse>> GetEditKriReportAsync(EditKriRequest request);
        Task<ObjectResponse<string>> DeleteKriReportAsync(UpdatePreviewKriRequest request);
        Task<ListResponse<string>> RemoveKriMetricAsync(UpdatePreviewKriRequest input);
        Task<ObjectResponse<string>> ValidateDuplicateKriReportAsync(ValidateDuplicateKriReportRequest request);
        
    }
}
