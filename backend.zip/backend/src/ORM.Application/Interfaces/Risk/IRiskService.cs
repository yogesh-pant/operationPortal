﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Infrastructure.Services
{
    public interface IRiskService
    {
        Task<ListResponse<RiskGridResponse>> GetRiskGridAsync(FilterRiskListRequest input);
        Task<ListResponse<ReturnId>> CreateRiskDataAsync(CreateRiskDataRequest input);
        Task<ListResponse<ReturnId>> EditRiskDataAsync(EditRiskDataRequest input);
        Task<ListResponse<ReturnId>> UpdateRiskDataAsync(UpdateRiskDataRequest input);
        Task<ListResponse<ReturnId>> UpdateRiskStatusAsync(UpdateRiskStatusRequest input);
        Task<ListResponse<RiskDoc>> GetRiskReportDoc(GetDocRequest input);
    }
}
