﻿using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Application.Interfaces.Role
{
    public interface IKriMasterService
    {
        Task<ListResponse<GetKriMasterGridResponse>> GetKriMasterGridAsync(GetKriMasterGridRequest input);
        Task<ListResponse<ReturnId>> CreateKriMasterAsync(CreateKriMasterRequest input);
        Task<ListResponse<ReturnId>> UpdateKriMasterAsync(UpdateKriMasterRequest input); 
        Task<ListResponse<ReturnId>> ToggleKriMasterStatusAsync(ToggleKriMasterStatusRequest input);
        Task<ListResponse<string>> ApproveKRIMasterChangeAsync(ReviewUserChangeRequest input);
        Task<ListResponse<string>> RejectKRIMasterChangeAsync(ReviewUserChangeRequest input);



    }
}
