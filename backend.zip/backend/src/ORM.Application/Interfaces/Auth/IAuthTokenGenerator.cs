﻿using ORM.Application.Models.Auth;

namespace ORM.Application.Interfaces.Auth
{
    public interface IAuthTokenGenerator
    {
        string Generate(bool isAutherizedUser,StaffSession session, TimeSpan validity);
    }
}
