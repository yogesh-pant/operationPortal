﻿using Fcmb.Shared.Auth.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Responses;
using System.Net;

namespace ORM.Application.Interfaces.Auth
{
    public interface IAuthSetupService
    {
        Task<ObjectResponse<LoginResponse>> LoginAsync(LoginRequest request, string ip);
        Task<ObjectResponse<LoginResponse>> CheckUserInAdAsync(string username, string ip);
        Task<ObjectResponse<string>>LogoutAsync(string UserName, string ip);
    }
}