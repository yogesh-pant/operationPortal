﻿using ORM.Application.Models.Auth;

namespace ORM.Application.Interfaces.Auth
{
    public interface ISessionService
    {
        StaffSession? GetStaffSession();
    }
}
