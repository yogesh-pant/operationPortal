﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Application.Interfaces.Role
{
    public interface IRoleService
    {
        Task<ListResponse<RoleGridResponse>> GetAllRoleAsync(FilterRoleRequest filterRoleRequest);
    }
}
