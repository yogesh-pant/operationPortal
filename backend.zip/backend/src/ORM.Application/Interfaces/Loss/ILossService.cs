﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;

namespace ORM.Application.Interfaces.Role
{
    public interface ILossService
    {
        Task<ListResponse<LossDataGridResponse>> GetLossGridAsync(LossGridRequest input);
        Task<ListResponse<ReturnId>> CreateLossDataAsync(CreateLossDataRequest input);
        Task<ListResponse<ReturnId>> UpdateLossDataRLOAsync(UpdateLossDataRloRequest input);
        Task<ListResponse<ReturnId>> UpdateLossDataBORMAsync(UpdateLossDataBormRequest input);
        Task<ListResponse<ReturnId>> ApproveLossDataBORMAsync(ApproveLossDataBormRequest input);
        Task<ListResponse<GetFullLossDataBySingleIdResponse>> GetFullLossDataBySingleIdAsync(GetFullLossDataBySingleIdRequest input);
        Task<ListResponse<SendLossRpReviewReminderResponse>> SendLossRpReviewReminder(GetFullLossDataBySingleIdRequest input);

    }
}
