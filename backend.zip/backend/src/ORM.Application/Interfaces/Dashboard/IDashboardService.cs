﻿using Fcmb.Shared.Models.Responses;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Interfaces.Dashboard
{
    public interface IDashboardService
    {
        Task<ListResponse<LossTrendResponse>> GetLossDataTrend(BaseDashboardChartsRequest request);
        Task<ListResponse<OperationalRiskLossVsFraudLossResponse>> GetOperationalRiskLossesVsFraudLoss(BaseDashboardChartsRequest request);
        Task<ListResponse<RegionalInternalFraudResponse>> GetRegionalInternalFraudChart(BaseDashboardChartsRequest request);
        Task<ListResponse<OperationalRiskLossResponse>> GetOperationalRiskLosses(BaseDashboardChartsRequest request);
        Task<ListResponse<RootCauseAnalysisResponse>> GetRootCauseAnalysisForActualLoss(BaseDashboardChartsRequest request);
        Task<ListResponse<GrossVsRecoveryVsNetLossResponse>> GetGrossVsRecoveryVsNetLoss(BaseDashboardChartsRequest request);
        Task<ListResponse<RiskChartReportResponse>> GetRiskOccurenceCharts(FilterRiskReportRequest request);
        Task<ListResponse<TrendOfOperationalRiskSourceResponse>> GetTrendOfOperationalRiskSource(FilterRiskReportRequest request);
        Task<ListResponse<KeyRiskIndicatorResponse>> GetKeyRiskIndicator(FilterKeyRiskIndicatorRequest request);
        Task<ListResponse<KycComplianceResponse>> GetKYCComplianceChart(FilterKriReportMetricsRequest request);
        Task<ListResponse<NonFunctionalCctvAndPatchesResponse>> GetNonFunctionalCCTVAndPatches(FilterKriReportMetricsRequest request);

    }
}
