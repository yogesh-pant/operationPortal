﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    /// <summary>
    /// Model for Loss Responses
    /// </summary>

    [ExcludeFromCodeCoverage]
    public partial class LossPreviewResponse
    {
        public long Id { get; set; }
        public string RefNum { get; set; } = string.Empty;
        public long? PrevLossReportId { get; set; }
        public string? LocationType { get; set; }
        public long LocationId { get; set; }
        public long? ValidatorILOUserId { get; set; }
        public DateTime DateOccurance { get; set; }
        public DateTime DateDiscovery { get; set; }
        public DateTime DateReported { get; set; }
        public string? Description { get; set; }
        public string ReportStatus { get; set; } = "Saved";
    }

    public partial class LossDataGrid
    {
        public long? Id { get; set; }
        public long? ValidatorILOid { get; set; }
        public string? ValidatorILOUserName { get; set; }
        public string? RefNum { get; set; }
        public long? PrevLossReportId { get; set; }
        public string? InternalBusinessLineId { get; set; }
        public string? LossType { get; set; }
        public string? Currency { get; set; }
        public DateTime? DateOfOccurrence { get; set; }
        public DateTime? DateDiscovered { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public DateTime? DateReported { get; set; }
        public string? DetailedLossEvent { get; set; }
        public decimal? NearMiss { get; set; }
        public decimal? PotentialLoss { get; set; }
        public decimal? GrossActualLoss { get; set; }
        public decimal? AmountRecovered { get; set; }
        public decimal? FurtherRecovery { get; set; }
        public decimal? NetActualLoss { get; set; }
        public string? RootCause { get; set; }
        public string? RiskSourceId { get; set; }
        public decimal? AmountInvolved { get; set; }
        public string? Region { get; set; }
        public string? ProcessInvolved { get; set; }
        public string? RecoveryMode { get; set; }
        public string? EventStatus { get; set; }
        public string? Department { get; set; }
        public string? Branch { get; set; }
        public string? ReportStatus { get; set; }
        public long? CreatedBy { get; set; }
        public string? CreatedByName { get; set; }
        public string? ModifiedBy { get; set; }
        public long? ApprovedBy { get; set; }
        public string? ApprovedByName { get; set; }
        public string? StaffInvolvement { get; set; }
        public int? AllCount { get; set; }
        public string? LocationType { get; set; }
        public string? LocationName { get; set; }
        public long? LocationId { get; set; }
        public string? StaffJobRole { get; set; }
        public string? BaselEventTypeI { get; set; }
        public string? BaselEventTypeII { get; set; }
        public string? BaselEventTypeIII { get; set; }
        public string? BaselLevel1BusinessLine { get; set; }
        public string? BaselLevel2BusinessLine { get; set; }
        public string? RootCauseTypeBORM { get; set; }
        public string? RiskSource { get; set; }
        public string? LessonLearnt { get; set; }
        public string? ReviewerComments { get; set; }
        public string? UpdateHistory { get; set; }
    }

    public partial class RecordCount
    {
        public int? AUpdatedByBORMCount { get; set; }

    }

    public class LossDataGridResponse
    {
        public List<LossDataGrid> LossData { get; set; }
        public RecordCount RecordCounts { get; set; }

        public LossDataGridResponse(List<LossDataGrid> lossData, RecordCount recordCounts)
        {
            LossData = lossData!;
            RecordCounts = recordCounts;
        }
    }


    public partial class GetFullLossDataBySingleIdResponse
    {
        public string RefNum { get; set; } = string.Empty;
        public long? ValidatorILOUserId { get; set; }
        public string? ValidatorILOUserName { get; set; }

        public DateTime DateOccurance { get; set; }

        public DateTime DateDiscovery { get; set; }

        public DateTime DateReported { get; set; }

        public string? Description { get; set; }

        public string? RootCauseRLO { get; set; }

        public string? LossType { get; set; }

        public string? CurrencyType { get; set; }

        public decimal? AmountInvolved { get; set; }

        public decimal? NearMissAmount { get; set; }


        public decimal? PotentialLossAmount { get; set; }


        public decimal? GrossActualAmount { get; set; }


        public decimal? RecoveredAmount { get; set; }


        public decimal? FurtherRecoveredAmount { get; set; }

        public decimal? NetActualLossAmount { get; set; }

        public string? RecoveryChannel { get; set; }

        public string? StaffInvolvement { get; set; }

        public string EventStatus { get; set; } = string.Empty;

        public string ReportStatus { get; set; } = string.Empty;

        // Data fields populated by BORM Admin
        public string? StaffJobRole { get; set; }

        public string? InternalBusLine { get; set; }

        public string? BaselEventTypeI { get; set; }

        public string? BaselEventTypeII { get; set; }

        public string? BaselEventTypeIII { get; set; }

        public string? BaselLevel1BusinessLine { get; set; }

        public string? BaselLevel2BusinessLine { get; set; }

        public string? RootCauseTypeBORM { get; set; }

        public string? ProcessInvolved { get; set; }

        public string? RiskSource { get; set; }

        public string? LessonLearnt { get; set; }

        public string? ReviewerComments { get; set; }

        public string? UpdateHistory { get; set; }

        //Meta Data fields populated by system
        public long? CreatedById { get; set; } = null!;

        public string? CreatedByName { get; set; } = null!;

        public long? ModifiedById { get; set; } = null!;

        public string? ModifiedByName { get; set; } = null!;

        public long? ValidatedById { get; set; } = null!;

        public long? ApprovedById { get; set; } = null!;

        public string? ApprovedByName { get; set; } = null!;

        public DateTime? CreatedDate { get; set; } = null!;

        public DateTime? ModifiedDate { get; set; } = null!;

        public DateTime? ValidationDate { get; set; } = null!;

        public DateTime? ApprovedDate { get; set; } = null!;
        public string? Documents { get; set; }
        public string? DocumentName { get; set; }
        public string? FileType { get; set; }
        public string? LocationType { get; set; }
        public long? LocationId { get; set; } = null!;
        public string? Branch { get; set; }
        public string? Region { get; set; }
        public string? Department { get; set; }
    }

    public partial class SendLossRpReviewReminderResponse
    {
        public string? RefNum { get; set; } = null!;
    }
}