﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    public partial class RiskChartReportResponse
    {
        public string? Title { get; set; }
        public List<BaseChartsResponse>? Charts { get; set; }    
    }
}
