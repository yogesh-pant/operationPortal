﻿using System.Diagnostics.CodeAnalysis;

namespace ORM.Application.Models.Responses
{
    /// <summary>
    /// Model for RoleResponse
    /// </summary>
    
   
    [ExcludeFromCodeCoverage]
    public partial class RoleGridResponse
    {
        public long? RoleId { get; set; }
        public string RoleTitle { get; set; } = null!;
        public bool? Status { get; set; }
        public string? RoleUpdatedBy { get; set; }
        public DateTime? RoleUpdatedDate { get; set; }
        public string? RoleCreatedBy { get; set; }
        public DateTime? RoleCreatedDate { get; set; }
        public long? TotalCount { get; set; }

    }

}
