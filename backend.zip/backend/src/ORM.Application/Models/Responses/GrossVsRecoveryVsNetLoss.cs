﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    public partial class GrossVsRecoveryVsNetLoss
    {
      public decimal GrossActualAmount { get; set; }   
      public decimal RecoveredAmount {  get; set; }  
      public decimal FurtherRecoveredAmount { get; set; }    
      public decimal NetActualLossAmount { get; set; }   

    }
}
