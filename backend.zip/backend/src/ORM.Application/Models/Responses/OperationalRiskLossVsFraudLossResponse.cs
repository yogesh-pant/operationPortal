﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    public record OperationalRiskLossVsFraudLossResponse
    {
        public string? Month { get; set; }
        public decimal? ClientProductBusinessPractices { get; set; }    
        public decimal? ExecutionDeliveryProcessManagement { get; set; }
        public decimal? EmploymentPracticesWorkplaceSafety { get; set; }    
        public decimal? Fraud {  get; set; }    
    }
}
