﻿using System.Diagnostics.CodeAnalysis;

namespace ORM.Application.Models.Responses
{
    /// <summary>
    /// Model for UserResponse
    /// </summary>
    
    [ExcludeFromCodeCoverage]
    public partial class UserResponse
    {
        public long UserId { get; set; }
        public string UserName { get; set; } = null!;
        public string[]? SolId { get; set; } 
        public string[]? Region { get; set; }
        public string? EmailId { get; set; }
        public string[]? Branch { get; set; }
        public string? StaffId { get; set; }
        public string[]? Department { get; set; }
        public long[]? locationIds { get; set; }
        public string Status { get; set; } = "Active"!;
        public string? UserChangeStatus { get; set; }
        public long? UserRoleId { get; set; }
        public string? UserRole { get; set; }
        public long? UserSubRoleId { get; set; }
        public string? FailedloginCount { get; set; }
        public DateTime? lastLoginTime { get; set; }
        public DateTime? CurrentLoginTime { get; set; }
        public string? ChangeRequestData { get; set; }
        public string? UserNewFlag { get; set; } = "No"!;
        public string? UserNewLocations { get; set; }
        public string? UserNewRole { get; set; }
        public string? UserNewSubRole { get; set; }
        public string? UserNewStatus { get; set; }
        public string? UserNewUpdatedBy { get; set; }
        public string? UserNewChangeRequestDate { get; set; }


        public long? CreatedBy { get; set; }
        public string? CreatedByName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? UpdatedBy { get; set; }
        public String? UpdatedByName { get; set; }
        public DateTime? ChangeRequestDate { get; set; }  
        public long? ReviewedBy { get; set; }
        public string? ReviewedByName { get; set; }
        public DateTime? ChangeReviewDate { get; set; }
        public string? ChangeReviewComments { get; set; }

    }

    [ExcludeFromCodeCoverage]
    public partial class GetUsersByRoleLocationResponse
    {        
       // Query Fields - Can be queries on one or more fields 
        public long? Locationid { get; set; }
        public long? Roleid { get; set; }
        public string? RoleTitle { get; set; }
        public long? SubRoleid { get; set; }
        public string? UserStatus { get; set; }

        // Retrieved data fields for above query fields 
        public long? UserId { get; set; }
        public string? UserName { get; set; }
        public string? LocationType { get; set; }
        public string? LocationName { get; set; }


    }
}