﻿using Fcmb.Shared.Auth.Models.Requests;
using Fcmb.Shared.Models.Responses;
namespace ORM.Application.Models.Responses
{
    /// <summary>
    /// This is the model for LoginResponse
    /// </summary>
    public record LoginResponse
    {
        public string Token { get; init; } = "";

        public string RefreshToken { get; init; } = "";

        public string UserName { get; set; } = "";
        public string UserRole { get; set; } = "user";
        public long? UserSubRoleId { get; set; }

        public int FailLoginCount { get; init; } = 0;
        public bool IsAccountLocked { get; init; } = false;
        public DateTime? LastLoginTime { get; init; } = null;

        public long? UserRoleId { get; init; }
        public long? UserId { get; init; }
        public string? Email { get; set; }
        public string? SolId { get; set; }
        public string? LocationType { get; set; }
        public List<LocationData>? LocationData { get; set; }

    }

    public record LocationData
    {
        public long? LocationId { get; init; }
        public string? Branch { get; set; }
        public string? Department { get; set; }
        public string? Region { get; set; }
    }
    public record DecryptionResult
    {
        public ObjectResponse<LoginResponse>? Response { get; set; }
        public LoginRequest? UpdatedRequest { get; set; }
    }
}
