﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    public record TrendOfOperationalRiskSourceResponse
    {

        public string? Title { get; set; }
        public int CurrentYear { get; set; }
        public int CurrentYearMinus1 {  get; set; }
        public int CurrentYearMinus2 { get; set; }


    }
}
