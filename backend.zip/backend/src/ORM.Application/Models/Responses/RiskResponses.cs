﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    public class RiskGridResponse
    {
        public List<RiskDataGrid> RiskData { get; set; }
        public RiskRecordCount RecordCounts { get; set; }

        public RiskGridResponse(List<RiskDataGrid> riskData, RiskRecordCount recordCounts)
        {
            RiskData = riskData!;
            RecordCounts = recordCounts;
        }
    }
    public partial class RiskRecordCount
    {
        public int? SubmittedCount { get; set; }
        public int? DraftCount { get; set; }
        public int? RejectCount { get; set; }
        public int? ApprovedCount { get; set; }

    }
    public partial class RiskDataGrid
    {
        public long Id { get; set; }
        public string? RefNum { get; set; }
        public string? LocationType { get; set; }
        public long? LocationId { get; set; }
        public string? LocationName { get; set; }
        public string? Branch { get; set; }
        public string? Region { get; set; }
        public string? Department { get; set; }
        public long? ValidatorUserId { get; set; }
        public string? ValidatorUserName { get; set; }
        public string? ProcessName { get; set; } 
        public string? SubProcessName { get; set; } 
        public string? InherentThreatRisk { get; set; } 
        public string? FrequencyOfOccurance { get; set; }  
        public string? RiskClassification { get; set; }  
        public string? RiskRootCause { get; set; }  
        public string? RiskSeverity { get; set; }  
        public string? RiskDirection { get; set; } 
        public string? ImplementedControls { get; set; } 
        public string? RiskControlDesign { get; set; } 
        public string? RiskControlType { get; set; } 
        public string? RiskControlEffectiveness { get; set; } 
        public string? RiskResidual { get; set; } 
        public string? RiskResponsibility { get; set; }
        public string? Documents { get; set; }
        public string? DocumentName { get; set; }
        public string? DocumentExtension { get; set; }
        public string? RiskCategory { get; set; } 
        public string? RiskResidualRating { get; set; } 
        public string? RiskActionPlan { get; set; } 
        public string? RiskActionPlanStatus { get; set; } 
        public DateTime? RiskExpectedResolutionTime { get; set; }
        public string? RiskStrategy { get; set; } 
        public string? ReportStatus { get; set; }
        public string? UpdateRequestStatus { get; set; }
        public string? RiskControlAssessment { get; set; }
        public string? RiskControlQuality { get; set; }
        public string? RiskRating { get; set; }
        public string? ReviewerComments { get; set; } 
        public long? CreatedById { get; set; }
        public string? CreatedByName { get; set; }
        public long? ModifiedById { get; set; }
        public string? ModifiedByName { get; set; }
        public long? ValidatedById { get; set; }
        public string? ValidatedByName { get; set; }
        public long? ApprovedById { get; set; }
        public string? ApprovedByName { get; set; }
        public DateTime? CreatedDate { get; set; } 
        public DateTime? ModifiedDate { get; set; } 
        public DateTime? ValidationDate { get; set; } 
        public DateTime? ApprovedDate { get; set; }
        public int AllCount { get; set; } = 0;

    }
}