﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    public partial class GroupedRiskOccurenceResponse
    {
        public List<BaseChartsResponse>? RiskSource { get; set; }
        public List<BaseChartsResponse>? RiskDirection { get; set; }
        public List<BaseChartsResponse>? RiskRating { get; set; }
        public List<BaseChartsResponse>? RiskResidualRating { get; set; }
        public List<BaseChartsResponse>? RiskControlDesign { get; set; }
        public List<BaseChartsResponse>? RiskControlAssessment { get; set; }
        public List<BaseChartsResponse>? RiskControlType { get; set; }
        public List<BaseChartsResponse>? RiskControlQuality { get; set; }

    }
}
