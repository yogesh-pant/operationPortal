﻿using ORM.Domain.Common;

namespace ORM.Application.Models.Responses
{
    /// <summary>
    /// Model for RoleResponse
    /// </summary>
  
    public partial class KriGridResponse
    {
        public long? Id { get; set; }
        public string? ReportRefNo { get; set; } = null!;
        public long? ValidatorILOUserId { get; set; }
        public string? ValidatorILOUserName { get; set; }
        public string? LocationType { get; set; }
        public string? ReportingPeriod { get; set; }
        public string? Frequency { get; set; }
        public int? LocationId { get; set; }
        public DateTime? DateReported { get; set; }
        public string? Branch { get; set; }
        public string? Department { get; set; }
        public string? Region { get; set; }
        public string? Status { get; set; }
        public string? SubmittedBy { get; set; }
        public DateTime? ReviewedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public partial class RecordCount
    {
        public int? SubmittedCount { get; set; }
        public int? DraftCount { get; set; }
        public int? RejectCount { get; set; }
        public int? ApprovedCount { get; set; }

    }

    public class KriDataGridResponse
    {
        public List<KriGridResponse> KriData { get; set; }
        public RecordCount RecordCounts { get; set; }

        public KriDataGridResponse(List<KriGridResponse> kriData, RecordCount recordCounts)
        {
            KriData = kriData!;
            RecordCounts = recordCounts;
        }
    }

    public partial record CreateKriResponse
    {
        public long Id { get; set; }
        public string? KRIMetricId { get; set; }
        public int LocationId { get; set; }
        public string? LocationType { get; set; }
        public string? MetricName { get; set; }
        public string? Frequency { get; set; }
        public string? AppetiteUpperBound { get; set; }
        public string? AppetiteLowerBound { get; set; }
        public string? AppetiteType { get; set; }
        public string? ToleranceLowerBound { get; set; }
        public string? ToleranceUpperBound { get; set; }
        public string? ToleranceType { get; set; }
        public string? EscalationLowerBound { get; set; }
        public string? EscalationUpperBound { get; set; }
        public string? EscalationType { get; set; }
        public bool? IsActive { get; set; }

    }

    public partial record NewKriReportResponse
    {
        public string NewRefNum { get; set; } = null!;
        public long reportId { get; set; }
        public List<long>? metricIds { get; set; }

    }

    public partial record EditKriResponse
    {
        public long id { get; set; }
        public long reportIds { get; set; }
        public string? reportingPeriod { get; set; }
        public string? reportingFrequency { get; set; }

    }

    public partial record ReturnId
    {
        public long id { get; set; }

    }
    public partial record RiskDoc
    {
        public string? Documents { get; set; }

    }
    public partial record KriPreviewResponse
    {
        public long MetricId { get; set; }
        public long KRIReportId  { get; set; }
        public string? reportRefNo { get; set; }
        public long? ValidatorILOUserId { get; set; }
        public string? ValidatorILOUserName { get; set; }
        public string? reportStatus { get; set; }
        public string? comments { get; set; }
        public DateTime dateReported  { get; set; }
        public string? locationType  { get; set; }
        public long LocationId { get; set; }
        public string? LocationName { get; set; }
        public string? Region { get; set; }
        public long KRIMetricMasterId  { get; set; }
        public string? KRIMetricTitle { get; set; }
        public string? MitigationPlan { get; set; }
        public string? Currency { get; set; }
        public string? AmountInvolved  { get; set; }
        public string? Description { get; set; }
        public string? KRIData { get; set; }
        public DateTime DateOccurance { get; set; }
        public bool? KRIMetricIsActive { get; set;}
        public string? Frequency { get; set; }
        public string? ReportingPeriod { get; set; }
        public string? AppetiteLowerBound { get; set; }
        public string? AppetiteUpperBound { get; set; }
        public string? AppetiteType { get; set; }
        public string? ToleranceLowerBound { get; set; }
        public string? ToleranceUpperBound { get; set; }
        public string? ToleranceType { get; set; }
        public string? EscalationLowerBound { get; set; }
        public string? EscalationUpperBound { get; set; }    
        public string? EscalationType { get; set; }
        public string? RiskAppetiteThreshold { get; set; }
        public string? SubmittedBy { get; set; }
        public string? ReviewedBy { get; set; }
        public DateTime? ReviewedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
    
    public partial record GetKriMasterGridResponse
    {
        public long Id { get; set; }
        public string? KRIMetricId { get; set; }
        public int? LocationId { get; set; }
        public string? LocationName { get; set; }
        public string? Region { get; set; }
        public string? LocationType { get; set; }
        public string? MetricName { get; set; }
        public string? Frequency { get; set; }
        public string? AppetiteUpperBound { get; set; }
        public string? AppetiteLowerBound { get; set; }
        public string? AppetiteType { get; set; }
        public string? ToleranceLowerBound { get; set; }
        public string? ToleranceUpperBound { get; set; }
        public string? ToleranceType { get; set; }
        public string? EscalationLowerBound { get; set; }
        public string? EscalationUpperBound { get; set; }
        public string? EscalationType { get; set; }
        public bool? IsActive { get; set; }
        public string? Status { get; set; }
        public string? ChangeRequestDataJson { get; set; }
        public KRIMasterChangeData? ChangeRequestData { get; set; }
        public string? ReviewerComments { get; set; }
        public long?   CreatedById { get; set; }
        public string? CreatedByName { get; set; }
        public long? ModifiedById { get; set; }
        public string? ModifiedByName { get; set; }
        public long? ApprovedById { get; set; }
        public string? ApprovedByName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public DateTime? ApprovedDate { get; set; }

    }
}
