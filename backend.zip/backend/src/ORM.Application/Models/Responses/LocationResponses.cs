﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Responses
{
    [ExcludeFromCodeCoverage]
    public partial class BranchLocationGridResponse
    {
        public long Id { get; set; }

        public string LocationId { get; set; } = null!;
                
        public string? SolId { get; set; }

        public string? Branch { get; set; }

        public string? Region { get; set; }

        public string Status { get; set; } = "Active"!;
        public string? LocationChangeData { get; set; } = null!;
        public string? LocationChangeStatus { get; set; } = null!;
        public string? ChangeReviewComments { get; set; } = null!;
        public string? LocationNewFlag { get; set; } = "No"!;
        public string? NewLocationBranch { get; set; }
        public string? NewLocationRegion { get; set; }
        public string? NewLocationStatus { get; set; }
        public long? NewLocationUpdatedBy { get; set; }
        public string? NewLocationUpdatedByName { get; set; }
        public DateTime? NewLocationChangeRequestDate { get; set; }
        public long? CreatedById { get; set; } = null!;
        public string? CreatedByName { get; set; } = null!;
        public long? ModifiedById { get; set; } = null!;
        public string? ModifiedByName { get; set; } = null!;
        public long? ReviewedById { get; set; } = null!;
        public string? ReviewedByName { get; set; } = null!;
        public DateTime? CreatedDate { get; set; } = null!;
        public DateTime? ModifiedDate { get; set; } = null!;
        public DateTime? ReviewedDate { get; set; } = null!;

    }
    [ExcludeFromCodeCoverage]
    public partial class DepartmentLocationGridResponse
    {
        public long Id { get; set; }

        public string LocationId { get; set; } = null!;

        public string? Department { get; set; }

        public string Status { get; set; } = "Active"!;
        public string? LocationChangeData { get; set; } = null!;
        public string? LocationChangeStatus { get; set; } = null!;
        public string? ChangeReviewComments { get; set; } = null!;
        public string? LocationNewFlag { get; set; } = "No"!;
        public string? NewLocationDepartment { get; set; }
        public string? NewLocationStatus { get; set; }
        public long? NewLocationUpdatedBy { get; set; }
        public string? NewLocationUpdatedByName { get; set; }
        public DateTime? NewLocationChangeRequestDate { get; set; }
        public long? CreatedById { get; set; } = null!;
        public string? CreatedByName { get; set; } = null!;
        public long? ModifiedById { get; set; } = null!;
        public string? ModifiedByName { get; set; } = null!;
        public long? ReviewedById { get; set; } = null!;
        public string? ReviewedByName { get; set; } = null!;
        public DateTime? CreatedDate { get; set; } = null!;
        public DateTime? ModifiedDate { get; set; } = null!;
        public DateTime? ReviewedDate { get; set; } = null!;

    }
}
