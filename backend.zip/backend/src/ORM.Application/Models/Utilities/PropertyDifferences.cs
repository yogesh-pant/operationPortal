﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Utilities
{

    [ExcludeFromCodeCoverage]
    public class PropertyDifference
    {
        public string PropertyName { get; set; } = string.Empty;
        public object? OldValue { get; set; } = null;
        public object? NewValue { get; set; } = null;
        public string ChangeText => $"{PropertyName}: Old Value - {OldValue}, Updated Value - {NewValue}" + "\r\n";
    }

}
