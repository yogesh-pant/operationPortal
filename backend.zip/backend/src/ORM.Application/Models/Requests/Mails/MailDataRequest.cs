﻿using Microsoft.AspNetCore.Http;

namespace ORM.Application.Models.Requests.Mails
{
    public class MailDataRequest
    {
        public string EmailToId { get; set; } = "";
        public string EmailToName { get; set; } = "";
        public string EmailSubject { get; set; } = "";
        public string EmailBody { get; set; } = "";
    }

    public class SendEmailRequest
    {
        public required string From { get; set; }
        public required string To { get; set; }
        public List<string>? Cc { get; set; }
        public List<string>? Bcc { get; set; }
        public required string Subject { get; set; }
        public required string Body { get; set; }
        public List<IFormFile>? Attachment { get; set; }
    }
}
