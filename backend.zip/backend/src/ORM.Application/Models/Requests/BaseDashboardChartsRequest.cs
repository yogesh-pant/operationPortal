﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.Requests
{
    public record BaseDashboardChartsRequest
    {
        public string? BaselEventType1 { get; set; }
        public List<int>? Months { get; set; }

        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        [Required]
        public int Year { get; set; }
    }
    public record FilterRiskReportRequest
    {
        public string? LocationType { get; set; }
        public int? LocationId { get; set; }    
        public List<int>? Months { get; set; }

        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        [Required]
        public int Year { get; set; }
    }

    public record FilterKeyRiskIndicatorRequest
    {
        public string? LocationType { get; set; }
        public int? LocationId { get; set; }
        public List<int>? Months { get; set; }

        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        [Required]
        public int Year { get; set; }
    }
    public record FilterKriReportMetricsRequest
    {
       public List<long>? MetricMasterIds { get; set; }
        public List<int>? Months { get; set; }

        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        [Required]
        public int Year { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public record FilterLossDataTrendRequest
    {
        public string? BaselEventType1 { get; set; } 
        public List<int>? Months { get; set; }

        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        [Required]
        public int Year { get; set; }   
        
    }

    [ExcludeFromCodeCoverage]
    public record FilterRegionalInternalFraudRequest
    {
        [Required]
        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        public int Year { get; set; }

        [MaxLength(3, ErrorMessage = "The list must contain exactly 3 elements.")]
        [Range(3, 3, ErrorMessage = "The list must contain exactly 3 elements.")]
        public List<int>? Months { get; set; }


    }

    [ExcludeFromCodeCoverage]
    public record FilterOperationalRiskLossesRequest
    {
        [Required]
        [Range(1900, 9999, ErrorMessage = "Year must be between 1900 and 9999.")]
        public int Year { get; set; }

        [MaxLength(3, ErrorMessage = "The list must contain exactly 3 elements.")]
        [Range(3, 3, ErrorMessage = "The list must contain exactly 3 elements.")]
        public List<int>? Months { get; set; }


    }
}
