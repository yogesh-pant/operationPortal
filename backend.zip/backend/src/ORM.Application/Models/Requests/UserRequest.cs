﻿using Fcmb.Shared.Models.Requests;
using Microsoft.AspNetCore.Http;
using ORM.Application.Models.Responses;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Application.Models.Requests
{
    
    public record FilterUserRequest : PaginatedRequest
    {
        public string? userName { get; set; } = default;
        public string? userRole { get; set; }
        public long? userSubRoleId { get; set; }
        public string? status { get; set; }
        public string? userchangestatus { get; set; }

    }

    public record FilterRoleRequest : PaginatedRequest
    {
        public string? roleTitle { get; set; }
        public bool? status { get; set; }

    }

    public record GetNewKriRequest
    {
        public string? locationType { get; set; }
        public int? locationId { get; set; }
        public string? frequecy { get; set; }
        public bool? active { get; set; }

    }

    public record GetPreviewKriRequest
    {
        public long[] ids { get; set; }= Array.Empty<long>();

    }
    public record GetPreviewKriMultipleRequest
    {
        public long[]? ids { get; set; }
        public long[]? rids { get; set; }

    }

    public record UpdatePreviewKriRequest
    {
        public long id { get; set; }

    }
    public record EditKriRequest
    {
        public long id { get; set; }

    }
    public record FinalKriReport
    {
        public long id { get; set; }
        public string? status { get; set; }
        public string? comments { get; set; }
        public long? approvedByid { get; set; }

    }
    public record KriGridRequest : PaginatedRequest
    {
        public string? RefNo { get; set; } = null!;
        public long? LocationId { get; set; } = null!;
        public string? LocationType { get; set; } = null!;
        public string? Branch { get; set; } = null!;
        public string? Department { get; set; } = null!;
        public string? Region { get; set; } = null!;
        public string? Status { get; set; } = null!;
        public DateTime? MinDate { get; set; } = null!;
        public DateTime? MaxDate { get; set; } = null!;

    }

    
    

    
    public record AddNewUserRequest
    {
        public string UserName { get; init; } = null!;
        public long[]? LocationIds { get; init; }
        public string? StaffId { get; init; }
        public long? RoleId { get; init; }
        public long? SubRoleId { get; init; }
        public string? Status { get; init; }

    }
    public record EditUserRequest
    {
        public long Id { get; set; }
        public long[]? LocationIds { get; init; }
        public long? RoleId { get; init; }
        public long? SubRoleId { get; init; }
        public string? Status { get; init; }

    }
    public record ReviewUserChangeRequest
    {
        public long Id { get; set; }
        public string? ChangeReviewComments { get; init; }

    }

    
    
    
    public record AddKriRequest
    {
        public long RefNum { get; init; }
        public string? ReportingPeriod { get; init; }
        public string? ReportingFrequency { get; init; }
        public long? ValidatorILOUserId { get; init; }
        public DateTime DateOfOccurance { get; init; }
        public int LocationId { get; init; }
        public string? LocationType { get; init; }
        public string? Status { get; init; }
        public int CreatedById { get; init; }
        public long[]? kris { get; init; }
        public long[]? removeKris { get; init; }


    }

    public record AddKriReport
    {
        public long masterId { get; init; }
        public long reportId { get; init; }
        public long metricId { get; init; }
        public DateTime DateOccurance { get; init; }
        public string? Description { get; init; }
        public string? AmountInvolved { get; init; }
        public string? Currency { get; init; }
        public string? MitigationPlan { get; init; }
        public string? NumberPercentage { get; init; }
        public string? RiskAppetiteThreshold { get; init; }


    }
    public record GetKriMasterGridRequest : PaginatedRequest
    {
        public long? LocationId { get; set; } = null!;
        public string? LocationName { get; set; } = null!;
        public string? LocationType { get; set; } = null!;
        public string? MetricName { get; set; } = null!;
        public string? Frequency { get; set; } = null!;
        public bool? IsActive { get; set; } = null!;
        public string? Status { get; set; } = null!;
    }

    public partial record CreateKriMasterRequest
    {
        public string? KRIMetricId { get; set; }
        public int LocationId { get; set; }
        public string? LocationType { get; set; }
        public string? MetricName { get; set; }
        public string? Frequency { get; set; }
        public string? AppetiteUpperBound { get; set; }
        public string? AppetiteLowerBound { get; set; }
        public string? AppetiteType { get; set; }
        public string? ToleranceLowerBound { get; set; }
        public string? ToleranceUpperBound { get; set; }
        public string? ToleranceType { get; set; }
        public string? EscalationLowerBound { get; set; }
        public string? EscalationUpperBound { get; set; }
        public string? EscalationType { get; set; }
        public bool IsActive { get; set; }
        public long? CreatedById { get; set; }

    }

    public partial record UpdateKriMasterRequest
    {
        public long? Id { get; set; }
        public string? MetricName { get; set; }
        public string? Frequency { get; set; }
        public string? AppetiteUpperBound { get; set; }
        public string? AppetiteLowerBound { get; set; }
        public string? AppetiteType { get; set; }
        public string? ToleranceLowerBound { get; set; }
        public string? ToleranceUpperBound { get; set; }
        public string? ToleranceType { get; set; }
        public string? EscalationLowerBound { get; set; }
        public string? EscalationUpperBound { get; set; }
        public string? EscalationType { get; set; }
        public bool IsActive { get; set; }
        public long? ModifiedById { get; set; }

    }

    public partial record ToggleKriMasterStatusRequest
    {
        public long? Id { get; set; }
        public bool  IsActive { get; set; }
    }
        
   

   

   
    public record LossGridRequest : PaginatedRequest
    {
        public long? LocationId { get; set; } = 0!;
        public string? LocationType { get; set; } = null!;
        public string? refNo { get; set; } = null!;
        public string? branch { get; set; } = ""!;
        public string? region { get; set; } = ""!;
        public string? department { get; set; } = ""!;
        public string? eventStatus { get; set; } = null!;
        public string? reportStatus { get; set; } = null!;
        public DateTime? minDate { get; set; } = null!;
        public DateTime? maxDate { get; set; } = null!;

    }
    public record CreateLossDataRequest
    {
        public string? LocationType { get; set; }

        public string LocationId { get; set; } = null!;

        public string? ValidatorILOUserId { get; set; }

        public string DateOccurance { get; set; } = null!;

        public string DateDiscovery { get; set; } = null!;

        public string DateReported { get; set; } = null!;

        public string? Description { get; set; }

        public string? RootCauseRLO { get; set; }

        public string? LossType { get; set; }

        public string? CurrencyType { get; set; }

        public string? AmountInvolved { get; set; }

        public string? NearMissAmount { get; set; }

        public string? PotentialLossAmount { get; set; }

        public string? GrossActualAmount { get; set; }

        public string? RecoveredAmount { get; set; }

        public string? FurtherRecoveredAmount { get; set; }

        public string? RecoveryChannel { get; set; }

        public string? StaffInvolvement { get; set; }

        public string? EventStatus { get; set; }
        public string? ReportStatus { get; set; }

        //Meta Data fields populated by system
        public string? CreatedById { get; set; } = null!;
        public string? DocumentName { get; set; } = null!;
        public List<IFormFile>? RegistrationDocuments { get; set; }
    }
    public record UpdateLossDataRloRequest
    {
        public long id { get; set; }

        public long? ValidatorILOUserId { get; set; }

        public DateTime DateOccurance { get; set; }

        public DateTime DateDiscovery { get; set; }

        public DateTime DateReported { get; set; }

        public string? Description { get; set; }

        public string? RootCauseRLO { get; set; }

        public string? LossType { get; set; }

        public string? CurrencyType { get; set; }

        public decimal? AmountInvolved { get; set; }

        public decimal? NearMissAmount { get; set; }

        public decimal? PotentialLossAmount { get; set; }

        public decimal? GrossActualAmount { get; set; }

        public decimal? RecoveredAmount { get; set; }

        public decimal? FurtherRecoveredAmount { get; set; }

        public string? RecoveryChannel { get; set; }

        public string? StaffInvolvement { get; set; }

        public string? EventStatus { get; set; }
        public string? ReportStatus { get; set; }

        public long? ModifiedById { get; set; }
        public string? DocumentName { get; set; } = null!;
        public List<IFormFile>? RegistrationDocuments { get; set; }

    }

    public record UpdateLossDataBormRequest
    {
        // Data fields populated by BORM Admin
        public long id { get; set; }
        public string? StaffJobRole { get; set; }

        public string? InternalBusLine { get; set; }

        public string? BaselEventTypeI { get; set; }

        public string? BaselEventTypeII { get; set; }

        public string? BaselEventTypeIII { get; set; }

        public string? BaselLevel1BusinessLine { get; set; }

        public string? BaselLevel2BusinessLine { get; set; }

        public string? RootCauseTypeBORM { get; set; }

        public string? ProcessInvolved { get; set; }

        public string? RiskSource { get; set; }

        public string? LessonLearnt { get; set; }

        public string? ReportStatus { get; set; }
        public string? ReviewerComments { get; set; }

        //Meta Data fields populated by system
        public long? ModifiedById { get; set; } = null!;

    }
    public record ApproveLossDataBormRequest
    {
        // Data fields populated by BORM Admin
        public long id { get; set; }
        public string? Action { get; set; }
        public string? ReviewerComments { get; set; }
        public long? ApprovedById { get; set; } = null!;

    }
    public record GetFullLossDataBySingleIdRequest
    {
        public long id { get; set; }

    }

    public record FilterBranchListRequest : PaginatedRequest
    {
        public long? id { get; set; }
        public string? Branch { get; set; }
        public string? Region { get; set; }
        public string? SolId { get; set; }
        public string? LocationId { get; set; }
        public string? Status { get; set; }
        public string? LocationChangeStatus { get; set; }

    }

    public record FilterDepartmentListRequest : PaginatedRequest
    {
        public long? id { get; set; }
        public string? Department { get; set; }
        public string? LocationId { get; set; }
        public string? Status { get; set; }
        public string? LocationChangeStatus { get; set; }

    }
    public record CreateBranchLocationRequest
    {
        public string? SolId { get; set; }
        public string? Branch { get; set; }
        public string? Region { get; set; }
        public long? CreatedById { get; set; }

    }
    public record CreateDepartmentLocationRequest
    {
        public string? Department { get; set; }
        public long? CreatedById { get; set; }

    }
    public record UpdateBranchLocationRequest
    {
        public long id { get; set; }
        public string? Status { get; set; }
        public string? Branch { get; set; }
        public string? Region { get; set; }
        public long ModifiedById { get; set; }

    }
    public record UpdateDepartmentLocationRequest
    {
        public long id { get; set; }
        public string? Status { get; set; }
        public string? Department { get; set; }
        public long ModifiedById { get; set; }

    }
    public record FilterRiskListRequest : PaginatedRequest
    {
        public long? Id { get; set; }
        public string? RefNum { get; set; }
        public string? Branch { get; set; } = null!;
        public string? Region { get; set; } = null!;
        public string? Department { get; set; } = null!;
        public string? LocationType { get; set; }
        public long? LocationId { get; set; }
        public DateTime? minDate { get; set; } = null!;
        public DateTime? maxDate { get; set; } = null!;
        public string? ReportStatus { get; set; }
    }
    public record CreateRiskDataRequest
    {
        public string? LocationType { get; set; }
        public long LocationId { get; set; }
        public long ValidatorUserId { get; set; }
        public string? ProcessName { get; set; }
        public string? SubProcessName { get; set; }
        public string? InherentThreatRisk { get; set; }
        public string? FrequencyOfOccurance { get; set; }
        public string? RiskSeverity { get; set; }
        public string? RiskDirection { get; set; }
        public string? ImplementedControls { get; set; }
        public string? RiskControlDesign { get; set; }
        public string? RiskControlType { get; set; }
        public string? RiskResidual { get; set; }
        public string? RiskResponsibility { get; set; }
        public string? RiskActionPlan { get; set; }
        public string? ReportStatus { get; set; }
        public long? CreatedById { get; set; }
        public List<IFormFile>? RiskDocuments { get; set; }
        public string? Documentname { get; set; }

    }
    public record EditRiskDataRequest
    {
        public long Id { get; set; } // used in edit
        public long? ValidatorUserId { get; set; }
        public string? ProcessName { get; set; }
        public string? SubProcessName { get; set; }
        public string? InherentThreatRisk { get; set; }
        public string? FrequencyOfOccurance { get; set; }
        public string? RiskSeverity { get; set; }
        public string? RiskDirection { get; set; }
        public string? ImplementedControls { get; set; }
        public string? RiskControlDesign { get; set; }
        public string? RiskControlType { get; set; }
        public string? RiskResidual { get; set; }
        public string? RiskResponsibility { get; set; }
        public string? RiskActionPlan { get; set; }
        public string? ReportStatus { get; set; }
        public long? ModifiedById { get; set; }
        public List<IFormFile>? RiskDocuments { get; set; }
        public string? Documentname { get; set; }
    }
    public record UpdateRiskDataRequest
    {
        public long Id { get; set; }
        public string? RiskClassification { get; set; }
        public string? RiskCategory { get; set; }
        public string? RiskRootCause { get; set; }
        public string? RiskActionPlanStatus { get; set; }
        public DateTime? RiskExpectedResolutionTime { get; set; }
        public string? RiskStrategy { get; set; }
        public string? ReportStatus { get; set; }
        public long? ModifiedById { get; set; }
    }
    public record GetDocRequest
    {
        public long Id { get; set; }
    }
        public record UpdateRiskStatusRequest
    {
        public long Id { get; set; }
        public string? UpdateRequestStatus { get; set; }
        public string? ReviewerComments { get; set; }
        public string? ReportStatus { get; set; }
        public long? ModifiedById { get; set; }
    }
    public record FilterGetUsersByRoleLocationRequest : PaginatedRequest
    {
        public long? Locationid { get; set; }
        public long? Roleid { get; set; }
        public long? SubRoleid { get; set; }
        public string? RoleTitle { get; set; }
        public string? UserStatus { get; set; }
    }

    public record ValidateDuplicateKriReportRequest
    {
        public long LocationId { get; set; }
        public string? ReportingPeriod { get; set; }

    }
}

