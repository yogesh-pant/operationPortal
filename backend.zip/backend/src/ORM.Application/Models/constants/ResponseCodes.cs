﻿using Fcmb.Shared.Models.Constants;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Application.Models.Constants
{
    [ExcludeFromCodeCoverage]
    public class ResponseCodes : BaseResponseCodes
    {
        #region User Codes
        public const string InactiveUser = "800";
        public const string InvalidToken = "801";
        public const string LockedOutUser = "802";
        #endregion
        
    }
}
