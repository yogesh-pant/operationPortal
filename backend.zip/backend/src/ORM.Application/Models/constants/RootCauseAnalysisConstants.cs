﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Application.Models.constants
{
    [ExcludeFromCodeCoverage]
    public static class RootCauseAnalysisConstants
    {
        public const string ProcessBreach = "process breach";
        public const string WeakControls = "weak controls";
        public const string SystemFailure = "system failure";
        public const string BusinessDecision = "business decision";
        public const string ExternalFraud = "external fraud";
        public const string PolicyViolation = "policy / sop violation";
        public const string PoorCustomerService = "poor customer service";
        public const string Poorconfigurationofsuspenseaccounts = "poor configuration of suspense accounts";


    }
}