﻿using System;

namespace ORM.Application.Models.Auth
{
    public abstract record BaseSession(long UserId, string UserName, string Email, string StaffId, long? RoleId);

    public sealed record StaffSession(long UserId, string UserName, string Email,         
         string StaffId, long? RoleId) : BaseSession(UserId, UserName, Email, StaffId, RoleId);
    
   }
