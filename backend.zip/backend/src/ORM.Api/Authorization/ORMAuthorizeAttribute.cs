﻿using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using ORM.Application.Models.Constants;
using ORM.Domain.Common;
using ORM.Infrastructure.Persistance;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ORM.Api.Authorization
{
    /// <summary>
    /// Ensures a user trying to access the system is still active
    /// </summary>
    [ExcludeFromCodeCoverage]
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    public class OrmAuthorizeAttribute : Attribute, IAsyncAuthorizationFilter
    {
        /// <summary>
        /// On authorization as an asynchronous operation.
        /// </summary>
        /// <param >OrmAuthorizeAttribute(string roleName)</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        /// 
        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {

            if (AllowAnonymous(context)) return;

            var userId = context.HttpContext.User.Claims.FirstOrDefault(x => x.Type == "UserId")?.Value;
            var token = "";
            var logger = context.HttpContext.RequestServices.GetRequiredService<ILogger<OrmAuthorizeAttribute>>();

            var authorizationHeaders = context.HttpContext.Request.Headers
       .FirstOrDefault(x => string.Equals(x.Key, "Authorization", StringComparison.InvariantCultureIgnoreCase));

            if (authorizationHeaders.Equals(default(KeyValuePair<string, Microsoft.Extensions.Primitives.StringValues>)))
            {
                // Handle missing Authorization header
                context.Result = new UnauthorizedObjectResult("Authorization header is missing.");
                return;
            }

            // Extract the token from the Authorization header
            var headerValue = authorizationHeaders.Value.FirstOrDefault();
            if (headerValue != null && headerValue.StartsWith("Bearer ", StringComparison.InvariantCultureIgnoreCase))
            {
                token = headerValue.Substring("Bearer ".Length).Trim();
               
            }
            else
            {
                // Handle invalid Authorization header format
                context.Result = new UnauthorizedObjectResult("Invalid Authorization header format.");
            }
            if (string.IsNullOrEmpty(userId))
            {
                var authorizationHeader = context.HttpContext.Request.Headers.FirstOrDefault(x =>
                    string.Equals(x.Key, "Authorization", StringComparison.InvariantCultureIgnoreCase));

                logger.LogCritical("Authorization Header: {AuthorizationValue}", authorizationHeader);

                logger.LogError("User Is Not Authenticated");
                context.Result =
                    new UnauthorizedObjectResult(new StatusResponse("User Must Be Authenticated",
                        ResponseCodes.Unauthenticated));
                return;
            }

            var serviceProvider = context.HttpContext.RequestServices.GetRequiredService<IServiceProvider>();

            using var scope = serviceProvider.CreateScope();

            var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();

            var user = await dbContext.ORMUsers.FirstOrDefaultAsync(x => x.Id == Int32.Parse(userId));

            var userrole = await dbContext.ORMRoles.FirstOrDefaultAsync(p => p.RoleId == user!.RoleId);
            if (userrole!.RoleTitle == "Admin")
            {
                userrole.RoleTitle = user!.SubRoleId == 1 ? "Admin-Maker" : "Admin-Checker";
            }

            if (token != user!.CurrentToken)
            {
                logger.LogError("Session Expired: An another session is active for:  {UserName} ", user.UserName);
                context.Result =
                    new BadRequestObjectResult(new StatusResponse("An another user session is active.", ResponseCodes.NoPermission));

                return;
            }
            var apis = context.HttpContext.Request.Path.Value;
            var pattern = @"[^/]+$";
            Regex regex = new Regex(pattern);
            Match match = regex.Match(apis ?? "");
            var apiString = "";
            if (match.Success)
            {
                apiString = match.Value;
            }
            if (apiString is not null && !ApiAuthenticationTest(userrole!.RoleTitle, apiString))
            {
                logger.LogError("User {UserName} with role {RoleTitle} not authorised to perform the api action {apiString}.", user!.UserName, userrole!.RoleTitle, apiString);
                context.Result =
                    new BadRequestObjectResult(new StatusResponse("User not authorised to perform the action", ResponseCodes.NoPermission));

                return;
            }
            if (user is null)
            {
                logger.LogError("User with Id {UserId} does not exist", userId);
                context.Result =
                    new NotFoundObjectResult(new StatusResponse("User Does Not Exist", ResponseCodes.DataNotFound));

                return;
            }

            if (user.Status != "Active")
            {
                logger.LogError("User with Id {UserId} is not active", userId);
                context.Result =
                    new BadRequestObjectResult(new StatusResponse("User Is Not Active", ResponseCodes.InactiveUser));
            }
        }

        private static bool AllowAnonymous(ActionContext context)
        {
            if (context.ActionDescriptor is ControllerActionDescriptor descriptor)
            {
                return descriptor.MethodInfo.GetCustomAttributes<AllowAnonymousAttribute>().Any();
            }

            return false;
        }

            private static bool ApiAuthenticationTest(string role, string api)
            {
                if (role == "Admin-Maker" && Enum.TryParse<AdminMakerApis>(api.ToLower(), out _))
                {
                    return true;
                }
                if (role == "Admin-Checker" && Enum.TryParse<AdminCheckerApis>(api.ToLower(), out _))
                {
                    return true;
                }
                if (role == "RLO" && Enum.TryParse<RloApis>(api.ToLower(), out _))
                {
                    return true;
                }
                if (role == "ICO" && Enum.TryParse<IcoApis>(api.ToLower(), out _))
                {
                    return true;
                }
                if (role == "GIA" && Enum.TryParse<GlaApis>(api.ToLower(), out _))
                {
                    return true;
                }
                return false;
            }


        }
}
