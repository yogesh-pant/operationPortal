﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using ORM.Api.Filters;
using ORM.Api.Logging;
using ORM.Api.Middlewares;
using ORM.Application.Models.Logging;
using ORM.Infrastructure.Persistance;
using ORM.Infrastructure.Services.Auth;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Text;
using ORM.Domain.Common;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using ORM.Application.Interfaces.Common;
using System.Data.Common;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Azure;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace ORM.Api
{
    /// <summary>
    /// Class ConfigureServices.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class ConfigureServices
    {
        private const string AllowedOrigins = nameof(AllowedOrigins);
        private const string AllOrigins = nameof(AllOrigins);
        /// <summary>
        /// Add services to the container.
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void AddServicesToContainer(this IServiceCollection services, IConfiguration configuration)
        {
            // Add logging services first
            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddConfiguration(configuration.GetSection("Logging"));
                loggingBuilder.AddConsole(); // Add other logging providers as needed
            });

            // Retrieve logger options from appsettings.json
            var loggerOptions = configuration.GetSection("Logging").Get<LoggerOptions>();
            services.ConfigureLoggingCapability(loggerOptions); // Assuming this method configures logging capabilities

            // Configure other services
            services.ConfigureAuthentication(configuration);
            services.AddRouting(options => options.LowercaseUrls = true);
            services.AddHttpContextAccessor();
            services.AddHttpClient();
            services.AddHealthChecks();
            services.AddDistributedMemoryCache();
            services.AddControllers(options =>
            {
                options.Filters.Add<RequestValidationFilter>();
            });

            var origins = configuration[AllowedOrigins] ?? string.Empty;
            services.AddCors(options =>
            {
                options.AddPolicy(AllOrigins, builder =>
                    builder.WithOrigins(origins.Split(","))
                           .SetIsOriginAllowedToAllowWildcardSubdomains()
                           .AllowAnyMethod()
                           .AllowAnyHeader());
            });

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });

            // Configure database connection
            // It works in following manner - 
            // Try to fetch orm-dbconnection string from appsettings.Development.json configuration 
            // incase it is not found there then try to read it via test azure key vault from url AzureKeyVaultURLDev
            // in appsettings.Development.json configuration.
            // This connection to key vault from url AzureKeyVaultURLDev for dev/test purpose is made using app registration 
            // AzureClientId,AzureClientSecret and AzureClientTenantId

            // both of the above methods are intended for development and testing purposes only
            //
            // if orm-dbconnection is not enabled in appsettings.Development.json and AzureKeyVaultURLDev is also disabled 
            // then it would read orm-dbconnection from AzureKeyVault:AzureKeyVaultURL in appsettings.json
            // This call to azure key vault usages default authentication assuming azure webapp is granted accesss to key vault

            var secretName = "orm-dbconnection";
            var con = configuration.GetValue<string>(secretName) ?? string.Empty;
            var logger = services.BuildServiceProvider().GetRequiredService<ILogger<Program>>();
            if (string.IsNullOrEmpty(con))
            {
                ConfigurationBuilder builder = new ConfigurationBuilder();

                string keyVaultUrlDev = configuration.GetValue<string>("AzureKeyVaultURLDev") ?? string.Empty;

                try
                {
                    if (keyVaultUrlDev != "")
                    {
                        string clientId = configuration.GetValue<string>("AzureClientId")!;
                        string clientSecret = configuration.GetValue<string>("AzureClientSecret")!;
                        string tenantId = configuration.GetValue<string>("AzureClientTenantId")!;
                        builder.AddAzureKeyVault(
                        new Uri(keyVaultUrlDev), new ClientSecretCredential(tenantId, clientId, clientSecret));
                        IConfiguration configurationKey = builder.Build();
                        con = configurationKey.GetValue<string>("orm-dbconnection") ?? string.Empty;
                    }
                    else
                    {
                        // Add Azure Key Vault as a configuration source
                        var AzureKeyVaultURL = configuration.GetValue<string>("AzureKeyVault:AzureKeyVaultURL");

                        if (string.IsNullOrEmpty(AzureKeyVaultURL))
                        {
                            logger.LogWarning("AzureKeyVaultURL is missing or empty in appsetting.");
                            throw new InvalidOperationException("AzureKeyVaultURL is missing or empty in appsetting.");

                        }
                        builder.AddAzureKeyVault(
                            new Uri(AzureKeyVaultURL!),
                            new DefaultAzureCredential());

                        // Build the configuration
                        logger.LogInformation("Validating key vault {AzureKeyVaultURL} to fetch secret orm-dbconnection ", AzureKeyVaultURL);
                        IConfiguration configurationKey = builder.Build();
                        con = configurationKey.GetValue<string>("orm-dbconnection") ?? string.Empty;
                        if (string.IsNullOrEmpty(con))
                        {
                            logger.LogWarning("Secret key orm-dbconnection is missing or empty in key vault.");
                            throw new InvalidOperationException("Secret key 'orm-dbconnection' is missing or empty in key vault.");

                        }
                    }
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Error fetching secret from Azure Key Vault:{secretName}", secretName);
                    throw;
                }
            }

                services.AddDbContext<AppDbContext>(options => options.UseSqlServer(con));

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            services.AddEndpointsApiExplorer();
            services.ConfigureSwagger(configuration);
        }


        /// <summary>
        /// Configures the logging capability.
        /// </summary>
        /// <param name="services">The services.</param>
        /// <param name="loggerOptions">The logger options.</param>
        /// <exception cref="System.ArgumentNullException">loggerOptions - LoggerOptions is null. Check the configuration.</exception>
        public static void ConfigureLoggingCapability(this IServiceCollection services, LoggerOptions? loggerOptions)
        {
            // Configure the logger
            var loggerConfigurationService = new LoggerConfigurationService();
            if (loggerOptions != null)
            {
                var loggerConfiguration = loggerConfigurationService.ConfigureLogger(loggerOptions);
                // Set the logger as the default logger for the application
                Log.Logger = loggerConfiguration.CreateLogger();
            }
            // Clear existing logging providers and add Serilog
            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.ClearProviders();
                loggingBuilder.AddSerilog(dispose: true);
            });

        }



        /// <summary>
        /// Configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        public static void ConfigureHttpRequestPipeline(this WebApplication app)
        {

            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ORM.Api v1"));


            app.UseRouting();

            app.UseCors(AllOrigins);

            app.UseGlobalExceptionHandler();

            app.UseAuthentication();
            app.UseAuthorization();
            app.MapControllers();
            app.Use(async (context, next) =>
            {
                context.Response.OnStarting(() =>
                {
                    return Task.CompletedTask;
                });
                await next();
            });
        }

        /// <summary>
        /// Configures the JWT Authentication.
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        [ExcludeFromCodeCoverage]
        private static void ConfigureAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwt(configuration);
        }

        private static void AddJwt(this AuthenticationBuilder builder, IConfiguration configuration)
        {
            var keyParam = configuration["orm-jwt-key"]!;
            var key = Encoding.ASCII.GetBytes(keyParam);
            var apiIssuer = configuration["JWTConfig:Issuer"]!;
            builder.AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = apiIssuer,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    RequireExpirationTime = false
                };
            });
        }


        private static void ConfigureSwagger(this IServiceCollection services, IConfiguration configuration)
        {

            // Bind Swagger options from configuration
            var swaggerOptions = new SwaggerOptions();
            configuration.GetSection("SwaggerOptions").Bind(swaggerOptions);

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(swaggerOptions.Version, new OpenApiInfo
                {
                    Title = swaggerOptions.Title,
                    Version = swaggerOptions.Version,
                    Description = swaggerOptions.Description,
                    Contact = new OpenApiContact
                    {
                        Name = swaggerOptions.ContactName,
                        Email = swaggerOptions.ContactEmail
                    },
                    License = new OpenApiLicense
                    {
                        Name = swaggerOptions.LicenseName,
                        Url = new Uri(swaggerOptions.LicenseUrl)
                    }
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile) ;
                c.IncludeXmlComments(xmlPath);
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme."
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                       Array.Empty<string>()
                    }
                });
            });
        }
    }
}
