﻿using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System.Net;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class LossController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [Route("api/[controller]")]
    [ApiController]
    [OrmAuthorize]

    public class LossController : BaseController
    {
        private readonly ILossService LossService;
        /// <summary>
        /// Initializes a new instance of the <see cref="LossController"/> class.
        /// </summary>
        /// <param name="LossService">The loss service.</param>
        /// <remarks>SBSC</remarks>
        public LossController(ILossService LossService)
        {
            this.LossService = LossService;
        }

        /// <summary>
        /// Retrieves loss data based on the filter request
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getLossGridData")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [OrmAuthorize]

        public async Task<ActionResult<ListResponse<LossDataGridResponse>>> GetLossGridData([FromQuery] LossGridRequest request)
        {
            try
            {
                var response = await LossService.GetLossGridAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Update loss data by RLO
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("UpdateLossDataRLO")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [OrmAuthorize]

        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateLossDataRLO([FromForm] UpdateLossDataRloRequest request)
        {
            try
            {
                var response = await LossService.UpdateLossDataRLOAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Input  " + ex!.InnerException!.Message);
            }
        }
        /// <summary>
        /// Create loss data by RLO
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("CreateLossDataRLO")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> CreateLossDataAsync([FromForm] CreateLossDataRequest request)
        {
            try
            {
                var response = await LossService.CreateLossDataAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Input  " + ex!.InnerException!.Message);
            }
        }
        /// <summary>
        /// Update loss data by BORM Admin
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("UpdateLossDataBORM")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateLossDataBORM([FromBody] UpdateLossDataBormRequest request)
        {
            try
            {
                var response = await LossService.UpdateLossDataBORMAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Approve/Reject loss data by BORM Admin
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("ApproveLossDataBORM")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> ApproveLossDataBORM([FromBody] ApproveLossDataBormRequest request)
        {
            try
            {
                var response = await LossService.ApproveLossDataBORMAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// get single loss data for one id
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("GetFullLossDataBySingleId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<GetFullLossDataBySingleIdResponse>>> GetFullLossDataBySingleId([FromQuery] GetFullLossDataBySingleIdRequest request)
        {
            try
            {
                var response = await LossService.GetFullLossDataBySingleIdAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Send Reminder Email to ICO User for pending review of Loss Report
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("SendLossRpReviewReminder")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<SendLossRpReviewReminderResponse>>> SendLossRpReviewReminder([FromQuery] GetFullLossDataBySingleIdRequest request)
        {
            try
            {
                var response = await LossService.SendLossRpReviewReminder(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        

    }
}
