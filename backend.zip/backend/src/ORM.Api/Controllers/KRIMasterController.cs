﻿using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System.Net;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class KRIMaster Controller.
    /// Implements the KRI Master service Methods" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [Route("api/[controller]")]
    [ApiController]
    [OrmAuthorize]

    public class KriMasterController : BaseController
    {
        private readonly IKriMasterService KriMasterService;
        /// <summary>
        /// Initializes a new instance of the <see cref="KriController"/> class.
        /// </summary>
        /// <param name="KriMasterService">The kri Master service.</param>
        /// <remarks>SBSC</remarks>
        public KriMasterController(IKriMasterService KriMasterService)
        {
            this.KriMasterService = KriMasterService;
        }

        /// <summary>
        /// Retrieves Kri Metrices Master Data based on the filter request
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getKriMasterGridData")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<GetKriMasterGridResponse>>> GetKriMasterGridAsync([FromQuery] GetKriMasterGridRequest request)
        {
            try
            {
                var response = await KriMasterService.GetKriMasterGridAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Create Kri Metrices Master Data 
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("createKriMaster")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> CreateKriMasterAsync([FromForm] CreateKriMasterRequest request)
        {
            try
            {
                var response = await KriMasterService.CreateKriMasterAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Input  " + ex!.InnerException!.Message);
            }
        }

        /// <summary>
        /// update Kri Metrices Master Data 
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("updateKriMaster")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateKriMasterAsync([FromForm] UpdateKriMasterRequest request)
        {
            try
            {
                var response = await KriMasterService.UpdateKriMasterAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Input  " + ex!.InnerException!.Message);
            }
        }

        /// <summary>
        /// Activate-Deactivate Kri Metrices Master Data 
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("toggleKriMasterStatus")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> ToggleKriMasterStatusAsync([FromBody] ToggleKriMasterStatusRequest request)
        {
            try
            {
                var response = await KriMasterService.ToggleKriMasterStatusAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Approve Kri Metrices Master Change Request 
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param> "ReviewUserChangeRequest"</param>
        /// <returns></returns>
        [HttpPost("approvekrimasterchange")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<string>>> ApproveKRIMasterChangeAsync([FromBody] ReviewUserChangeRequest request)
        {
            try
            {
                var response = await KriMasterService.ApproveKRIMasterChangeAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Reject Kri Metrices Master Change Request 
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <param> "ReviewUserChangeRequest"</param>
        /// <returns></returns>
        [HttpPost("rejectkrimasterchange")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<string>>> RejectKRIMasterChangeAsync([FromBody] ReviewUserChangeRequest request)
        {
            try
            {
                var response = await KriMasterService.RejectKRIMasterChangeAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

