﻿using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System.Net;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class KRIController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [Route("api/[controller]")]
    [ApiController]
    [OrmAuthorize]

    public class KriController : BaseController
    {
        private readonly IKriService kriService;
        private readonly ILogger<KriController> logger;
        /// <summary>
        /// Initializes a new instance of the <see cref="KriController"/> class.
        /// </summary>
        /// <param >The kri service.</param>
        /// <remarks>SBSC</remarks>
        public KriController(IKriService kriService, ILogger<KriController> logger)
        {
            this.kriService = kriService ?? throw new ArgumentNullException(nameof(kriService));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Retrieves KRI Report data based on the filter request
        /// </summary>
        /// <remarks>
        /// The retrieved data is used to populate the main KRI Report grid 
        /// The counts are used to populate the status cards
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getKriGridData")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KriPreviewResponse>>> GetKriGridData([FromQuery] KriGridRequest request)
        {
            try
            {
                var response = await kriService.GetKriGridAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Export KRI report based on the filter request
        /// </summary>
        /// <remarks>
        /// The retrieved data is used to populate the KRI report export data in CSV format  
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getKriGridReportData")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KriDataGridResponse>>> GetKriGridReportData([FromQuery] KriGridRequest request)
        {
            try
            {
                var response = await kriService.GetKriReportGridAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Gets the KRI metric master data by Location and Reporting Frequency 
        /// </summary>
        /// <remarks>
        /// The retrieved data is used to populate KRI metrics in drop down when creating new KRI report  
        /// </remarks>
        /// <param name="request">The request.</param>
        /// <returns>ActionResult&lt;ListResponse&lt;CreateKriResponse&gt;&gt;.</returns>
        [HttpGet("getNewKriData")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<CreateKriResponse>>> GetNewKriData([FromQuery] GetNewKriRequest request)
        {
            try
            {
                var response = await kriService.GetNewKriAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Create a new KRI metric in an newly created KRI report.
        /// </summary>
        /// <remarks>
        /// A KRI metric is created(with in a report) with Blank values 
        /// It is further edited by user with values   
        /// </remarks>
        /// <param name="request">The request.</param>
        /// <returns>ActionResult&lt;ListResponse&lt;NewKriReportResponse&gt;&gt;.</returns>
        [HttpPost("postNewKri")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<NewKriReportResponse>>> CreateNewKriReport([FromBody] AddKriRequest request)
        {
            try
            {
                var response = await kriService.AddKriInfo(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        /// <summary>
        /// Edit/Update an existing KRI metric in KRI report
        /// </summary>
        /// <remarks>
        /// A KRI metric is edited with values updated by user
        /// </remarks>
        /// <param name="request">The request.</param>
        /// <returns>ActionResult&lt;ListResponse&lt;ReturnId&gt;&gt;.</returns>
        [HttpPost("postKriReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> PostKriReport([FromBody] AddKriReport request)
        {
            try
            {
                var response = await kriService.AddKrimetric(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "An error occurred while fetching KRI grid data: {ErrorMessage}", ex.Message);
                return BadRequest("An error occurred while processing the request.");
            }
        }

        /// <summary>
        /// Get All Metrics within a KRI report search either by metricid or reportid
        /// </summary>
        /// <remarks>
        /// When searched by metricid - it internally finds related reportid and 
        /// always returns All Metrics within a KRI report
        /// </remarks>
        /// <param name="request">The request.</param>
        /// <returns>ActionResult&lt;ListResponse&lt;KriPreviewResponse&gt;&gt;.</returns>
        [HttpGet("getPreviewKriApi")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KriPreviewResponse>>> GetPreviewKriApi([FromQuery] GetPreviewKriMultipleRequest request)
        {
            try
            {
                var response = await kriService.GetPreviewKriAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        ///  Get All Metrics within a KRI report search by one or more reportids
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>ActionResult&lt;ListResponse&lt;KriPreviewResponse&gt;&gt;.</returns>
        [HttpGet("getDetailKriApi")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KriPreviewResponse>>> GetDetailKriApi([FromQuery] GetPreviewKriRequest request)
        {
            try
            {
                var response = await kriService.GetDetailKriReportAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Updates a KRI report with Status as "Submitted".
        /// </summary>
        /// <remarks>
        /// One report id is provided as input
        /// </remarks>
        /// <param name="request">The request.</param>
        /// <returns>ActionResult&lt;ListResponse&lt;System.String&gt;&gt;.</returns>
        [HttpGet("updatePreviewKriApi")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<string>>> UpdatePreviewKriApi([FromQuery] UpdatePreviewKriRequest request)
        {
            try
            {
                var response = await kriService.UpdatePreviewKriAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Updates the a KRI report Status as Approved/Rejected with Comments 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("updateFinalKriApi")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<string>>> UpdateFinalKriApi([FromBody] FinalKriReport request)
        {
            try
            {
                var response = await kriService.updateKriApproval(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Gets KRI metric data by Metricid.
        /// </summary>
        /// <remarks>
        /// This metric data is fetched after a blank metric is created via addmetric in new KRI Report
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getMetricDataApi")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KriPreviewResponse>>> GetMetricDataApi([FromQuery] UpdatePreviewKriRequest request)
        {
            try
            {
                var response = await kriService.GetDetailKriMetricAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Get KRI Report headers info when draft report is opened for editing
        /// </summary>
        /// <remarks>
        /// Returns header info like Reporting Period and Reporting Frequency
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getEditkridata")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<EditKriResponse>>> GetEditkridata([FromQuery] EditKriRequest request)
        {
            try
            {
                var response = await kriService.GetEditKriReportAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Delete a Draft KRI report .
        /// </summary>
        /// <remarks>
        /// It deletes given report along with all associated metric Ids
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("deleteKriReportApi")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> DeleteKriReportApi([FromQuery] UpdatePreviewKriRequest request)
        {
            try
            {
                var response = await kriService.DeleteKriReportAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Removes the one single metricid within a KRI report.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("removeMetric")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<string>>> RemoveMetric([FromQuery] UpdatePreviewKriRequest request)
        {
            try
            {
                var response = await kriService.RemoveKriMetricAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Validate if there is a duplicate KRI report for given location and reporting period.
        /// </summary>
        /// <remarks>
        /// This is with the exception of reports with Status "Rejected".
        /// Report with Status Draft, Submitted and Approved are considered duplicate.
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("validateduplicatekrireport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> ValidateDuplicateKriReport([FromQuery] ValidateDuplicateKriReportRequest request)
        {
            try
            {
                var response = await kriService.ValidateDuplicateKriReportAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
    }
}
