﻿using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Dashboard;
using ORM.Application.Interfaces.User;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System;
using System.Net;


namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class DashboardController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [ApiController]
    [Route("api/[controller]")]
    [OrmAuthorize]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class DashboardController : BaseController
    {
        private readonly IDashboardService dashboardService;
        /// <summary>
        /// Initializes a new instance of the <see cref="DashboardController"/> class.
        /// </summary>
        /// <param name="DashboardService">The Dashboard service.</param>
        /// <remarks>SBSC</remarks>
        public DashboardController(IDashboardService DashboardService)
        {
            this.dashboardService = DashboardService;
        }

        /// <summary>
        /// Retrieves Loss data based on the filter request
        /// </summary>
        /// <remarks>
        /// Loss data Dashboard trend
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getlossdatatrend")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<LossTrendResponse>>> GetLossDataTrend([FromQuery] BaseDashboardChartsRequest request)
        {
            try
            {
                var response = await dashboardService.GetLossDataTrend(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves Operational risk losses vs fraud loss based on the filter request
        /// </summary>
        /// <remarks>
        /// Operational Risk Losses vs fraud loss
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getoperationalrisklossesvsfraudloss")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<OperationalRiskLossVsFraudLossResponse>>> GetOperationalRiskLossesVsFraudLoss([FromQuery] BaseDashboardChartsRequest request)
        {
            try
            {
                var response = await dashboardService.GetOperationalRiskLossesVsFraudLoss(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves regional internal frauds based on the filter request
        /// </summary>
        /// <remarks>
        /// Regional Internal Fraud Distribution
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getregionalinternalfraud")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<RegionalInternalFraudResponse>>> GetRegionalInternalFraudChart([FromQuery] BaseDashboardChartsRequest request)
        {
            try
            {
                var response = await dashboardService.GetRegionalInternalFraudChart(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves Operational risk losses based on the filter request
        /// </summary>
        /// <remarks>
        /// Operational Risk Losses
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getoperationalrisklosses")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<OperationalRiskLossResponse>>> GetOperationalRiskLosses([FromQuery] BaseDashboardChartsRequest request)
        {
            try
            {
                var response = await dashboardService.GetOperationalRiskLosses(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves root cause analysis for actua loss based on the filter request
        /// </summary>
        /// <remarks>
        /// Root Cause Analysis For Actual Loss
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getrootcauseanalysisforactualloss")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<RootCauseAnalysisResponse>>> GetRootCauseAnalysisForActualLoss([FromQuery] BaseDashboardChartsRequest request)
        {
            try
            {
                var response = await dashboardService.GetRootCauseAnalysisForActualLoss(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Retrieves gross vs recovery vs net loss based on the filter request
        /// </summary>
        /// <remarks>
        /// Gross Vs Recovery Vs Net Loss
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getgrossvsrecoveryvsnetloss")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<GrossVsRecoveryVsNetLossResponse>>> GetGrossVsRecoveryVsNetLoss([FromQuery] BaseDashboardChartsRequest request)
        {
            try
            {
                var response = await dashboardService.GetGrossVsRecoveryVsNetLoss(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Retrieves Risk based on the filter request
        /// </summary>
        /// <remarks>
        /// Risk Reports
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("riskreports")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<RiskChartReportResponse>>> GetRiskOccurenceCharts([FromQuery] FilterRiskReportRequest request)
        {
            try
            {
                var response = await dashboardService.GetRiskOccurenceCharts(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves trend of operational risk source based on the filter request
        /// </summary>
        /// <remarks>
        /// Trend operational risk source
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("gettrendofoperationalrisksource")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<TrendOfOperationalRiskSourceResponse>>> GetTrendOfOperationalRiskSource([FromQuery] FilterRiskReportRequest request)
        {
            try
            {
                var response = await dashboardService.GetTrendOfOperationalRiskSource(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves key risk indicators based on the filter request
        /// </summary>
        /// <remarks>
        /// Key risk Indicator
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getkeyriskindicator")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KeyRiskIndicatorResponse>>> GetKeyRiskIndicator([FromQuery] FilterKeyRiskIndicatorRequest request)
        {
            try
            {
                var response = await dashboardService.GetKeyRiskIndicator(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Retrieves kyc compliance charts based on the filter request
        /// </summary>
        /// <remarks>
        /// Kyc Compliance
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getkyccompliance")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<KycComplianceResponse>>> GetKYCComplianceChart([FromQuery] FilterKriReportMetricsRequest request)
        {
            try
            {
                var response = await dashboardService.GetKYCComplianceChart(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves Non functional CCTV and systems with or without up to date patches based on the filter request
        /// </summary>
        /// <remarks>
        /// NonFunctionalCCTVAndPatches
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getnonfunctionalcctvandpatches")]  
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<NonFunctionalCctvAndPatchesResponse>>> GetNonFunctionalCCTVAndPatches([FromQuery] FilterKriReportMetricsRequest request)
        {
            try
            {
                var response = await dashboardService.GetNonFunctionalCCTVAndPatches(request);
                return HandleResponse(response);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
