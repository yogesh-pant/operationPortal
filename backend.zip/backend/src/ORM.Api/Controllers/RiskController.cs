﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Location;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System.Net;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class RiskController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [ApiController]
    [Route("api/[controller]")]
    [OrmAuthorize]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class RiskController : BaseController
    {
        private readonly IRiskService riskService;
        /// <summary>
        /// Initializes a new instance of the <see cref="RiskController"/> class.
        /// </summary>
        /// <param name="RiskService">The risk service.</param>
        /// <remarks>SBSC</remarks>
        public RiskController(IRiskService RiskService)
        {
            this.riskService = RiskService;
        }

        /// <summary>
        /// Retrieves Risk Reports based on the filter request
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("GetRiskReportList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<RiskGridResponse>>> GetRiskGridAsync([FromQuery] FilterRiskListRequest request)
        {
            try
            {
                var response = await riskService.GetRiskGridAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Create Risk Report for RLO 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("CreateRiskReport")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> CreateRiskDataAsync([FromForm] CreateRiskDataRequest request)
        {
            try
            {
                var response = await riskService.CreateRiskDataAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Input  " + ex!.InnerException!.Message);
            }
        }
        /// <summary>
        /// Edit Risk Report for RLO 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("EditRiskReport")]
        [Consumes("multipart/form-data")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> EditRiskDataAsync([FromForm] EditRiskDataRequest request)
        {
            try
            {
                var response = await riskService.EditRiskDataAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid Input  " + ex!.InnerException!.Message);
            }
        }
        /// <summary>
        /// Update Risk Report by BORM Admin 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("UpdateRiskReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateRiskDataAsync([FromBody] UpdateRiskDataRequest request)
        {
            try
            {
                var response = await riskService.UpdateRiskDataAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// get the upload document for risk report on view / edit 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getriskDoc")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<RiskDoc>>> GetRiskDoc([FromQuery] GetDocRequest request)
        {
            try
            {
                var response = await riskService.GetRiskReportDoc(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Risk Report Status by BORM Admin (Reject/Request Update)
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("UpdateRiskReportStatus")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateRiskStatusAsync([FromBody] UpdateRiskStatusRequest request)
        {
            try
            {
                var response = await riskService.UpdateRiskStatusAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
