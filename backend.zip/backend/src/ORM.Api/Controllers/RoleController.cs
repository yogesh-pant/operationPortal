﻿using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Role;
using ORM.Application.Interfaces.User;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System.Net;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class RoleController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [ApiController]
    [Route("api/[controller]")]
    [OrmAuthorize]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class RoleController : BaseController
    {
        private readonly IRoleService roleService;
        /// <summary>
        /// Initializes a new instance of the <see cref="RoleController"/> class.
        /// </summary>
        /// <param name="roleService">The role service.</param>
        /// <remarks>SBSC</remarks>
        public RoleController(IRoleService roleService)
        {
            this.roleService = roleService;
        }

        /// <summary>
        /// Retrieves Roles based on the filter request
        /// </summary>
        /// <remarks>
        /// RoleStatus is an enum with the following: Active - true, Inactive - false
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getRoles")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<RoleGridResponse>>> GetRoles([FromQuery] FilterRoleRequest request)
        {
            try
            {
                var response = await roleService.GetAllRoleAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

