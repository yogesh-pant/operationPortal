﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Location;
using ORM.Application.Interfaces.User;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System.Net;



namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class LocationController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [ApiController]
    [Route("api/[controller]")]
    [OrmAuthorize]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class LocationController : BaseController
    {
        private readonly ILocationService locationService;
        /// <summary>
        /// Initializes a new instance of the <see cref="LocationController"/> class.
        /// </summary>
        /// <param name="locationService">The location service.</param>
        /// <remarks>SBSC</remarks>
        public LocationController(ILocationService locationService)
        {
            this.locationService = locationService;
        }

        /// <summary>
        /// Retrieves Branches based on the filter request
        /// </summary>
        /// <remarks>
        /// Branch status can be Active Or Inactive
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("GetBranchList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<BranchLocationGridResponse>>> GetAllBranchLocationsAsync([FromQuery] FilterBranchListRequest request)
        {
            try
            {
                var response = await locationService.GetAllBranchLocationsAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Retrieves Departments based on the filter request
        /// </summary>
        /// <remarks>
        /// Branch status can be Active Or Inactive
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("GetDepartmentList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<DepartmentLocationGridResponse>>> GetAllDepartmentLocationsAsync([FromQuery] FilterDepartmentListRequest request)
        {
            try
            {
                var response = await locationService.GetAllDepartmentLocationsAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Create New Branch Location
        /// </summary>
        /// <remarks>
        /// Branch status can be Active Or Inactive
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("CreateBranchLocation")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> CreateBranchLocationAsync([FromBody] CreateBranchLocationRequest request)
        {
            try
            {
                var response = await locationService.CreateBranchLocationAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Create New Department Location
        /// </summary>
        /// <remarks>
        /// Department status can be Active Or Inactive
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("CreateDepartmentLocation")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> CreateDepartmentLocationAsync([FromBody] CreateDepartmentLocationRequest request)
        {
            try
            {
                var response = await locationService.CreateDepartmentLocationAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Branch Location
        /// </summary>
        /// <remarks>
        /// Branch status can be Active Or Inactive
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("UpdateBranchLocation")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateBranchLocationAsync([FromBody] UpdateBranchLocationRequest request)
        {
            try
            {
                var response = await locationService.UpdateBranchLocationAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Department Location
        /// </summary>
        /// <remarks>
        /// Department status can be Active Or Inactive
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("UpdateDepartmentLocation")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> UpdateDepartmentLocationAsync([FromBody] UpdateDepartmentLocationRequest request)
        {
            try
            {
                var response = await locationService.UpdateDepartmentLocationAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Approve the Location change request(Update/Create) by Checker Admin and update the Location record
        /// </summary>
        /// <remarks>         
        /// </remarks>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns></returns>
        [HttpGet("ApproveLocationChange")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> ApproveUserInfoAsync([FromQuery] ReviewUserChangeRequest request)
        {
            try
            {
                var response = await locationService.ApproveLocationChangeAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Reject the Location change request(Update/Create) by Checker Admin and update the Location record
        /// </summary>
        /// <remarks>         
        /// </remarks>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns></returns>
        [HttpGet("RejectLocationChange")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> RejectUserInfoAsync([FromQuery] ReviewUserChangeRequest request)
        {
            try
            {
                var response = await locationService.RejectLocationChangeAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }




    }

}

