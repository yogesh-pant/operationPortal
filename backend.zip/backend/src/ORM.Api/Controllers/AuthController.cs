﻿using Fcmb.Shared.Auth.Models.Requests;
using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Responses;
using System.Net;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class AuthController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class AuthController : BaseController
    {
        private readonly IAuthSetupService authSetupService;
        /// <summary>
        /// Initializes a new instance of the <see cref="AuthController"/> class.
        /// </summary>
        /// <param name="authSetupService">The authentication setup service.</param>
        /// <remarks>SBSC</remarks>
        public AuthController(IAuthSetupService authSetupService)
        {
            this.authSetupService = authSetupService;
        }

        /// <summary>
        /// Logins in a user to the AD based on the username and encrypted password
        /// </summary>
        /// <remarks>
        /// A JWT Token is returned which must passed to the other endpoints in the Auth Header for subsequent requests
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("login")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<LoginResponse>>> Login([FromBody] LoginRequest request)
        {
            var ip = IpAddress;
            var response = await authSetupService.LoginAsync(request,ip!);
            return HandleResponse(response);

        }
        /// <summary>
        /// This checks the user id to be available in AD
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        [HttpGet("userexists")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<LoginResponse>>> CheckUserInAd(string userName)
        {
            var ip = IpAddress;
            var response = await authSetupService.CheckUserInAdAsync(userName,ip!);
            return HandleResponse(response);

        }
        /// <summary>
        /// This function is used to get user log out
        /// </summary>
        /// <param name="UserName"></param>
        /// <returns></returns>
        [HttpGet("logout")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [OrmAuthorize]
        [Consumes("application/json")]
        [Produces("application/json")]
        public async Task<ActionResult<ObjectResponse<string>>> Logout(string UserName)
        {
            var ip = IpAddress;
            var response = await authSetupService.LogoutAsync(UserName,ip!);
            return HandleResponse(response);

        }


    }
}
