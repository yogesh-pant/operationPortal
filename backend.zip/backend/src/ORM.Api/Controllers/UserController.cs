﻿using Fcmb.Shared.Models.Requests;
using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Authorization;
using ORM.Application.Interfaces.User;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using System.Net;



namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class UsersController.
    /// Implements the <see cref="ORM.Api.Controllers.BaseController" />
    /// </summary>
    /// <seealso cref="ORM.Api.Controllers.BaseController" />
    [ApiController]
    [Route("api/[controller]")]
    [OrmAuthorize]
    [Consumes("application/json")]
    [Produces("application/json")]
    public class UsersController : BaseController
    {
        private readonly IUserService userService;
        /// <summary>
        /// Initializes a new instance of the <see cref="UsersController"/> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <remarks>SBSC</remarks>
        public UsersController(IUserService userService)
        {
            this.userService = userService;
        }

        /// <summary>
        /// Retrieves users based on the filter request
        /// </summary>
        /// <remarks>
        /// UserStatus is an enum with the following: Active - 0, Inactive - 1
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getUsers")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<UserResponse>>> GetUsers([FromQuery] FilterUserRequest request)
        {
            try
            {
                var response = await userService.GetAllUserAsync(request);
                return HandleResponse(response);
            }
            catch   (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        /// <summary>
        /// Edit/Update existing ORM user details
        /// </summary>
        /// <remarks>
        /// ORMUser
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("updateuserdetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> Updateuserdetails([FromBody] EditUserRequest request)
        {
            try 
            {
                var response = await userService.UpdateUserInfo(request); 
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Validate user name before creating new user
        /// </summary>
        /// <remarks>
        /// ORMUser
        /// </remarks>
        /// <param name="UserName"></param>
        /// <returns></returns>
        [HttpGet("CreateORMUser")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<UserResponse>>> CreateORMUser([FromQuery] string UserName)
        {
            try
            {
                var response = await userService.AddUserInfo(UserName);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        /// <summary>
        /// Submit Request for creating new ORM user after prior user validation via AD
        /// </summary>
        /// <remarks>
        /// Request is submitted by Maker Admin
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("newUser")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<ReturnId>>> NewUser([FromBody] AddNewUserRequest request)
        {
            try
            {
                var response = await userService.AddNewUserInfo(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Retrieves List of Users based on role and/or location
        /// </summary>
        /// <remarks>
        /// It is used in poulating ICO user dropdown
        /// </remarks>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("GetUserByRoleLocation")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ListResponse<GetUsersByRoleLocationResponse>>> GetUserByRoleLocationAsync([FromQuery] FilterGetUsersByRoleLocationRequest request)
        {
            try
            {
                var response = await userService.GetUserByRoleLocationAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// This API is used to Approve the user change request(Update/Create) by Checker Admin and update the user record
        /// </summary>
        /// <remarks>         
        /// </remarks>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns></returns>
        [HttpGet("ApproveUserInfo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> ApproveUserInfoAsync([FromQuery] ReviewUserChangeRequest request)
        {
            try
            {
                var response = await userService.ApproveUserInfoAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// This API is used to Reject the user change request(Update/Create) by Checker Admin and update the user record
        /// </summary>
        /// <remarks>         
        /// </remarks>
        /// <param>ReviewUserChangeRequest</param>
        /// <returns></returns>
        [HttpGet("RejectUserInfo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult<ObjectResponse<string>>> RejectUserInfoAsync([FromQuery] ReviewUserChangeRequest request)
        {
            try
            {
                var response = await userService.RejectUserInfoAsync(request);
                return HandleResponse(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}

