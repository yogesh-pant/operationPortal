﻿using ORM.Application.Models.Constants;
using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;

namespace ORM.Api.Controllers
{
    /// <summary>
    /// Class BaseController.
    /// Implements the <see cref="ControllerBase" />
    /// </summary>
    /// <seealso cref="ControllerBase" />
    public class BaseController : ControllerBase
    {
        /// <summary>
        /// This is used to provide handling the requests
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="result"></param>
        /// <returns></returns>
        protected ActionResult<T> HandleResponse<T>(T result) where T : StatusResponse
        {
            try
            {
                return result.Code switch
                {
                    ResponseCodes.Success => Ok(result),
                    ResponseCodes.Unauthenticated => Unauthorized(result),
                    ResponseCodes.ServiceError => StatusCode(500, result),
                    ResponseCodes.DataNotFound => NotFound(result),
                    _ => BadRequest(result)
                };
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Gets the IP address of the client
        /// </summary>
        public string? IpAddress
        {
            get
            {
                StringValues value;
                return Request.Headers.TryGetValue("X-Forwarded-For", out value) ? ((string?)value) : (HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? null);
            }
        }

    }
}
