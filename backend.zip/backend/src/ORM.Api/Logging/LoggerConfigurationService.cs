﻿using Serilog.Events;
using Serilog;
using ORM.Application.Models.Logging;
using System.Diagnostics.CodeAnalysis;

namespace ORM.Api.Logging
{
    /// <summary>
    /// Service for configuring the logger.
    /// </summary>
    public interface ILoggerConfigurationService
    {
        /// <summary>
        /// Configures the logger based on the provided options.
        /// </summary>
        /// <param name="options">The logger configuration options.</param>
        LoggerConfiguration ConfigureLogger(LoggerOptions options);
    }

    /// <summary>
    /// Service implementation for configuring the logger.
    /// </summary>
    public class LoggerConfigurationService : ILoggerConfigurationService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoggerConfigurationService"/> class.
        /// </summary>
        public LoggerConfigurationService()
        {
        }

        /// <summary>
        /// Configures the logger based on the provided options.
        /// </summary>
        /// <param name="options">The logger configuration options.</param>
        /// <returns></returns>
        public LoggerConfiguration ConfigureLogger(LoggerOptions options)
        {
            // Initialize Serilog logger configuration
            var loggerConfiguration = new LoggerConfiguration()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                .Enrich.FromLogContext();

            // Configure console logging if enabled
            if (options.EnableConsole)
                loggerConfiguration.WriteTo.Console();

            // Configure file logging if enabled and a valid file path is provided
            if (options.EnableFile && !string.IsNullOrEmpty(options.LogFilePath))
            {
                loggerConfiguration.WriteTo.File(
                    formatter: new CustomTextFormatter(),
                    path: options.LogFilePath,
                    fileSizeLimitBytes: options.FileSizeLimitBytes,
                    rollingInterval: RollingInterval.Day,
                    rollOnFileSizeLimit: options.RollOnFileSizeLimit,
                    retainedFileCountLimit: options.RetainedFileCountLimit);
            }

            // Configure Azure Application Insights logging if enabled and a valid instrumentation key is provided
            if (options.EnableAzureApplicationInsights && !string.IsNullOrEmpty(options.AzureInstrumentationKey))
                loggerConfiguration.WriteTo.ApplicationInsights(options.AzureInstrumentationKey, TelemetryConverter.Traces);

            // Return the configured logger configuration
            return loggerConfiguration;
        }
    }
}

