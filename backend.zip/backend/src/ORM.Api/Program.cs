
using ORM.Api;
using ORM.Domain.Common;
using ORM.Infrastructure;
using Org.BouncyCastle.Asn1.Mozilla;
using System.Diagnostics.CodeAnalysis;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;

namespace ORM.Api
{
    /// <summary>
    /// Class Program.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Program
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Program"/> class.
        /// </summary>
        /// <remarks>SBSC</remarks>
        protected Program()
        {
        }
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var configuration = builder.Configuration;

            builder.Services.AddServicesToContainer(configuration);
            builder.Services.ConfigureInfrastructureServices(configuration);
            var app = builder.Build();

            app.ConfigureHttpRequestPipeline();
            app.Run();

        }

    }
}



