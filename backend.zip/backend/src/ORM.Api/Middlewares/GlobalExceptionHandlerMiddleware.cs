﻿using System.Net;
using ORM.Application.Exceptions;
using ORM.Application.Models.Constants;
using Fcmb.Shared.Models.Responses;
using Fcmb.Shared.Utilities;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;


namespace ORM.Api.Middlewares
{
    /// <summary>
    /// Class GlobalExceptionHandlerMiddleware.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class GlobalExceptionHandlerMiddleware
    {
        /// <summary>
        /// This is middleware function used to handle global exception
        /// </summary>
        /// <param name="app"></param>
        public static void UseGlobalExceptionHandler(this IApplicationBuilder app)
        {
                app.UseExceptionHandler(appError =>
                   {
                       appError.Run(async context =>
                       {
                           var logger = context.RequestServices.GetRequiredService<ILogger>();
                           context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

                           context.Response.ContentType = "application/json";

                           var contextFeature = context.Features.Get<IExceptionHandlerFeature>();

                           if (contextFeature is not null)
                           {
                               var exception = contextFeature.Error.GetBaseException();

                               logger.LogCritical(exception, "Something went wrong: {Exception}", contextFeature.Error);

                               var responseMessage = exception switch
                               {
                                   InAppException => contextFeature.Error.Message,
                                   _ => "Error Processing Request"
                               };

                               await context.Response.WriteAsync(
                                   new StatusResponse(responseMessage, ResponseCodes.ServiceError).Serialize());
                           }
                       });
                   });
           
        }
    }
}
