﻿using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using ORM.Application.Interfaces.Auth;
using ORM.Domain.Common;
using ORM.Infrastructure.Repositories;
using ORM.Infrastructure.Services;
using ORM.Application.Interfaces.Location;

namespace ORM.Test.LocationServiceTests
{
    public class GetAllBranchLocationsTest
    {
        private readonly Mock<ILogger<LocationService>> _mockLogger;
        private readonly Mock<ISessionService> _mockSessionService;
        private readonly Mock<IUnitOfWork> _mockUnitOfWork;
        private readonly ILocationService _locationService;

        public GetAllBranchLocationsTest()
        {
            _mockLogger = new Mock<ILogger<LocationService>>();
            _mockSessionService = new Mock<ISessionService>();
            _mockUnitOfWork = new Mock<IUnitOfWork>();

            _locationService = new LocationService(
                _mockLogger.Object,
                _mockSessionService.Object,
                _mockUnitOfWork.Object);
        }

        [Fact]
        public async Task GetAllBranchLocations_ShouldWork()
        {
            // Arrange
            var input = new FilterBranchListRequest();
            SetupMocks(branchCount: 5);

            // Act
            var result = await _locationService.GetAllBranchLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Equal(5, result.Total);
            Assert.Equal("Successfully Retrieved Branch grid data", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            VerifyMocks();
        }

        [Fact]
        public async Task GetAllBranchLocations_WithUnauthenticatedUser_ShouldReturnError()
        {
            // Arrange
            var input = new FilterBranchListRequest();
            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationService.GetAllBranchLocationsAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task GetAllBranchLocations_WithNullInput_ShouldReturnError()
        {
            // Arrange
            FilterBranchListRequest input = null!;
            SetupMocks();

            // Act
            var result = await _locationService.GetAllBranchLocationsAsync(input!);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Invalid input", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task GetAllBranchLocations_WithNoRecords_ShouldReturnEmptyList()
        {
            // Arrange
            var input = new FilterBranchListRequest();
            SetupMocks(branchCount: 0);

            // Act
            var result = await _locationService.GetAllBranchLocationsAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal(0, result.Total);
            Assert.Equal("No record found for given input", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task GetAllBranchLocations_WithFilters_ShouldReturnFilteredResults()
        {
            // Arrange
            var input = new FilterBranchListRequest
            {
                Branch = "Test",
                Region = "Region 1",
                Status = "Active"
            };
            SetupMocks(branchCount: 10);

            // Act
            var result = await _locationService.GetAllBranchLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.True(result.Total > 0 && result.Total < 10);
            Assert.All(result.Data, item => Assert.Contains("Test", item.Branch));
            Assert.All(result.Data, item => Assert.Equal("Region 1", item.Region));
            Assert.All(result.Data, item => Assert.Equal("Active", item.Status));
        }

        [Fact]
        public async Task GetAllBranchLocations_WithPagination_ShouldReturnPaginatedResults()
        {
            // Arrange
            var input = new FilterBranchListRequest
            {
                PageNumber = 2,
                PageSize = 3
            };
            SetupMocks(branchCount: 10);

            // Act
            var result = await _locationService.GetAllBranchLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Equal(3, result.Data.Count());
            Assert.Equal(10, result.Total);
        }

        private void SetupMocks(bool authenticatedUser = true, int branchCount = 5)
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestUser", "Test", "Test", null) : null;
            _mockSessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var branches = new List<ORMLocation>();
            for (int i = 1; i <= branchCount; i++)
            {
                branches.Add(new ORMLocation
                {
                    Id = i,
                    LocationId = $"B00{i}",
                    LocationType = "B",  // This is crucial
                    SolId = $"SOL{i}",
                    Branch = $"Test Branch {i}",
                    Region = $"Region {i % 3}",
                    Status = i % 2 == 0 ? "Active" : "Inactive",
                    CreatedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-i),
                    ModifiedById = 1,
                    ModifiedDate = DateTime.Now.AddDays(-i),
                    ReviewedById = 1,
                    ReviewedDate = DateTime.Now.AddDays(-i),
                    LocationChangeStatus = "Pending",
                    ChangeReviewComments = "ssasa",
                    ChangeRequestData = JsonConvert.SerializeObject(new LocationBranchChangeData
                    {
                        NewLocationBranch = $"New Branch {i}",
                        NewLocationRegion = $"New Region {i % 3}",
                        NewLocationStatus = "Active",
                        LocationNewFlag = "Yes",
                        LocationNewUpdatedBy = 1,
                        LocationNewUpdatedByName = "Test User",
                        LocationNewChangeRequestDate = DateTime.Now
                    })
                });
            }

            var mockBranchDbSet = branches.AsQueryable().BuildMockDbSet();
            _mockUnitOfWork.Setup(x => x.ORMLocation.GetAll()).Returns(mockBranchDbSet.Object);

            var users = new List<ORMUser>
                {
                    new() { Id = 1, UserName = "TestUser" }
                };
            var mockUserDbSet = users.AsQueryable().BuildMockDbSet();
            _mockUnitOfWork.Setup(x => x.ORMUsers.GetAll()).Returns(mockUserDbSet.Object);
        }

        private void VerifyMocks()
        {
            _mockUnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.AtLeastOnce);
            _mockUnitOfWork.Verify(x => x.ORMUsers.GetAll(), Times.AtLeastOnce);
        }
    }
}