﻿using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.Repositories;

namespace ORM.Test.LocationServiceTests
{
    public class UpdateBranchLocationTest
    {
        private readonly LocationServiceFactory _locationServiceFactory;

        public UpdateBranchLocationTest()
        {
            _locationServiceFactory = new LocationServiceFactory();
        }

        [Fact]
        public async Task UpdateBranchLocation_ShouldWork()
        {
            // Arrange
            var input = new UpdateBranchLocationRequest
            {
                id = 1,
                Branch = "UpdatedBranch",
                Region = "UpdatedRegion",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: true);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateBranchLocationAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            //Assert.Equal(1, result.Data[0].id);
            Assert.Equal("Successfully Submitted Update Request for Branch", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            VerifyMocks(input);
        }

        [Fact]
        public async Task UpdateBranchLocation_WithUnauthenticatedUser_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateBranchLocationRequest
            {
                id = 1,
                Branch = "UpdatedBranch",
                Region = "UpdatedRegion",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateBranchLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task UpdateBranchLocation_WithExistingBranchName_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateBranchLocationRequest
            {
                id = 1,
                Branch = "ExistingBranch",
                Region = "UpdatedRegion",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: true, existingBranchName: true);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateBranchLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Input Branch Name already exists in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        [Fact]
        public async Task UpdateBranchLocation_WithNonExistentLocation_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateBranchLocationRequest
            {
                id = 999,
                Branch = "UpdatedBranch",
                Region = "UpdatedRegion",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: false);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateBranchLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Location not found for Branch id in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        [Fact]
        public async Task UpdateBranchLocation_WithNoChanges_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateBranchLocationRequest
            {
                id = 1,
                Branch = "ExistingBranch",
                Region = "ExistingRegion",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: true, noChanges: true);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateBranchLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("No changes made in Branch data!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        private void SetupMocks(bool authenticatedUser = true, bool existingLocation = true, bool existingBranchName = false, bool noChanges = false)
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null) : null;
            _locationServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var locRepository = new Mock<IOrmLocationRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(locRepository.Object);

            var existingLocations = new List<ORMLocation>();
            if (existingLocation)
            {
                existingLocations.Add(new ORMLocation
                {
                    Id = 1,
                    LocationType = "B",
                    Branch = noChanges ? "ExistingBranch" : "OldBranch",
                    Region = noChanges ? "ExistingRegion" : "OldRegion",
                    Status = noChanges ? "Active" : "Inactive"
                });
            }
            if (existingBranchName)
            {
                existingLocations.Add(new ORMLocation { Id = 2, LocationType = "B", Branch = "ExistingBranch" });
            }

            var mockDbSet = existingLocations.AsQueryable().BuildMockDbSet();

            locRepository.Setup(repo => repo.GetAll()).Returns(mockDbSet.Object);

            var userRepository = new Mock<IOrmUserRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable())
                .Returns(new List<ORMUser> { new ORMUser { Id = 1, UserName = "TestUser" } }.AsQueryable().BuildMockDbSet().Object);

            _locationServiceFactory.UnitOfWork.Setup(x => x.Save()).Returns(1);
        }

        private void VerifyMocks(UpdateBranchLocationRequest input)
        {
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.Exactly(2));
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMUsers.GetAll(), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.Save(), Times.Once);
        }
    }
}