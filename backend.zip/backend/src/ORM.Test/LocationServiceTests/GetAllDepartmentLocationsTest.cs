﻿using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using ORM.Application.Interfaces.Auth;
using ORM.Domain.Common;
using ORM.Infrastructure.Repositories;
using ORM.Infrastructure.Services;
using ORM.Application.Interfaces.Location;

namespace ORM.Test.LocationServiceTests
{
    public class GetAllDepartmentLocationsTest
    {
        private readonly Mock<ILogger<LocationService>> _mockLogger;
        private readonly Mock<ISessionService> _mockSessionService;
        private readonly Mock<IUnitOfWork> _mockUnitOfWork;
        private readonly ILocationService _locationService;

        public GetAllDepartmentLocationsTest()
        {
            _mockLogger = new Mock<ILogger<LocationService>>();
            _mockSessionService = new Mock<ISessionService>();
            _mockUnitOfWork = new Mock<IUnitOfWork>();

            _locationService = new LocationService(
                _mockLogger.Object,
                _mockSessionService.Object,
                _mockUnitOfWork.Object);
        }

        [Fact]
        public async Task GetAllDepartmentLocations_ShouldWork()
        {
            // Arrange
            var input = new FilterDepartmentListRequest();
            SetupMocks(deptCount: 5);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Equal(5, result.Total);
            Assert.Equal("Successfully Retrieved Department grid data", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            VerifyMocks();
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithUnauthenticatedUser_ShouldReturnError()
        {
            // Arrange
            var input = new FilterDepartmentListRequest();
            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithNullInput_ShouldReturnError()
        {
            // Arrange
            FilterDepartmentListRequest input = null!;
            SetupMocks();

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Invalid input", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithNoRecords_ShouldReturnEmptyList()
        {
            // Arrange
            var input = new FilterDepartmentListRequest();
            SetupMocks(deptCount: 0);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal(0, result.Total);
            Assert.Equal("No record found for given input", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithFilters_ShouldReturnFilteredResults()
        {
            // Arrange
            var input = new FilterDepartmentListRequest
            {
                Department = "Test",
                Status = "Active"
            };
            SetupMocks(deptCount: 10);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.True(result.Total > 0 && result.Total < 10);
            Assert.All(result.Data, item => Assert.Contains("Test", item.Department));
            Assert.All(result.Data, item => Assert.Equal("Active", item.Status));
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithPagination_ShouldReturnPaginatedResults()
        {
            // Arrange
            var input = new FilterDepartmentListRequest
            {
                PageNumber = 2,
                PageSize = 3
            };
            SetupMocks(deptCount: 10);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Equal(3, result.Data.Count());
            Assert.Equal(10, result.Total);
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithNullChangeRequestData_ShouldInitializeEmptyDeptChangeData()
        {
            // Arrange
            var input = new FilterDepartmentListRequest();
            SetupMocks(deptCount: 1, nullChangeRequestData: true);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            var department = result.Data.First();
            Assert.Equal("No", department.LocationNewFlag);
            Assert.Empty(department.NewLocationDepartment!);
            Assert.Empty(department.NewLocationStatus!);
            Assert.Null(department.NewLocationUpdatedBy);
            Assert.Empty(department.NewLocationUpdatedByName!);
            Assert.Null(department.NewLocationChangeRequestDate);
        }

        [Fact]
        public async Task GetAllDepartmentLocations_WithEmptyChangeRequestData_ShouldInitializeEmptyDeptChangeData()
        {
            // Arrange
            var input = new FilterDepartmentListRequest();
            SetupMocks(deptCount: 1, emptyChangeRequestData: true);

            // Act
            var result = await _locationService.GetAllDepartmentLocationsAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            var department = result.Data.First();
            Assert.Equal("No", department.LocationNewFlag);
            Assert.Empty(department.NewLocationDepartment!);
            Assert.Empty(department.NewLocationStatus!);
            Assert.Null(department.NewLocationUpdatedBy);
            Assert.Empty(department.NewLocationUpdatedByName!);
            Assert.Null(department.NewLocationChangeRequestDate);
        }

        private void SetupMocks(bool authenticatedUser = true, int deptCount = 5, bool nullChangeRequestData = false, bool emptyChangeRequestData = false)
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestUser", "Test", "Test", null) : null;
            _mockSessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var depts = new List<ORMLocation>();
            for (int i = 1; i <= deptCount; i++)
            {
                var dept = new ORMLocation
                {
                    Id = i,
                    LocationId = $"D00{i}",
                    LocationType = "D",
                    SolId = $"SOL{i}",
                    Department = $"Test Department {i}",
                    Status = i % 2 == 0 ? "Active" : "Inactive",
                    CreatedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-i),
                    ModifiedById = 1,
                    ModifiedDate = DateTime.Now.AddDays(-i),
                    ReviewedById = 1,
                    ReviewedDate = DateTime.Now.AddDays(-i),
                    LocationChangeStatus = "Pending",
                    ChangeReviewComments = "ssasa",
                };

                if (nullChangeRequestData)
                {
                    dept.ChangeRequestData = null;
                }
                else if (emptyChangeRequestData)
                {
                    dept.ChangeRequestData = "";
                }
                else
                {
                    dept.ChangeRequestData = JsonConvert.SerializeObject(new LocationDeptChangeData
                    {
                        NewLocationDepartment = $"New Department {i}",
                        NewLocationStatus = "Active",
                        LocationNewFlag = "Yes",
                        LocationNewUpdatedBy = 1,
                        LocationNewUpdatedByName = "Test User",
                        LocationNewChangeRequestDate = DateTime.Now
                    });
                }

                depts.Add(dept);
            }

            var mockDeptDbSet = depts.AsQueryable().BuildMockDbSet();
            _mockUnitOfWork.Setup(x => x.ORMLocation.GetAll()).Returns(mockDeptDbSet.Object);

            var users = new List<ORMUser>
                {
                    new() { Id = 1, UserName = "TestUser" }
                };
            var mockUserDbSet = users.AsQueryable().BuildMockDbSet();
            _mockUnitOfWork.Setup(x => x.ORMUsers.GetAll()).Returns(mockUserDbSet.Object);
        }

        private void VerifyMocks()
        {
            _mockUnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.AtLeastOnce);
            _mockUnitOfWork.Verify(x => x.ORMUsers.GetAll(), Times.AtLeastOnce);
        }
    }
}