﻿using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ORM.Test.LocationServiceTests
{
    public class CreateDepartmentLocationTest
    {
        private readonly LocationServiceFactory _locationServiceFactory;

        public CreateDepartmentLocationTest()
        {
            _locationServiceFactory = new LocationServiceFactory();
        }

        [Fact]
        public async Task CreateDepartmentLocation_ShouldWork()
        {
            // Arrange
            var data = new CreateDepartmentLocationRequest()
            {
                Department = "NewDept",
                CreatedById = 1
            };

            SetupMocks();

            // Act
            var result = await _locationServiceFactory.LocationService.CreateDepartmentLocationAsync(data);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            //Assert.Equal(2, result.Data[0].id);
            Assert.Equal("New Department Created!", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            VerifyMocks(data);
        }

        [Fact]
        public async Task CreateDepartmentLocation_WithInvalidInput_ShouldReturnError()
        {
            // Arrange
            var invalidData = new CreateDepartmentLocationRequest()
            {
                Department = "",
                CreatedById = 1
            };

            SetupMocks();

            // Act
            var result = await _locationServiceFactory.LocationService.CreateDepartmentLocationAsync(invalidData);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("invalid input", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task CreateDepartmentLocation_WithUnauthenticatedUser_ShouldReturnError()
        {
            // Arrange
            var data = new CreateDepartmentLocationRequest()
            {
                Department = "NewDept",
                CreatedById = 1
            };

            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationServiceFactory.LocationService.CreateDepartmentLocationAsync(data);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task CreateDepartmentLocation_WithExistingDepartmentName_ShouldReturnError()
        {
            // Arrange
            var data = new CreateDepartmentLocationRequest()
            {
                Department = "existingDept",
                CreatedById = 1
            };

            SetupMocks(existingDepartment: true);

            // Act
            var result = await _locationServiceFactory.LocationService.CreateDepartmentLocationAsync(data);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Input Department Name already exists in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        private void SetupMocks(bool authenticatedUser = true, bool existingDepartment = false)
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null) : null;
            _locationServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var locRepository = new Mock<IOrmLocationRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(locRepository.Object);

            var existingLocations = new List<ORMLocation>();
            if (existingDepartment)
                existingLocations.Add(new ORMLocation { Department = "existingDept" });

            locRepository.Setup(repo => repo.GetAll().AsQueryable())
                .Returns(existingLocations.BuildMock());

            _locationServiceFactory.UnitOfWork.Setup(x => x.GetNextLocationId("D")).ReturnsAsync("D001");

            var userRepository = new Mock<IOrmUserRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable())
                .Returns(new List<ORMUser> { new ORMUser { Id = 1, UserName = "TestUser" } }.BuildMock());

            _locationServiceFactory.UnitOfWork.Setup(x => x.SaveAndGetIdLocationAsync(It.IsAny<ORMLocation>()))
                .ReturnsAsync(2);
        }

        private void VerifyMocks(CreateDepartmentLocationRequest data)
        {
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMUsers.GetAll(), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.GetNextLocationId("D"), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.SaveAndGetIdLocationAsync(It.Is<ORMLocation>(l =>
                l.LocationId == "D001" &&
                l.LocationType == "D" &&
                l.Status == "Inactive" &&
                l.Department == data.Department &&
                l.LocationChangeStatus == "Pending" &&
                l.CreatedById == data.CreatedById
            )), Times.Once);
        }
    }
}