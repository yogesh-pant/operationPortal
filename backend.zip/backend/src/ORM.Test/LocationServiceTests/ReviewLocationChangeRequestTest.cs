﻿using Moq;
using Xunit;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using ORM.Application.Interfaces.Auth;
using ORM.Domain.Common;

namespace ORM.Test.LocationServiceTests
{
    public class ReviewLocationChangeRequestTest
    {
        private readonly Mock<ILogger<LocationService>> _mockLogger;
        private readonly Mock<ISessionService> _mockSessionService;
        private readonly Mock<IUnitOfWork> _mockUnitOfWork;
        private readonly LocationService _locationService;

        public ReviewLocationChangeRequestTest()
        {
            _mockLogger = new Mock<ILogger<LocationService>>();
            _mockSessionService = new Mock<ISessionService>();
            _mockUnitOfWork = new Mock<IUnitOfWork>();

            _locationService = new LocationService(
                _mockLogger.Object,
                _mockSessionService.Object,
                _mockUnitOfWork.Object);
        }



        [Fact]
        public async Task ApproveLocationChange_ShouldWork_ForBranchLocation()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };
            SetupMocks(locationType: "B");

            // Act
            var result = await _locationService.ApproveLocationChangeAsync(request);

            // Assert
            Assert.Equal("Location Update request approved and record updated successfully ", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
            VerifyMocks();
        }

        [Fact]
        public async Task ApproveLocationChange_ShouldWork_ForDepartmentLocation()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };
            SetupMocks(locationType: "D");

            // Act
            var result = await _locationService.ApproveLocationChangeAsync(request);

            // Assert
            Assert.Equal("Location Update request approved and record updated successfully ", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
            VerifyMocks();
        }

        [Fact]
        public async Task ApproveLocationChange_ShouldReturnError_WhenUserIsUnauthenticated()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };
            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationService.ApproveLocationChangeAsync(request);

            // Assert
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task ApproveLocationChange_ShouldReturnError_WhenLocationNotFound()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 999, ChangeReviewComments = "Approved" };
            SetupMocks(locationExists: false);

            // Act
            var result = await _locationService.ApproveLocationChangeAsync(request);

            // Assert
            Assert.Equal("Input location not found in Database  ", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
        }

        [Fact]
        public async Task ApproveLocationChange_ShouldReturnError_WhenChangeStatusIsNotPending()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };
            SetupMocks(changeStatus: "Approved");

            // Act
            var result = await _locationService.ApproveLocationChangeAsync(request);

            // Assert
            Assert.Equal("Location change in not Pending Review ", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task RejectLocationChange_ShouldWork_ForBranchLocation()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Rejected" };
            SetupMocks(locationType: "B");

            // Act
            var result = await _locationService.RejectLocationChangeAsync(request);

            // Assert
            Assert.Equal("Location Update request Rejected. ", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
            VerifyMocks();
        }

        [Fact]
        public async Task RejectLocationChange_ShouldWork_ForDepartmentLocation()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Rejected" };
            SetupMocks(locationType: "D");

            // Act
            var result = await _locationService.RejectLocationChangeAsync(request);

            // Assert
            Assert.Equal("Location Update request Rejected. ", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
            VerifyMocks();
        }

        [Fact]
        public async Task RejectLocationChange_ShouldReturnError_WhenUserIsUnauthenticated()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Rejected" };
            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationService.RejectLocationChangeAsync(request);

            // Assert
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task RejectLocationChange_ShouldReturnError_WhenLocationNotFound()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 999, ChangeReviewComments = "Rejected" };
            SetupMocks(locationExists: false);

            // Act
            var result = await _locationService.RejectLocationChangeAsync(request);

            // Assert
            Assert.Equal("Input location not found in Database  ", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
        }

        [Fact]
        public async Task RejectLocationChange_ShouldReturnError_WhenChangeStatusIsNotPending()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Rejected" };
            SetupMocks(changeStatus: "Approved");

            // Act
            var result = await _locationService.RejectLocationChangeAsync(request);

            // Assert
            Assert.Equal("Location change in not Pending Review ", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        private void SetupMocks(bool authenticatedUser = true, string locationType = "B", bool locationExists = true, string changeStatus = "Pending")
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestUser", "Test", "Test", null) : null;
            _mockSessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var locations = new List<ORMLocation>();
            if (locationExists)
            {
                var location = new ORMLocation
                {
                    Id = 1,
                    LocationId = "L001",
                    LocationType = locationType,
                    Branch = locationType == "B" ? "TestBranch" : null,
                    Department = locationType == "D" ? "TestDepartment" : null,
                    Region = locationType == "B" ? "TestRegion" : null,
                    Status = "Active",
                    LocationChangeStatus = changeStatus,
                    ChangeRequestData = JsonConvert.SerializeObject(
                        locationType == "B" ?
                        (object)new LocationBranchChangeData
                        {
                            NewLocationBranch = "NewBranch",
                            NewLocationRegion = "NewRegion",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        } :
                        new LocationDeptChangeData
                        {
                            NewLocationDepartment = "NewDepartment",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        })
                };
                locations.Add(location);
            }

            var mockLocationDbSet = locations.AsQueryable().BuildMockDbSet();
            _mockUnitOfWork.Setup(x => x.ORMLocation.GetAll()).Returns(mockLocationDbSet.Object);

            _mockUnitOfWork.Setup(x => x.Save()).Returns(1);
        }

        private void VerifyMocks()
        {
            _mockUnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.Once);
            _mockUnitOfWork.Verify(x => x.Save(), Times.Once);
        }
    }
}