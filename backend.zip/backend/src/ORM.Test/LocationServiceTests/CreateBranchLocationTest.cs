﻿using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ORM.Test.LocationServiceTests
{
    public class CreateBranchLocationTest
    {
        private readonly LocationServiceFactory _locationServiceFactory;

        public CreateBranchLocationTest()
        {
            _locationServiceFactory = new LocationServiceFactory();
        }

        [Fact]
        public async Task CreateBranchLocation_ShouldWork()
        {
            // Arrange
            var data = new CreateBranchLocationRequest()
            {
                Branch = "abcNew",
                SolId = "1234",
                Region = "reg1",
                CreatedById = 1
            };

            SetupMocks();

            // Act
            var result = await _locationServiceFactory.LocationService.CreateBranchLocationAsync(data);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            //Assert.Equal(2, result.Data[0].id);
            Assert.Equal("New Branch Created!", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            VerifyMocks(data);
        }

        [Fact]
        public async Task CreateBranchLocation_WithInvalidInput_ShouldReturnError()
        {
            // Arrange
            var invalidData = new CreateBranchLocationRequest()
            {
                Branch = "",
                SolId = "1234",
                Region = "reg1",
                CreatedById = 1
            };

            SetupMocks();

            // Act
            var result = await _locationServiceFactory.LocationService.CreateBranchLocationAsync(invalidData);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("invalid input", result.Description);
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }

        [Fact]
        public async Task CreateBranchLocation_WithUnauthenticatedUser_ShouldReturnError()
        {
            // Arrange
            var data = new CreateBranchLocationRequest()
            {
                Branch = "abcNew",
                SolId = "1234",
                Region = "reg1",
                CreatedById = 1
            };

            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationServiceFactory.LocationService.CreateBranchLocationAsync(data);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task CreateBranchLocation_WithExistingBranchName_ShouldReturnError()
        {
            // Arrange
            var data = new CreateBranchLocationRequest()
            {
                Branch = "existingBranch",
                SolId = "1234",
                Region = "reg1",
                CreatedById = 1
            };

            SetupMocks(existingBranch: true);

            // Act
            var result = await _locationServiceFactory.LocationService.CreateBranchLocationAsync(data);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Input Branch Name already exists in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        [Fact]
        public async Task CreateBranchLocation_WithExistingSolId_ShouldReturnError()
        {
            // Arrange
            var data = new CreateBranchLocationRequest()
            {
                Branch = "newBranch",
                SolId = "existingSolId",
                Region = "reg1",
                CreatedById = 1
            };

            SetupMocks(existingSolId: true);

            // Act
            var result = await _locationServiceFactory.LocationService.CreateBranchLocationAsync(data);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("A branch with input SolId already exists in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        private void SetupMocks(bool authenticatedUser = true, bool existingBranch = false, bool existingSolId = false)
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null) : null;
            _locationServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var locRepository = new Mock<IOrmLocationRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(locRepository.Object);

            var existingLocations = new List<ORMLocation>();
            if (existingBranch)
                existingLocations.Add(new ORMLocation { Branch = "existingBranch" });
            if (existingSolId)
                existingLocations.Add(new ORMLocation { SolId = "existingSolId" });

            locRepository.Setup(repo => repo.GetAll().AsQueryable())
                .Returns(existingLocations.BuildMock());

            _locationServiceFactory.UnitOfWork.Setup(x => x.GetNextLocationId("B")).ReturnsAsync("B001");

            var userRepository = new Mock<IOrmUserRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable())
                .Returns(new List<ORMUser> { new ORMUser { Id = 1, UserName = "TestUser" } }.BuildMock());

            _locationServiceFactory.UnitOfWork.Setup(x => x.SaveAndGetIdLocationAsync(It.IsAny<ORMLocation>()))
                .ReturnsAsync(2);
        }

        private void VerifyMocks(CreateBranchLocationRequest data)
        {
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.Exactly(2));
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMUsers.GetAll(), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.GetNextLocationId("B"), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.SaveAndGetIdLocationAsync(It.Is<ORMLocation>(l =>
                l.LocationId == "B001" &&
                l.LocationType == "B" &&
                l.Status == "Inactive" &&
                l.SolId == data.SolId &&
                l.Branch == data.Branch &&
                l.Region == data.Region &&
                l.LocationChangeStatus == "Pending" &&
                l.CreatedById == data.CreatedById
            )), Times.Once);
        }
    }
}