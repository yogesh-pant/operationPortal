﻿using Microsoft.Extensions.Logging;
using Moq;
using ORM.Application.Interfaces.Auth;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.LocationServiceTests
{
    public class LocationServiceFactory
    {
        public Mock<IUnitOfWork> UnitOfWork = new();
        public Mock<ISessionService> SessionService = new();
        public Mock<ILogger<LocationService>> Logger = new();
        public Mock<IOrmLocationRepository> ORMLocationRepository = new(); 

        public LocationService LocationService { get; set; }

        public LocationServiceFactory()
        {
            LocationService = new LocationService
            (
                Logger.Object,
                SessionService.Object,
                UnitOfWork.Object
            );

        }



    }
}
