﻿using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using ORM.Infrastructure.Repositories;

namespace ORM.Test.LocationServiceTests
{
    public class UpdateDepartmentLocationTest
    {
        private readonly LocationServiceFactory _locationServiceFactory;

        public UpdateDepartmentLocationTest()
        {
            _locationServiceFactory = new LocationServiceFactory();
        }

        [Fact]
        public async Task UpdateDepartmentLocation_ShouldWork()
        {
            // Arrange
            var input = new UpdateDepartmentLocationRequest
            {
                id = 1,
                Department = "UpdatedDepartment",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: true);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateDepartmentLocationAsync(input);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            //Assert.Equal(1, result.Data[0].id);
            Assert.Equal("Successfully Submitted Update Request for Department", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            VerifyMocks(input);
        }

        [Fact]
        public async Task UpdateDepartmentLocation_WithUnauthenticatedUser_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateDepartmentLocationRequest
            {
                id = 1,
                Department = "UpdatedDepartment",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(authenticatedUser: false);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateDepartmentLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task UpdateDepartmentLocation_WithExistingDepartmentName_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateDepartmentLocationRequest
            {
                id = 1,
                Department = "ExistingDepartment",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: true, existingDepartmentName: true);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateDepartmentLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Input Department Name already exists in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        [Fact]
        public async Task UpdateDepartmentLocation_WithNonExistentLocation_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateDepartmentLocationRequest
            {
                id = 999,
                Department = "UpdatedDepartment",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: false);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateDepartmentLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("Location not found for Department id in ORM Database!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        [Fact]
        public async Task UpdateDepartmentLocation_WithNoChanges_ShouldReturnError()
        {
            // Arrange
            var input = new UpdateDepartmentLocationRequest
            {
                id = 1,
                Department = "ExistingDepartment",
                Status = "Active",
                ModifiedById = 1
            };

            SetupMocks(existingLocation: true, noChanges: true);

            // Act
            var result = await _locationServiceFactory.LocationService.UpdateDepartmentLocationAsync(input);

            // Assert
            Assert.Null(result.Data);
            Assert.Equal("No changes made in Department data!", result.Description);
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        private void SetupMocks(bool authenticatedUser = true, bool existingLocation = true, bool existingDepartmentName = false, bool noChanges = false)
        {
            var staffSession = authenticatedUser ? new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null) : null;
            _locationServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(staffSession);

            var locRepository = new Mock<IOrmLocationRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(locRepository.Object);

            var existingLocations = new List<ORMLocation>();
            if (existingLocation)
            {
                existingLocations.Add(new ORMLocation
                {
                    Id = 1,
                    LocationType = "D",
                    Department = noChanges ? "ExistingDepartment" : "OldDepartment",
                    Status = noChanges ? "Active" : "Inactive"
                });
            }
            if (existingDepartmentName)
            {
                existingLocations.Add(new ORMLocation { Id = 2, LocationType = "D", Department = "ExistingDepartment" });
            }

            var mockDbSet = existingLocations.AsQueryable().BuildMockDbSet();

            locRepository.Setup(repo => repo.GetAll()).Returns(mockDbSet.Object);

            var userRepository = new Mock<IOrmUserRepository>();
            _locationServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable())
                .Returns(new List<ORMUser> { new ORMUser { Id = 1, UserName = "TestUser" } }.AsQueryable().BuildMockDbSet().Object);

            _locationServiceFactory.UnitOfWork.Setup(x => x.Save()).Returns(1);
        }

        private void VerifyMocks(UpdateDepartmentLocationRequest input)
        {
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMLocation.GetAll(), Times.Exactly(2));
            _locationServiceFactory.UnitOfWork.Verify(x => x.ORMUsers.GetAll(), Times.Once);
            _locationServiceFactory.UnitOfWork.Verify(x => x.Save(), Times.Once);
        }
    }
}