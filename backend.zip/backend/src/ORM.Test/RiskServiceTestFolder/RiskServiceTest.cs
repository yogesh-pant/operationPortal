﻿using Azure;
using Fcmb.Shared.Models.Responses;
using Microsoft.AspNetCore.Http;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Common;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using ORM.Test.Lossservicetestsfolder;
using ORM.Test.UserServiceTests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ORM.Test.RiskServiceTestFolder
{
    public class RiskServiceTest
    {
        [Fact]
        public async Task GetRiskGridAsync_UserUnAuthenticated_ReturnUserUnathenticatedResponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = new FilterRiskListRequest();

            //Act
            var response = await riskService.GetRiskGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task GetRiskGridAsync_EmptyInput_ReturnEmptyInputResponse()
        {
            var session = LossServiceTests.MockSessionService();

            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            var riskService = new RiskService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            var input = (FilterRiskListRequest?)null;

            //Act
            var response = await riskService.GetRiskGridAsync(input!);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Invalid input", response.Description);
            Assert.Equal(ResponseCodes.DataNotFound, response.Code);

        }
        [Theory]

        [InlineData("ReturnData")]     // GetRiskGridAsync returns data  
        [InlineData("ReturnNoData")]   // GetRiskGridAsync returns no data due to applied Filter
        public async Task GetRiskGridAsync_ValidRequest_ReturnSucessfulResponse( string ExpectedResult)
        {
            var session = LossServiceTests.MockSessionService();
            
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            var riskService = new RiskService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            var data = GenerateORMRiskReportMockData();

            mockUnitOfWork.Setup(uow => uow.ORMRiskReport.GetAll().AsQueryable())
                        .Returns(data.BuildMock()); // Simulating that a Risk report with the given ID exists

            var ORMLocationVM = GenerateORMLocationMockDataList();
            mockUnitOfWork.Setup(repo => repo.ORMLocation.GetAll().AsQueryable())
                .Returns(ORMLocationVM.BuildMock());

            var usersVm = GenerateORMUserMockDataList();
            mockUnitOfWork.Setup(repo => repo.ORMUsers.GetAll().AsQueryable()).Returns(usersVm.BuildMock());

         
            var input = GenerateFilterRiskListRequestMockData();
            if (ExpectedResult == "ReturnNoData")
            {
                input.LocationType = "H"; // change value so that search returns no data

            };


            //Act
            var result = await riskService.GetRiskGridAsync(input);

            //Assert
            if (ExpectedResult == "ReturnData")
            {
                Assert.NotNull(result.Data);
                Assert.NotEqual(0, result.Total);
                Assert.Equal("Successfully Retrieved Risk grid data", result.Description);
            }
            if (ExpectedResult == "ReturnNoData")
            {
                Assert.Null(result.Data);
                Assert.Equal(0, result.Total);
                Assert.Equal("No record found for given input", result.Description);
            }
        }

        [Fact]
        public async Task CreateRiskDataAsync_UserUnAuthenticated_ReturnUserUnathenticatedResponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = new CreateRiskDataRequest();

            //Act
            var response = await riskService.CreateRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task CreateRiskDataAsync_ValidResponse_ReturnSucessfulResponse()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();


            var input = CreateRiskDataRequestMockData();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            

            //Act
            var response = await riskService.CreateRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Risk Report Created!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }

         [Fact]
        public async Task EditRiskDataAsync_UserUnAuthenticated_ReturnUserUnathenticatedResponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = new EditRiskDataRequest();

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task EditRiskDataAsync_ValidResponse_ReturnSucessfulResponse()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var riskRepository = new Mock<IOrmRiskRepository>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            mockUnitOfWork.Setup(x => x.ORMRiskReport).Returns(riskRepository.Object);
            riskRepository.Setup(x => x.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>() { new ORMRiskReport { Id = 1 } }.BuildMock());

            var input = EditRiskDataRequestMockData();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }

        [Fact]
        public async Task EditRiskDataAsync_ValidResponse_ReturnSucessfulResponse_CalculateRiskRating()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var riskRepository = new Mock<IOrmRiskRepository>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            mockUnitOfWork.Setup(x => x.ORMRiskReport).Returns(riskRepository.Object);
            riskRepository.Setup(x => x.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>() { new ORMRiskReport { Id = 1 } }.BuildMock());

            var input = EditRiskDataRequestMockData();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }

        [Fact]
        public async Task EditRiskDataAsync_ValidResponse_ReturnSucessfulResponse_Possible_Monthly()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var riskRepository = new Mock<IOrmRiskRepository>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            mockUnitOfWork.Setup(x => x.ORMRiskReport).Returns(riskRepository.Object);
            riskRepository.Setup(x => x.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>() { new ORMRiskReport { Id = 1 } }.BuildMock());

            var input = EditRiskDataRequestMockData_Possible_Monthly();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }

        [Fact]
        public async Task EditRiskDataAsync_ValidResponse_ReturnSucessfulResponse_UnlikelyQuarterly()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var riskRepository = new Mock<IOrmRiskRepository>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            mockUnitOfWork.Setup(x => x.ORMRiskReport).Returns(riskRepository.Object);
            riskRepository.Setup(x => x.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>() { new ORMRiskReport { Id = 1 } }.BuildMock());

            var input = EditRiskDataRequestMockData_Unlikely_Quarterly();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);

            input.RiskControlDesign = "Semi-Automated";
            input.RiskControlType = "Detective";

            //Act
            var response2 = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response2);
            Assert.Equal(ResponseCodes.Success, response2.Code);

            input.RiskControlDesign = "Automated";
            input.RiskControlType = "Corrective";

            //Act
            var response3 = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response3);
            Assert.Equal(ResponseCodes.Success, response3.Code);

        }

        [Fact]
        public async Task EditRiskDataAsync_ValidResponse_ReturnSucessfulResponse_Very_Rare_Annually()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var riskRepository = new Mock<IOrmRiskRepository>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            mockUnitOfWork.Setup(x => x.ORMRiskReport).Returns(riskRepository.Object);
            riskRepository.Setup(x => x.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>() { new ORMRiskReport { Id = 1 } }.BuildMock());

            var input = EditRiskDataRequestMockData_Very_Rare_Annually();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);

            input.RiskControlDesign = "Manual";
            input.RiskControlType = "Detective";

            var response2 = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response2);
            Assert.Equal(ResponseCodes.Success, response2.Code);

            input.RiskControlType = "Preventive";

            var response3 = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response3);
            Assert.Equal(ResponseCodes.Success, response3.Code);
            
            input.RiskControlType = "";

            var response4 = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response4);
            Assert.Equal(ResponseCodes.Success, response4.Code);

        }

        [Fact]
        public async Task EditRiskDataAsync_ValidResponse_ReturnSucessfulResponse_SeverityValue()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var riskRepository = new Mock<IOrmRiskRepository>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            mockUnitOfWork.Setup(x => x.ORMRiskReport).Returns(riskRepository.Object);
            riskRepository.Setup(x => x.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>() { new ORMRiskReport { Id = 1 } }.BuildMock());

            var input = EditRiskDataRequestMockData_SeverityValue();

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);

            //Act
            var response = await riskService.EditRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);

            input.RiskControlDesign = "Automated";
            input.RiskControlType = "Preventive";
            var response2 = await riskService.EditRiskDataAsync(input);

            Assert.NotNull(response2);
            Assert.Equal(ResponseCodes.Success, response2.Code);

            input.RiskControlDesign = "Automated";
            input.RiskControlType = "";
            var response3 = await riskService.EditRiskDataAsync(input);

            Assert.NotNull(response3);
            Assert.Equal(ResponseCodes.Success, response3.Code);


            input.RiskControlDesign = "Semi-Automated";
            input.RiskControlType = "Preventive";
            var response4 = await riskService.EditRiskDataAsync(input);

            Assert.NotNull(response4);
            Assert.Equal(ResponseCodes.Success, response4.Code);

            input.RiskControlDesign = "Semi-Automated";
            input.RiskControlType = "";
            var response5 = await riskService.EditRiskDataAsync(input);

            Assert.NotNull(response5);
            Assert.Equal(ResponseCodes.Success, response5.Code);

        }

        [Fact]
        public async Task GetRiskReportDoc_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            var data = GenerateORMRiskReportMockData();
            mockUnitOfWork.Setup(uow => uow.ORMRiskReport.GetAll().AsQueryable())
                      .Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists


            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = new GetDocRequest() { Id = 1};

            //Act
            var response = await riskService.GetRiskReportDoc(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved Risk Data for one id", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

            input.Id = 2;
            //Act
            var response2 = await riskService.GetRiskReportDoc(input);

            //Assert
            Assert.NotNull(response);
        }

        [Fact]
        public async Task UpdateRiskDataAsync_UserUnAuthenticated_ReturnUserUnathenticatedResponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = new UpdateRiskDataRequest();

            //Act
            var response = await riskService.UpdateRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task UpdateRiskDataAsync_ValidRequest_ReturnSuccessfulResponse()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            var data = GenerateORMRiskReportMockData();
            mockUnitOfWork.Setup(uow => uow.ORMRiskReport.GetAll().AsQueryable())
                      .Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = UpdateRiskDataRequestMockData();

            //Act
            var response = await riskService.UpdateRiskDataAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Risk Report Updated!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);



        }


          [Fact]
        public async Task UpdateRiskStatusAsync_UserUnAuthenticated_ReturnUserUnathenticatedResponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = new UpdateRiskStatusRequest();

            //Act
            var response = await riskService.UpdateRiskStatusAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task UpdateRiskStatusAsync_ValidRequest_ReturnSuccessfulResponse()
        {
            //Arrange
            var sessionObj = new LossServiceTests();
            var mockSessionService = LossServiceTests.MockSessionService();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();

            var data = GenerateORMRiskReportMockData();
            mockUnitOfWork.Setup(uow => uow.ORMRiskReport.GetAll().AsQueryable())
                      .Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists

            var riskService = new RiskService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object);
            var input = UpdateRiskStatusRequestMockData();

            //Act
            var response = await riskService.UpdateRiskStatusAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Risk Report Status Updated!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);



        }



        public static FilterRiskListRequest GenerateFilterRiskListRequestMockData()
        {
            return new FilterRiskListRequest
            {
                Id = 1,
                RefNum = "RiskRP-202202-B0001-NN",
                LocationType = "B",
                LocationId = 123,
                minDate = DateTime.Now.AddDays(-60),
                maxDate = DateTime.Now.AddDays(-60),
                ReportStatus = "Saved"
        };
        }
        
        public static List<ORMRiskReport> GenerateORMRiskReportMockData()
        {
            return new List<ORMRiskReport>
            {
                new ORMRiskReport 
                {
                    Id = 1,
                    RefNum = "RiskRP-202202-B0001-NN",
                    LocationType = "B",
                    LocationId = 123,
                    ValidatorUserId = 1,
                    ProcessName = "Sample Process",
                    SubProcessName = "Sample Subprocess",
                    InherentThreatRisk = "Sample Inherent Threat Risk",
                    FrequencyOfOccurance = "Sample Frequency",
                    RiskClassification = "Sample Classification",
                    RiskRootCause = "Sample Root Cause",
                    RiskSeverity = "High",
                    RiskDirection = "Down",
                    ImplementedControls = "Sample Controls",
                    RiskControlDesign = "Sample Control Design",
                    RiskControlType = "Sample Control Type",
                    RiskControlEffectiveness = "Effective",
                    RiskResidual = "Sample Residual Risk",
                    RiskResponsibility = "Sample Responsibility",
                    RiskCategory = "Category A",
                    RiskResidualRating = "Low",
                    RiskActionPlan = "Sample Action Plan",
                    RiskActionPlanStatus = "In Progress",
                    RiskExpectedResolutionTime = DateTime.Now.AddDays(30),
                    RiskStrategy = "Sample Strategy",
                    ReportStatus = "Saved",
                    RiskControlAssessment = "Assessment",
                    RiskControlQuality = "Good",
                    RiskRating = "Low",
                    ReviewerComments = "Sample Reviewer Comments",
                    CreatedById = 1,
                    ModifiedById = 1,
                    ValidatedById = 1,
                    ApprovedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-60),
                    ModifiedDate = DateTime.Now.AddDays(-30),
                    ValidationDate = DateTime.Now.AddDays(-10),
                    ApprovedDate = DateTime.Now.AddDays(-10),
                    DocumentName = "Docs",
                    UpdateRequestStatus = "Pending"
                }
            };
        }

        public static List<ORMLocation> GenerateORMLocationMockDataList()
        {
            var mockDataList = new List<ORMLocation>();

            // Generate multiple instances of ORMLocation with different values
            for (int i = 1; i <= 2; i++)
            {
                mockDataList.Add(new ORMLocation
                {
                    Id = 123, // Sample ID value
                    LocationId = "123", // Sample location ID value
                    LocationType = "B", // Sample location type value
                    SolId = $"{i}", // Sample SolId value
                    Branch = $"Branch {i}", // Sample branch value
                    Region = $"Region {i}", // Sample region value
                    Department = $"Department {i}", // Sample department value
                    Status = "Active", // Sample status value
                    CreatedById = i, // Sample created by ID value
                    ModifiedById = i, // Sample modified by ID value
                    CreatedDate = DateTime.Now.AddDays(-i), // Sample created date value
                    ModifiedDate = DateTime.Now.AddDays(-i - 1) // Sample modified date value
                });
            }

            return mockDataList;
        }


        public static List<ORMUser> GenerateORMUserMockDataList()
        {
            var mockDataList = new List<ORMUser>();

            // Generate multiple instances of ORMUser with different values
            for (int i = 1; i <= 2; i++)
            {
                mockDataList.Add(new ORMUser
                {
                    Id = 1, // Sample ID value
                    UserName = $"TestUser_{i}", // Sample user name value
                    Email = $"user{i}@example.com", // Sample email value
                    StaffId = $"S123{i}", // Sample staff ID value
                    Status = "Active", // Sample status value
                    RoleId = i, // Sample role ID value
                    FailedLoginCount = $"{i}", // Sample failed login count value
                    LastLoginTime = DateTime.Now.AddDays(-i), // Sample last login time value
                    CurrentLoginTime = DateTime.Now // Sample current login time value
                });
            }

            return mockDataList;
        }

        public static EditRiskDataRequest EditRiskDataRequestMockData()
        {
            return new EditRiskDataRequest
            {
                Id = 1, // Sample ID
                ValidatorUserId = 123, // Sample validator user ID
                ProcessName = "Sample Process", // Sample process name
                SubProcessName = "Sample Sub-process", // Sample sub-process name
                InherentThreatRisk = "Sample threat risk", // Sample inherent threat risk
                FrequencyOfOccurance = "Likely/Weekly", // Sample frequency of occurrence
                RiskSeverity = "Major", // Sample risk severity
                RiskDirection = "Sample direction", // Sample risk direction
                ImplementedControls = "Sample controls", // Sample implemented controls
                RiskControlDesign = "Automated", // Sample risk control design
                RiskControlType = "Detective", // Sample risk control type
                RiskResidual = "Sample residual risk", // Sample residual risk
                RiskResponsibility = "Sample responsibility", // Sample risk responsibility
                RiskActionPlan = "Sample action plan", // Sample risk action plan
                ReportStatus = "Draft", // Sample report status
                ModifiedById = 456, // Sample modified by user ID
                RiskDocuments = MockDocumentVm(), // Sample risk documents (if needed)
                Documentname = "SampleDocument.pdf" // Sample document name
            };
        }
         public static EditRiskDataRequest EditRiskDataRequestMockData_Possible_Monthly()
        {
            return new EditRiskDataRequest
            {
                Id = 1, // Sample ID
                ValidatorUserId = 123, // Sample validator user ID
                ProcessName = "Sample Process", // Sample process name
                SubProcessName = "Sample Sub-process", // Sample sub-process name
                InherentThreatRisk = "Sample threat risk", // Sample inherent threat risk
                FrequencyOfOccurance = "Possible/Monthly", // Sample frequency of occurrence
                RiskSeverity = "Moderate", // Sample risk severity
                RiskDirection = "Sample direction", // Sample risk direction
                ImplementedControls = "Sample controls", // Sample implemented controls
                RiskControlDesign = "Semi-Automated", // Sample risk control design
                RiskControlType = "Corrective", // Sample risk control type
                RiskResidual = "Sample residual risk", // Sample residual risk
                RiskResponsibility = "Sample responsibility", // Sample risk responsibility
                RiskActionPlan = "Sample action plan", // Sample risk action plan
                ReportStatus = "Draft", // Sample report status
                ModifiedById = 456, // Sample modified by user ID
                RiskDocuments = MockDocumentVm(), // Sample risk documents (if needed)
                Documentname = "SampleDocument.pdf" // Sample document name
            };
        }

        public static EditRiskDataRequest EditRiskDataRequestMockData_Unlikely_Quarterly()
        {
            return new EditRiskDataRequest
            {
                Id = 1, // Sample ID
                ValidatorUserId = 123, // Sample validator user ID
                ProcessName = "Sample Process", // Sample process name
                SubProcessName = "Sample Sub-process", // Sample sub-process name
                InherentThreatRisk = "Sample threat risk", // Sample inherent threat risk
                FrequencyOfOccurance = "Unlikely/Quarterly", // Sample frequency of occurrence
                RiskSeverity = "Minor", // Sample risk severity
                RiskDirection = "Sample direction", // Sample risk direction
                ImplementedControls = "Sample controls", // Sample implemented controls
                RiskControlDesign = "Sample control design", // Sample risk control design
                RiskControlType = "Sample control type", // Sample risk control type
                RiskResidual = "Sample residual risk", // Sample residual risk
                RiskResponsibility = "Sample responsibility", // Sample risk responsibility
                RiskActionPlan = "Sample action plan", // Sample risk action plan
                ReportStatus = "Draft", // Sample report status
                ModifiedById = 456, // Sample modified by user ID
                RiskDocuments = MockDocumentVm(), // Sample risk documents (if needed)
                Documentname = "SampleDocument.pdf" // Sample document name
            };
        }
        
        public static EditRiskDataRequest EditRiskDataRequestMockData_Very_Rare_Annually()
        {
            return new EditRiskDataRequest
            {
                Id = 1, // Sample ID
                ValidatorUserId = 123, // Sample validator user ID
                ProcessName = "Sample Process", // Sample process name
                SubProcessName = "Sample Sub-process", // Sample sub-process name
                InherentThreatRisk = "Sample threat risk", // Sample inherent threat risk
                FrequencyOfOccurance = "Very Rare/Annually", // Sample frequency of occurrence
                RiskSeverity = "Insignificant", // Sample risk severity
                RiskDirection = "Sample direction", // Sample risk direction
                ImplementedControls = "Sample controls", // Sample implemented controls
                RiskControlDesign = "Sample control design", // Sample risk control design
                RiskControlType = "Sample control type", // Sample risk control type
                RiskResidual = "Sample residual risk", // Sample residual risk
                RiskResponsibility = "Sample responsibility", // Sample risk responsibility
                RiskActionPlan = "Sample action plan", // Sample risk action plan
                ReportStatus = "Draft", // Sample report status
                ModifiedById = 456, // Sample modified by user ID
                RiskDocuments = MockDocumentVm(), // Sample risk documents (if needed)
                Documentname = "SampleDocument.pdf" // Sample document name
            };
        }

         public static EditRiskDataRequest EditRiskDataRequestMockData_SeverityValue()
        {
            return new EditRiskDataRequest
            {
                Id = 1, // Sample ID
                ValidatorUserId = 123, // Sample validator user ID
                ProcessName = "Sample Process", // Sample process name
                SubProcessName = "Sample Sub-process", // Sample sub-process name
                InherentThreatRisk = "Sample threat risk", // Sample inherent threat risk
                FrequencyOfOccurance = "Rare/Annually", // Sample frequency of occurrence
                RiskSeverity = "", // Sample risk severity
                RiskDirection = "Sample direction", // Sample risk direction
                ImplementedControls = "Sample controls", // Sample implemented controls
                RiskControlDesign = "Sample control design", // Sample risk control design
                RiskControlType = "Sample control type", // Sample risk control type
                RiskResidual = "Sample residual risk", // Sample residual risk
                RiskResponsibility = "Sample responsibility", // Sample risk responsibility
                RiskActionPlan = "Sample action plan", // Sample risk action plan
                ReportStatus = "Draft", // Sample report status
                ModifiedById = 456, // Sample modified by user ID
                RiskDocuments = MockDocumentVm(), // Sample risk documents (if needed)
                Documentname = "SampleDocument.pdf" // Sample document name
            };
        }


        public static List<IFormFile> MockDocumentVm()
        {
            // Create a list to hold mock IFormFile objects
            List<IFormFile> riskDocuments = new List<IFormFile>();

            // Add mock IFormFile objects to the list
            riskDocuments.Add(new FormFile(null!, 0, 0, "Document1", "document1.pdf"));
            riskDocuments.Add(new FormFile(null!, 0, 0, "Document2", "document2.docx"));
            riskDocuments.Add(new FormFile(null!, 0, 0, "Document3", "document3.txt"));

            // Create an instance of EditRiskDataRequest and assign the mock list to RiskDocuments
            //var editRiskDataRequest = new EditRiskDataRequest
            //{
            //    Id = 1, // Sample ID
            //            // Assign the mock list to RiskDocuments
            //    RiskDocuments = riskDocuments
            //};

            return riskDocuments;
        }


        public static CreateRiskDataRequest CreateRiskDataRequestMockData()
        {
            // Create a list to hold mock IFormFile objects
            List<IFormFile> riskDocuments = new List<IFormFile>();

            // Add mock IFormFile objects to the list
            riskDocuments.Add(new FormFile(null!, 0, 0, "Document1", "document1.pdf"));
            riskDocuments.Add(new FormFile(null!, 0, 0, "Document2", "document2.docx"));
            riskDocuments.Add(new FormFile(null!, 0, 0, "Document3", "document3.txt"));

            // Create an instance of CreateRiskDataRequest and assign the mock list to RiskDocuments
            var createRiskDataRequest = new CreateRiskDataRequest
            {
                LocationType = "Branch",
                LocationId = 123,
                ValidatorUserId = 456,
                ProcessName = "Sample Process",
                SubProcessName = "Sample Subprocess",
                InherentThreatRisk = "Sample threat",
                FrequencyOfOccurance = "Certainly/Daily",
                RiskSeverity = "Significant",
                RiskDirection = "Upward",
                ImplementedControls = "Sample controls",
                RiskControlDesign = "Design A",
                RiskControlType = "Type X",
                RiskResidual = "Residual risk",
                RiskResponsibility = "Team A",
                RiskActionPlan = "Action plan details",
                ReportStatus = "Draft",
                CreatedById = 789,
                // Assign the mock list to RiskDocuments
                RiskDocuments = riskDocuments,
                Documentname = "Sample Document"
            };

            return createRiskDataRequest;
        }

        public static UpdateRiskDataRequest UpdateRiskDataRequestMockData()
        {
            var updateRiskDataRequest = new UpdateRiskDataRequest
            {
                Id = 1,
                RiskClassification = "High",
                RiskCategory = "Category A",
                RiskRootCause = "Root cause details",
                RiskActionPlanStatus = "In progress",
                RiskExpectedResolutionTime = DateTime.Now.AddDays(30), // Set to 30 days from now
                RiskStrategy = "Strategy details",
                ReportStatus = "Updated",
                ModifiedById = 789
            };

            return updateRiskDataRequest;
        }

        public static UpdateRiskStatusRequest UpdateRiskStatusRequestMockData()
        {
            var updateRiskStatusRequest = new UpdateRiskStatusRequest
            {
                Id = 1,
                UpdateRequestStatus = "Approved",
                ReviewerComments = "This risk update request has been approved.",
                ReportStatus = "Updated",
                ModifiedById = 789
            };

            return updateRiskStatusRequest;
        }
    }
}
