﻿using Fcmb.Shared.Utilities;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Domain.Common;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Test.KRIMasterServiceTests;

namespace ORM.Test.KriMasterTests
{
    public class GetKriMasterGridTests
    {
        private readonly KRIMasterServiceFactory _krimasterServiceFactory;

        public GetKriMasterGridTests()
        {
            _krimasterServiceFactory = new KRIMasterServiceFactory();

        }

        [Theory]
        [InlineData(1,"SessionNull")]   // Session Null - Failed with User Unauthenticaled  
        [InlineData(2,"NoRecordFound")]   // No Record found for given filters (Locationid)- Failed Validation 
        [InlineData(1,"RecordFound")]  // Records found successfully 
        public async Task GetKriMasterGrid_ShouldWork(long LocationId,string ExpectedResult)
        {
            //Arrange
            var data = new GetKriMasterGridRequest
            {
                LocationId = LocationId,
                LocationName = "Lagos",
                LocationType = "B",
                MetricName = "Compliance",
                Frequency = "Monthly",
                IsActive = true
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            if (ExpectedResult == "SessionNull")
            {
                _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            };
            

            //
            // Set up Location Data 
            //
            var mockLocationRepository = new Mock<IOrmLocationRepository>();

            var ORMBranchLocationData = new List<ORMLocation>
            {
                new ORMLocation
                {
                    Id = 1,
                    LocationId = "B0001" ,
                    LocationType = "B",
                    SolId = "267",
                    Branch = "Lagos",
                    Region = "Central",
                    Department = "Risk",
                    Status  = "Active"!,
                    CreatedById = 1,
                    ModifiedById  = 1,
                    CreatedDate =DateTime.Now,
                    ModifiedDate = DateTime.Now
                }
            };
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            mockLocationRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(ORMBranchLocationData.BuildMock());

            //
            // Set up User Data 
            //
            var MockUserRepository = new Mock<IOrmUserRepository>();

            var ORMUserData = new List<ORMUser>
            {
                new ORMUser
                {
                    Id = 1,
                    UserName = "TestUser" ,
                    StaffId = "eweB",
                    Email = "TestUser@fcmb.com",
                    Status = "Active",
                    RoleId = 1,
                    FailedLoginCount = "Risk",
                    LastLoginTime  = DateTime.Now,
                    CurrentLoginTime = DateTime.Now,
                }
            };
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(MockUserRepository.Object);
            MockUserRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(ORMUserData.BuildMock());
            //
            // Set up KRI Metric Master Data 
            //

            var MockKriReportMetricMasterRepository = new Mock<IKriReportMetricMasterRepository>();

            var ORMKRIMetricMasterData = new List<ORMKRIMetricMaster>
            {
                new ORMKRIMetricMaster
                {
                    Id = 1,
                    KRIMetricId = "KRI01",
                    LocationId = 1,
                    LocationType = "B",
                    MetricName = "Compliance",
                    Frequency= "Monthly" ,
                    AppetiteLowerBound = "",
                    AppetiteUpperBound  = "",
                    AppetiteType = "N",
                    ToleranceLowerBound  = "",
                    ToleranceUpperBound  = "",
                    ToleranceType = "N",
                    EscalationLowerBound = "B",
                    EscalationUpperBound    = "B",
                    EscalationType = "N",
                    IsActive = true,
                    Status = "Active",
                    ReviewerComments ="",
                    CreatedById =1,
                    ModifiedById = 1,
                    ApprovedById =1,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now,
                    ApprovedDate = DateTime.Now,
                }
            };
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(MockKriReportMetricMasterRepository.Object);
            MockKriReportMetricMasterRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(ORMKRIMetricMasterData.BuildMock());

            //_krimasterServiceFactory.AuthService.Setup(x => x.GetUserAdFullDetailsWLoginName(RequestUserName)).ReturnsAsync(result);

            //Act

            var result = await _krimasterServiceFactory.KRIMasterService.GetKriMasterGridAsync(data);

            //Assert
            if (ExpectedResult == "RecordFound")
            {
                Assert.NotNull(result.Data);
                Assert.Equal("Successfully Retrieved KRI master data", result.Description);
            }
            if (ExpectedResult == "NoRecordFound")
            {
                Assert.Null(result.Data);
                Assert.Equal("No record found for given input", result.Description);
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            }
            if (ExpectedResult == "SessionNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("User Is Unauthenticated", result.Description);
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
            }
        }



        [Fact]
        public async Task GetKriMasterGrid_WithChangeRequestData_ShouldExtractCorrectly()
        {
            // Arrange
            var data = new GetKriMasterGridRequest
            {
                LocationId = 1,
                LocationName = "Lagos",
                LocationType = "D",
                MetricName = "Compliance",
                Frequency = "Monthly",
                IsActive = true
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestUser", "TestValue349530768", "TestValue1835299848", null));

            var mockKriReportMetricMasterRepository = new Mock<IKriReportMetricMasterRepository>();
            var changeRequestData = new KRIMasterChangeData
            {
                MetricNewName = "Updated Compliance",
                MetricNewFrequency = "Quarterly",
                KRIMasterNewFlag = "No",
                MetricNewActivationStatus = true,
                MetricNewAppetiteLowerBound = "10",
                MetricNewAppetiteUpperBound = "90",
                MetricNewAppetiteType = "Range",
                MetricNewToleranceLowerBound = "5",
                MetricNewToleranceUpperBound = "95",
                MetricNewToleranceType = "Range",
                MetricNewEscalationLowerBound = "0",
                MetricNewEscalationUpperBound = "100",
                MetricNewEscalationType = "Range",
                MetricNewUpdatedByName = "John Doe",
                MetricNewChangeRequestDate = DateTime.Now
            };

            var ORMKRIMetricMasterData = new List<ORMKRIMetricMaster>
            {
                new ORMKRIMetricMaster
                {
                    Id = 1,
                    KRIMetricId = "KRI01",
                    LocationId = 1,
                    LocationType = "D",
                    MetricName = "Compliance",
                    Frequency = "Monthly",
                    AppetiteLowerBound = "20",
                    AppetiteUpperBound = "80",
                    AppetiteType = "Range",
                    ToleranceLowerBound = "10",
                    ToleranceUpperBound = "90",
                    ToleranceType = "Range",
                    EscalationLowerBound = "0",
                    EscalationUpperBound = "100",
                    EscalationType = "Range",
                    IsActive = true,
                    Status = "Pending",
                    ChangeRequestData = JsonConvert.SerializeObject(changeRequestData),
                    CreatedById = 1,
                    ModifiedById = 2,
                    ApprovedById = 3,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-15),
                    ApprovedDate = DateTime.Now.AddDays(-10),
                }
            };

            var mockKRIMetricMasterDbSet = ORMKRIMetricMasterData.AsQueryable().BuildMockDbSet();

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(mockKriReportMetricMasterRepository.Object);
            mockKriReportMetricMasterRepository.Setup(repo => repo.GetAll()).Returns(mockKRIMetricMasterDbSet.Object);

            // Mock other repositories
            var mockLocationRepository = new Mock<IOrmLocationRepository>();
            var mockUserRepository = new Mock<IOrmUserRepository>();

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object); 
            
            var mockLocationData = new List<ORMLocation>
            {
                new ORMLocation { Id = 1, Department = "Lagos" }
            };
            var mockLocationDbSet = mockLocationData.AsQueryable().BuildMockDbSet();

            var mockUserData = new List<ORMUser>
            {
                new ORMUser { Id = 1, UserName = "User1" },
                new ORMUser { Id = 2, UserName = "User2" },
                new ORMUser { Id = 3, UserName = "User3" }
            };
            var mockUserDbSet = mockUserData.AsQueryable().BuildMockDbSet();

            mockLocationRepository.Setup(repo => repo.GetAll()).Returns(mockLocationDbSet.Object);
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.GetKriMasterGridAsync(data);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            var kriMasterData = result.Data.First();

            Assert.Equal("Successfully Retrieved KRI master data", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            Assert.NotNull(kriMasterData.ChangeRequestData);
            Assert.Equal("Updated Compliance", kriMasterData.ChangeRequestData.MetricNewName);
            Assert.Equal("Quarterly", kriMasterData.ChangeRequestData.MetricNewFrequency);
            Assert.Equal("No", kriMasterData.ChangeRequestData.KRIMasterNewFlag);
            Assert.True(kriMasterData.ChangeRequestData.MetricNewActivationStatus);
            Assert.Equal("10", kriMasterData.ChangeRequestData.MetricNewAppetiteLowerBound);
            Assert.Equal("90", kriMasterData.ChangeRequestData.MetricNewAppetiteUpperBound);
            Assert.Equal("Range", kriMasterData.ChangeRequestData.MetricNewAppetiteType);
            Assert.Equal("5", kriMasterData.ChangeRequestData.MetricNewToleranceLowerBound);
            Assert.Equal("95", kriMasterData.ChangeRequestData.MetricNewToleranceUpperBound);
            Assert.Equal("Range", kriMasterData.ChangeRequestData.MetricNewToleranceType);
            Assert.Equal("0", kriMasterData.ChangeRequestData.MetricNewEscalationLowerBound);
            Assert.Equal("100", kriMasterData.ChangeRequestData.MetricNewEscalationUpperBound);
            Assert.Equal("Range", kriMasterData.ChangeRequestData.MetricNewEscalationType);
            Assert.Equal("John Doe", kriMasterData.ChangeRequestData.MetricNewUpdatedByName);
            Assert.NotNull(kriMasterData.ChangeRequestData.MetricNewChangeRequestDate);
        }

        [Fact]
        public async Task GetKriMasterGrid_WithInvalidChangeRequestData_ShouldHandleGracefully()
        {
            // Arrange
            var data = new GetKriMasterGridRequest
            {
                LocationId = 1,
                LocationType = "B",
                IsActive = true
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestUser", "TestValue349530768", "TestValue1835299848", null));

            var mockKriReportMetricMasterRepository = new Mock<IKriReportMetricMasterRepository>();
            var ORMKRIMetricMasterData = new List<ORMKRIMetricMaster>
            {
                new ORMKRIMetricMaster
                {
                    Id = 1,
                    KRIMetricId = "KRI01",
                    LocationId = 1,
                    LocationType = "B",
                    MetricName = "Compliance",
                    Frequency = "Monthly",
                    IsActive = true,
                    Status = "Active",
                    ChangeRequestData = "Invalid JSON",
                    CreatedById = 1,
                    ModifiedById = 2,
                    ApprovedById = 3,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-15),
                    ApprovedDate = DateTime.Now.AddDays(-10),
                }
            };

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(mockKriReportMetricMasterRepository.Object);
            mockKriReportMetricMasterRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(ORMKRIMetricMasterData.BuildMock());

            // Set up other necessary mocks (Location, User) as in the existing tests
            var mockLocationRepository = new Mock<IOrmLocationRepository>();
            var mockUserRepository = new Mock<IOrmUserRepository>();
            var mockLocationData = new List<ORMLocation>
            {
                new ORMLocation { Id = 2, LocationType = "D", Department = "Lagos", Branch = null  },
                new ORMLocation { Id = 1, LocationType = "B", Department = null, Branch = "Abuja" }
            };
            var mockLocationDbSet = mockLocationData.AsQueryable().BuildMockDbSet();

            var mockUserData = new List<ORMUser>
            {
                new ORMUser { Id = 1, UserName = "User1" },
                new ORMUser { Id = 2, UserName = "User2" },
                new ORMUser { Id = 3, UserName = "User3" }
            };
            var mockUserDbSet = mockUserData.AsQueryable().BuildMockDbSet();

            mockLocationRepository.Setup(repo => repo.GetAll()).Returns(mockLocationDbSet.Object);
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.GetKriMasterGridAsync(data);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            var kriMasterData = result.Data.First();

            Assert.Equal("Successfully Retrieved KRI master data", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            Assert.NotNull(kriMasterData.ChangeRequestData);
            Assert.Null(kriMasterData.ChangeRequestData.MetricNewName);
            Assert.Null(kriMasterData.ChangeRequestData.MetricNewFrequency);
            Assert.Equal("No", kriMasterData.ChangeRequestData.KRIMasterNewFlag);
            Assert.Null(kriMasterData.ChangeRequestData.MetricNewActivationStatus);
            // ... other assertions for null values
        }

        [Fact]
        public async Task GetKriMasterGrid_WithFilters_ShouldReturnFilteredResults()
        {
            // Arrange
            var data = new GetKriMasterGridRequest
            {
                LocationId = 1,
                LocationType = "B",
                MetricName = "Compliance",
                Frequency = "Monthly",
                IsActive = true,
                Status = "Active"
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestUser", "TestValue349530768", "TestValue1835299848", null));

            var mockKriReportMetricMasterRepository = new Mock<IKriReportMetricMasterRepository>();
            var ORMKRIMetricMasterData = new List<ORMKRIMetricMaster>
            {
                new ORMKRIMetricMaster
                {
                    Id = 1,
                    KRIMetricId = "KRI01",
                    LocationId = 1,
                    LocationType = "B",
                    MetricName = "Compliance",
                    Frequency = "Monthly",
                    IsActive = true,
                    Status = "Active",
                    ChangeRequestData = null,
                    CreatedById = 1,
                    ModifiedById = 2,
                    ApprovedById = 3,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-15),
                    ApprovedDate = DateTime.Now.AddDays(-10),
                },
                new ORMKRIMetricMaster
                {
                    Id = 2,
                    KRIMetricId = "KRI02",
                    LocationId = 2,
                    LocationType = "D",
                    MetricName = "Risk",
                    Frequency = "Quarterly",
                    IsActive = false,
                    Status = "Inactive",
                    ChangeRequestData = null,
                    CreatedById = 1,
                    ModifiedById = 2,
                    ApprovedById = 3,
                    CreatedDate = DateTime.Now.AddDays(-20),
                    ModifiedDate = DateTime.Now.AddDays(-10),
                    ApprovedDate = DateTime.Now.AddDays(-5),
                }
            };

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(mockKriReportMetricMasterRepository.Object);
            mockKriReportMetricMasterRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(ORMKRIMetricMasterData.BuildMock());
            var mockLocationRepository = new Mock<IOrmLocationRepository>();
            var mockUserRepository = new Mock<IOrmUserRepository>();
            var mockLocationData = new List<ORMLocation>
            {
                new ORMLocation { Id = 2, LocationType = "D", Department = "Lagos", Branch = null  },
                new ORMLocation { Id = 1, LocationType = "B", Department = null, Branch = "Abuja" }
            };
            var mockLocationDbSet = mockLocationData.AsQueryable().BuildMockDbSet();

            var mockUserData = new List<ORMUser>
            {
                new ORMUser { Id = 1, UserName = "User1" },
                new ORMUser { Id = 2, UserName = "User2" },
                new ORMUser { Id = 3, UserName = "User3" }
            };
            var mockUserDbSet = mockUserData.AsQueryable().BuildMockDbSet();

            mockLocationRepository.Setup(repo => repo.GetAll()).Returns(mockLocationDbSet.Object);
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);

            var result = await _krimasterServiceFactory.KRIMasterService.GetKriMasterGridAsync(data);

            // Assert
            Assert.NotNull(result.Data);
            Assert.Single(result.Data);
            var kriMasterData = result.Data.First();

            Assert.Equal("Successfully Retrieved KRI master data", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);

            Assert.Equal(1, kriMasterData.Id);
            Assert.Equal("KRI01", kriMasterData.KRIMetricId);
            Assert.Equal(1, kriMasterData.LocationId);
            Assert.Equal("B", kriMasterData.LocationType);
            Assert.Equal("Compliance", kriMasterData.MetricName);
            Assert.Equal("Monthly", kriMasterData.Frequency);
            Assert.True(kriMasterData.IsActive);
            Assert.Equal("Active", kriMasterData.Status);
        }
    }
}
