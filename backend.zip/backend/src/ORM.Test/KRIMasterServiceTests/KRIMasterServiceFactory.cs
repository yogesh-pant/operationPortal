﻿using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Role;
using ORM.Application.Interfaces.User;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;

namespace ORM.Test.KRIMasterServiceTests
{
    public class KRIMasterServiceFactory
    {
        public Mock<IUnitOfWork> UnitOfWork { get; set; }
        public Mock<ISessionService> SessionService { get; set; }
        public Mock<IUserService> UserService { get; set; }
        public Mock<ILogger<KriMasterService>> Logger { get; set; }
        public Mock<IConfiguration> Configuration { get; set; }
        public IKriMasterService KRIMasterService { get; set; }

        public KRIMasterServiceFactory()
        {
            UnitOfWork = new Mock<IUnitOfWork>();
            SessionService = new Mock<ISessionService>();
            UserService = new Mock<IUserService>();
            Logger = new Mock<ILogger<KriMasterService>>();
            Configuration = new Mock<IConfiguration>();

            KRIMasterService = new KriMasterService(Logger.Object, SessionService.Object, UnitOfWork.Object);

            SetupMockData();
        }

        private void SetupMockData()
        {
            // Setup KRI Metric Master Data
            var mockKriMetricMasterRepo = new Mock<IKriReportMetricMasterRepository>();

            var kriMetricMasterData = new List<ORMKRIMetricMaster>
            {
                new ORMKRIMetricMaster
                {
                    Id = 1,
                    KRIMetricId = "KRI001",
                    LocationId = 1,
                    LocationType = "B",
                    MetricName = "Test Metric",
                    Frequency = "Monthly",
                    AppetiteUpperBound = "100",
                    AppetiteLowerBound = "0",
                    AppetiteType = "N",
                    ToleranceUpperBound = "90",
                    ToleranceLowerBound = "10",
                    ToleranceType = "N",
                    EscalationUpperBound = "80",
                    EscalationLowerBound = "20",
                    EscalationType = "N",
                    IsActive = true,
                    Status = "Pending",
                    ChangeRequestData = "{\"MetricNewName\":\"NewMetric\",\"MetricNewFrequency\":\"Weekly\",\"MetricNewUpdatedBy\":2}",
                    CreatedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-10),
                    ModifiedById = 2,
                    ModifiedDate = DateTime.Now.AddDays(-5)
                }
            };

            UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(mockKriMetricMasterRepo.Object);
            mockKriMetricMasterRepo.Setup(repo => repo.GetAll().AsQueryable()).Returns(kriMetricMasterData.BuildMock());

            // Setup User Data
            var mockUserRepository = new Mock<IOrmUserRepository>();

            var userData = new List<ORMUser>
            {
                new ORMUser
                {
                    Id = 1,
                    UserName = "TestUser1",
                    StaffId = "STAFF001",
                    Email = "testuser1@fcmb.com",
                    Status = "Active",
                    RoleId = 1,
                    FailedLoginCount = "0",
                    LastLoginTime = DateTime.Now.AddDays(-1),
                    CurrentLoginTime = DateTime.Now
                },
                new ORMUser
                {
                    Id = 2,
                    UserName = "TestUser2",
                    StaffId = "STAFF002",
                    Email = "testuser2@fcmb.com",
                    Status = "Active",
                    RoleId = 2,
                    FailedLoginCount = "0",
                    LastLoginTime = DateTime.Now.AddDays(-2),
                    CurrentLoginTime = DateTime.Now.AddDays(-1)
                }
            };

            UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);
            mockUserRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(userData.BuildMock());

            // Setup Location Data
            var mockLocationRepository = new Mock<IOrmLocationRepository>();

            var locationData = new List<ORMLocation>
            {
                new ORMLocation
                {
                    Id = 1,
                    LocationId = "LOC001",
                    LocationType = "B",
                    SolId = "SOL001",
                    Branch = "Test Branch",
                    Region = "Test Region",
                    Department = "Test Department",
                    Status = "Active",
                    CreatedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedById = 1,
                    ModifiedDate = DateTime.Now.AddDays(-15)
                }
            };

            UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            mockLocationRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(locationData.BuildMock());
        }

    }
}
