﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using Xunit;
using MockQueryable.Moq;
using ORM.Domain.Common;
using ORM.Test.KRIMasterServiceTests;

namespace ORM.Test.KRIMasterServiceTests
{
    public class UpdateKriMasterTests
    {
        private readonly KRIMasterServiceFactory _krimasterServiceFactory;

        public UpdateKriMasterTests()
        {
            _krimasterServiceFactory = new KRIMasterServiceFactory();
        }

        [Theory]
        [InlineData("SessionNull", "Active", false)]
        [InlineData("Success", "Active", true)]
        [InlineData("PendingStatus", "Pending", false)]
        [InlineData("NoChanges", "Active", false)]
        public async Task UpdateKriMaster_ShouldWork(string expectedResult, string initialStatus, bool hasChanges)
        {
            // Arrange
            var data = new UpdateKriMasterRequest
            {
                Id = 1,
                MetricName = hasChanges ? "Updated Compliance" : "Compliance",
                Frequency = hasChanges ? "Quarterly" : "Monthly",
                AppetiteLowerBound = hasChanges ? "10" : "0",
                AppetiteUpperBound = hasChanges ? "90" : "100",
                AppetiteType = hasChanges ? "ND" : "N",
                ToleranceLowerBound = hasChanges ? "20" : "10",
                ToleranceUpperBound = hasChanges ? "80" : "90",
                ToleranceType = hasChanges ? "ND" : "N",
                EscalationLowerBound = hasChanges ? "30" : "20",
                EscalationUpperBound = hasChanges ? "70" : "80",
                EscalationType = hasChanges ? "PD" : "N",
                ModifiedById = 1
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession())
                .Returns(expectedResult == "SessionNull" ? null : new StaffSession(1, "TestUser", "TestRole", "TestDepartment", null));

            var mockKriReportMetricMasterRepository = new Mock<IKriReportMetricMasterRepository>();
            var mockUserRepository = new Mock<IOrmUserRepository>();

            var kriMetricMasterData = new ORMKRIMetricMaster
            {
                Id = 1,
                KRIMetricId = "KRI01",
                LocationId = 1,
                LocationType = "B",
                MetricName = "Compliance",
                Frequency = "Monthly",
                AppetiteLowerBound = "0",
                AppetiteUpperBound = "100",
                AppetiteType = "N",
                ToleranceLowerBound = "10",
                ToleranceUpperBound = "90",
                ToleranceType = "N",
                EscalationLowerBound = "20",
                EscalationUpperBound = "80",
                EscalationType = "N",
                IsActive = true,
                Status = initialStatus,
                CreatedById = 1,
                ModifiedById = 1,
                ApprovedById = 1,
                CreatedDate = DateTime.Now,
                ModifiedDate = DateTime.Now,
                ApprovedDate = DateTime.Now,
            };

            var mockKriMetricMasterDbSet = new List<ORMKRIMetricMaster> { kriMetricMasterData }.AsQueryable().BuildMockDbSet();
            mockKriReportMetricMasterRepository.Setup(repo => repo.GetAll()).Returns(mockKriMetricMasterDbSet.Object);

            // Mock ORMUsers table
            var mockUserData = new List<ORMUser>
            {
                new ORMUser { Id = 1, UserName = "User1" },
                new ORMUser { Id = 2, UserName = "User2" },
                new ORMUser { Id = 3, UserName = "User3" }
            };
            var mockUserDbSet = mockUserData.AsQueryable().BuildMockDbSet();
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(mockKriReportMetricMasterRepository.Object);
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.Save()).Returns(1);

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.UpdateKriMasterAsync(data);

            // Assert
            if (expectedResult == "Success")
            {
                Assert.NotNull(result.Data);
                Assert.Equal("Successfully Submitted Update Request for KRI Metric Master", result.Description);
                Assert.Equal(ResponseCodes.Success, result.Code);

                mockKriReportMetricMasterRepository.Verify(repo => repo.GetAll(), Times.Once);
                _krimasterServiceFactory.UnitOfWork.Verify(x => x.Save(), Times.Once);

                Assert.Equal("Pending", kriMetricMasterData.Status);
                Assert.NotNull(kriMetricMasterData.ChangeRequestData);

                var changeData = JsonConvert.DeserializeObject<KRIMasterChangeData>(kriMetricMasterData.ChangeRequestData);
                Assert.Equal("Updated Compliance", changeData!.MetricNewName);
                Assert.Equal("Quarterly", changeData.MetricNewFrequency);
                Assert.Equal("10", changeData.MetricNewAppetiteLowerBound);
                Assert.Equal("90", changeData.MetricNewAppetiteUpperBound);
                Assert.Equal("20", changeData.MetricNewToleranceLowerBound);
                Assert.Equal("80", changeData.MetricNewToleranceUpperBound);
                Assert.Equal("30", changeData.MetricNewEscalationLowerBound);
                Assert.Equal("70", changeData.MetricNewEscalationUpperBound);
                Assert.Equal("No", changeData.KRIMasterNewFlag);
                Assert.Equal(1, changeData.MetricNewUpdatedBy);
                Assert.Equal("User1", changeData.MetricNewUpdatedByName);
            }
            else if (expectedResult == "SessionNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("User Is Unauthenticated", result.Description);
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
            }
            else if (expectedResult == "PendingStatus")
            {
                Assert.Null(result.Data);
                Assert.Equal("KRI Metric Master info change is Pending Review, No Change Allowed ", result.Description);
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            }
            else if (expectedResult == "NoChanges")
            {
                Assert.Null(result.Data);
                Assert.Equal("No changes made in KRI Master data!", result.Description);
                Assert.Equal(ResponseCodes.ServiceError, result.Code);
                Assert.Null(kriMetricMasterData.ChangeRequestData);
            }
        }
    }
}