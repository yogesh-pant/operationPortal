﻿using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.Services.Auth;
using ORM.Infrastructure.IRepositories;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using ORM.Domain.Common;
using ORM.Test.KRIMasterServiceTests;

namespace ORM.Test.KRIMasterServiceTests
{
    public class CreateKriMasterTests
    {
        private readonly KRIMasterServiceFactory _krimasterServiceFactory;

        public CreateKriMasterTests()
        {
            _krimasterServiceFactory = new KRIMasterServiceFactory();
        }

        [Theory]
        [InlineData("SessionNull")]  // Session is null - Failed Validation
        [InlineData("Success")]     // Records created successfully
        [InlineData("KRIMetricIdGeneration")] // Test KRI Metric ID generation
        [InlineData("ChangeDataCreation")] // Test KRIMasterChangeData creation
        [InlineData("JsonConversion")] // Test JSON conversion of KRIMasterChangeData
        [InlineData("UpdatedByNameAssignment")] // Test MetricNewUpdatedByName assignment
        public async Task CreateKriMaster_ShouldWork(string expectedResult)
        {
            // Arrange
            var data = new CreateKriMasterRequest
            {
                LocationId = 1,
                LocationType = "B",
                MetricName = "Test Metric",
                Frequency = "Monthly",
                AppetiteUpperBound = "100",
                AppetiteLowerBound = "0",
                AppetiteType = "N",
                ToleranceUpperBound = "90",
                ToleranceLowerBound = "10",
                ToleranceType = "N",
                EscalationUpperBound = "80",
                EscalationLowerBound = "20",
                EscalationType = "N",
                CreatedById = 1
            };

            var testUserId = 1;
            var testUserName = "User1"; // Changed to match the mock data
            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(testUserId, testUserName, "TestValue349530768", "TestValue1835299848", null));

            if (expectedResult == "SessionNull")
            {
                _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            }

            ORMKRIMetricMaster capturedMaster = null!;
            _krimasterServiceFactory.UnitOfWork
                .Setup(x => x.SaveAndGetIdKriMasterAsync(It.IsAny<ORMKRIMetricMaster>()))
                .Callback<ORMKRIMetricMaster>(master => capturedMaster = master)
                .ReturnsAsync(1);

            if (expectedResult == "KRIMetricIdGeneration")
            {
                _krimasterServiceFactory.UnitOfWork.Setup(x => x.GetKRIMasterRecordCount("00001")).ReturnsAsync("KRI-B0001-0001");
            }

            // Mock other repositories
            var mockUserRepository = new Mock<IOrmUserRepository>();
            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);

            var mockUserData = new List<ORMUser>
            {
                new ORMUser { Id = 1, UserName = "User1" },
                new ORMUser { Id = 2, UserName = "User2" },
                new ORMUser { Id = 3, UserName = "User3" }
            };
            var mockUserDbSet = mockUserData.AsQueryable().BuildMockDbSet();
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.CreateKriMasterAsync(data);

            // Assert
            if (expectedResult == "Success" || expectedResult == "UpdatedByNameAssignment")
            {
                Assert.NotNull(result.Data);
                Assert.Equal("Successfully Submitted New MetricKRI Master", result.Description);
                Assert.Equal(ResponseCodes.Success, result.Code);

                Assert.NotNull(capturedMaster);
                Assert.Contains($"\"MetricNewUpdatedByName\":\"{testUserName}\"", capturedMaster.ChangeRequestData);
            }
            else if (expectedResult == "SessionNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("User Is Unauthenticated", result.Description);
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
            }
            else if (expectedResult == "KRIMetricIdGeneration")
            {
                _krimasterServiceFactory.UnitOfWork.Verify(x => x.GetKRIMasterRecordCount("00001"), Times.Once);
                Assert.NotNull(capturedMaster);
                Assert.Equal("KRI-B0001-0001", capturedMaster.KRIMetricId);
            }
            else if (expectedResult == "ChangeDataCreation" || expectedResult == "JsonConversion")
            {
                Assert.NotNull(capturedMaster);
                var verificationResult = VerifyChangeData(capturedMaster.ChangeRequestData!, testUserName);
                Assert.True(verificationResult, $"VerifyChangeData failed. ChangeRequestData: {capturedMaster.ChangeRequestData}");
            }
        }

        private static bool VerifyChangeData(string changeRequestData, string expectedUserName)
        {
            if (string.IsNullOrEmpty(changeRequestData)) return false;
            var changeData = JsonConvert.DeserializeObject<KRIMasterChangeData>(changeRequestData);
            return changeData != null &&
                   changeData.KRIMasterNewFlag == "Yes" &&
                   changeData.MetricNewActivationStatus == true &&
                   changeData.MetricNewUpdatedByName == expectedUserName;
        }
    }
}