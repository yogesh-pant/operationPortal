﻿using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Moq;
using Xunit;
using System.Linq;
using ORM.Test.LocationServiceTests;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Role;
using ORM.Application.Interfaces.User;
using ORM.Infrastructure.UOW;
using ORM.Test.KRIMasterServiceTests;

namespace ORM.Test.KRIMasterServiceTests
{

    public class KriMasterApprovalRejectionTests
    {
        private readonly KRIMasterServiceFactory _krimasterServiceFactory;

        public KriMasterApprovalRejectionTests()
        {
            _krimasterServiceFactory = new KRIMasterServiceFactory();
        }

        [Theory]
        [InlineData("SessionNull")]   // Session Null - Failed with User Unauthenticated  
        [InlineData("NoRecordFound")]   // No Record found - Failed Validation 
        [InlineData("NotPending")]   // Status is not Pending - Failed Validation
        [InlineData("Success")]  // Approval successful
        public async Task ApproveKRIMasterChangeAsync_ShouldWork(string ExpectedResult)
        {
            // Arrange
            var request = new ReviewUserChangeRequest
            {
                Id = 1,
                ChangeReviewComments = "Approved"
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestUser", "Test", "User", null));

            if (ExpectedResult == "SessionNull")
            {
                _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            }

            if (ExpectedResult == "NoRecordFound")
            {
                _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable()).Returns(new List<ORMKRIMetricMaster>().BuildMock());
            }

            if (ExpectedResult == "NotPending")
            {
                var notPendingData = new List<ORMKRIMetricMaster>
                {
                    new ORMKRIMetricMaster
                    {
                        Id = 1,
                        Status = "Approved",
                        ChangeRequestData = "{\"MetricNewName\":\"NewMetric\",\"MetricNewFrequency\":\"Weekly\",\"MetricNewUpdatedBy\":2}"
                    }
                };
                _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable()).Returns(notPendingData.BuildMock());
            }

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.ApproveKRIMasterChangeAsync(request);

            // Assert
            if (ExpectedResult == "Success")
            {
                Assert.Equal(ResponseCodes.Success, result.Code);
                Assert.Equal("KRI Metric Master Update request approved and record updated successfully ", result.Description);
            }
            else if (ExpectedResult == "SessionNull")
            {
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
                Assert.Equal("User Is Unauthenticated", result.Description);
            }
            else if (ExpectedResult == "NoRecordFound")
            {
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
                Assert.Equal("KRI Metric Master Data Not Found", result.Description);
            }
            else if (ExpectedResult == "NotPending")
            {
                Assert.Equal(ResponseCodes.ServiceError, result.Code);
                Assert.Equal("KRI Metric Master info change is Not Pending Review ", result.Description);
            }
        }

        [Theory]
        [InlineData("SessionNull")]   // Session Null - Failed with User Unauthenticated  
        [InlineData("NoRecordFound")]   // No Record found - Failed Validation 
        [InlineData("NotPending")]   // Status is not Pending - Failed Validation
        [InlineData("Success")]  // Rejection successful
        public async Task RejectKRIMasterChangeAsync_ShouldWork(string ExpectedResult)
        {
            // Arrange
            var request = new ReviewUserChangeRequest
            {
                Id = 1,
                ChangeReviewComments = "Rejected"
            };

            _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestUser", "Test", "User", null));

            if (ExpectedResult == "SessionNull")
            {
                _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            }

            if (ExpectedResult == "NoRecordFound")
            {
                _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable()).Returns(new List<ORMKRIMetricMaster>().BuildMock());
            }

            if (ExpectedResult == "NotPending")
            {
                var notPendingData = new List<ORMKRIMetricMaster>
                {
                    new ORMKRIMetricMaster
                    {
                        Id = 1,
                        Status = "Approved",
                        ChangeRequestData = "{\"MetricNewName\":\"NewMetric\",\"MetricNewFrequency\":\"Weekly\",\"MetricNewUpdatedBy\":2}"
                    }
                };
                _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable()).Returns(notPendingData.BuildMock());
            }

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.RejectKRIMasterChangeAsync(request);

            // Assert
            if (ExpectedResult == "Success")
            {
                Assert.Equal(ResponseCodes.Success, result.Code);
                Assert.Equal("KRI Metric Master Update request rejected and record updated successfully ", result.Description);
            }
            else if (ExpectedResult == "SessionNull")
            {
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
                Assert.Equal("User Is Unauthenticated", result.Description);
            }
            else if (ExpectedResult == "NoRecordFound")
            {
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
                Assert.Equal("KRI Metric Master Data Not Found", result.Description);
            }
            else if (ExpectedResult == "NotPending")
            {
                Assert.Equal(ResponseCodes.ServiceError, result.Code);
                Assert.Equal("KRI Metric Master info change is Not Pending Review ", result.Description);
            }
        }
    }
}