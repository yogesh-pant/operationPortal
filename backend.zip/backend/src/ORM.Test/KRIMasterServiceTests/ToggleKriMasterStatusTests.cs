﻿using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.UOW;
using ORM.Test.LocationServiceTests;
using Newtonsoft.Json;
using MockQueryable.Moq;
using ORM.Domain.Common;
using ORM.Test.KRIMasterServiceTests;

namespace ORM.Test.KRIMasterServiceTests
{
    public class ToggleKriMasterTests
    {
        private readonly KRIMasterServiceFactory _krimasterServiceFactory;

        public ToggleKriMasterTests()
        {
            _krimasterServiceFactory = new KRIMasterServiceFactory();
        }

        [Theory]
        [InlineData("SessionNull", false, "Approved", ResponseCodes.Unauthenticated)]
        [InlineData("Success", false, "Approved", ResponseCodes.Success)]
        [InlineData("PendingStatus", false, "Pending", ResponseCodes.ServiceError)]
        [InlineData("NoStatusChange", true, "Approved", ResponseCodes.ServiceError)]
        [InlineData("NotFound", true, "Approved", ResponseCodes.DataNotFound)]
        public async Task ToggleKriMaster_ShouldWork(string scenario, bool currentIsActive, string currentStatus, string expectedResponseCode)
        {
            // Arrange

            var data = SetupSessionandInput(scenario, currentIsActive);
            SetupMockData(scenario,currentIsActive, currentStatus);

            // Act
            var result = await _krimasterServiceFactory.KRIMasterService.ToggleKriMasterStatusAsync(data);

            // Assert
            Assert.Equal(expectedResponseCode, result.Code);

            if (expectedResponseCode == ResponseCodes.Success)
            {
                Assert.NotNull(result.Data);
                Assert.Equal("Successfully Submitted Toggle Status Request for KRI Metric Master", result.Description);
                VerifyChangeRequestData(currentIsActive);
            }
            else if (scenario == "SessionNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("User Is Unauthenticated", result.Description);
            }
            else if (scenario == "PendingStatus")
            {
                Assert.Null(result.Data);
                Assert.Equal("KRI Metric Master info change is Pending Review, No Change Allowed ", result.Description);
            }
            else if (scenario == "NoStatusChange")
            {
                Assert.Null(result.Data);
                Assert.Equal("KRI Metric Master Status Toggling to same value, No Change Applied ", result.Description);
            }
            else if (scenario == "NotFound")
            {
                Assert.Null(result.Data); 
                Assert.Equal(expectedResponseCode, result.Code);
                Assert.Equal("KRI Metric Master Data Not Found", result.Description);
            }
        }

        private ToggleKriMasterStatusRequest SetupSessionandInput(string scenario, bool currentIsActive)
        {
            var data = new ToggleKriMasterStatusRequest { Id = 1, IsActive = !currentIsActive };

            if (scenario == "SessionNull")
            {
                _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            }
            else
            {
                _krimasterServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestUser", "TestValue349530768", "TestValue1835299848", null));
            }
            if (scenario == "NoStatusChange")
            {
                data = new ToggleKriMasterStatusRequest { Id = 1, IsActive = currentIsActive };
            }
            if (scenario == "NotFound")
            {
                data = new ToggleKriMasterStatusRequest { Id = 3, IsActive = currentIsActive };
            }
            return data;
        }

        private void SetupMockData(string scenario,bool isActive, string status)
        {
            var mockRepository = new Mock<IKriReportMetricMasterRepository>();
            var mockUserRepository = new Mock<IOrmUserRepository>();

            var kriMetricMasterData = new List<ORMKRIMetricMaster>
            {
                new ORMKRIMetricMaster
                {
                    Id = scenario == "NotFound" ? 2 : 1,
                    IsActive = isActive,
                    Status = status,
                    ChangeRequestData = null
                }
            };

            var userData = new List<ORMUser>
            {
                new ORMUser { Id = 1, UserName = "TestUser" },
                new ORMUser { Id = 2, UserName = "User2" },
                new ORMUser { Id = 3, UserName = "User3" }
            };

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMKRIMetricMaster).Returns(mockRepository.Object);
            mockRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(kriMetricMasterData.AsQueryable().BuildMock());

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);
            var mockUserDbSet = userData.AsQueryable().BuildMockDbSet();
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            _krimasterServiceFactory.UnitOfWork.Setup(x => x.Save()).Returns(1);
        }

        private void VerifyChangeRequestData(bool currentIsActive)
        {
            var mockRepository = _krimasterServiceFactory.UnitOfWork.Object.ORMKRIMetricMaster;
            var updatedData = mockRepository.GetAll().AsQueryable().First();

            Assert.NotNull(updatedData.ChangeRequestData);
            var changeData = JsonConvert.DeserializeObject<KRIMasterChangeData>(updatedData.ChangeRequestData);

            Assert.NotNull(changeData);
            Assert.Equal("No", changeData.KRIMasterNewFlag);
            Assert.Equal(!currentIsActive, changeData.MetricNewActivationStatus);
            Assert.Equal(1, changeData.MetricNewUpdatedBy);
            Assert.Equal("TestUser", changeData.MetricNewUpdatedByName);
            Assert.NotNull(changeData.MetricNewChangeRequestDate);
        }
    }
}