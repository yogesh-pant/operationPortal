namespace ORM.Test.Repositories
{
    using FakeItEasy;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class GenericRepositoryTests
    {
        [Fact]
        public void GetById_WithValidId_ShouldReturnEntity()
        {
            // Arrange
            var dbContext = A.Fake<AppDbContext>();
            var fakeSet = A.Fake<DbSet<TestEntity>>();
            A.CallTo(() => dbContext.Set<TestEntity>()).Returns(fakeSet);

            var repository = new TestRepository(dbContext);
            var entityId = 1;

            // Act
            var result = repository.GetById(entityId);

            // Assert
            A.CallTo(() => fakeSet.Find(A<long>._)).MustHaveHappenedOnceExactly();
            result.Should().NotBeNull();
        }

        [Fact]
        public void GetAll_ShouldReturnDbSet()
        {
            // Arrange
            var dbContext = A.Fake<AppDbContext>();
            var fakeSet = A.Fake<DbSet<TestEntity>>();
            A.CallTo(() => dbContext.Set<TestEntity>()).Returns(fakeSet);

            var repository = new TestRepository(dbContext);

            // Act
            var result = repository.GetAll();

            // Assert
            result.Should().BeEquivalentTo(fakeSet);
        }

        // Test entity for demonstration purposes
        public class TestEntity
        {
            public long Id { get; set; }
            // Other properties...
        }

        // Test repository for demonstration purposes
        public class TestRepository : GenericRepository<TestEntity>
        {
            public TestRepository(AppDbContext context) : base(context)
            {
            }
        }
    }
}