namespace ORM.Test.Repositories
{
    using System;
    using System.Collections.Generic;
    using AutoFixture;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using Moq;
    using ORM.Infrastructure.Entities;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class KriReportRepositoryTests
    {
        private readonly KriReportRepository _testClass;
        private readonly AppDbContext _dbContext;

        public KriReportRepositoryTests()
        {
            _dbContext = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: "SBSC")
                .Options);
            _testClass = new KriReportRepository(_dbContext);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new KriReportRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public void DeleteRange_ShouldRemoveEntitiesAndSaveChanges()
        {
            // Arrange
            var entitiesToDelete = new List<ORMKRIReport> { new() { Id = 1 }, new() };
            // Act
            _testClass.DeleteRange(entitiesToDelete);

            // Assert
            _dbContext.SaveChanges().Should().Be(0);
        }
    }
}