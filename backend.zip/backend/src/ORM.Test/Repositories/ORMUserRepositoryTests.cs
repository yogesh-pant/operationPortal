namespace ORM.Test.Repositories
{
    using System;
    using AutoFixture;
    using FakeItEasy;
    using FluentAssertions;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class OrmUserRepositoryTests
    {
        private readonly AppDbContext _dbContext;
        public OrmUserRepositoryTests()
        {
            _dbContext = A.Fake<AppDbContext>();
        }
        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new OrmUserRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }
    }
}