namespace ORM.Test.Repositories
{
    using System;
    using AutoFixture;
    using FakeItEasy;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using ORM.Infrastructure.Entities;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class OrmUserLocationMapRepositoryTests
    {
        private readonly AppDbContext _dbContext;
        private readonly OrmUserLocationMapRepository _testClass;
        public OrmUserLocationMapRepositoryTests()
        {
            _dbContext = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>()
               .UseInMemoryDatabase(databaseName: "SBSC")
               .Options);
            _testClass = new OrmUserLocationMapRepository(_dbContext);
        }
        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new OrmUserLocationMapRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public void Delete_ShouldRemoveEntityAndSaveChanges()
        {
            // Arrange
            var entityToDelete = new ORMUserLocationMap();
            _dbContext.Add(entityToDelete);
            _dbContext.SaveChanges();
            // Act
            _testClass.Delete(entityToDelete);

            // Assert
            _dbContext.SaveChanges().Should().Be(0);
        }

        [Fact]
        public void DeleteRange_ShouldRemoveEntitiesAndSaveChanges()
        {
            // Arrange
            var entitiesToDelete = new List<ORMUserLocationMap> { new(), new() };
            _dbContext.AddRange(entitiesToDelete);
            _dbContext.SaveChanges();
            // Act
            _testClass.DeleteRange(entitiesToDelete);

            // Assert
            _dbContext.SaveChanges().Should().Be(0);
        }
    }
}