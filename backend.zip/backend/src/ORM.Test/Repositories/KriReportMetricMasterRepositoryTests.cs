namespace ORM.Test.Repositories
{
    using System;
    using FakeItEasy;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using ORM.Infrastructure.Entities;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class KriReportMetricMasterRepositoryTests
    {
        private readonly AppDbContext _dbContext;
        public KriReportMetricMasterRepositoryTests()
        {
            _dbContext = A.Fake<AppDbContext>();
        }
        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new KriReportMetricMasterRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }
    }
}