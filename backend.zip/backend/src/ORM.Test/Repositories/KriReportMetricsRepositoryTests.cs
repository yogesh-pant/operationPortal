namespace ORM.Test.Repositories
{
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using ORM.Infrastructure.Entities;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class KriReportMetricsRepositoryTests
    {
        private readonly AppDbContext _dbContext;
        private readonly KriReportMetricsRepository _testClass;
        public KriReportMetricsRepositoryTests()
        {
            _dbContext = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: "SBSC")
                .Options);
            _testClass = new KriReportMetricsRepository(_dbContext);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new KriReportMetricsRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public void Delete_ShouldRemoveEntityAndSaveChanges()
        {
            // Arrange
            var entityToDelete = new ORMKRIReportMetrics();
            _dbContext.Add(entityToDelete);
            _dbContext.SaveChanges();
            // Act
            _testClass.Delete(entityToDelete);

            // Assert
            _dbContext.SaveChanges().Should().Be(0);
        }

        [Fact]
        public void DeleteRange_ShouldRemoveEntitiesAndSaveChanges()
        {
            // Arrange
            var entitiesToDelete = new List<ORMKRIReportMetrics> { new(), new() };
            _dbContext.AddRange(entitiesToDelete);
            _dbContext.SaveChanges();
            // Act
            _testClass.DeleteRange(entitiesToDelete);

            // Assert
            _dbContext.SaveChanges().Should().Be(0);
        }


    }
}