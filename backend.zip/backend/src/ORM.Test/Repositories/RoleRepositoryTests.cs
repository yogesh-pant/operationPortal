namespace ORM.Test.Repositories
{
    using System;
    using AutoFixture;
    using FakeItEasy;
    using FluentAssertions;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class RoleRepositoryTests
    {
        private readonly AppDbContext _dbContext;
        public RoleRepositoryTests()
        {
            _dbContext = A.Fake<AppDbContext>();
        }
        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new RoleRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }
    }
}