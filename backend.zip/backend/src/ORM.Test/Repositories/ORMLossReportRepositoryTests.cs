namespace ORM.Test.Repositories
{
    using System;
    using System.Collections.Generic;
    using AutoFixture;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using Moq;
    using ORM.Infrastructure.Entities;
    using ORM.Infrastructure.Persistance;
    using ORM.Infrastructure.Repositories;
    using Xunit;

    public class OrmLossReportRepositoryTests
    {
        private readonly OrmLossReportRepository _testClass;
        private readonly AppDbContext _dbContext;

        public OrmLossReportRepositoryTests()
        {
            _dbContext = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: "SBSC")
                .Options);
            _testClass = new OrmLossReportRepository(_dbContext);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new OrmLossReportRepository(_dbContext);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public void DeleteRange_ShouldRemoveEntitiesAndSaveChanges()
        {
            // Arrange
            var entitiesToDelete = new List<ORMLossReport> { new() { Id = 1 }, new() };
            // Act
            _testClass.DeleteRange(entitiesToDelete);

            // Assert
            _dbContext.SaveChanges().Should().Be(0);
        }
    }
}