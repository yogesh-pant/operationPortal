namespace ORM.Test.Controllers
{
    using System;
    using System.Threading.Tasks;
    using FakeItEasy;
    using Fcmb.Shared.Auth.Models.Requests;
    using Fcmb.Shared.Models.Responses;
    using FluentAssertions;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using ORM.Api.Controllers;
    using ORM.Application.Interfaces.Auth;
    using ORM.Application.Interfaces.Common;
    using ORM.Application.Models.Responses;
    using Xunit;

    public class AuthControllerTests
    {
        private AuthController _testClass;
        private IAuthSetupService _authSetupService;

        public AuthControllerTests()
        {
            _authSetupService = A.Fake<IAuthSetupService>();
            _testClass = new AuthController(_authSetupService);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new AuthController(_authSetupService);

            // Assert
            instance.Should().NotBeNull();
        }
        [Fact]
        public async Task CanCallLogin()
        {
            // Arrange
            var request = new LoginRequest();

            // Mock HttpContext
            var httpContext = new DefaultHttpContext();

            // Set up X-Forwarded-For header (optional) or RemoteIpAddress
            httpContext.Request.Headers["X-Forwarded-For"] = "127.168.0.1"; // Or use whatever IP you want to test

            // Alternatively, set the RemoteIpAddress if you are not using a proxy
            httpContext.Connection.RemoteIpAddress = System.Net.IPAddress.Parse("127.168.0.1");

            // Mock ControllerContext
            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };

            // Assign the mock ControllerContext to your controller
            _testClass.ControllerContext = controllerContext;

            // Mock the service call with the fake IP
            A.CallTo(() => _authSetupService.LoginAsync(A<LoginRequest>._, "127.168.0.1"))
                .Returns(new ObjectResponse<LoginResponse>("TestValue1573571141", "TestValue178239481"));

            // Act
            var result = await _testClass.Login(request);

            // Assert
            A.CallTo(() => _authSetupService.LoginAsync(A<LoginRequest>._, "127.168.0.1")).MustHaveHappened();
            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallCheckUserInAd()
        {
            // Arrange
            var userName = "TestValue1141887120";

            // Mock HttpContext
            var httpContext = new DefaultHttpContext();

            // Set up X-Forwarded-For header (optional) or RemoteIpAddress
            httpContext.Request.Headers["X-Forwarded-For"] = "127.168.0.1"; // Or use whatever IP you want to test

            // Alternatively, set the RemoteIpAddress if you are not using a proxy
            httpContext.Connection.RemoteIpAddress = System.Net.IPAddress.Parse("127.168.0.1");

            // Mock ControllerContext
            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };

            // Assign the mock ControllerContext to your controller
            _testClass.ControllerContext = controllerContext;


            A.CallTo(() => _authSetupService.CheckUserInAdAsync(A<string>._, "127.168.0.1")).Returns(new ObjectResponse<LoginResponse>("TestValue629106807", "TestValue872589573"));

            var mockLoginResponse = LoginResponseMockData();
            // Act
            var result = await _testClass.CheckUserInAd(userName);

            // Assert
            A.CallTo(() => _authSetupService.CheckUserInAdAsync(A<string>._, "127.168.0.1")).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallLogout()
        {
            // Arrange
            var email = "TestValue2065232020";

            // Mock HttpContext
            var httpContext = new DefaultHttpContext();

            // Set up X-Forwarded-For header (optional) or RemoteIpAddress
            httpContext.Request.Headers["X-Forwarded-For"] = "127.168.0.1"; // Or use whatever IP you want to test

            // Alternatively, set the RemoteIpAddress if you are not using a proxy
            httpContext.Connection.RemoteIpAddress = System.Net.IPAddress.Parse("127.168.0.1");

            // Mock ControllerContext
            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext
            };

            // Assign the mock ControllerContext to your controller
            _testClass.ControllerContext = controllerContext;
            A.CallTo(() => _authSetupService.LogoutAsync(A<string>._, "127.168.0.1")).Returns(new ObjectResponse<string>("TestValue1797573730", "TestValue1650820376"));

            // Act
            var result = await _testClass.Logout(email);

            // Assert
            A.CallTo(() => _authSetupService.LogoutAsync(A<string>._, "127.168.0.1")).MustHaveHappened();
            result.Should().NotBeNull();
        }


        private static LoginResponse LoginResponseMockData()
        {
            return new LoginResponse
            {
                Token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c",
                RefreshToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c",
                UserName = "john_doe",
                UserRole = "admin",
                FailLoginCount = 0,
                IsAccountLocked = false,
                LastLoginTime = DateTime.Parse("2023-01-20"),
                UserRoleId = 1,
                UserId = 123,
                Email = "john.doe@example.com",
                SolId = "SOL001",
                LocationType = "Branch",
                LocationData = new List<LocationData>
                {
                    new LocationData { LocationId = 1001, Region = "North", Branch = "Branch A", Department = "Department X"},
                    new LocationData { LocationId = 1002, Region = "South", Branch = "Branch E", Department = "Department R"}
                }
            };

            
            
        }
    }
}