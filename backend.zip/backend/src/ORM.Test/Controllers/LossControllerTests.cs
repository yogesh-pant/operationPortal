namespace ORM.Test.Controllers
{
    using System;
    using System.Threading.Tasks;
    using FakeItEasy;
    using Fcmb.Shared.Models.Responses;
    using FluentAssertions;
    using ORM.Api.Controllers;
    using ORM.Application.Interfaces.Role;
    using ORM.Application.Models.Requests;
    using ORM.Application.Models.Responses;
    using Xunit;

    public class LossControllerTests
    {
        private LossController _testClass;
        private ILossService _lossService;

        public LossControllerTests()
        {
            _lossService = A.Fake<ILossService>();
            _testClass = new LossController(_lossService);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new LossController(_lossService);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetLossGridData()
        {
            // Arrange
            var request = new LossGridRequest();

            A.CallTo(() => _lossService.GetLossGridAsync(A<LossGridRequest>._)).Returns(new ListResponse<LossDataGridResponse>("TestValue505821346", "TestValue2085306528"));

            // Act
            var result = await _testClass.GetLossGridData(request);

            // Assert
            A.CallTo(() => _lossService.GetLossGridAsync(A<LossGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }
        [Fact]
        public async Task CanCallGetLossGridDataException()
        {
            // Arrange
            var request = new LossGridRequest();

            A.CallTo(() => _lossService.GetLossGridAsync(A<LossGridRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetLossGridData(request);

            // Assert
            A.CallTo(() => _lossService.GetLossGridAsync(A<LossGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateLossDataRLO()
        {
            // Arrange
            var request = new UpdateLossDataRloRequest();

            A.CallTo(() => _lossService.UpdateLossDataRLOAsync(A<UpdateLossDataRloRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1310955372", "TestValue873411970"));

            // Act
            var result = await _testClass.UpdateLossDataRLO(request);

            // Assert
            A.CallTo(() => _lossService.UpdateLossDataRLOAsync(A<UpdateLossDataRloRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateLossDataRLOException()
        {
            // Arrange
            var request = new UpdateLossDataRloRequest();

            A.CallTo(() => _lossService.UpdateLossDataRLOAsync(A<UpdateLossDataRloRequest>._)).Throws(new Exception("Test exception", new Exception("Inner exception message", new Exception("Inner exception message"))));

            // Act
            var result = await _testClass.UpdateLossDataRLO(request);

            // Assert
            A.CallTo(() => _lossService.UpdateLossDataRLOAsync(A<UpdateLossDataRloRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCreateLossDataAsync()
        {
            // Arrange
            var request = new CreateLossDataRequest();

            A.CallTo(() => _lossService.CreateLossDataAsync(A<CreateLossDataRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1131448126", "TestValue1180957017"));

            // Act
            var result = await _testClass.CreateLossDataAsync(request);

            // Assert
            A.CallTo(() => _lossService.CreateLossDataAsync(A<CreateLossDataRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallCreateLossDataAsyncException()
        {
            // Arrange
            var request = new CreateLossDataRequest();

            A.CallTo(() => _lossService.CreateLossDataAsync(A<CreateLossDataRequest>._)).Throws(new Exception("Test exception", new Exception("Inner exception message")));

            // Act
            var result = await _testClass.CreateLossDataAsync(request);

            // Assert
            A.CallTo(() => _lossService.CreateLossDataAsync(A<CreateLossDataRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateLossDataBORM()
        {
            // Arrange
            var request = new UpdateLossDataBormRequest();

            A.CallTo(() => _lossService.UpdateLossDataBORMAsync(A<UpdateLossDataBormRequest>._)).Returns(new ListResponse<ReturnId>("TestValue865354067", "TestValue399296706"));

            // Act
            var result = await _testClass.UpdateLossDataBORM(request);

            // Assert
            //A.CallTo(() => _lossService.UpdateLossDataBORMAsync(A<UpdateLossDataBormRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallUpdateLossDataBORMException()
        {
            // Arrange
            var request = new UpdateLossDataBormRequest();

            A.CallTo(() => _lossService.UpdateLossDataBORMAsync(A<UpdateLossDataBormRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.UpdateLossDataBORM(request);

            // Assert
            A.CallTo(() => _lossService.UpdateLossDataBORMAsync(A<UpdateLossDataBormRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallApproveLossDataBORM()
        {
            // Arrange
            var request = new ApproveLossDataBormRequest();

            A.CallTo(() => _lossService.ApproveLossDataBORMAsync(A<ApproveLossDataBormRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1659440810", "TestValue382900636"));

            // Act
            var result = await _testClass.ApproveLossDataBORM(request);

            // Assert
            A.CallTo(() => _lossService.ApproveLossDataBORMAsync(A<ApproveLossDataBormRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallApproveLossDataBORMException()
        {
            // Arrange
            var request = new ApproveLossDataBormRequest();

            A.CallTo(() => _lossService.ApproveLossDataBORMAsync(A<ApproveLossDataBormRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.ApproveLossDataBORM(request);

            // Assert
            A.CallTo(() => _lossService.ApproveLossDataBORMAsync(A<ApproveLossDataBormRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetFullLossDataBySingleId()
        {
            // Arrange
            var request = new GetFullLossDataBySingleIdRequest();
            
            var mockData = GetFullLossDataBySingleIdResponseMockData();

            A.CallTo(() => _lossService.GetFullLossDataBySingleIdAsync(A<GetFullLossDataBySingleIdRequest>._)).Returns(new ListResponse<GetFullLossDataBySingleIdResponse>("TestValue736758837", "TestValue1842444224"));

            // Act
            var result = await _testClass.GetFullLossDataBySingleId(request);

            // Assert
            A.CallTo(() => _lossService.GetFullLossDataBySingleIdAsync(A<GetFullLossDataBySingleIdRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetFullLossDataBySingleIdException()
        {
            // Arrange
            var request = new GetFullLossDataBySingleIdRequest();

            A.CallTo(() => _lossService.GetFullLossDataBySingleIdAsync(A<GetFullLossDataBySingleIdRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetFullLossDataBySingleId(request);

            // Assert
            A.CallTo(() => _lossService.GetFullLossDataBySingleIdAsync(A<GetFullLossDataBySingleIdRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        private static GetFullLossDataBySingleIdResponse GetFullLossDataBySingleIdResponseMockData()
        {
             return new GetFullLossDataBySingleIdResponse
             {
                 RefNum = "REF001",
                 ValidatorILOUserId = 123,
                 ValidatorILOUserName = "JaneDoe",
                 DateOccurance = DateTime.Parse("2024-02-23"),
                 DateDiscovery = DateTime.Parse("2024-02-24"),
                 DateReported = DateTime.Parse("2024-02-25"),
                 Description = "Description of the loss",
                 RootCauseRLO = "Root cause of the loss",
                 LossType = "Financial",
                 CurrencyType = "USD",
                 AmountInvolved = 10000.50m,
                 NearMissAmount = 500.75m,
                 PotentialLossAmount = 15000.25m,
                 GrossActualAmount = 12000.80m,
                 RecoveredAmount = 2000.40m,
                 FurtherRecoveredAmount = 1000.20m,
                 NetActualLossAmount = 9000.60m,
                 RecoveryChannel = "Recovery channel",
                 StaffInvolvement = "Yes",
                 EventStatus = "Open",
                 ReportStatus = "Submitted",
                 StaffJobRole = "Staff job role",
                 InternalBusLine = "Internal business line",
                 BaselEventTypeI = "Basel event type I",
                 BaselEventTypeII = "Basel event type II",
                 BaselEventTypeIII = "Basel event type III",
                 BaselLevel1BusinessLine = "Basel level 1 business line",
                 BaselLevel2BusinessLine = "Basel level 2 business line",
                 RootCauseTypeBORM = "Root cause type by BORM",
                 ProcessInvolved = "Process involved",
                 RiskSource = "Risk source",
                 LessonLearnt = "Lesson learnt",
                 ReviewerComments = "Reviewer comments",
                 UpdateHistory = "Update history",
                 CreatedById = 456,
                 ModifiedById = 789,
                 ValidatedById = 101,
                 ApprovedById = 111,
                 CreatedDate = DateTime.Parse("2024-01-01"),
                 ModifiedDate = DateTime.Parse("2024-01-02"),
                 ValidationDate = DateTime.Parse("2024-01-03"),
                 ApprovedDate = DateTime.Parse("2024-01-04"),
                 Documents = "Document path",
                 DocumentName = "Document name",
                 FileType = "PDF",
                 LocationType = "Branch",
                 LocationId = 12345,
                 Branch = "Branch A",
                 Region = "North",
                 Department = "Department X"
             };
        }
    }
}