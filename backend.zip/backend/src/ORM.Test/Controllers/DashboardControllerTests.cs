﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using ORM.Api.Controllers;
using ORM.Application.Interfaces.Dashboard;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using Fcmb.Shared.Models.Responses;

namespace ORM.Tests.Controllers
{
    public class DashboardControllerTests
    {
        private readonly Mock<IDashboardService> _mockDashboardService;
        private readonly DashboardController _controller;

        public DashboardControllerTests()
        {
            _mockDashboardService = new Mock<IDashboardService>();
            _controller = new DashboardController(_mockDashboardService.Object);
        }

        [Fact]
        public async Task GetLossDataTrend_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            var expectedResponse = new ListResponse<LossTrendResponse>("Success")
            {
                Data = new List<LossTrendResponse>
                {
                    new LossTrendResponse { Name = "Test", Frequency = 5, Value = 100.5m }
                },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetLossDataTrend(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetLossDataTrend(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<LossTrendResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Name, actualResponse.Data.First().Name);
        }

        [Fact]
        public async Task GetLossDataTrend_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            _mockDashboardService.Setup(s => s.GetLossDataTrend(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetLossDataTrend(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetOperationalRiskLossesVsFraudLoss_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            var expectedResponse = new ListResponse<OperationalRiskLossVsFraudLossResponse>("Success")
            {
                Data = new List<OperationalRiskLossVsFraudLossResponse>
                {
                    new OperationalRiskLossVsFraudLossResponse { Month = "January", Fraud = 1000m }
                },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetOperationalRiskLossesVsFraudLoss(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetOperationalRiskLossesVsFraudLoss(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<OperationalRiskLossVsFraudLossResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Month, actualResponse.Data.First().Month);
        }

        [Fact]
        public async Task GetOperationalRiskLossesVsFraudLoss_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            _mockDashboardService.Setup(s => s.GetOperationalRiskLossesVsFraudLoss(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetOperationalRiskLossesVsFraudLoss(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetRegionalInternalFraudChart_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            var expectedResponse = new ListResponse<RegionalInternalFraudResponse>("Success")
            {
                Data = new List<RegionalInternalFraudResponse>
                {
                    new RegionalInternalFraudResponse { Region = "North", Value = 500m }
                },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetRegionalInternalFraudChart(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetRegionalInternalFraudChart(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<RegionalInternalFraudResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Region, actualResponse.Data.First().Region);
        }

        [Fact]
        public async Task GetRegionalInternalFraudChart_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            _mockDashboardService.Setup(s => s.GetRegionalInternalFraudChart(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetRegionalInternalFraudChart(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }
        [Fact]
        public async Task GetOperationalRiskLosses_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            var expectedResponse = new ListResponse<OperationalRiskLossResponse>("Success")
            {
                Data = new List<OperationalRiskLossResponse>
            {
                new OperationalRiskLossResponse { Id = 1, Label = "Risk A", Value = 1000 }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetOperationalRiskLosses(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetOperationalRiskLosses(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<OperationalRiskLossResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Label, actualResponse.Data.First().Label);
        }

        [Fact]
        public async Task GetOperationalRiskLosses_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            _mockDashboardService.Setup(s => s.GetOperationalRiskLosses(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetOperationalRiskLosses(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetRootCauseAnalysisForActualLoss_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            var expectedResponse = new ListResponse<RootCauseAnalysisResponse>("Success")
            {
                Data = new List<RootCauseAnalysisResponse>
            {
                new RootCauseAnalysisResponse { Id = 1, Label = "Cause A", Value = 500 }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetRootCauseAnalysisForActualLoss(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetRootCauseAnalysisForActualLoss(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<RootCauseAnalysisResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Label, actualResponse.Data.First().Label);
        }

        [Fact]
        public async Task GetRootCauseAnalysisForActualLoss_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            _mockDashboardService.Setup(s => s.GetRootCauseAnalysisForActualLoss(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetRootCauseAnalysisForActualLoss(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetGrossVsRecoveryVsNetLoss_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            var expectedResponse = new ListResponse<GrossVsRecoveryVsNetLossResponse>("Success")
            {
                Data = new List<GrossVsRecoveryVsNetLossResponse>
            {
                new GrossVsRecoveryVsNetLossResponse { Id = 1, Label = "Gross", Value = 1000m }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetGrossVsRecoveryVsNetLoss(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetGrossVsRecoveryVsNetLoss(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<GrossVsRecoveryVsNetLossResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Label, actualResponse.Data.First().Label);
        }

        [Fact]
        public async Task GetGrossVsRecoveryVsNetLoss_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new BaseDashboardChartsRequest();
            _mockDashboardService.Setup(s => s.GetGrossVsRecoveryVsNetLoss(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetGrossVsRecoveryVsNetLoss(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetRiskOccurenceCharts_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new FilterRiskReportRequest();
            var expectedResponse = new ListResponse<RiskChartReportResponse>("Success")
            {
                Data = new List<RiskChartReportResponse>
            {
                new RiskChartReportResponse { Title = "Risk Chart", Charts = new List<BaseChartsResponse>() }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetRiskOccurenceCharts(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetRiskOccurenceCharts(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<RiskChartReportResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Title, actualResponse.Data.First().Title);
        }

        [Fact]
        public async Task GetRiskOccurenceCharts_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new FilterRiskReportRequest();
            _mockDashboardService.Setup(s => s.GetRiskOccurenceCharts(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetRiskOccurenceCharts(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }
        [Fact]
        public async Task GetTrendOfOperationalRiskSource_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new FilterRiskReportRequest();
            var expectedResponse = new ListResponse<TrendOfOperationalRiskSourceResponse>("Success")
            {
                Data = new List<TrendOfOperationalRiskSourceResponse>
            {
                new TrendOfOperationalRiskSourceResponse
                {
                    Title = "Trend",
                    CurrentYear = 2023,
                    CurrentYearMinus1 = 2022,
                    CurrentYearMinus2 = 2021
                }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetTrendOfOperationalRiskSource(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetTrendOfOperationalRiskSource(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<TrendOfOperationalRiskSourceResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Title, actualResponse.Data.First().Title);
        }

        [Fact]
        public async Task GetTrendOfOperationalRiskSource_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new FilterRiskReportRequest();
            _mockDashboardService.Setup(s => s.GetTrendOfOperationalRiskSource(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetTrendOfOperationalRiskSource(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetKeyRiskIndicator_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new FilterKeyRiskIndicatorRequest();
            var expectedResponse = new ListResponse<KeyRiskIndicatorResponse>("Success")
            {
                Data = new List<KeyRiskIndicatorResponse>
            {
                new KeyRiskIndicatorResponse
                {
                    MetricMasterId = 1,
                    MetricName = "KRI 1",
                    Threshold = "High"
                }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetKeyRiskIndicator(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetKeyRiskIndicator(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<KeyRiskIndicatorResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().MetricName, actualResponse.Data.First().MetricName);
        }

        [Fact]
        public async Task GetKeyRiskIndicator_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new FilterKeyRiskIndicatorRequest();
            _mockDashboardService.Setup(s => s.GetKeyRiskIndicator(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetKeyRiskIndicator(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetKYCComplianceChart_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new FilterKriReportMetricsRequest();
            var expectedResponse = new ListResponse<KycComplianceResponse>("Success")
            {
                Data = new List<KycComplianceResponse>
            {
                new KycComplianceResponse
                {
                    Name = "Compliant",
                    count = 100,
                    Value = 80.5m
                }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetKYCComplianceChart(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetKYCComplianceChart(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<KycComplianceResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Name, actualResponse.Data.First().Name);
        }

        [Fact]
        public async Task GetKYCComplianceChart_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new FilterKriReportMetricsRequest();
            _mockDashboardService.Setup(s => s.GetKYCComplianceChart(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetKYCComplianceChart(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }

        [Fact]
        public async Task GetNonFunctionalCCTVAndPatches_ReturnsOkResult_WhenServiceReturnsData()
        {
            // Arrange
            var request = new FilterKriReportMetricsRequest();
            var expectedResponse = new ListResponse<NonFunctionalCctvAndPatchesResponse>("Success")
            {
                Data = new List<NonFunctionalCctvAndPatchesResponse>
            {
                new NonFunctionalCctvAndPatchesResponse
                {
                    Name = "Non-Functional CCTV",
                    Value = 5
                }
            },
                Total = 1
            };
            _mockDashboardService.Setup(s => s.GetNonFunctionalCCTVAndPatches(request)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.GetNonFunctionalCCTVAndPatches(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var actualResponse = Assert.IsType<ListResponse<NonFunctionalCctvAndPatchesResponse>>(okResult.Value);
            Assert.Equal(expectedResponse.Description, actualResponse.Description);
            Assert.Equal(expectedResponse.Code, actualResponse.Code);
            Assert.Equal(expectedResponse.Total, actualResponse.Total);
            Assert.Equal(expectedResponse.Data.First().Name, actualResponse.Data.First().Name);
        }

        [Fact]
        public async Task GetNonFunctionalCCTVAndPatches_ReturnsBadRequest_WhenExceptionOccurs()
        {
            // Arrange
            var request = new FilterKriReportMetricsRequest();
            _mockDashboardService.Setup(s => s.GetNonFunctionalCCTVAndPatches(request))
                .ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetNonFunctionalCCTVAndPatches(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Equal("Test exception", badRequestResult.Value);
        }
    }
}