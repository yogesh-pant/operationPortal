namespace ORM.Test.Controllers
{
    using System;
    using System.Threading.Tasks;
    using FakeItEasy;
    using Fcmb.Shared.Models.Responses;
    using FluentAssertions;
    using ORM.Api.Controllers;
    using ORM.Application.Models.Requests;
    using ORM.Application.Models.Responses;
    using ORM.Infrastructure.Services;
    using Xunit;

    public class RiskControllerTests
    {
        private RiskController _testClass;
        private IRiskService _riskService;

        public RiskControllerTests()
        {
            _riskService = A.Fake<IRiskService>();
            _testClass = new RiskController(_riskService);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new RiskController(_riskService);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetRiskGridAsync()
        {
            // Arrange
            var request = new FilterRiskListRequest();

            A.CallTo(() => _riskService.GetRiskGridAsync(A<FilterRiskListRequest>._)).Returns(new ListResponse<RiskGridResponse>("TestValue804811612", "TestValue965284633"));

            // Act
            var result = await _testClass.GetRiskGridAsync(request);

            // Assert
            A.CallTo(() => _riskService.GetRiskGridAsync(A<FilterRiskListRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetRiskGridAsyncException()
        {
            // Arrange
            var request = new FilterRiskListRequest();

            A.CallTo(() => _riskService.GetRiskGridAsync(A<FilterRiskListRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetRiskGridAsync(request);

            // Assert
            A.CallTo(() => _riskService.GetRiskGridAsync(A<FilterRiskListRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCreateRiskDataAsync()
        {
            // Arrange
            var request = new CreateRiskDataRequest();

            A.CallTo(() => _riskService.CreateRiskDataAsync(A<CreateRiskDataRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1461929338", "TestValue1798632233"));

            // Act
            var result = await _testClass.CreateRiskDataAsync(request);

            // Assert
            A.CallTo(() => _riskService.CreateRiskDataAsync(A<CreateRiskDataRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCreateRiskDataAsyncException()
        {
            // Arrange
            var request = new CreateRiskDataRequest();

            A.CallTo(() => _riskService.CreateRiskDataAsync(A<CreateRiskDataRequest>._)).Throws(new Exception("Test exception", new Exception("Inner exception message")));

            // Act
            var result = await _testClass.CreateRiskDataAsync(request);

            // Assert
            //A.CallTo(() => _riskService.CreateRiskDataAsync(A<CreateRiskDataRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallEditRiskDataAsync()
        {
            // Arrange
            var request = new EditRiskDataRequest();

            A.CallTo(() => _riskService.EditRiskDataAsync(A<EditRiskDataRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1677986683", "TestValue1118723378"));

            // Act
            var result = await _testClass.EditRiskDataAsync(request);

            // Assert
            A.CallTo(() => _riskService.EditRiskDataAsync(A<EditRiskDataRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallEditRiskDataAsyncException()
        {
            // Arrange
            var request = new EditRiskDataRequest();

            A.CallTo(() => _riskService.EditRiskDataAsync(A<EditRiskDataRequest>._)).Throws(new Exception("Test exception", new Exception("Inner exception message")));
            // Act
            var result = await _testClass.EditRiskDataAsync(request);

            // Assert
            A.CallTo(() => _riskService.EditRiskDataAsync(A<EditRiskDataRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateRiskDataAsync()
        {
            // Arrange
            var request = new UpdateRiskDataRequest();

            A.CallTo(() => _riskService.UpdateRiskDataAsync(A<UpdateRiskDataRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1396055342", "TestValue537328626"));

            // Act
            var result = await _testClass.UpdateRiskDataAsync(request);

            // Assert
            A.CallTo(() => _riskService.UpdateRiskDataAsync(A<UpdateRiskDataRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateRiskDataAsyncError()
        {
            // Arrange
            var request = new UpdateRiskDataRequest();

            A.CallTo(() => _riskService.UpdateRiskDataAsync(A<UpdateRiskDataRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.UpdateRiskDataAsync(request);

            // Assert
            A.CallTo(() => _riskService.UpdateRiskDataAsync(A<UpdateRiskDataRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallGetRiskDoc()
        {
            // Arrange
            var request = new GetDocRequest();

            A.CallTo(() => _riskService.GetRiskReportDoc(A<GetDocRequest>._)).Returns(new ListResponse<RiskDoc>("TestValue18599517", "TestValue845577737"));

            // Act
            var result = await _testClass.GetRiskDoc(request);

            // Assert
            A.CallTo(() => _riskService.GetRiskReportDoc(A<GetDocRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetRiskDocError()
        {
            // Arrange
            var request = new GetDocRequest();

            A.CallTo(() => _riskService.GetRiskReportDoc(A<GetDocRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetRiskDoc(request);

            // Assert
            A.CallTo(() => _riskService.GetRiskReportDoc(A<GetDocRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateRiskStatusAsync()
        {
            // Arrange
            var request = new UpdateRiskStatusRequest();

            A.CallTo(() => _riskService.UpdateRiskStatusAsync(A<UpdateRiskStatusRequest>._)).Returns(new ListResponse<ReturnId>("TestValue2107977999", "TestValue16440215"));

            // Act
            var result = await _testClass.UpdateRiskStatusAsync(request);

            // Assert
            A.CallTo(() => _riskService.UpdateRiskStatusAsync(A<UpdateRiskStatusRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateRiskStatusAsyncError()
        {
            // Arrange
            var request = new UpdateRiskStatusRequest();

            A.CallTo(() => _riskService.UpdateRiskStatusAsync(A<UpdateRiskStatusRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.UpdateRiskStatusAsync(request);

            // Assert
            A.CallTo(() => _riskService.UpdateRiskStatusAsync(A<UpdateRiskStatusRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }
    }
}