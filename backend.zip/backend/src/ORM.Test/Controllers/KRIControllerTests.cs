namespace ORM.Test.Controllers
{
    using System;
    using System.Threading.Tasks;
    using FakeItEasy;
    using Fcmb.Shared.Models.Responses;
    using FluentAssertions;
    using Microsoft.AspNetCore.Mvc;
    using ORM.Api.Controllers;
    using ORM.Application.Interfaces.Role;
    using ORM.Application.Models.Requests;
    using ORM.Application.Models.Responses;
    using ORM.Infrastructure.Services;
    using Xunit;

    public class KriControllerTests
    {
        private KriController _testClass;
        private IKriService _kriService;
        private ILogger<KriController> _logger;

        public KriControllerTests()
        {
            _kriService = A.Fake<IKriService>();
            _logger = A.Fake<ILogger<KriController>>();
            _testClass = new KriController(_kriService, _logger);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new KriController(_kriService, _logger);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetKriGridData()
        {
            // Arrange
            var request = new KriGridRequest();

            A.CallTo(() => _kriService.GetKriGridAsync(A<KriGridRequest>._)).Returns(new ListResponse<KriPreviewResponse>("TestValue664206469", "TestValue1379329023"));

            // Act
            var result = await _testClass.GetKriGridData(request);

            // Assert
            A.CallTo(() => _kriService.GetKriGridAsync(A<KriGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }
        [Fact]
        public async Task CanCallGetKriGridDataError()
        {
            // Arrange
            var request = new KriGridRequest();
            A.CallTo(() => _kriService.GetKriGridAsync(A<KriGridRequest>._))
                .Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetKriGridData(request);

            // Assert
            A.CallTo(() => _kriService.GetKriGridAsync(A<KriGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
            result.Result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task CanCallGetKriGridReportData()
        {
            // Arrange
            var request = new KriGridRequest();

            A.CallTo(() => _kriService.GetKriReportGridAsync(A<KriGridRequest>._)).Returns(new ListResponse<KriDataGridResponse>("TestValue358405901", "TestValue1734028692"));

            // Act
            var result = await _testClass.GetKriGridReportData(request);

            // Assert
            A.CallTo(() => _kriService.GetKriReportGridAsync(A<KriGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetKriGridReportDataError()
        {
            // Arrange
            var request = new KriGridRequest();

            A.CallTo(() => _kriService.GetKriReportGridAsync(A<KriGridRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetKriGridReportData(request);

            // Assert
            A.CallTo(() => _kriService.GetKriReportGridAsync(A<KriGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetNewKriData()
        {
            // Arrange
            var request = new GetNewKriRequest();

            A.CallTo(() => _kriService.GetNewKriAsync(A<GetNewKriRequest>._)).Returns(new ListResponse<CreateKriResponse>("TestValue755864513", "TestValue1344704790"));

            // Act
            var result = await _testClass.GetNewKriData(request);

            // Assert
            A.CallTo(() => _kriService.GetNewKriAsync(A<GetNewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetNewKriDataNull()
        {
            // Arrange
            var request = new GetNewKriRequest();

            A.CallTo(() => _kriService.GetNewKriAsync(A<GetNewKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetNewKriData(request);

            // Assert
            A.CallTo(() => _kriService.GetNewKriAsync(A<GetNewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallCreateNewKriReport()
        {
            // Arrange
            var request = new AddKriRequest();

            A.CallTo(() => _kriService.AddKriInfo(A<AddKriRequest>._)).Returns(new ListResponse<NewKriReportResponse>("TestValue2009779734", "TestValue674976368"));

            // Act
            var result = await _testClass.CreateNewKriReport(request);

            // Assert
            A.CallTo(() => _kriService.AddKriInfo(A<AddKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCreateNewKriReportException()
        {
            // Arrange
            var request = new AddKriRequest();

            A.CallTo(() => _kriService.AddKriInfo(A<AddKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.CreateNewKriReport(request);

            // Assert
            A.CallTo(() => _kriService.AddKriInfo(A<AddKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallpostKriReport()
        {
            // Arrange
            var request = new AddKriReport();

            A.CallTo(() => _kriService.AddKrimetric(A<AddKriReport>._)).Returns(new ListResponse<ReturnId>("TestValue201480402", "TestValue1781589337"));

            // Act
            var result = await _testClass.PostKriReport(request);

            // Assert
            A.CallTo(() => _kriService.AddKrimetric(A<AddKriReport>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallpostKriReportException()
        {
            // Arrange
            var request = new AddKriReport();

            A.CallTo(() => _kriService.AddKrimetric(A<AddKriReport>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.PostKriReport(request);

            // Assert
            A.CallTo(() => _kriService.AddKrimetric(A<AddKriReport>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetPreviewKriApi()
        {
            // Arrange
            var request = new GetPreviewKriMultipleRequest();

            A.CallTo(() => _kriService.GetPreviewKriAsync(A<GetPreviewKriMultipleRequest>._)).Returns(new ListResponse<KriPreviewResponse>("TestValue370631472", "TestValue201193513"));

            // Act
            var result = await _testClass.GetPreviewKriApi(request);

            // Assert
            A.CallTo(() => _kriService.GetPreviewKriAsync(A<GetPreviewKriMultipleRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetPreviewKriApiException()
        {
            // Arrange
            var request = new GetPreviewKriMultipleRequest();

            A.CallTo(() => _kriService.GetPreviewKriAsync(A<GetPreviewKriMultipleRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetPreviewKriApi(request);

            // Assert
            A.CallTo(() => _kriService.GetPreviewKriAsync(A<GetPreviewKriMultipleRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetDetailKriApi()
        {
            // Arrange
            var request = new GetPreviewKriRequest();

            A.CallTo(() => _kriService.GetDetailKriReportAsync(A<GetPreviewKriRequest>._)).Returns(new ListResponse<KriPreviewResponse>("TestValue525214030", "TestValue1747954987"));

            // Act
            var result = await _testClass.GetDetailKriApi(request);

            // Assert
            A.CallTo(() => _kriService.GetDetailKriReportAsync(A<GetPreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetDetailKriApiException()
        {
            // Arrange
            var request = new GetPreviewKriRequest();

            A.CallTo(() => _kriService.GetDetailKriReportAsync(A<GetPreviewKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetDetailKriApi(request);

            // Assert
            A.CallTo(() => _kriService.GetDetailKriReportAsync(A<GetPreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdatePreviewKriApi()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.UpdatePreviewKriAsync(A<UpdatePreviewKriRequest>._)).Returns(new ListResponse<string>("TestValue23005183", "TestValue284668005"));

            // Act
            var result = await _testClass.UpdatePreviewKriApi(request);

            // Assert
            A.CallTo(() => _kriService.UpdatePreviewKriAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdatePreviewKriApiException()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.UpdatePreviewKriAsync(A<UpdatePreviewKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.UpdatePreviewKriApi(request);

            // Assert
            A.CallTo(() => _kriService.UpdatePreviewKriAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallupdateFinalKriApi()
        {
            // Arrange
            var request = new FinalKriReport();

            A.CallTo(() => _kriService.updateKriApproval(A<FinalKriReport>._)).Returns(new ListResponse<string>("TestValue1274168071", "TestValue2025883251"));

            // Act
            var result = await _testClass.UpdateFinalKriApi(request);

            // Assert
            A.CallTo(() => _kriService.updateKriApproval(A<FinalKriReport>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallupdateFinalKriApiException()
        {
            // Arrange
            var request = new FinalKriReport();

            A.CallTo(() => _kriService.updateKriApproval(A<FinalKriReport>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.UpdateFinalKriApi(request);

            // Assert
            A.CallTo(() => _kriService.updateKriApproval(A<FinalKriReport>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetMetricDataApi()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.GetDetailKriMetricAsync(A<UpdatePreviewKriRequest>._)).Returns(new ListResponse<KriPreviewResponse>("TestValue972953640", "TestValue81029402"));

            // Act
            var result = await _testClass.GetMetricDataApi(request);

            // Assert
            A.CallTo(() => _kriService.GetDetailKriMetricAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetMetricDataApiException()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.GetDetailKriMetricAsync(A<UpdatePreviewKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetMetricDataApi(request);

            // Assert
            A.CallTo(() => _kriService.GetDetailKriMetricAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetEditkridata()
        {
            // Arrange
            var request = new EditKriRequest();

            A.CallTo(() => _kriService.GetEditKriReportAsync(A<EditKriRequest>._)).Returns(new ListResponse<EditKriResponse>("TestValue1645950980", "TestValue1151726842"));

            // Act
            var result = await _testClass.GetEditkridata(request);

            // Assert
            A.CallTo(() => _kriService.GetEditKriReportAsync(A<EditKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetEditkridataException()
        {
            // Arrange
            var request = new EditKriRequest();

            A.CallTo(() => _kriService.GetEditKriReportAsync(A<EditKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetEditkridata(request);

            // Assert
            A.CallTo(() => _kriService.GetEditKriReportAsync(A<EditKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallDeleteKriReportApi()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.DeleteKriReportAsync(A<UpdatePreviewKriRequest>._)).Returns(new ObjectResponse<string>("TestValue574517411", "TestValue1540604915"));

            // Act
            var result = await _testClass.DeleteKriReportApi(request);

            // Assert
            A.CallTo(() => _kriService.DeleteKriReportAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallDeleteKriReportApiEception()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.DeleteKriReportAsync(A<UpdatePreviewKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.DeleteKriReportApi(request);

            // Assert
            A.CallTo(() => _kriService.DeleteKriReportAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallRemoveMetric()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.RemoveKriMetricAsync(A<UpdatePreviewKriRequest>._)).Returns(new ListResponse<string>("TestValue272099354", "TestValue1104715927"));

            // Act
            var result = await _testClass.RemoveMetric(request);

            // Assert
            A.CallTo(() => _kriService.RemoveKriMetricAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CanCallRemoveMetricException()
        {
            // Arrange
            var request = new UpdatePreviewKriRequest();

            A.CallTo(() => _kriService.RemoveKriMetricAsync(A<UpdatePreviewKriRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.RemoveMetric(request);

            // Assert
            A.CallTo(() => _kriService.RemoveKriMetricAsync(A<UpdatePreviewKriRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }
    }
}