namespace ORM.Test.Controllers
{
    using System;
    using System.Threading.Tasks;
    using FakeItEasy;
    using Fcmb.Shared.Models.Responses;
    using FluentAssertions;
    using ORM.Api.Controllers;
    using ORM.Application.Interfaces.Role;
    using ORM.Application.Models.Requests;
    using ORM.Application.Models.Responses;
    using Xunit;

    public class KriMasterControllerTests
    {
        private KriMasterController _testClass;
        private IKriMasterService _kriMasterService;

        public KriMasterControllerTests()
        {
            _kriMasterService = A.Fake<IKriMasterService>();
            _testClass = new KriMasterController(_kriMasterService);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new KriMasterController(_kriMasterService);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallGetKriMasterGridAsync()
        {
            // Arrange
            var request = new GetKriMasterGridRequest();


            var mockdata = GetKriMasterGridResponseMockData();

            A.CallTo(() => _kriMasterService.GetKriMasterGridAsync(A<GetKriMasterGridRequest>._)).Returns(new ListResponse<GetKriMasterGridResponse>("TestValue87740959", "TestValue490561021"));

            // Act
            var result = await _testClass.GetKriMasterGridAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.GetKriMasterGridAsync(A<GetKriMasterGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task CanCallGetKriMasterGridAsyncError()
        {
            // Arrange
            var request = new GetKriMasterGridRequest();

            A.CallTo(() => _kriMasterService.GetKriMasterGridAsync(A<GetKriMasterGridRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.GetKriMasterGridAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.GetKriMasterGridAsync(A<GetKriMasterGridRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();

        }

        [Fact]
        public async Task CanCallCreateKriMasterAsync()
        {
            // Arrange
            var request = new CreateKriMasterRequest()
            {
                KRIMetricId = "KRI-001",
                LocationId = 123,
                LocationType = "Branch",
                MetricName = "Example Metric",
                Frequency = "Monthly",
                AppetiteUpperBound = "High",
                AppetiteLowerBound = "Low",
                AppetiteType = "Percentage",
                ToleranceLowerBound = "Medium",
                ToleranceUpperBound = "High",
                ToleranceType = "Percentage",
                EscalationLowerBound = "High",
                EscalationUpperBound = "Very High",
                EscalationType = "Number",
                IsActive = true,
                CreatedById = 456
            };

            A.CallTo(() => _kriMasterService.CreateKriMasterAsync(A<CreateKriMasterRequest>._)).Returns(new ListResponse<ReturnId>("TestValue534340457", "TestValue792114455"));

            // Act
            var result = await _testClass.CreateKriMasterAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.CreateKriMasterAsync(A<CreateKriMasterRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCreateKriMasterAsyncError()
        {
            // Arrange
            var request = new CreateKriMasterRequest();

            A.CallTo(() => _kriMasterService.CreateKriMasterAsync(A<CreateKriMasterRequest>._)).Throws(new Exception("Test exception", new Exception("Inner exception message")));

            // Act
            var result = await _testClass.CreateKriMasterAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.CreateKriMasterAsync(A<CreateKriMasterRequest>._)).MustHaveHappened();
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateKriMasterAsync()
        {
            // Arrange
            var request = new UpdateKriMasterRequest();

            A.CallTo(() => _kriMasterService.UpdateKriMasterAsync(A<UpdateKriMasterRequest>._)).Returns(new ListResponse<ReturnId>("TestValue534340457", "TestValue792114455"));

            // Act
            var result = await _testClass.UpdateKriMasterAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.UpdateKriMasterAsync(A<UpdateKriMasterRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallUpdateKriMasterAsyncError()
        {
            // Arrange
            var request = new UpdateKriMasterRequest()
            {
                Id = 123,
                MetricName = "Updated Metric Name",
                Frequency = "Weekly",
                AppetiteUpperBound = "Very High",
                AppetiteLowerBound = "Medium",
                AppetiteType = "Percentage",
                ToleranceLowerBound = "Low",
                ToleranceUpperBound = "Medium",
                ToleranceType = "Number",
                EscalationLowerBound = "High",
                EscalationUpperBound = "Very High",
                EscalationType = "Percentage",
                IsActive = true,
                ModifiedById = 456
            };

            A.CallTo(() => _kriMasterService.UpdateKriMasterAsync(A<UpdateKriMasterRequest>._)).Throws(new Exception("Test exception", new Exception("Inner exception message")));

            // Act
            var result = await _testClass.UpdateKriMasterAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.UpdateKriMasterAsync(A<UpdateKriMasterRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallToggleKriMasterStatusAsync()
        {
            // Arrange
            var request = new ToggleKriMasterStatusRequest();

            A.CallTo(() => _kriMasterService.ToggleKriMasterStatusAsync(A<ToggleKriMasterStatusRequest>._)).Returns(new ListResponse<ReturnId>("TestValue1194545730", "TestValue1392548309"));

            // Act
            var result = await _testClass.ToggleKriMasterStatusAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.ToggleKriMasterStatusAsync(A<ToggleKriMasterStatusRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallToggleKriMasterStatusAsyncError()
        {
            // Arrange
            var request = new ToggleKriMasterStatusRequest()
            {
                Id = 123,
                IsActive = true
            };

            A.CallTo(() => _kriMasterService.ToggleKriMasterStatusAsync(A<ToggleKriMasterStatusRequest>._)).Throws(new Exception("Test exception"));

            // Act
            var result = await _testClass.ToggleKriMasterStatusAsync(request);

            // Assert
            A.CallTo(() => _kriMasterService.ToggleKriMasterStatusAsync(A<ToggleKriMasterStatusRequest>._)).MustHaveHappened();

            result.Should().NotBeNull();
        }


        private static GetKriMasterGridResponse GetKriMasterGridResponseMockData()
        {
            return new GetKriMasterGridResponse
            {
                Id = 1,
                KRIMetricId = "KRI001",
                LocationId = 1001,
                LocationName = "Branch A",
                Region = "North",
                LocationType = "Branch",
                MetricName = "Revenue",
                Frequency = "Monthly",
                AppetiteUpperBound = "1000",
                AppetiteLowerBound = "500",
                AppetiteType = "Currency",
                ToleranceLowerBound = "200",
                ToleranceUpperBound = "700",
                ToleranceType = "Currency",
                EscalationLowerBound = "800",
                EscalationUpperBound = "1200",
                EscalationType = "Currency",
                IsActive = true,
                CreatedById = 101,
                CreatedByName = "John Doe",
                ModifiedById = 102,
                ModifiedByName = "Jane Smith",
                CreatedDate = DateTime.Parse("2023-01-15"),
                ModifiedDate = DateTime.Parse("2023-02-20")
            };
        }


    }
}