﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Xunit;
using ORM.Application.Models.Requests;

namespace ORM.Test.Models.Requests
{
    public class RequestModelsTests
    {
        [Fact]
        public void FilterUserRequest_Properties_SetAndGetCorrectly()
        {
            var request = new FilterUserRequest
            {
                userName = "John Doe",
                userRole = "Admin",
                userSubRoleId = 1,
                status = "Active",
                userchangestatus = "Pending"
            };

            Assert.Equal("John Doe", request.userName);
            Assert.Equal("Admin", request.userRole);
            Assert.Equal(1, request.userSubRoleId);
            Assert.Equal("Active", request.status);
            Assert.Equal("Pending", request.userchangestatus);
        }

        [Fact]
        public void FilterRoleRequest_Properties_SetAndGetCorrectly()
        {
            var request = new FilterRoleRequest
            {
                roleTitle = "Manager",
                status = true
            };

            Assert.Equal("Manager", request.roleTitle);
            Assert.True(request.status);
        }

        [Fact]
        public void GetNewKriRequest_Properties_SetAndGetCorrectly()
        {
            var request = new GetNewKriRequest
            {
                locationType = "Branch",
                locationId = 1,
                frequecy = "Monthly",
                active = true
            };

            Assert.Equal("Branch", request.locationType);
            Assert.Equal(1, request.locationId);
            Assert.Equal("Monthly", request.frequecy);
            Assert.True(request.active);
        }

        [Fact]
        public void GetPreviewKriRequest_Properties_SetAndGetCorrectly()
        {
            var request = new GetPreviewKriRequest
            {
                ids = new long[] { 1, 2, 3 }
            };

            Assert.Equal(new long[] { 1, 2, 3 }, request.ids);
        }

        [Fact]
        public void GetPreviewKriMultipleRequest_Properties_SetAndGetCorrectly()
        {
            var request = new GetPreviewKriMultipleRequest
            {
                ids = new long[] { 1, 2, 3 },
                rids = new long[] { 4, 5, 6 }
            };

            Assert.Equal(new long[] { 1, 2, 3 }, request.ids);
            Assert.Equal(new long[] { 4, 5, 6 }, request.rids);
        }

        [Fact]
        public void UpdatePreviewKriRequest_Properties_SetAndGetCorrectly()
        {
            var request = new UpdatePreviewKriRequest
            {
                id = 1
            };

            Assert.Equal(1, request.id);
        }

        [Fact]
        public void EditKriRequest_Properties_SetAndGetCorrectly()
        {
            var request = new EditKriRequest
            {
                id = 1
            };

            Assert.Equal(1, request.id);
        }

        [Fact]
        public void FinalKriReport_Properties_SetAndGetCorrectly()
        {
            var request = new FinalKriReport
            {
                id = 1,
                status = "Approved",
                comments = "Test comments",
                approvedByid = 2
            };

            Assert.Equal(1, request.id);
            Assert.Equal("Approved", request.status);
            Assert.Equal("Test comments", request.comments);
            Assert.Equal(2, request.approvedByid);
        }

        [Fact]
        public void KriGridRequest_Properties_SetAndGetCorrectly()
        {
            var request = new KriGridRequest
            {
                RefNo = "REF001",
                LocationId = 1,
                LocationType = "Branch",
                Branch = "Main Branch",
                Department = "Finance",
                Region = "North",
                Status = "Active",
                MinDate = new DateTime(2023, 1, 1),
                MaxDate = new DateTime(2023, 12, 31)
            };

            Assert.Equal("REF001", request.RefNo);
            Assert.Equal(1, request.LocationId);
            Assert.Equal("Branch", request.LocationType);
            Assert.Equal("Main Branch", request.Branch);
            Assert.Equal("Finance", request.Department);
            Assert.Equal("North", request.Region);
            Assert.Equal("Active", request.Status);
            Assert.Equal(new DateTime(2023, 1, 1), request.MinDate);
            Assert.Equal(new DateTime(2023, 12, 31), request.MaxDate);
        }

        [Fact]
        public void AddNewUserRequest_Properties_SetAndGetCorrectly()
        {
            var request = new AddNewUserRequest
            {
                UserName = "John Doe",
                LocationIds = new long[] { 1, 2 },
                StaffId = "S001",
                RoleId = 1,
                SubRoleId = 2,
                Status = "Active"
            };

            Assert.Equal("John Doe", request.UserName);
            Assert.Equal(new long[] { 1, 2 }, request.LocationIds);
            Assert.Equal("S001", request.StaffId);
            Assert.Equal(1, request.RoleId);
            Assert.Equal(2, request.SubRoleId);
            Assert.Equal("Active", request.Status);
        }

        [Fact]
        public void EditUserRequest_Properties_SetAndGetCorrectly()
        {
            var request = new EditUserRequest
            {
                Id = 1,
                LocationIds = new long[] { 1, 2 },
                RoleId = 1,
                SubRoleId = 2,
                Status = "Active"
            };

            Assert.Equal(1, request.Id);
            Assert.Equal(new long[] { 1, 2 }, request.LocationIds);
            Assert.Equal(1, request.RoleId);
            Assert.Equal(2, request.SubRoleId);
            Assert.Equal("Active", request.Status);
        }

        [Fact]
        public void ReviewUserChangeRequest_Properties_SetAndGetCorrectly()
        {
            var request = new ReviewUserChangeRequest
            {
                Id = 1,
                ChangeReviewComments = "Approved changes"
            };

            Assert.Equal(1, request.Id);
            Assert.Equal("Approved changes", request.ChangeReviewComments);
        }

        [Fact]
        public void AddKriRequest_Properties_SetAndGetCorrectly()
        {
            var request = new AddKriRequest
            {
                RefNum = 1001,
                ReportingPeriod = "Q1 2023",
                ReportingFrequency = "Quarterly",
                ValidatorILOUserId = 1,
                DateOfOccurance = new DateTime(2023, 1, 1),
                LocationId = 1,
                LocationType = "Branch",
                Status = "Active",
                CreatedById = 1,
                kris = new long[] { 1, 2, 3 },
                removeKris = new long[] { 4, 5 }
            };

            Assert.Equal(1001, request.RefNum);
            Assert.Equal("Q1 2023", request.ReportingPeriod);
            Assert.Equal("Quarterly", request.ReportingFrequency);
            Assert.Equal(1, request.ValidatorILOUserId);
            Assert.Equal(new DateTime(2023, 1, 1), request.DateOfOccurance);
            Assert.Equal(1, request.LocationId);
            Assert.Equal("Branch", request.LocationType);
            Assert.Equal("Active", request.Status);
            Assert.Equal(1, request.CreatedById);
            Assert.Equal(new long[] { 1, 2, 3 }, request.kris);
            Assert.Equal(new long[] { 4, 5 }, request.removeKris);
        }

        [Fact]
        public void AddKriReport_Properties_SetAndGetCorrectly()
        {
            var request = new AddKriReport
            {
                masterId = 1,
                reportId = 2,
                metricId = 3,
                DateOccurance = new DateTime(2023, 1, 1),
                Description = "Test description",
                AmountInvolved = "1000",
                Currency = "USD",
                MitigationPlan = "Test plan",
                NumberPercentage = "50%",
                RiskAppetiteThreshold = "Low"
            };

            Assert.Equal(1, request.masterId);
            Assert.Equal(2, request.reportId);
            Assert.Equal(3, request.metricId);
            Assert.Equal(new DateTime(2023, 1, 1), request.DateOccurance);
            Assert.Equal("Test description", request.Description);
            Assert.Equal("1000", request.AmountInvolved);
            Assert.Equal("USD", request.Currency);
            Assert.Equal("Test plan", request.MitigationPlan);
            Assert.Equal("50%", request.NumberPercentage);
            Assert.Equal("Low", request.RiskAppetiteThreshold);
        }

        [Fact]
        public void GetKriMasterGridRequest_Properties_SetAndGetCorrectly()
        {
            var request = new GetKriMasterGridRequest
            {
                LocationId = 1,
                LocationName = "Main Branch",
                LocationType = "Branch",
                MetricName = "Test Metric",
                Frequency = "Monthly",
                IsActive = true
            };

            Assert.Equal(1, request.LocationId);
            Assert.Equal("Main Branch", request.LocationName);
            Assert.Equal("Branch", request.LocationType);
            Assert.Equal("Test Metric", request.MetricName);
            Assert.Equal("Monthly", request.Frequency);
            Assert.True(request.IsActive);
        }
        [Fact]
        public void CreateKriMasterRequest_Properties_SetAndGetCorrectly()
        {
            var request = new CreateKriMasterRequest
            {
                KRIMetricId = "KRI001",
                LocationId = 1,
                LocationType = "Branch",
                MetricName = "Test Metric",
                Frequency = "Monthly",
                AppetiteUpperBound = "100",
                AppetiteLowerBound = "0",
                AppetiteType = "Percentage",
                ToleranceLowerBound = "10",
                ToleranceUpperBound = "90",
                ToleranceType = "Percentage",
                EscalationLowerBound = "20",
                EscalationUpperBound = "80",
                EscalationType = "Percentage",
                IsActive = true,
                CreatedById = 1
            };

            Assert.Equal("KRI001", request.KRIMetricId);
            Assert.Equal(1, request.LocationId);
            Assert.Equal("Branch", request.LocationType);
            Assert.Equal("Test Metric", request.MetricName);
            Assert.Equal("Monthly", request.Frequency);
            Assert.Equal("100", request.AppetiteUpperBound);
            Assert.Equal("0", request.AppetiteLowerBound);
            Assert.Equal("Percentage", request.AppetiteType);
            Assert.Equal("10", request.ToleranceLowerBound);
            Assert.Equal("90", request.ToleranceUpperBound);
            Assert.Equal("Percentage", request.ToleranceType);
            Assert.Equal("20", request.EscalationLowerBound);
            Assert.Equal("80", request.EscalationUpperBound);
            Assert.Equal("Percentage", request.EscalationType);
            Assert.True(request.IsActive);
            Assert.Equal(1, request.CreatedById);
        }

        [Fact]
        public void UpdateKriMasterRequest_Properties_SetAndGetCorrectly()
        {
            var request = new UpdateKriMasterRequest
            {
                Id = 1,
                MetricName = "Updated Metric",
                Frequency = "Quarterly",
                AppetiteUpperBound = "200",
                AppetiteLowerBound = "50",
                AppetiteType = "Value",
                ToleranceLowerBound = "75",
                ToleranceUpperBound = "175",
                ToleranceType = "Value",
                EscalationLowerBound = "100",
                EscalationUpperBound = "150",
                EscalationType = "Value",
                IsActive = false,
                ModifiedById = 2
            };

            Assert.Equal(1, request.Id);
            Assert.Equal("Updated Metric", request.MetricName);
            Assert.Equal("Quarterly", request.Frequency);
            Assert.Equal("200", request.AppetiteUpperBound);
            Assert.Equal("50", request.AppetiteLowerBound);
            Assert.Equal("Value", request.AppetiteType);
            Assert.Equal("75", request.ToleranceLowerBound);
            Assert.Equal("175", request.ToleranceUpperBound);
            Assert.Equal("Value", request.ToleranceType);
            Assert.Equal("100", request.EscalationLowerBound);
            Assert.Equal("150", request.EscalationUpperBound);
            Assert.Equal("Value", request.EscalationType);
            Assert.False(request.IsActive);
            Assert.Equal(2, request.ModifiedById);
        }

        [Fact]
        public void ToggleKriMasterStatusRequest_Properties_SetAndGetCorrectly()
        {
            var request = new ToggleKriMasterStatusRequest
            {
                Id = 1,
                IsActive = true
            };

            Assert.Equal(1, request.Id);
            Assert.True(request.IsActive);
        }

        [Fact]
        public void LossGridRequest_Properties_SetAndGetCorrectly()
        {
            var request = new LossGridRequest
            {
                LocationId = 1,
                LocationType = "Branch",
                refNo = "REF001",
                branch = "Main Branch",
                region = "North",
                department = "Finance",
                eventStatus = "Active",
                reportStatus = "Pending",
                minDate = new DateTime(2023, 1, 1),
                maxDate = new DateTime(2023, 12, 31)
            };

            Assert.Equal(1, request.LocationId);
            Assert.Equal("Branch", request.LocationType);
            Assert.Equal("REF001", request.refNo);
            Assert.Equal("Main Branch", request.branch);
            Assert.Equal("North", request.region);
            Assert.Equal("Finance", request.department);
            Assert.Equal("Active", request.eventStatus);
            Assert.Equal("Pending", request.reportStatus);
            Assert.Equal(new DateTime(2023, 1, 1), request.minDate);
            Assert.Equal(new DateTime(2023, 12, 31), request.maxDate);
        }

        [Fact]
        public void CreateLossDataRequest_Properties_SetAndGetCorrectly()
        {
            var request = new CreateLossDataRequest
            {
                LocationType = "Branch",
                LocationId = "1",
                ValidatorILOUserId = "2",
                DateOccurance = "2023-01-01",
                DateDiscovery = "2023-01-02",
                DateReported = "2023-01-03",
                Description = "Test loss",
                RootCauseRLO = "Human error",
                LossType = "Operational",
                CurrencyType = "USD",
                AmountInvolved = "1000",
                NearMissAmount = "500",
                PotentialLossAmount = "2000",
                GrossActualAmount = "1500",
                RecoveredAmount = "300",
                FurtherRecoveredAmount = "200",
                RecoveryChannel = "Insurance",
                StaffInvolvement = "Yes",
                EventStatus = "Open",
                ReportStatus = "Draft",
                CreatedById = "3",
                DocumentName = "LossReport.pdf"
            };

            Assert.Equal("Branch", request.LocationType);
            Assert.Equal("1", request.LocationId);
            Assert.Equal("2", request.ValidatorILOUserId);
            Assert.Equal("2023-01-01", request.DateOccurance);
            Assert.Equal("2023-01-02", request.DateDiscovery);
            Assert.Equal("2023-01-03", request.DateReported);
            Assert.Equal("Test loss", request.Description);
            Assert.Equal("Human error", request.RootCauseRLO);
            Assert.Equal("Operational", request.LossType);
            Assert.Equal("USD", request.CurrencyType);
            Assert.Equal("1000", request.AmountInvolved);
            Assert.Equal("500", request.NearMissAmount);
            Assert.Equal("2000", request.PotentialLossAmount);
            Assert.Equal("1500", request.GrossActualAmount);
            Assert.Equal("300", request.RecoveredAmount);
            Assert.Equal("200", request.FurtherRecoveredAmount);
            Assert.Equal("Insurance", request.RecoveryChannel);
            Assert.Equal("Yes", request.StaffInvolvement);
            Assert.Equal("Open", request.EventStatus);
            Assert.Equal("Draft", request.ReportStatus);
            Assert.Equal("3", request.CreatedById);
            Assert.Equal("LossReport.pdf", request.DocumentName);
        }
        [Fact]
        public void UpdateLossDataRloRequest_Properties_SetAndGetCorrectly()
        {
            var request = new UpdateLossDataRloRequest
            {
                id = 1,
                ValidatorILOUserId = 2,
                DateOccurance = new DateTime(2023, 1, 1),
                DateDiscovery = new DateTime(2023, 1, 2),
                DateReported = new DateTime(2023, 1, 3),
                Description = "Updated loss description",
                RootCauseRLO = "System failure",
                LossType = "Operational",
                CurrencyType = "EUR",
                AmountInvolved = 1000m,
                NearMissAmount = 500m,
                PotentialLossAmount = 2000m,
                GrossActualAmount = 1500m,
                RecoveredAmount = 300m,
                FurtherRecoveredAmount = 200m,
                RecoveryChannel = "Legal action",
                StaffInvolvement = "No",
                EventStatus = "Closed",
                ReportStatus = "Approved",
                ModifiedById = 3,
                DocumentName = "UpdatedLossReport.pdf"
            };

            Assert.Equal(1, request.id);
            Assert.Equal(2, request.ValidatorILOUserId);
            Assert.Equal(new DateTime(2023, 1, 1), request.DateOccurance);
            Assert.Equal(new DateTime(2023, 1, 2), request.DateDiscovery);
            Assert.Equal(new DateTime(2023, 1, 3), request.DateReported);
            Assert.Equal("Updated loss description", request.Description);
            Assert.Equal("System failure", request.RootCauseRLO);
            Assert.Equal("Operational", request.LossType);
            Assert.Equal("EUR", request.CurrencyType);
            Assert.Equal(1000m, request.AmountInvolved);
            Assert.Equal(500m, request.NearMissAmount);
            Assert.Equal(2000m, request.PotentialLossAmount);
            Assert.Equal(1500m, request.GrossActualAmount);
            Assert.Equal(300m, request.RecoveredAmount);
            Assert.Equal(200m, request.FurtherRecoveredAmount);
            Assert.Equal("Legal action", request.RecoveryChannel);
            Assert.Equal("No", request.StaffInvolvement);
            Assert.Equal("Closed", request.EventStatus);
            Assert.Equal("Approved", request.ReportStatus);
            Assert.Equal(3, request.ModifiedById);
            Assert.Equal("UpdatedLossReport.pdf", request.DocumentName);
        }

        [Fact]
        public void UpdateLossDataBormRequest_Properties_SetAndGetCorrectly()
        {
            var request = new UpdateLossDataBormRequest
            {
                id = 1,
                StaffJobRole = "Manager",
                InternalBusLine = "Retail Banking",
                BaselEventTypeI = "Type I",
                BaselEventTypeII = "Type II",
                BaselEventTypeIII = "Type III",
                BaselLevel1BusinessLine = "Level 1",
                BaselLevel2BusinessLine = "Level 2",
                RootCauseTypeBORM = "Process",
                ProcessInvolved = "Account Opening",
                RiskSource = "Internal",
                LessonLearnt = "Improved process needed",
                ReportStatus = "Under Review",
                ReviewerComments = "Needs further investigation",
                ModifiedById = 2
            };

            Assert.Equal(1, request.id);
            Assert.Equal("Manager", request.StaffJobRole);
            Assert.Equal("Retail Banking", request.InternalBusLine);
            Assert.Equal("Type I", request.BaselEventTypeI);
            Assert.Equal("Type II", request.BaselEventTypeII);
            Assert.Equal("Type III", request.BaselEventTypeIII);
            Assert.Equal("Level 1", request.BaselLevel1BusinessLine);
            Assert.Equal("Level 2", request.BaselLevel2BusinessLine);
            Assert.Equal("Process", request.RootCauseTypeBORM);
            Assert.Equal("Account Opening", request.ProcessInvolved);
            Assert.Equal("Internal", request.RiskSource);
            Assert.Equal("Improved process needed", request.LessonLearnt);
            Assert.Equal("Under Review", request.ReportStatus);
            Assert.Equal("Needs further investigation", request.ReviewerComments);
            Assert.Equal(2, request.ModifiedById);
        }

        [Fact]
        public void ApproveLossDataBormRequest_Properties_SetAndGetCorrectly()
        {
            var request = new ApproveLossDataBormRequest
            {
                id = 1,
                Action = "Approve",
                ReviewerComments = "All checks passed",
                ApprovedById = 2
            };

            Assert.Equal(1, request.id);
            Assert.Equal("Approve", request.Action);
            Assert.Equal("All checks passed", request.ReviewerComments);
            Assert.Equal(2, request.ApprovedById);
        }

        [Fact]
        public void GetFullLossDataBySingleIdRequest_Properties_SetAndGetCorrectly()
        {
            var request = new GetFullLossDataBySingleIdRequest
            {
                id = 1
            };

            Assert.Equal(1, request.id);
        }

        [Fact]
        public void FilterBranchListRequest_Properties_SetAndGetCorrectly()
        {
            var request = new FilterBranchListRequest
            {
                id = 1,
                Branch = "Main Branch",
                Region = "North",
                SolId = "SOL001",
                LocationId = "LOC001",
                Status = "Active",
                LocationChangeStatus = "Pending"
            };

            Assert.Equal(1, request.id);
            Assert.Equal("Main Branch", request.Branch);
            Assert.Equal("North", request.Region);
            Assert.Equal("SOL001", request.SolId);
            Assert.Equal("LOC001", request.LocationId);
            Assert.Equal("Active", request.Status);
            Assert.Equal("Pending", request.LocationChangeStatus);
        }

        [Fact]
        public void FilterDepartmentListRequest_Properties_SetAndGetCorrectly()
        {
            var request = new FilterDepartmentListRequest
            {
                id = 1,
                Department = "Finance",
                LocationId = "LOC001",
                Status = "Active",
                LocationChangeStatus = "Approved"
            };

            Assert.Equal(1, request.id);
            Assert.Equal("Finance", request.Department);
            Assert.Equal("LOC001", request.LocationId);
            Assert.Equal("Active", request.Status);
            Assert.Equal("Approved", request.LocationChangeStatus);
        }

        [Fact]
        public void CreateBranchLocationRequest_Properties_SetAndGetCorrectly()
        {
            var request = new CreateBranchLocationRequest
            {
                SolId = "SOL002",
                Branch = "New Branch",
                Region = "South",
                CreatedById = 1
            };

            Assert.Equal("SOL002", request.SolId);
            Assert.Equal("New Branch", request.Branch);
            Assert.Equal("South", request.Region);
            Assert.Equal(1, request.CreatedById);
        }

        [Fact]
        public void CreateDepartmentLocationRequest_Properties_SetAndGetCorrectly()
        {
            var request = new CreateDepartmentLocationRequest
            {
                Department = "Human Resources",
                CreatedById = 1
            };

            Assert.Equal("Human Resources", request.Department);
            Assert.Equal(1, request.CreatedById);
        }
    }
}