﻿using FluentAssertions;
using Moq;
using ORM.Api.Controllers;
using ORM.Application.Interfaces.Location;
using ORM.Application.Interfaces.Role;
using ORM.Application.Models.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.ControllerTests
{
    public class RoleServiceControllerTests
    {
        public Mock<IRoleService> RoleService = new();

        public RoleController RoleController { get; set; }

        public RoleServiceControllerTests()
        {
            RoleController = new RoleController
            (
                RoleService.Object
            );
        }

        [Fact]
        public async Task GetRoles()
        {
            //Arrange
            var request = new FilterRoleRequest();
            
            //Act
            var result = await RoleController.GetRoles(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetRoles_ThrowsException()
        {
            //Arrange
            var request = new FilterRoleRequest();

            //Act
            RoleService.Setup(x => x.GetAllRoleAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await RoleController.GetRoles(request);

            //Assert
            result.Should().NotBeNull();
        }
    }
}
