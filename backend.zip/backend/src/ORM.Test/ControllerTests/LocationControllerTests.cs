﻿using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ORM.Api.Controllers;
using ORM.Application.Interfaces.Location;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.ControllerTests
{
    public class LocationControllerTests
    {
        public LocationController LocationController { get; set; }

        public Mock<ILocationService> LocationService = new();


        public LocationControllerTests()
        {
            LocationController = new LocationController
            (
                LocationService.Object
            );
                
        }

        [Fact]
        public async Task GetAllBranchLocationsAsync()
        {
            //Arrange
            var request = new FilterBranchListRequest 
            {
                id = 1,
                Branch = "branch",
                Region = "region",
                SolId = "999",
                LocationId = "location",
                Status = "status"
            };

            //Act
            var result = await LocationController.GetAllBranchLocationsAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetAllBranchLocationsAsync_ThrowsException() 
        {
            //Arrange
            var request = new FilterBranchListRequest
            {
                id = 1,
                Branch = "branch",
                Region = "region",
                SolId = "999",
                LocationId = "location",
                Status = "status"
            };

            //Act
            LocationService.Setup(x => x.GetAllBranchLocationsAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await LocationController.GetAllBranchLocationsAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetAllDepartmentLocationsAsync()
        {
            //Arrange
            var request = new FilterDepartmentListRequest
            {
                id = 1,
                Department = "department",
                LocationId = "location",
                Status = "status"
            };

            //Act
            var result = await LocationController.GetAllDepartmentLocationsAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetAllDepartmentLocationsAsync_ThrowsException()
        {
            //Arrange
            var request = new FilterDepartmentListRequest
            {
                id = 1,
                Department = "department",
                LocationId = "location",
                Status = "status"
            };

            //Act
            LocationService.Setup(x => x.GetAllDepartmentLocationsAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await LocationController.GetAllDepartmentLocationsAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateBranchLocationAsync()
        {
            //Arrange
            var request = new CreateBranchLocationRequest();

            //Act
            var result = await LocationController.CreateBranchLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateBranchLocationAsync_ThrowsException()
        {
            //Arrange
            var request = new CreateBranchLocationRequest(); 

            //Act
            LocationService.Setup(x => x.CreateBranchLocationAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await LocationController.CreateBranchLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateDepartmentLocationAsync()
        {
            //Arrange
            var request = new CreateDepartmentLocationRequest();

            //Act
            var result = await LocationController.CreateDepartmentLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateDepartmentLocationAsync_ThrowsException()
        {
            //Arrange
            var request = new CreateDepartmentLocationRequest();

            //Act
            LocationService.Setup(x => x.CreateDepartmentLocationAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await LocationController.CreateDepartmentLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateBranchLocationAsync()
        {
            //Arrange
            var request = new UpdateBranchLocationRequest();

            //Act
            var result = await LocationController.UpdateBranchLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateBranchLocationAsync_ThrowsException()
        {
            //Arrange
            var request = new UpdateBranchLocationRequest();

            //Act
            LocationService.Setup(x => x.UpdateBranchLocationAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await LocationController.UpdateBranchLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateDepartmentLocationAsync()
        {
            //Arrange
            var request = new UpdateDepartmentLocationRequest();

            //Act
            var result = await LocationController.UpdateDepartmentLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task UpdateDepartmentLocationAsync_ThrowsException()
        {
            //Arrange
            var request = new UpdateDepartmentLocationRequest();

            //Act
            LocationService.Setup(x => x.UpdateDepartmentLocationAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await LocationController.UpdateDepartmentLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }
    }
}
