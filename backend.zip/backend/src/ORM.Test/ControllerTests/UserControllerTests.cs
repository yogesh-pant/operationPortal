﻿using FluentAssertions;
using Moq;
using ORM.Api.Controllers;
using ORM.Application.Interfaces.Location;
using ORM.Application.Interfaces.User;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.ControllerTests
{
    public class UserControllerTests
    {
        public UsersController UsersController { get; set; }

        public Mock<IUserService> UserService = new();

        public UserControllerTests()
        {
            UsersController = new UsersController
            (
                UserService.Object
            );
        }


        [Fact]
        public async Task GetUsers()
        {
            //Arrange
            var request = new FilterUserRequest();

            //Act
            var result = await UsersController.GetUsers(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetUsers_ThrowsException() 
        {
            //Arrange
            var request = new FilterUserRequest();

            //Act
            UserService.Setup(x => x.GetAllUserAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await UsersController.GetUsers(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task Updateuserdetails()
        {
            //Arrange
            var request = new EditUserRequest();

            //Act
            var result = await UsersController.Updateuserdetails(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task Updateuserdetails_ThrowsException() 
        {
            //Arrange
            var request = new EditUserRequest();

            //Act
            UserService.Setup(x => x.UpdateUserInfo(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await UsersController.Updateuserdetails(request);

            //Assert
            result.Should().NotBeNull();
        }


        [Fact]
        public async Task CreateORMUser()
        {
            //Arrange
            var request = "";

            //Act
            var result = await UsersController.CreateORMUser(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CreateORMUser_ThrowsException()
        {
            //Arrange
            var request = "";

            //Act
            UserService.Setup(x => x.AddUserInfo(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await UsersController.CreateORMUser(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task NewUser()
        {
            //Arrange
            var request = new AddNewUserRequest();

            //Act
            var result = await UsersController.NewUser(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task NewUser_ThrowsException()
        {
            //Arrange
            var request = new AddNewUserRequest();

            //Act
            UserService.Setup(x => x.AddNewUserInfo(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await UsersController.NewUser(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetUserByRoleLocationAsync()
        {
            //Arrange
            var request = new FilterGetUsersByRoleLocationRequest();

            //Act
            var result = await UsersController.GetUserByRoleLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task GetUserByRoleLocationAsync_ThrowsException()
        {
            //Arrange
            var request = new FilterGetUsersByRoleLocationRequest();

            //Act
            UserService.Setup(x => x.GetUserByRoleLocationAsync(request)).ThrowsAsync(new Exception("Test Exception"));

            var result = await UsersController.GetUserByRoleLocationAsync(request);

            //Assert
            result.Should().NotBeNull();
        }
    }
}
