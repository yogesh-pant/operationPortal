﻿using System;
using System.Collections.Generic;
using Xunit;
using ORM.Application.Models.Responses;

namespace ORM.Test.Models.Responses
{
    public class LossResponsesTests
    {
        [Fact]
        public void LossPreviewResponse_Properties_SetAndGetCorrectly()
        {
            // Arrange
            var response = new LossPreviewResponse
            {
                Id = 1,
                RefNum = "REF001",
                PrevLossReportId = 2,
                LocationType = "Branch",
                LocationId = 3,
                ValidatorILOUserId = 4,
                DateOccurance = new DateTime(2023, 1, 1),
                DateDiscovery = new DateTime(2023, 1, 2),
                DateReported = new DateTime(2023, 1, 3),
                Description = "Test description",
                ReportStatus = "Approved"
            };

            // Assert
            Assert.Equal(1, response.Id);
            Assert.Equal("REF001", response.RefNum);
            Assert.Equal(2, response.PrevLossReportId);
            Assert.Equal("Branch", response.LocationType);
            Assert.Equal(3, response.LocationId);
            Assert.Equal(4, response.ValidatorILOUserId);
            Assert.Equal(new DateTime(2023, 1, 1), response.DateOccurance);
            Assert.Equal(new DateTime(2023, 1, 2), response.DateDiscovery);
            Assert.Equal(new DateTime(2023, 1, 3), response.DateReported);
            Assert.Equal("Test description", response.Description);
            Assert.Equal("Approved", response.ReportStatus);
        }

        [Fact]
        public void LossDataGrid_Properties_SetAndGetCorrectly()
        {
            // Arrange
            var response = new LossDataGrid
            {
                Id = 1,
                ValidatorILOid = 2,
                ValidatorILOUserName = "John Doe",
                RefNum = "REF001",
                PrevLossReportId = 3,
                InternalBusinessLineId = "BL001",
                LossType = "Type A",
                Currency = "USD",
                DateOfOccurrence = new DateTime(2023, 1, 1),
                DateDiscovered = new DateTime(2023, 1, 2),
                ModifiedDate = new DateTime(2023, 1, 3),
                ApprovedDate = new DateTime(2023, 1, 4),
                DateReported = new DateTime(2023, 1, 5),
                DetailedLossEvent = "Detailed description",
                NearMiss = 100,
                PotentialLoss = 200,
                GrossActualLoss = 300,
                AmountRecovered = 50,
                FurtherRecovery = 25,
                NetActualLoss = 225,
                RootCause = "Root cause description",
                RiskSourceId = "RS001",
                AmountInvolved = 500,
                Region = "North",
                ProcessInvolved = "Process A",
                RecoveryMode = "Mode A",
                EventStatus = "Active",
                Department = "Finance",
                Branch = "Main Branch",
                ReportStatus = "Approved",
                CreatedBy = 5,
                CreatedByName = "Jane Smith",
                ModifiedBy = "John Doe",
                ApprovedBy = 6,
                ApprovedByName = "Alice Johnson",
                StaffInvolvement = "Yes",
                AllCount = 10,
                LocationType = "Branch",
                LocationName = "Downtown Branch",
                LocationId = 7,
                StaffJobRole = "Manager",
                BaselEventTypeI = "Type I",
                BaselEventTypeII = "Type II",
                BaselEventTypeIII = "Type III",
                BaselLevel1BusinessLine = "Level 1",
                BaselLevel2BusinessLine = "Level 2",
                RootCauseTypeBORM = "BORM Type",
                RiskSource = "Source A",
                LessonLearnt = "Lesson A",
                ReviewerComments = "Good report",
                UpdateHistory = "Updated on 2023-01-06"
            };

            // Assert
            Assert.Equal(1, response.Id);
            Assert.Equal(2, response.ValidatorILOid);
            Assert.Equal("John Doe", response.ValidatorILOUserName);
            Assert.Equal("REF001", response.RefNum);
            // ... Add assertions for all other properties
        }

        [Fact]
        public void RecordCount_Properties_SetAndGetCorrectly()
        {
            // Arrange
            var recordCount = new RecordCount
            {
                AUpdatedByBORMCount = 5
            };

            // Assert
            Assert.Equal(5, recordCount.AUpdatedByBORMCount);
        }

        [Fact]
        public void LossDataGridResponse_Constructor_SetsPropertiesCorrectly()
        {
            // Arrange
            var lossData = new List<LossDataGrid> { new LossDataGrid { Id = 1 } };
            var recordCount = new RecordCount { AUpdatedByBORMCount = 5 };

            // Act
            var response = new LossDataGridResponse(lossData, recordCount);

            // Assert
            Assert.Same(lossData, response.LossData);
            Assert.Same(recordCount, response.RecordCounts);
        }

        [Fact]
        public void GetFullLossDataBySingleIdResponse_Properties_SetAndGetCorrectly()
        {
            // Arrange
            var response = new GetFullLossDataBySingleIdResponse
            {
                RefNum = "REF001",
                ValidatorILOUserId = 1,
                ValidatorILOUserName = "John Doe",
                DateOccurance = new DateTime(2023, 1, 1),
                DateDiscovery = new DateTime(2023, 1, 2),
                DateReported = new DateTime(2023, 1, 3),
                Description = "Test description",
                RootCauseRLO = "RLO Cause",
                LossType = "Type A",
                CurrencyType = "USD",
                AmountInvolved = 1000,
                NearMissAmount = 100,
                PotentialLossAmount = 200,
                GrossActualAmount = 300,
                RecoveredAmount = 50,
                FurtherRecoveredAmount = 25,
                NetActualLossAmount = 225,
                RecoveryChannel = "Channel A",
                StaffInvolvement = "Yes",
                EventStatus = "Active",
                ReportStatus = "Approved",
                // ... Set other properties
            };

            // Assert
            Assert.Equal("REF001", response.RefNum);
            Assert.Equal(1, response.ValidatorILOUserId);
            Assert.Equal("John Doe", response.ValidatorILOUserName);
            Assert.Equal(new DateTime(2023, 1, 1), response.DateOccurance);
            Assert.Equal(new DateTime(2023, 1, 2), response.DateDiscovery);
            Assert.Equal(new DateTime(2023, 1, 3), response.DateReported);
            Assert.Equal("Test description", response.Description);
            Assert.Equal("RLO Cause", response.RootCauseRLO);
            Assert.Equal("Type A", response.LossType);
            Assert.Equal("USD", response.CurrencyType);
            Assert.Equal(1000, response.AmountInvolved);
            Assert.Equal(100, response.NearMissAmount);
            Assert.Equal(200, response.PotentialLossAmount);
            Assert.Equal(300, response.GrossActualAmount);
            Assert.Equal(50, response.RecoveredAmount);
            Assert.Equal(25, response.FurtherRecoveredAmount);
            Assert.Equal(225, response.NetActualLossAmount);
            Assert.Equal("Channel A", response.RecoveryChannel);
            Assert.Equal("Yes", response.StaffInvolvement);
            Assert.Equal("Active", response.EventStatus);
            Assert.Equal("Approved", response.ReportStatus);
            // ... Assert other properties
        }

        [Fact]
        public void SendLossRpReviewReminderResponse_Properties_SetAndGetCorrectly()
        {
            // Arrange
            var response = new SendLossRpReviewReminderResponse
            {
                RefNum = "REF001"
            };

            // Assert
            Assert.Equal("REF001", response.RefNum);
        }
    }
}