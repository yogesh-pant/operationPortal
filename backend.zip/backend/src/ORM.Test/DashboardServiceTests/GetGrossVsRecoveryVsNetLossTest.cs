﻿using Microsoft.IdentityModel.Tokens;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.DashboardServiceTests
{
    public class GetGrossVsRecoveryVsNetLossTest
    {
        private readonly DashboardServiceFactory _dashboardServiceFactory;

        public GetGrossVsRecoveryVsNetLossTest()
        {
            _dashboardServiceFactory = new DashboardServiceFactory();
        }


       [Fact]
        public async Task GetGrossVsRecoveryVsNetLoss_ShouldWork()  
        {
            //Arrange
            var request = new BaseDashboardChartsRequest
            {
                Months = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8 ,9, 10, 11, 12},
                BaselEventType1 = "baselEventType1",
                Year = DateTime.Now.Year
            };


            _dashboardServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport).Returns(new Mock<IOrmLossReportRepository>().Object);
            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                         .Returns(new List<ORMLossReport>() { new() { Id = 1, DateReported = DateTime.Now, BaselEventTypeI = "baselEventType1",ReportStatus = "approved-updatedbyborm" } }.BuildMock());

            var mockLocationRepository = new Mock<IOrmLocationRepository>();
            _dashboardServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            mockLocationRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMLocation>().BuildMock());

            //Act
            var result = await _dashboardServiceFactory.DashboardService.GetGrossVsRecoveryVsNetLoss(request);

            //Assert
            Assert.Equal(ResponseCodes.Success, result.Code);
            Assert.True(!(result.Data.IsNullOrEmpty()));
        }

        [Fact]
        public async Task GetGrossVsRecoveryVsNetLoss_ShouldReturn_EmptyData()
        {
            //Arrange
            var request = new BaseDashboardChartsRequest
            {
                Months = new List<int> { 1, 2, 3, },
                BaselEventType1 = "baselEventType1",
                Year = DateTime.Now.Year
            };


            _dashboardServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport).Returns(new Mock<IOrmLossReportRepository>().Object);
            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                         .Returns(new List<ORMLossReport>().BuildMock());

            var mockLocationRepository = new Mock<IOrmLocationRepository>();
            _dashboardServiceFactory.UnitOfWork.Setup(x => x.ORMLocation).Returns(mockLocationRepository.Object);
            mockLocationRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMLocation>().BuildMock());

            //Act
            var result = await _dashboardServiceFactory.DashboardService.GetGrossVsRecoveryVsNetLoss(request);

            //Assert
            Assert.Equal(ResponseCodes.Success, result.Code);
            Assert.True(result.Data.IsNullOrEmpty());
        }
    }
}
