﻿using ORM.Application.Interfaces.Auth;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.DashboardServiceTests
{
    public class DashboardServiceFactory
    {
        public Mock<IUnitOfWork> UnitOfWork = new();
        public Mock<ISessionService> SessionService = new();
        public Mock<ILogger<DashboardService>> Logger = new();

        public DashboardService DashboardService { get; set; }

        public DashboardServiceFactory()
        {
            DashboardService = new DashboardService
            (
                SessionService.Object,
                UnitOfWork.Object
            );

        }
    }
}
