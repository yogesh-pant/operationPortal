﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Dashboard;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.DashboardServiceTests
{
    public class GetKeyRiskIndicatorTest
    {

        private readonly DashboardServiceFactory _dashboardServiceFactory;

        public GetKeyRiskIndicatorTest()
        {
            _dashboardServiceFactory = new DashboardServiceFactory();
        }

        [Fact]
        public async Task GetKeyRiskIndicator_ShouldWork()
        {

            var request = new FilterKeyRiskIndicatorRequest
            {
                Months = new List<int> { 1, 2, 3, },
                LocationType = "B",
                Year = 2023
            };


            _dashboardServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMKRIReportMetrics).Returns(new Mock<IKriReportMetricsRepository>().Object);

            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(GenerateORMKRIReportMetricsMockData().BuildMock());

            var result = await _dashboardServiceFactory.DashboardService.GetKeyRiskIndicator(request);

            //Assert
            Assert.NotNull(result.Data);
        }

        public static Mock<ISessionService> MockSessionService()
        {
            var mockSessionService = new Mock<ISessionService>();

            mockSessionService.Setup(x => x.GetStaffSession()).Returns(new
                StaffSession(1,
                "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            return mockSessionService;
        }

        public static List<ORMKRIReportMetrics> GenerateORMKRIReportMetricsMockData()
        {
            return new List<ORMKRIReportMetrics>
            {
                new ORMKRIReportMetrics
                {
                    Id = 1,
                    KRIReportId = 1,
                    ORMKRIReport = new ORMKRIReport { Id = 1, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Parse("2023-01-02"),ReportingPeriod = "Mar  6 2023 11:05AM", RefNum = "KRI001",LocationType = "B", Status = "Pending"},
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1, KRIMetricId = "1", LocationType ="B",LocationId = 1}, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"
                }
            };
        }
    }
}
