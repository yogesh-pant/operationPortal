﻿using ORM.Application.Models.Auth;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Test.LocationServiceTests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.DashboardServiceTests
{
    public class GetLossDataTrendTest
    {
        private readonly DashboardServiceFactory _dashboardServiceFactory;

        public GetLossDataTrendTest()
        {
            _dashboardServiceFactory = new DashboardServiceFactory();  
        }

        [Fact]
        public async Task GetLossDataTrend_ShouldWork()
        {
            //Arrange
            var request = new BaseDashboardChartsRequest 
            {
                Months = new List<int> { 1, 2, 3,},
                BaselEventType1 = "baselEventType1",
                Year = 2000
            };


            _dashboardServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport).Returns(new Mock<IOrmLossReportRepository>().Object);
            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                         .Returns(new List<ORMLossReport>() { new() { Id = 1 } }.BuildMock());

            //Act
            var result = await _dashboardServiceFactory.DashboardService.GetLossDataTrend(request);

            //Assert
            Assert.NotNull(result.Data);
        }
    }
}
