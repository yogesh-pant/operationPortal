﻿using ORM.Application.Models.Auth;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.DashboardServiceTests
{
    public class GetRiskOccurenceChartsTest
    {
        private readonly DashboardServiceFactory _dashboardServiceFactory;

        public GetRiskOccurenceChartsTest()
        {
            _dashboardServiceFactory = new DashboardServiceFactory();
        }


       [Fact]
        public async Task GetRiskOccurenceChart_ShouldWork()
        {
            //Arrange
            var request = new FilterRiskReportRequest
            {
                Months = new List<int> { 1, 2, 3, },
                Year = 2000
            };


            _dashboardServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport).Returns(new Mock<IOrmLossReportRepository>().Object);
            _dashboardServiceFactory.UnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                         .Returns(new List<ORMLossReport>() { new() { Id = 1 ,ReportStatus = "Approved"} }.BuildMock());

            var mockRiskRepository = new Mock<IOrmRiskRepository>(); 
            _dashboardServiceFactory.UnitOfWork.Setup(x => x.ORMRiskReport).Returns(mockRiskRepository.Object);
            mockRiskRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMRiskReport>().BuildMock());

            //Act
            var result = await _dashboardServiceFactory.DashboardService.GetRiskOccurenceCharts(request);

            //Assert
            Assert.NotNull(result.Data);
        }
    }
}
