namespace ORM.Test.Logging
{
    using System;
    using FakeItEasy;
    using FluentAssertions;
    using ORM.Api.Logging;
    using ORM.Application.Models.Logging;
    using Serilog;
    using Xunit;

    public class LoggerConfigurationServiceTests
    {
        private LoggerConfigurationService _testClass;

        public LoggerConfigurationServiceTests()
        {
            _testClass = new LoggerConfigurationService();
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new LoggerConfigurationService();

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public void CanCallConfigureLogger()
        {
            // Arrange
            var options = new LoggerOptions
            {
                EnableConsole = true,
                EnableFile = true,
                LogFilePath = "TestValue1712279829",
                RetainedFileCountLimit = 1417898045,
                FileSizeLimitBytes = 1910668476L,
                RollOnFileSizeLimit = false,
                EnableAzureApplicationInsights = false,
                AzureInstrumentationKey = "TestValue695893782"
            };

            // Act
            var result = _testClass.ConfigureLogger(options);

            // Assert
            result.Should().NotBeNull();
        }


    }
}