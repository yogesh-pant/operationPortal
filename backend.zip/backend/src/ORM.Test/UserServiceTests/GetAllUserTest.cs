﻿using MockQueryable.Moq;
using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Requests;
using ORM.Domain.Common;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Test.RoleServiceTests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.UserServiceTests
{
    public class GetAllUserTest
    {
        private readonly UserServiceFactory _userServiceFactory;

        public GetAllUserTest()
        {
            _userServiceFactory = new UserServiceFactory();   
        }

        [Fact]
        public async Task GetAllUser_ShouldWork()
        {
            //Arrange
            var request = new FilterUserRequest
            {
                userName = "testuser",
                userRole = "Admin",
                status = "Active"
            };

            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            var roleRepository = new Mock<IRoleRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMRoles).Returns(roleRepository.Object);
            roleRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMAppRole>() 
            { new() {
                    RoleId = 1,
                    RoleTitle = "Admin" ,
                    RoleStatus = true ,
                    RoleCreatedBy = "1",
                    RoleUpdatedBy  = "1",
                    RoleCreationTime =DateTime.Now,
                    RoleUpdationTime = DateTime.Now
                    } }.BuildMock());

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>() 
            { new() 
                    { 
                    Id = 1,
                    UserName = "testuser",
                    Email = "testemail",
                    StaffId = "Staff",
                    Status = "Active",
                    RoleId = 1,
                    SubRoleId = 1,
                    FailedLoginCount = "0",
                    LastLoginTime = DateTime.Now,
                    CurrentLoginTime = DateTime.Now,
                    ChangeRequestData = JsonConvert.SerializeObject(
                        new LocationBranchChangeData {
                            NewLocationBranch = "NewBranch",
                            NewLocationRegion = "NewRegion",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        }),
                    CreatedBy = 1,
                    CreatedDate = DateTime.Now,
                    UpdatedBy = 1,
                    ChangeRequestDate = DateTime.Now,
                    ReviewedBy =1,
                    ChangeReviewDate = DateTime.Now,
                    ChangeReviewComments = ""
                    } }.BuildMock());

            var userLocationMapRepository = new Mock<IOrmUserLocationMapRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUserLocationMap).Returns(userLocationMapRepository.Object);
            userLocationMapRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUserLocationMap>() 
            { new() 
                { 
                    Id = 1, 
                    UserId =1, 
                    LocationId =1,
                    ORMLocation = new ORMLocation
                    {
                        Id = 1, LocationId = "TestLocation",LocationType = "B" ,  Branch = "BranchName",  Department = "DepartmantName"
                    },
                    ORMUser = new ORMUser
                    {
                        Id = 1,
                        UserName = "testuser",
                        Email = "testemail",
                        StaffId = "Staff",
                        Status = "Active",
                        RoleId = 1,
                        FailedLoginCount = "0",
                        LastLoginTime = DateTime.Now,
                        CurrentLoginTime = DateTime.Now,
                    }
                } }.BuildMock());


            //Act
            var result = await _userServiceFactory.UserService.GetAllUserAsync(request);

            //Assert
            Assert.NotNull(result.Data);
        }
    }
}
