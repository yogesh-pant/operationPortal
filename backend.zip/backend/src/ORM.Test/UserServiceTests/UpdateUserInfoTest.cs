﻿using MockQueryable.Moq;
using Moq;
using Newtonsoft.Json;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Domain.Common;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace ORM.Test.UserServiceTests
{
    public class UpdateUserInfoTest
    {
        private readonly UserServiceFactory _userServiceFactory;

        public UpdateUserInfoTest()
        {
            _userServiceFactory = new UserServiceFactory();

        }

        [Fact]
        public async Task UpdateUserInfo_ShouldWork() 
        {
            //Arrange
            var request = new EditUserRequest
            {
                Id = 1,
                LocationIds = new long[] { 1, 2,}
            };


            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            var roleRepository = new Mock<IRoleRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMRoles).Returns(roleRepository.Object);
            roleRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMAppRole>() { new() { RoleId = 1, RoleTitle = "role" } }.BuildMock());

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>() { new() { Id = 1, UserName = "ormuser@email.com" } }.BuildMock());

            var userLocationMapRepository = new Mock<IOrmUserLocationMapRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUserLocationMap).Returns(userLocationMapRepository.Object);
            userLocationMapRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUserLocationMap>() { new() { Id = 1, UserId = 1 } }.BuildMock());

            // For locations
            var locations = new List<ORMLocation>()
            {
                new() {
                    Id = 1,
                    LocationId = "BL001",
                    LocationType = "B",
                    Branch = "TestBranch",
                    Department = null,
                    Region = "TestRegion",
                    Status = "Active",
                    LocationChangeStatus = "Approved",
                    ChangeRequestData = JsonConvert.SerializeObject(
                        new LocationBranchChangeData {
                            NewLocationBranch = "NewBranch",
                            NewLocationRegion = "NewRegion",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        })
                },
                new() {
                    Id = 2,
                    LocationId = "DL001",
                    LocationType = "D",
                    Branch = null,
                    Department = "TestDepartment",
                    Region = null,
                    Status = "Active",
                    LocationChangeStatus = "Approved",
                    ChangeRequestData = JsonConvert.SerializeObject(
                        new LocationDeptChangeData {
                            NewLocationDepartment = "NewDepartment",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        })
                }
            };
            var mockLocationsDbSet = locations.AsQueryable().BuildMockDbSet();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMLocation.GetAll()).Returns(mockLocationsDbSet.Object);

            _userServiceFactory.UnitOfWork.Setup(x => x.SaveAndGetIdORMUserLocationMapAsync(It.IsAny<List<ORMUserLocationMap>>())).ReturnsAsync(new List<long> { 1, 2 });

            //Act
            var result = await _userServiceFactory.UserService.UpdateUserInfo(request);

            //Assert
            Assert.Equal(ResponseCodes.Success, result.Code);
        }

        [Fact]
        public async Task UpdateUserInfo_ShouldNot_UpdateSuccessfully() 
        {
            //Arrange
            var request = new EditUserRequest
            {
                Id = 1,
                LocationIds = new long[] { 1 },
                SubRoleId = 1,
                Status = "Active",
                RoleId = 1
            };


            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>() { new() { Id = 1, UserName = "ormuser@email.com", RoleId =1 , SubRoleId =1} }.BuildMock());

            var roleRepository = new Mock<IRoleRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMRoles).Returns(roleRepository.Object);
            roleRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMAppRole>() { new() { RoleId = 1, RoleTitle = "ormuser@email.com"} }.BuildMock());

            var userLocationMapRepository = new Mock<IOrmUserLocationMapRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUserLocationMap).Returns(userLocationMapRepository.Object);
            userLocationMapRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUserLocationMap>() { new() { Id = 1, UserId = 1, LocationId =1 } }.BuildMock());

            // For locations
            var locations = new List<ORMLocation>()
            {
                new() {
                    Id = 1,
                    LocationId = "BL001",
                    LocationType = "B",
                    Branch = "TestBranch",
                    Department = null,
                    Region = "TestRegion",
                    Status = "Active",
                    LocationChangeStatus = "Approved",
                    ChangeRequestData = JsonConvert.SerializeObject(
                        new LocationBranchChangeData {
                            NewLocationBranch = "NewBranch",
                            NewLocationRegion = "NewRegion",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        })
                },
                new() {
                    Id = 2,
                    LocationId = "DL001",
                    LocationType = "D",
                    Branch = null,
                    Department = "TestDepartment",
                    Region = null,
                    Status = "Active",
                    LocationChangeStatus = "Approved",
                    ChangeRequestData = JsonConvert.SerializeObject(
                        new LocationDeptChangeData {
                            NewLocationDepartment = "NewDepartment",
                            NewLocationStatus = "Inactive",
                            LocationNewUpdatedBy = 2,
                            LocationNewChangeRequestDate = DateTime.Now
                        })
                }
            };
            var mockLocationsDbSet = locations.AsQueryable().BuildMockDbSet();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMLocation.GetAll()).Returns(mockLocationsDbSet.Object);

            //Act
            var result = await _userServiceFactory.UserService.UpdateUserInfo(request);

            //Assert
            Assert.Equal(ResponseCodes.ServiceError, result.Code);
        }

        [Fact]
        public async Task UpdateUserInfo_ShouldReturn_UserNotFound() 
        {
            //Arrange
            var request = new EditUserRequest
            {
               // UserName = "ormuser1@email.com"
            };


            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>() { new() { Id = 1, UserName = "ormuser@email.com" } }.BuildMock());

            _userServiceFactory.UnitOfWork.Setup(x => x.Save()).Returns(1);

            //Act
            var result = await _userServiceFactory.UserService.UpdateUserInfo(request);

            //Assert
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
        }
    }
}
