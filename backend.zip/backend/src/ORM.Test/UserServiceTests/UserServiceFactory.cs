﻿using Fcmb.Shared.Auth.Services;
using Microsoft.Extensions.Logging;
using Moq;
using ORM.Application.Interfaces.Auth;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.UserServiceTests
{
    public class UserServiceFactory
    {
        public Mock<IUnitOfWork> UnitOfWork = new();
        public Mock<ISessionService> SessionService = new();
        public Mock<IAuthService> AuthService = new();
        public Mock<ILogger<UserService>> Logger = new();

        public UserService UserService { get; set; }


        public UserServiceFactory()
        {
            UserService = new UserService
            (
                Logger.Object,
                SessionService.Object,
                UnitOfWork.Object,
                AuthService.Object
            );     
        }
    }
}
