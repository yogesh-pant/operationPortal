﻿using Xunit;
using Moq;
using ORM.Infrastructure.Services;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.User;
using ORM.Infrastructure.UOW;
using Microsoft.Extensions.Logging;
using Fcmb.Shared.Auth.Services;
using ORM.Infrastructure.Entities;
using ORM.Application.Models.Requests;
using System.Threading.Tasks;
using System.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using ORM.Application.Models.Responses;
using ORM.Application.Models.Constants;
using ORM.Domain.Common;
using ORM.Application.Models.Auth;
using ORM.Infrastructure.Services.Auth;
using MockQueryable.Moq;
using ORM.Infrastructure.IRepositories;

namespace ORM.Test.UserServiceTests
{
    public class ReviewUserChangeRequestTests
    {
        private readonly UserServiceFactory _userServiceFactory;

        public ReviewUserChangeRequestTests()
        {
            _userServiceFactory = new UserServiceFactory();
        }

        [Fact]
        public async Task ApproveUserInfoAsync_ValidRequest_ReturnsSuccess()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };

            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession())
                .Returns(new StaffSession(1, "TestUser", "test@example.com", "STAFF001", 2));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>
            {
                new ORMUser
                {
                    Id = 1,
                    UserName = "testuser",
                    UserChangeStatus = "Pending",
                    ChangeRequestData = JsonConvert.SerializeObject(new CombinedUserChangeData
                    {
                        UserChangeData = new UserChangeData
                        {
                            UserNewRole = 2,
                            UserNewSubRole = 1,
                            UserNewStatus = "Active",
                            UserNewLocations = new long[] { 1, 2 },
                            UserNewUpdatedBy = 1,
                            UserNewChangeRequestDate = DateTime.Now
                        }
                    })
                }
            }.BuildMock());

            var userLocationMapRepository = new Mock<IOrmUserLocationMapRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUserLocationMap).Returns(userLocationMapRepository.Object);
            userLocationMapRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUserLocationMap>().BuildMock());

            _userServiceFactory.UnitOfWork.Setup(u => u.SaveAndGetIdORMUserLocationMapAsync(It.IsAny<List<ORMUserLocationMap>>()))
                .ReturnsAsync(new List<long> { 1, 2 });

            // Act
            var result = await _userServiceFactory.UserService.ApproveUserInfoAsync(request);

            // Assert
            Assert.Equal(ResponseCodes.Success, result.Code);
            Assert.Equal("User update request approved and record updated successfully ", result.Description);
            _userServiceFactory.UnitOfWork.Verify(u => u.Save(), Times.Once);
        }

        [Fact]
        public async Task RejectUserInfoAsync_ValidRequest_ReturnsSuccess()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Rejected" };

            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession())
                .Returns(new StaffSession(1, "TestUser", "test@example.com", "STAFF001", 2));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>
            {
                new ORMUser
                {
                    Id = 1,
                    UserName = "testuser",
                    UserChangeStatus = "Pending"
                }
            }.BuildMock());

            // Act
            var result = await _userServiceFactory.UserService.RejectUserInfoAsync(request);

            // Assert
            Assert.Equal(ResponseCodes.Success, result.Code);
            Assert.Equal("User update request Rejected ", result.Description);
            _userServiceFactory.UnitOfWork.Verify(u => u.Save(), Times.Once);
        }

        [Fact]
        public async Task ApproveUserInfoAsync_UserNotFound_ReturnsDataNotFound()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };

            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession())
                .Returns(new StaffSession(1, "TestUser", "test@example.com", "STAFF001", 2));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>().BuildMock());

            // Act
            var result = await _userServiceFactory.UserService.ApproveUserInfoAsync(request);

            // Assert
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            Assert.Equal("User Not Found", result.Description);
        }

        [Fact]
        public async Task ApproveUserInfoAsync_UserChangeStatusNotPending_ReturnsDataNotFound()
        {
            // Arrange
            var request = new ReviewUserChangeRequest { Id = 1, ChangeReviewComments = "Approved" };

            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession())
                .Returns(new StaffSession(1, "TestUser", "test@example.com", "STAFF001", 2));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>
            {
                new ORMUser
                {
                    Id = 1,
                    UserName = "testuser",
                    UserChangeStatus = "Approved" // Not Pending
                }
            }.BuildMock());

            // Act
            var result = await _userServiceFactory.UserService.ApproveUserInfoAsync(request);

            // Assert
            Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            Assert.Equal("User info change in not Pending Review ", result.Description);
        }
    }
}