﻿using FakeItEasy;
using Fcmb.Shared.Auth.Services;
using Fcmb.Shared.Models.Responses;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;

namespace ORM.Test.UserServiceTests
{
    public class AddUserInfoTest
    {
        private readonly UserServiceFactory _userServiceFactory;
        private readonly UserService _testClass;
        private readonly ILogger<UserService> _logger;
        private readonly IAuthService _authService;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ISessionService _sessionService;

        public AddUserInfoTest()
        {
            _userServiceFactory = new UserServiceFactory();
            _logger = A.Fake<ILogger<UserService>>();
            _authService = A.Fake<IAuthService>();
            _unitOfWork = A.Fake<IUnitOfWork>();
            _sessionService = A.Fake<ISessionService>();
            _testClass = new UserService(_logger , _sessionService,  _unitOfWork, _authService);

        }

        [Theory]
        [InlineData("johndoe", "Successful")]   // Valid UserName provided -User not found in ORM Db and AD response success - Successful Validation 
        [InlineData("johndo1", "AlreadyinDB")]  // Valid UserName provided -User found in ORM Db - Failed Validation 
        [InlineData("johndoe", "NotinAD")]      // Valid UserName provided -User not found in ORM Db and not found in AD  - Failed Validation 
        [InlineData("johndoe", "ServiceError")] // Valid UserName provided -User not found in ORM Db and AD Service Error - Failed Validation 
        [InlineData(""       , "invalidinput")] // Blank or null UserName provided --Failed Validation 

        public async Task AddUserInfo_ShouldWork(string UserName, string ExpectedResult) 
        {
            //Arrange
            var RequestUserName = UserName;
            var ORMUserName     = UserName + "_Different";
            var result = new ObjectResponse<bool>("Account exists with this username in Ad", ResponseCodes.Success);

            if (ExpectedResult == "AlreadyinDB") 
                { 
                    ORMUserName = RequestUserName;   
                };
            if (ExpectedResult == "NotinAD") 
                {
                    result = new ObjectResponse<bool>("User not found in AD !", ResponseCodes.DataNotFound);
                };
            if (ExpectedResult == "ServiceError")
                {
                    result = new ObjectResponse<bool>("AD is not responding !", ResponseCodes.ServiceError);
                };
            if (ExpectedResult == "invalidinput")
            {
                RequestUserName = "";
                result = new ObjectResponse<bool>("Error - User Name is blank!", ResponseCodes.InvalidCredentials);
            };

            _userServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            var userRepository = new Mock<IOrmUserRepository>();
            _userServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>() { new() { Id = 1, UserName = ORMUserName } }.BuildMock());
                        
            _userServiceFactory.AuthService.Setup(x => x.GetUserAdFullDetailsWLoginName(RequestUserName)).ReturnsAsync(result);
            //Act
            var adduserresult = await _userServiceFactory.UserService.AddUserInfo(RequestUserName);

            //Assert
            if (ExpectedResult == "Successful")
            {
                Assert.NotNull(adduserresult.Data);
                Assert.Equal("00", adduserresult.Code);
            }
            else
            {
                Assert.Null(adduserresult.Data);
                Assert.NotEqual("00", adduserresult.Code);
            }
        }
    }
}
