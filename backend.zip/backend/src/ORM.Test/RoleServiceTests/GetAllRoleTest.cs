﻿using MockQueryable.Moq;
using Moq;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Test.LocationServiceTests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.RoleServiceTests
{
    public class GetAllRoleTest
    {
        private readonly RoleServiceFactory _roleServiceFactory;

        public GetAllRoleTest()
        {
            _roleServiceFactory = new RoleServiceFactory();  
        }

        [Fact]
        public async Task GetAllRole_ShouldWork()
        {
            //Arrange
            var data = new FilterRoleRequest
            {
                roleTitle = "Test",
                status = true,
            };

            _roleServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            var roleRepository = new Mock<IRoleRepository>();
            roleRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMAppRole>().BuildMock());
            _roleServiceFactory.UnitOfWork.Setup(x => x.ORMRoles).Returns(roleRepository.Object);

            //Act
            var result = await _roleServiceFactory.RoleService.GetAllRoleAsync(data);

            //Assert
            Assert.NotNull(result.Data);
        }
    }
}
