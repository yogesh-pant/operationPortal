﻿using Microsoft.Extensions.Logging;
using Moq;
using ORM.Application.Interfaces.Auth;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test.RoleServiceTests
{
    public class RoleServiceFactory
    {
        public Mock<IUnitOfWork> UnitOfWork = new();
        public Mock<ISessionService> SessionService = new();
        public Mock<ILogger<RoleService>> Logger = new();
        public Mock<IOrmLocationRepository> ORMLocationRepository = new();

        public RoleService RoleService { get; set; }
        public RoleServiceFactory()
        {
            RoleService = new RoleService
            (
                Logger.Object,
                SessionService.Object,
                UnitOfWork.Object
            );
        }
    }
}
