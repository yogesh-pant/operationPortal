global using Xunit;
global using MockQueryable.Moq;
global using Moq;
global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.Logging;