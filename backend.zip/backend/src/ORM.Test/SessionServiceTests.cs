﻿using FluentAssertions;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Http;
using Org.BouncyCastle.Ocsp;
using ORM.Infrastructure.Services.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Test
{
    public class SessionServiceTests
    {
            
        public Mock<ILogger<SessionService>> Logger = new();

        public SessionService SessionService { get; set; }

        public SessionServiceTests()
        {

            SessionService = new SessionService
            (
                Logger.Object,
                new HttpContextAccessor
                {
                    HttpContext = new DefaultHttpContext
                    {
                        User = GetAuthenticatedUser()
                    }    
                }
            );
           
        }

        [Fact]
        public void GetStaffSession_ShouldWork()
        {
            //Arrange

            //Act
           
            var result = SessionService.GetStaffSession();

            //Assert
            result.Should().NotBeNull();
        }

        public static ClaimsPrincipal GetAuthenticatedUser()
        {
            return new ClaimsPrincipal(new ClaimsIdentity(new[]
            {
                new Claim("UserId", 1.ToString()),
                new Claim("UserName","ormuser@test.com"),
                new Claim("Email","ormuser@test.com"),
                new Claim("StaffId","1"),
                new Claim("RoleId","1"),
            }, "TestAuthentication"));
        }

    }
}
