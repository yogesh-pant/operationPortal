namespace ORM.Test.Services.Auth
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using AutoFixture;
    using FakeItEasy;
    using Fcmb.Shared.Auth.Models.Requests;
    using Fcmb.Shared.Auth.Models.Responses;
    using Fcmb.Shared.Auth.Services;
    using Fcmb.Shared.Models.Responses;
    using FluentAssertions;
    using Microsoft.Extensions.Logging;
    using MockQueryable.FakeItEasy;
    using ORM.Api;
    using ORM.Application.Interfaces.Auth;
    using ORM.Application.Models.Auth;
    using ORM.Application.Models.Constants;
    using ORM.Infrastructure.Entities;
    using ORM.Infrastructure.IRepositories;
    using ORM.Infrastructure.Services.Auth;
    using ORM.Infrastructure.UOW;
    using Xunit;
    using System.Reflection;
    using ORM.Application.Interfaces.Common;
    using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;
    using Azure;
    using ORM.Application.Models.Responses;
    using static System.Runtime.InteropServices.JavaScript.JSType;

    public class AuthSetupServiceTests
    {
        private readonly AuthSetupService _testClass;
        private readonly ILogger<AuthSetupService> _logger;
        private readonly IAuthService _authService;
        private readonly IAuthTokenGenerator _authTokenGenerator;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ISessionService _sessionService;
        private readonly IKeyVaultHelper _keyVaultHelpere;

        private static readonly Fixture Fixture = new Fixture();
        public AuthSetupServiceTests()
        {
            _logger = A.Fake<ILogger<AuthSetupService>>();
            _authService = A.Fake<IAuthService>();
            _authTokenGenerator = A.Fake<IAuthTokenGenerator>();
            _unitOfWork = A.Fake<IUnitOfWork>();
            _sessionService = A.Fake<ISessionService>();
            _keyVaultHelpere= A.Fake<IKeyVaultHelper>();

            _testClass = new AuthSetupService(_logger, _authService, _authTokenGenerator, _unitOfWork, _sessionService, _keyVaultHelpere);
        }


        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new AuthSetupService(_logger, _authService, _authTokenGenerator, _unitOfWork, _sessionService, _keyVaultHelpere);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCheckUserInAdAsync()
        {
            // Arrange
            var username = "Test";

            var user = new ORMUser
            {
                UserName = username,
                Id = 400,
                Email = "email@test.com",
                Status = "active",
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
            };
            var list = new List<ORMUser>() { user };
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);

            // Act
            var result = await _testClass.CheckUserInAdAsync(username, "127.168.0.1");

            // Assert
            result.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallCheckUserInAdAsyncLockedStatus()
        {
            // Arrange
            var username = "Test";

            var user = new ORMUser
            {
                UserName = username,
                Id = 400,
                Email = "email@test.com",
                Status = "Locked",
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
            };
            var list = new List<ORMUser>() { user };
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);

            // Act
            var result1 = new ObjectResponse<bool>("Account exists with this username in Ad", ResponseCodes.Success)
            {
            };


            //A.CallTo(() => _authService.LoginAsync(DecryptedLoginrequest)).Returns(result);
            A.CallTo(() => _authService.GetUserAdFullDetailsWLoginName(username)).Returns(result1);

            var result = await _testClass.CheckUserInAdAsync(username, "127.168.0.1");

            // Assert
            result.Should().NotBeNull();
        }
        [Fact]
        public async Task CanCallCheckUserInAdAsyncUserNull()
        {
            // Arrange
            var username = "Test";

            var user = new ORMUser
            {
                UserName = "User",
                Id = 400,
                Email = "email@test.com",
                Status = "active",
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
            };
            var list = new List<ORMUser>() { user };
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);

            // Act
            var result = await _testClass.CheckUserInAdAsync(username, "127.168.0.1");

            // Assert
            result.Should().NotBeNull();
        }

        [Theory]
        [InlineData("Admin", "Locked", "testemail", "NoPermission")]      // Valid Admin User but user is not allowed to log in due due to Status = Locked
        [InlineData("Admin", "Inactive", "testemail", "NoPermission")]    // Valid Admin User but user is not allowed to log in due due to Status = InActive
        [InlineData("Admin", "Active", "testemail", "AllowPermission")]   // Valid Admin User with Active Status - Log in successfully
        [InlineData("Admin", "Active", "invalidtestemail", "UserNotFound")] // Valid AD User with Active Status - Authenticated successfully in AD but not found in ORMUser table
        [InlineData("RLO", "Active", "testemail", "AllowPermission")]   // Valid Active RLO user with one or more mapped locations  Log in successfully
        [InlineData("RLO", "Active", "testemail", "NoRoleFound")]       // Valid Active RLO user with one or more mapped locations NoRoleFound Log in Rejected
        [InlineData("RLO", "Active", "testemail", "NoLocationMapped")]  // Valid Active RLO user with NO mapped locations  Log in Rejected
        public async Task CanCallLoginAsync(string RoleTitle,string UserStatus, string UserName, string ExpectedResult)
        {
            // Arrange
            var username = "testemail";
            var EncryptedPassword = "/+ax3FRFrly5qS4TqSwBZ4kzxrDDrdmREjYJ/zCRrcA=";
            var DecryptedPassword = "Courageous@@2024";
            var EncryptedLoginrequest = new LoginRequest() { Email = username, Password = EncryptedPassword };
            var DecryptedLoginrequest = new LoginRequest() { Email = username, Password = DecryptedPassword };

            var _configuration = new ConfigurationBuilder().
                             SetBasePath(Directory.GetCurrentDirectory())
                             .AddJsonFile("appsettings.json", false)
                            .AddUserSecrets(typeof(Program).GetTypeInfo().Assembly).Build();

            A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).Returns("TestValue19909655");
            A.CallTo(() => _unitOfWork.Save()).Returns(2107767265);
            A.CallTo(() => _unitOfWork.ORMUsers).Returns(A.Fake<IOrmUserRepository>());
            A.CallTo(() => _unitOfWork.ORMUserLocationMap).Returns(A.Fake<IOrmUserLocationMapRepository>());
            A.CallTo(() => _unitOfWork.ORMRoles).Returns(A.Fake<IRoleRepository>());
            A.CallTo(() => _keyVaultHelpere.GetSecretAsync("orm-encryption-iv")).Returns("znQ343StbIgWSZrm");
            A.CallTo(() => _keyVaultHelpere.GetSecretAsync("orm-encryption-key")).Returns("Ps5mzoHtFAmDFpg7");

            var user = new ORMUser
            {
                UserName = UserName,
                Id = 400,
                Email = EncryptedLoginrequest.Email,
                Status = UserStatus,
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
            };
            var list = new List<ORMUser>() { user };
            var role = new ORMAppRole
            {
                RoleId = 1,
                RoleTitle = RoleTitle
            };
            var roleList = new List<ORMAppRole>() { role };
            if (ExpectedResult == "NoRoleFound")
            {
                roleList = new List<ORMAppRole>() { };
            }
            var roleMock = roleList.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMRoles.GetAll()).Returns(roleMock);
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);

            var locationMap = new ORMLocation
            {
                Id = 1,
                LocationType = "B"
            };
            var userLocationMap = new ORMUserLocationMap { };
            if (ExpectedResult == "NoLocationMapped")
            {
                userLocationMap = new ORMUserLocationMap { };  // No Location Mapped for non Admin user 
            }
            else
            {
                userLocationMap = new ORMUserLocationMap
                {
                    UserId = user.Id,
                    ORMUser = user,
                    ORMLocation = locationMap,
                    LocationId = 1,
                    Id = 1,
                };
            };
            var userLlocationList = new List<ORMUserLocationMap>() { userLocationMap }.AsQueryable();
            var userLocationMock = userLlocationList.BuildMockDbSet();

            var locationList = new List<ORMLocation>() { locationMap }.AsQueryable();
            var locationMock = locationList.AsQueryable().BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUserLocationMap.GetAll()).Returns(userLocationMock);

            ///send response for Successful Login attempt
            var AdResponse = new AdLoginResponse()
            {
                ManagerDepartment = "qqq",
                ManagerName = "www",
                StaffName = EncryptedLoginrequest.Email,
                DisplayName = EncryptedLoginrequest.Email,
                Email = EncryptedLoginrequest.Email,
                Department = "rrr",
                Groups = "TestUser | NAPSSuper ",
                MobileNo = "333333",
                StaffId = "FCMB",
            };

            var result = new ObjectResponse<AdLoginResponse>("Account exists with this username in Ad", ResponseCodes.Success)
            {
                Data = AdResponse
            };
            
            A.CallTo(() => _authService.LoginAsync(DecryptedLoginrequest)).Returns(result);
            // Act
            var LoginResult = await _testClass.LoginAsync(EncryptedLoginrequest, "127.168.0.1");

            // Assert
            if (ExpectedResult == "NoPermission")
            {
                Assert.NotNull(result);
                Assert.Equal("995", LoginResult.Code);
                A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustNotHaveHappened();
                A.CallTo(() => _unitOfWork.Save()).MustNotHaveHappened();
            }
            if (ExpectedResult == "NoLocationMapped")
            {
                Assert.NotNull(result);
                Assert.Equal("Login rejected- No Location Assigned to User. Please contact Admin", LoginResult.Description);
                Assert.Equal("995", LoginResult.Code);
            }
            if (ExpectedResult == "AllowPermission")
            {
                Assert.NotNull(result);
                Assert.Equal("00", LoginResult.Code);
                A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustHaveHappened();
                A.CallTo(() => _unitOfWork.Save()).MustHaveHappened();
            }
            
            if (ExpectedResult == "UserNotFound")
            {
                Assert.NotNull(result);
                Assert.Equal("999", LoginResult.Code);
                A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustNotHaveHappened();
                A.CallTo(() => _unitOfWork.Save()).MustNotHaveHappened();
            }
            if (ExpectedResult == "NoRoleFound")
            {
                Assert.NotNull(result);
                Assert.Equal("999", LoginResult.Code);
                Assert.Equal("No Role Assigned to User", LoginResult.Description);
                A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustNotHaveHappened();
                A.CallTo(() => _unitOfWork.Save()).MustNotHaveHappened();
            }

        }

        [Theory]
        [InlineData("testemail", "ExistingUser")]  
        [InlineData("incorrecttestemail", "NewUser")]  
        public async Task LoginAsync_InvalidCredentials_ReturnUnauthenticatedUser(string ormusername, string ExpectedResult)
        {
            // Arrange
            var username = "testemail";
            var EncryptedPassword = "/+ax3FRFrly5qS4TqSwBZ4kzxrDDrdmREjYJ/zCRrcA=";
            var DecryptedPassword = "Courageous@@2024";
            var EncryptedLoginrequest = new LoginRequest() { Email = username, Password = EncryptedPassword };
            var DecryptedLoginrequest = new LoginRequest() { Email = username, Password = DecryptedPassword };

            var _configuration = new ConfigurationBuilder().
                             SetBasePath(Directory.GetCurrentDirectory())
                             .AddJsonFile("appsettings.json", false)
                            .AddUserSecrets(typeof(Program).GetTypeInfo().Assembly).Build();

            A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).Returns("TestValue19909655");
            A.CallTo(() => _unitOfWork.Save()).Returns(2107767265);
            A.CallTo(() => _unitOfWork.ORMUsers).Returns(A.Fake<IOrmUserRepository>());
            A.CallTo(() => _unitOfWork.ORMUserLocationMap).Returns(A.Fake<IOrmUserLocationMapRepository>());
            A.CallTo(() => _unitOfWork.ORMRoles).Returns(A.Fake<IRoleRepository>());
            A.CallTo(() => _keyVaultHelpere.GetSecretAsync("orm-encryption-iv")).Returns("znQ343StbIgWSZrm");
            A.CallTo(() => _keyVaultHelpere.GetSecretAsync("orm-encryption-key")).Returns("Ps5mzoHtFAmDFpg7");

            var user = new ORMUser
            {
                UserName = ormusername,  // Choose correct username so that ormuser fetch record
                Id = 400,
                Email = EncryptedLoginrequest.Email,
                Status = "Active",
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
                FailedLoginCount = "0",
            };
            var list = new List<ORMUser>() { user };
            var role = new ORMAppRole
            {
                RoleId = 1,
                RoleTitle = "Admin"
            };
            var roleList = new List<ORMAppRole>() { role };
            var roleMock = roleList.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMRoles.GetAll()).Returns(roleMock);
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);

            var locationMap = new ORMLocation
            {
                Id = 1,
                LocationType = "B"
            };
            var userLocationMap = new ORMUserLocationMap
            {
                UserId = user.Id,
                ORMUser = user,
                ORMLocation = locationMap,
                LocationId = 1,
                Id = 1,
            };
            var userLlocationList = new List<ORMUserLocationMap>() { userLocationMap }.AsQueryable();
            var userLocationMock = userLlocationList.BuildMockDbSet();

            var locationList = new List<ORMLocation>() { locationMap }.AsQueryable();
            var locationMock = locationList.AsQueryable().BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUserLocationMap.GetAll()).Returns(userLocationMock);

            ///send response for Successful Login attempt
            var AdResponse = new AdLoginResponse()
            {
                ManagerDepartment = "qqq",
                ManagerName = "www",
                StaffName = EncryptedLoginrequest.Email,
                DisplayName = EncryptedLoginrequest.Email,
                Email = EncryptedLoginrequest.Email,
                Department = "rrr",
                Groups = "TestUser | NAPSSuper ",
                MobileNo = "333333",
                StaffId = "FCMB",
            };

            var result = new ObjectResponse<AdLoginResponse>("Unauthenticated User", ResponseCodes.InvalidCredentials)
            {
                Data = AdResponse
            };
            //var _authService = new Mock<IAuthService>();
            A.CallTo(() => _authService.LoginAsync(DecryptedLoginrequest)).Returns(result);
            //authService.Setup(o => o.LoginAsync(RequestData)).ReturnsAsync(result);
            //AuthSetupService testClass1 = new AuthSetupService(_logger, _authService, _authTokenGenerator, _unitOfWork, _mailService, _sessionService, _configuration);
            // Act
            var LoginResult = await _testClass.LoginAsync(EncryptedLoginrequest, "127.168.0.1");

            // Assert
            if (ExpectedResult == "ExistingUser")
            {
                A.CallTo(() => _unitOfWork.Save()).MustHaveHappened();
                Assert.Equal("1", user.FailedLoginCount);   // failed count increments for existing user 
            }
            if (ExpectedResult == "NewUser")
            {
                A.CallTo(() => _unitOfWork.Save()).MustNotHaveHappened();
                Assert.Equal("0", user.FailedLoginCount);   // failed count does not increment for new user 
            }
            Assert.NotNull(LoginResult);
            Assert.Equal("996", LoginResult.Code);
            A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustNotHaveHappened();

        }
        [Fact]
        public async Task LoginAsync_Ad_Timeout()
        {
            // Arrange
            var username = "testemail";
            var EncryptedPassword = "/+ax3FRFrly5qS4TqSwBZ4kzxrDDrdmREjYJ/zCRrcA=";
            var DecryptedPassword = "Courageous@@2024";
            var EncryptedLoginrequest = new LoginRequest() { Email = username, Password = EncryptedPassword };
            var DecryptedLoginrequest = new LoginRequest() { Email = username, Password = DecryptedPassword };

            var _configuration = new ConfigurationBuilder().
                              SetBasePath(Directory.GetCurrentDirectory())
                             .AddJsonFile("appsettings.json", false)
                             .AddUserSecrets(typeof(Program).GetTypeInfo().Assembly).Build();

            var result = new ObjectResponse<AdLoginResponse>("Invalid return from Ad", ResponseCodes.ServiceError) {};

            A.CallTo(() => _authService.LoginAsync(DecryptedLoginrequest)).Returns(result);
            A.CallTo(() => _keyVaultHelpere.GetSecretAsync("orm-encryption-iv")).Returns("znQ343StbIgWSZrm");
            A.CallTo(() => _keyVaultHelpere.GetSecretAsync("orm-encryption-key")).Returns("Ps5mzoHtFAmDFpg7");
            A.CallTo(() => _unitOfWork.ORMUsers).Returns(A.Fake<IOrmUserRepository>());

            var user = new ORMUser
            {
                UserName = username,  // Choose correct username so that ormuser fetch record
                Id = 400,
                Email = EncryptedLoginrequest.Email,
                Status = "Active",
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
                FailedLoginCount = "0",
            };
            var list = new List<ORMUser>() { user };
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);
            // Act
            var LoginResult = await _testClass.LoginAsync(EncryptedLoginrequest, "127.168.0.1");

            // Assert
            Assert.NotNull(result);
            Assert.Equal("999", LoginResult.Code);
            A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustNotHaveHappened();
            A.CallTo(() => _unitOfWork.Save()).MustNotHaveHappened();
        }

        [Theory]
        [InlineData("RequestNull")]                     // Request is null  
        [InlineData("RequestEmailBlank")]               // Request.Email is ""
        [InlineData("RequestPasswordBlank")]            // Request.Password is ""
        [InlineData("orm-encryption-iv")]               // EncryptionKeys:IV is blank/null in appsetting file
        [InlineData("orm-encryption-key")]              // EncryptionKeys:Key secret is blank/null in appsetting file
        public async Task LoginAsync_Invalid_Request(string input)
        {
            // Arrange

            var _configuration = new ConfigurationBuilder().
                             //SetBasePath(Directory.GetCurrentDirectory())
                             SetBasePath(AppContext.BaseDirectory)
                             .AddJsonFile("appsettings.json", false)
                            .AddUserSecrets(typeof(Program).GetTypeInfo().Assembly).Build();

            var Loginrequest = new LoginRequest() { Email = "TestEmail", Password = "UserPassword" };

            var ErrorMessage = "Please provide valid user name and/or Password";
            var ErrorCode = "996";

            if (input == "RequestNull")
            {
                Loginrequest = null;

            }
            if (input == "RequestEmailBlank")
            {
                Loginrequest = new LoginRequest() { Email = "", Password = "UserPassword" };

            }
            if (input == "RequestPasswordBlank")
            {
                Loginrequest = new LoginRequest() { Email = "TestEmail", Password = "" };

            }
            if (input == "orm-encryption-iv")
            {
                _configuration["orm-encryption-iv"] = null;
                ErrorMessage = "orm-encryption-iv is missing in appsettings file";
                ErrorCode = "994";
            }
            if (input == "orm-encryption-key")
            {
                _configuration["orm-encryption-key"] = null;
                ErrorMessage = "orm-encryption-iv is missing in appsettings file";
                ErrorCode = "994";
            }

            var _newtestClass = new AuthSetupService(_logger, _authService, _authTokenGenerator, _unitOfWork, _sessionService, _keyVaultHelpere);

            var LoginResult = await _newtestClass.LoginAsync(Loginrequest!, "127.168.0.1");

            // Assert

            //
            //

            Assert.NotNull(LoginResult);
            Assert.Equal(ErrorCode, LoginResult.Code);
            Assert.Equal(ErrorMessage, LoginResult.Description);
            A.CallTo(() => _authTokenGenerator.Generate(A<bool>._, A<StaffSession>._, A<TimeSpan>._)).MustNotHaveHappened();
            A.CallTo(() => _unitOfWork.Save()).MustNotHaveHappened();
        }

        [Theory]
        [InlineData("TestValue", "Unauthenticated")]      // session data is null 
        [InlineData("", "InvalidInputUserName")]            // input username is null or blank
        [InlineData("InValidUser", "UserNotinSession")]     // session data does not have username in request 
        [InlineData("ValidUser", "UserNotFoundinORM")]  // Username not found in ORMUser table
        [InlineData("TestValue", "SuccessfullLogout")]    // logout is successfull
        public async Task CanCallLogoutAsync(string UserName,string ExpectedResult)
        {
            // Arrange
            var username = UserName;
            if (ExpectedResult == "UserNotFoundinORM")
            {
                username = "UserNamenotinORM";
            }
            var user = new ORMUser
            {
                UserName = username,
                Id = 400,
                Email = UserName,
                Status = "Active",
                RoleId = 1,
                CurrentLoginTime = DateTime.Now,
            };
            var list = new List<ORMUser>() { user };
            var mock = list.BuildMockDbSet();
            A.CallTo(() => _unitOfWork.ORMUsers.GetAll()).Returns(mock);

            var staffSession = new StaffSession(1, UserName, UserName, "ABC123", 2);

            if (ExpectedResult == "UserNotinSession")
            {
                staffSession = new StaffSession(1, "UserName", "UserName", "ABC123", 2);
            }

            if (ExpectedResult == "Unauthenticated")
            {
                A.CallTo(() => _sessionService.GetStaffSession()).Returns(null);
            }
            else
            {
                A.CallTo(() => _sessionService.GetStaffSession()).Returns(staffSession);
            }
            // Act
            var result = new ObjectResponse<string>("You have been successfully logged out", ResponseCodes.Success);
            if (ExpectedResult == "InvalidInputUserName")
            {
                result = await _testClass.LogoutAsync(null!, "127.168.0.1");
            }
            else
            {
                result = await _testClass.LogoutAsync(UserName, "127.168.0.1");
            }


            // Assert
            Assert.NotNull(result);
            if (ExpectedResult == "Unauthenticated")
            {
                Assert.Equal("997", result.Code);
                Assert.Equal("User Is Unauthenticated", result.Description);
            }
            if (ExpectedResult == "InvalidInputUserName")
            {
                Assert.Equal("998", result.Code);
                Assert.Equal("Error - User Name is blank!.", result.Description);
            }
            if (ExpectedResult == "UserNotinSession")
            {
                Assert.Equal("997", result.Code);
                Assert.Equal("This user does not belong to existing session.", result.Description);
            }
            if (ExpectedResult == "UserNotFoundinORM")
            {
                Assert.Equal("998", result.Code);
                Assert.Equal("User Not Found", result.Description);
            }
            if (ExpectedResult == "SuccessfullLogout")
            {
                Assert.Equal("00", result.Code);
                Assert.Equal("You have been successfully logged out", result.Description);
            }
        }

    }

}