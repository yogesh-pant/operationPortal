namespace ORM.Test.Services.Auth
{
    using System;
    using System.Security.Claims;
    using FakeItEasy;
    using FluentAssertions;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using ORM.Application.Models.Auth;
    using ORM.Infrastructure.Services.Auth;
    using Xunit;

    public class JwtTokenGeneratorTests
    {
        private readonly JwtTokenGenerator _testClass;
        private readonly ILogger<JwtTokenGenerator> _logger;
        private readonly IConfiguration _configuration;

        public JwtTokenGeneratorTests()
        {
            _logger = A.Fake<ILogger<JwtTokenGenerator>>();
            _configuration = A.Fake<IConfiguration>();
            _testClass = new JwtTokenGenerator(_logger, _configuration);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new JwtTokenGenerator(_logger, _configuration);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public void CanCallGenerateEmpty()
        {
            // Arrange
            var isAutherizedUser = false;
            var session = new StaffSession(906748309L, "TestValue1553199723", "TestValue1633745203", "TestValue1150902736", 1883670696L);
            var validity = TimeSpan.FromSeconds(226);

            // Act
            var result = _testClass.Generate(isAutherizedUser, session, validity);

            // Assert
            result.Should().BeNullOrEmpty();

        }

        [Fact]
        public void CanCallGenerate()
        {
            // Arrange
            var logger = A.Fake<ILogger<JwtTokenGenerator>>();

            // Set up configuration for testing
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection()
                .AddJsonFile("appsettings.json") // Adjust the path if necessary
                .Build();

            configuration["orm-jwt-key"] = "-20hjewuuewyuhwqeiuhweiuhewiuhweiuhewiyhwey";
            configuration["JWTConfig:Issuer"] = "your_issuer";
            configuration["JWTConfig:Audience"] = "your_audience";

            var jwtTokenGenerator = new JwtTokenGenerator(logger, configuration);

            var session = new StaffSession(906748309L, "TestValue1553199723", "TestValue1633745203", "TestValue1150902736", 1883670696L);


            // Act
            var token = jwtTokenGenerator.Generate(true, session, TimeSpan.FromMinutes(30));
           
            // Assert
            token.Should().NotBeNullOrEmpty();

        }


    }
}