﻿using System.Collections.Generic;
using ORM.Infrastructure.Services.Common;
using Xunit;

namespace ORM.Test.Services
{
    public class EmailUtilsTests
    {
        [Fact]
        public void UpdatePlaceHolders_NullText_ReturnsNull()
        {
            // Arrange
            string text = null!;
            var replacements = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("{{NAME}}", "John")
            };

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void UpdatePlaceHolders_EmptyText_ReturnsEmptyString()
        {
            // Arrange
            string text = string.Empty;
            var replacements = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("{{NAME}}", "John")
            };

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Equal(string.Empty, result);
        }

        [Fact]
        public void UpdatePlaceHolders_NullReplacements_ReturnsOriginalText()
        {
            // Arrange
            string text = "Hello, {{NAME}}!";
            List<KeyValuePair<string, string>> replacements = null!;

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements!);

            // Assert
            Assert.Equal("Hello, {{NAME}}!", result);
        }

        [Fact]
        public void UpdatePlaceHolders_EmptyReplacements_ReturnsOriginalText()
        {
            // Arrange
            string text = "Hello, {{NAME}}!";
            var replacements = new List<KeyValuePair<string, string>>();

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Equal("Hello, {{NAME}}!", result);
        }

        [Fact]
        public void UpdatePlaceHolders_SingleReplacement_ReplacesCorrectly()
        {
            // Arrange
            string text = "Hello, {{NAME}}!";
            var replacements = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("{{NAME}}", "John")
            };

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Equal("Hello, John!", result);
        }

        [Fact]
        public void UpdatePlaceHolders_MultipleReplacements_ReplacesAllCorrectly()
        {
            // Arrange
            string text = "Hello, {{NAME}}! Your order #{{ORDER_ID}} has been processed.";
            var replacements = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("{{NAME}}", "John"),
                new KeyValuePair<string, string>("{{ORDER_ID}}", "12345")
            };

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Equal("Hello, John! Your order #12345 has been processed.", result);
        }

        [Fact]
        public void UpdatePlaceHolders_NoMatchingPlaceholders_ReturnsOriginalText()
        {
            // Arrange
            string text = "Hello, {{NAME}}!";
            var replacements = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("{{EMAIL}}", "john@example.com")
            };

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Equal("Hello, {{NAME}}!", result);
        }

        [Fact]
        public void UpdatePlaceHolders_CaseSensitivePlaceholders_ReplacesCorrectly()
        {
            // Arrange
            string text = "Hello, {{NAME}}! Your name in lowercase is {{name}}.";
            var replacements = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("{{NAME}}", "John"),
                new KeyValuePair<string, string>("{{name}}", "john")
            };

            // Act
            var result = EmailUtils.UpdatePlaceHolders(text, replacements);

            // Assert
            Assert.Equal("Hello, John! Your name in lowercase is john.", result);
        }
    }
}