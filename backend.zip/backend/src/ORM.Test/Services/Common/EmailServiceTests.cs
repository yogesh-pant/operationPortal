﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using ORM.Application.Interfaces.Common;
using ORM.Application.Models.Requests.Mails;
using ORM.Infrastructure.Services.Common;
using Xunit;

namespace ORM.Test.Services
{
    public class EmailServiceTests
    {
        private readonly Mock<IHttpClientFactory> _mockHttpClientFactory;
        private readonly Mock<ILogger<EmailService>> _mockLogger;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly Mock<IKeyVaultHelper> _mockKeyVaultHelper;
        private readonly EmailService _emailService;

        public EmailServiceTests()
        {
            _mockHttpClientFactory = new Mock<IHttpClientFactory>();
            _mockLogger = new Mock<ILogger<EmailService>>();
            _mockConfiguration = new Mock<IConfiguration>();
            _mockKeyVaultHelper = new Mock<IKeyVaultHelper>();

            _emailService = new EmailService(
                _mockHttpClientFactory.Object,
                _mockLogger.Object,
                _mockConfiguration.Object,
                _mockKeyVaultHelper.Object
            );
        }

        [Fact]
        public async Task SendEmailAsync_SuccessfulRequest_ReturnsTrue()
        {
            // Arrange
            var emailRequest = new SendEmailRequest
            {
                From = "sender@example.com",
                To = "recipient@example.com",
                Subject = "Test Subject",
                Body = "Test Body",
                Cc = new List<string> { "cc@example.com" },
                Bcc = new List<string> { "bcc@example.com" }
            };

            var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
            mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("Email sent successfully")
                });

            var client = new HttpClient(mockHttpMessageHandler.Object);
            _mockHttpClientFactory.Setup(x => x.CreateClient("emailClient")).Returns(client);

            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns("http://example.com");
            _mockConfiguration.Setup(x => x.GetSection("FCMBConfig:EmailConfig:EmailUrl")).Returns(mockConfigSection.Object);

            _mockKeyVaultHelper.Setup(x => x.GetSecretAsync("orm-fcmbconfig-clientid"))
                .ReturnsAsync("test-client-id");

            // Act
            var result = await _emailService.SendEmailAsync(emailRequest);

            // Assert
            Assert.True(result);
            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => o.ToString()!.Contains("Email sent successfully")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()!),
                Times.Once);
        }

        [Fact]
        public async Task SendEmailAsync_FailedRequest_ReturnsFalse()
        {
            // Arrange
            var emailRequest = new SendEmailRequest
            {
                From = "sender@example.com",
                To = "recipient@example.com",
                Subject = "Test Subject",
                Body = "Test Body"
            };

            var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
            mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.InternalServerError,
                    Content = new StringContent("Error sending email")
                });

            var client = new HttpClient(mockHttpMessageHandler.Object);
            _mockHttpClientFactory.Setup(x => x.CreateClient("emailClient")).Returns(client); var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns("http://example.com");
            _mockConfiguration.Setup(x => x.GetSection("FCMBConfig:EmailConfig:EmailUrl")).Returns(mockConfigSection.Object);

            _mockKeyVaultHelper.Setup(x => x.GetSecretAsync("orm-fcmbconfig-clientid"))
                .ReturnsAsync("test-client-id");

            // Act
            var result = await _emailService.SendEmailAsync(emailRequest);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SendEmailAsync_WithCcAndBcc_SendsCorrectRequest()
        {
            // Arrange
            var emailRequest = new SendEmailRequest
            {
                From = "sender@example.com",
                To = "recipient@example.com",
                Subject = "Test Subject",
                Body = "Test Body",
                Cc = new List<string> { "cc1@example.com", "cc2@example.com" },
                Bcc = new List<string> { "bcc1@example.com", "bcc2@example.com" }
            };

            var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
            mockHttpMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("Email sent successfully")
                })
                .Callback<HttpRequestMessage, CancellationToken>((req, token) =>
                {
                    var content = req.Content as MultipartFormDataContent;
                    Assert.NotNull(content);
                    Assert.Equal(8, content.Count()); // From, To, Subject, Body, 2 Cc, 2 Bcc
                });

            var client = new HttpClient(mockHttpMessageHandler.Object);
            _mockHttpClientFactory.Setup(x => x.CreateClient("emailClient")).Returns(client);

            var mockConfigSection = new Mock<IConfigurationSection>();
            mockConfigSection.Setup(x => x.Value).Returns("http://example.com");
            _mockConfiguration.Setup(x => x.GetSection("FCMBConfig:EmailConfig:EmailUrl")).Returns(mockConfigSection.Object);

            _mockKeyVaultHelper.Setup(x => x.GetSecretAsync("orm-fcmbconfig-clientid"))
                .ReturnsAsync("test-client-id");

            // Act
            var result = await _emailService.SendEmailAsync(emailRequest);

            // Assert
            Assert.True(result);
        }
    }
}