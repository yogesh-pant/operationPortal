namespace ORM.Test.Services.Common
{
    using System;
    using System.Threading.Tasks;
    using FakeItEasy;
    using FluentAssertions;
    using MailKit.Net.Smtp;
    using Microsoft.Extensions.Options;
    using MimeKit;
    using ORM.Application.Models.Requests.Mails;
    using ORM.Domain.Common;
    using ORM.Infrastructure.Services.Common;
    using Xunit;

    public class MailServiceTests
    {
        private MailService _testClass;
        private IOptions<MailSettings> _mailSettingsOptions;

        public MailServiceTests()
        {
            _mailSettingsOptions = A.Fake<IOptions<MailSettings>>();
            _testClass = new MailService(_mailSettingsOptions);
        }

        [Fact]
        public void CanConstruct()
        {
            // Act
            var instance = new MailService(_mailSettingsOptions);

            // Assert
            instance.Should().NotBeNull();
        }

        [Fact]
        public async Task CanCallSendMailAsync()
        {
            // Arrange
            var mailData = new MailDataRequest
            {
                EmailToId = "TestValue1761622906",
                EmailToName = "TestValue1925300513",
                EmailSubject = "TestValue433800940",
                EmailBody = "TestValue387700632"
            };

            // Act
            var result = await _testClass.SendMailAsync(mailData);

            // Assert
            result.Should().BeFalse();
        }


        

    }
}