﻿using System;
using System.Threading.Tasks;
using Azure;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using ORM.Application.Interfaces.Common;
using Xunit;

namespace ORM.Application.Tests
{
    public class KeyVaultHelperTests
    {
        private readonly Mock<ILogger<KeyVaultHelper>> _loggerMock;
        private readonly Mock<IConfiguration> _configurationMock;

        public KeyVaultHelperTests()
        {
            _loggerMock = new Mock<ILogger<KeyVaultHelper>>();
            _configurationMock = new Mock<IConfiguration>();
        }

        [Fact]
        public async Task GetSecretAsync_ConfigurationValueExists_ReturnsConfigurationValue()
        {
            // Arrange
            const string secretName = "TestSecret";
            const string expectedValue = "TestValue";

            _configurationMock.Setup(c => c.GetSection(secretName).Value).Returns(expectedValue);

            var keyVaultHelper = new KeyVaultHelper(_loggerMock.Object, _configurationMock.Object);

            // Act
            var result = await keyVaultHelper.GetSecretAsync(secretName);

            // Assert
            Assert.Equal(expectedValue, result);
        }

        //[Fact]
        public async Task GetSecretAsync_DevKeyVaultEnabled_ReturnsSecretFromDevKeyVault()
        {
            // Arrange
            const string secretName = "TestSecret";
            const string expectedValue = "DevKeyVaultValue";
            SetupDevKeyVaultConfiguration();
            _configurationMock.Setup(c => c.GetSection(secretName).Value).Returns((string)null);

            var keyVaultHelper = new KeyVaultHelper(_loggerMock.Object, _configurationMock.Object);

            // Set up mock SecretClient
            var mockSecretClient = SetupMockSecretClient(secretName, expectedValue);
            SetSecretClientField(keyVaultHelper, mockSecretClient.Object);

            // Act
            var result = await keyVaultHelper.GetSecretAsync(secretName);

            // Assert
            Assert.Equal(expectedValue, result);
        }

        //[Fact]
        public async Task GetSecretAsync_ProdKeyVaultEnabled_ReturnsSecretFromProdKeyVault()
        {
            // Arrange
            const string secretName = "TestSecret";
            const string expectedValue = "ProdKeyVaultValue";
            SetupProdKeyVaultConfiguration();
            _configurationMock.Setup(c => c.GetSection(secretName).Value).Returns((string)null);

            var keyVaultHelper = new KeyVaultHelper(_loggerMock.Object, _configurationMock.Object);

            // Set up mock SecretClient
            var mockSecretClient = SetupMockSecretClient(secretName, expectedValue);
            SetSecretClientField(keyVaultHelper, mockSecretClient.Object);

            // Act
            var result = await keyVaultHelper.GetSecretAsync(secretName);

            // Assert
            Assert.Equal(expectedValue, result);
        }

        //[Fact]
        public async Task GetSecretAsync_SecretNotFound_ThrowsRequestFailedException()
        {
            // Arrange
            const string secretName = "NonExistentSecret";
            SetupDevKeyVaultConfiguration();
            _configurationMock.Setup(c => c.GetSection(secretName).Value).Returns((string)null);

            var keyVaultHelper = new KeyVaultHelper(_loggerMock.Object, _configurationMock.Object);

            // Set up mock SecretClient to throw RequestFailedException
            var mockSecretClient = new Mock<SecretClient>();
            mockSecretClient.Setup(c => c.GetSecretAsync(secretName, It.IsAny<string>(), default))
                .ThrowsAsync(new RequestFailedException(404, "Secret not found"));
            SetSecretClientField(keyVaultHelper, mockSecretClient.Object);

            // Act & Assert
            await Assert.ThrowsAsync<RequestFailedException>(() => keyVaultHelper.GetSecretAsync(secretName));
        }

        [Fact]
        public async Task GetSecretAsync_KeyVaultUrlMissing_ThrowsInvalidOperationException()
        {
            // Arrange
            const string secretName = "TestSecret";
            _configurationMock.Setup(c => c.GetSection(secretName).Value).Returns((string)null);
            _configurationMock.Setup(c => c.GetSection("AzureKeyVaultURLDev").Value).Returns("");
            _configurationMock.Setup(c => c.GetSection("AzureKeyVault:AzureKeyVaultURL").Value).Returns((string)null);

            var keyVaultHelper = new KeyVaultHelper(_loggerMock.Object, _configurationMock.Object);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => keyVaultHelper.GetSecretAsync(secretName));
        }

        private void SetupDevKeyVaultConfiguration()
        {
            _configurationMock.Setup(c => c.GetSection("AzureKeyVaultURLDev").Value).Returns("https://dev-keyvault.vault.azure.net/");
            _configurationMock.Setup(c => c.GetSection("AzureClientId").Value).Returns("client-id");
            _configurationMock.Setup(c => c.GetSection("AzureClientSecret").Value).Returns("client-secret");
            _configurationMock.Setup(c => c.GetSection("AzureClientTenantId").Value).Returns("tenant-id");
        }

        private void SetupProdKeyVaultConfiguration()
        {
            _configurationMock.Setup(c => c.GetSection("AzureKeyVaultURLDev").Value).Returns("");
            _configurationMock.Setup(c => c.GetSection("AzureKeyVault:AzureKeyVaultURL").Value).Returns("https://prod-keyvault.vault.azure.net/");
        }

        private Mock<SecretClient> SetupMockSecretClient(string secretName, string secretValue)
        {
            var mockSecretClient = new Mock<SecretClient>();
            var mockResponse = Response.FromValue(new KeyVaultSecret(secretName, secretValue), Mock.Of<Response>());
            mockSecretClient.Setup(c => c.GetSecretAsync(secretName, It.IsAny<string>(), default))
                .ReturnsAsync(mockResponse);
            return mockSecretClient;
        }

        private void SetSecretClientField(KeyVaultHelper keyVaultHelper, SecretClient secretClient)
        {
            var field = typeof(KeyVaultHelper).GetField("secretClient", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (field != null)
            {
                field.SetValue(keyVaultHelper, secretClient);
            }
            else
            {
                throw new InvalidOperationException("Unable to set _secretClient field. The field might have been renamed or removed.");
            }
        }
    }
}