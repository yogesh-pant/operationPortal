﻿using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;

namespace ORM.Test.KRIServiceTestFolder
{
    public class KRIServiceTest
    {
        [Fact]
        public async Task GetKriReportGridAsync_UserUnAuthenticated_ReturnUnauthenticatedReponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new KriGridRequest();

            //Act
            var response = await kriService.GetKriGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task GetKriGridAsync_ValidRequest_ReturnSucessfulResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            var data = GenerateORMKRIReportMetricsMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 

            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());


            //ORMKRI -Report
            var reportData2 = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(reportData2.BuildMock()); //

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());

            var input = GenerateKriGridRequestMockData();
            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI grid data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task GetKriGridAsync_ValidRequest_ReturnZeroResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            var data = GenerateORMKRIReportMetricsMockData();
            //var data = new List<ORMKRIReportMetrics>
            //{
            //    new ORMKRIReportMetrics
            //    {
            //    },
            //};
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());


            //ORMKRI -Report
            var reportData2 = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(reportData2.BuildMock()); //

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());

            var input = new KriGridRequest
            {
                RefNo = "KRI001",
                LocationId = 2,
                Branch = "Branch A",
                Status = "Pending",
                MinDate = DateTime.Now.AddDays(-30),
                MaxDate = DateTime.Now.AddDays(+1)
            };
            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("No record found for given input", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task GetKriGridAsync_ValidRequest_NullInputResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            var data = GenerateORMKRIReportMetricsMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());


            //ORMKRI -Report
            var reportData2 = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(reportData2.BuildMock()); //

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());
            //no input provided 
            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriGridAsync(null);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Invalid input", response.Description);
            Assert.Equal(ResponseCodes.DataNotFound, response.Code);

        }

        [Fact]
        public async Task GetKriReportGridAsync_UserUnAuthenticated_ReturnUnauthenticatedReposne()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new KriGridRequest();

            //Act
            var response = await kriService.GetKriReportGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task GetKriReportGridAsync_ValidRequest_ReturnSucessfulResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();


            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };

            //ORM users
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());


            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());

            var input = GenerateKriGridRequestMockData();

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriReportGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI grid data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task GetKriReportGridAsync_ValidRequest_ReturnZeroResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();


            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };

            //ORM users
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());


            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());

            //var input = GenerateKriGridRequestMockData();
            var input = new KriGridRequest
            {
                RefNo = "KRI001",
                LocationId = 2,
                Branch = "Branch A",
                //Department = "Department X",
                //Region = "Region 1",
                Status = "Pending",
                MinDate = DateTime.Now.AddDays(-30),
                MaxDate = DateTime.Now.AddDays(+1)
            };

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriReportGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("No record found for given input", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task GetKriReportGridAsync_ValidRequest_NullInputResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();


            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };

            //ORM users
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());


            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriReportGridAsync(null);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Invalid input", response.Description);
            Assert.Equal(ResponseCodes.DataNotFound, response.Code);

        }

        [Fact]
        public async Task GetKriReportGridAsync_InvalidRequest_ReturnDataNotFoundResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();


            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };

            //ORM users
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());


            //ORM Location
            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable())
                    .Returns(locationData.BuildMock());

            var input = GenerateKriGridRequestMockData2();

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            //Act
            var response = await kriService.GetKriReportGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI grid data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }


        [Fact]
        public async Task GetNewKriAsync_UserUnathenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new GetNewKriRequest();

            //Act
            var response = await kriService.GetNewKriAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task GetNewKriAsync_ValidRequest_ReturnSuccessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var data = GenerateORMKRIMetricMasterMockData();

            mockUnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 

            var input = GenerateGetNewKriRequestMockData();

            //Act
            var response = await kriService.GetNewKriAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI master data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);


        }

        [Fact]
        public async Task AddKriInfo_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new AddKriRequest();

            //Act
            var response = await kriService.AddKriInfo(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task AddKriInfo_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            var input = GenerateAddKriRequestMockData();

            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 


            //Act
            var response = await kriService.AddKriInfo(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Kri report Created!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task AddKriInfo_ValidRequest_NoRefNUM_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object,  mockUnitOfWork.Object);

            var input = GenerateAddKriRequestMockData2();

            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 


            //Act
            var response = await kriService.AddKriInfo(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Kri report Created!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task AddKrimetric_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new AddKriReport();

            //Act
            var response = await kriService.AddKrimetric(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }


        [Fact]
        public async Task AddKrimetric_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object,  mockUnitOfWork.Object);
            var input = GenerateAddKriReportMockData();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); // Simulating that a user exists with the given ID exists


            var ORMKRIMetricMasterData = GenerateORMKRIMetricMasterMockData();

            mockUnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable())
                         .Returns(ORMKRIMetricMasterData.BuildMock()); 
            //Act
            var response = await kriService.AddKrimetric(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Kri Metric Saved!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }



        [Fact]
        public async Task AddKrimetric_ValidRequest_AppetitieType_D_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateAddKriReportMockData();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 


            var ORMKRIMetricMasterData = GenerateORMKRIMetricMasterMockData2();

            mockUnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable())
                         .Returns(ORMKRIMetricMasterData.BuildMock()); 

            //Act
            var response = await kriService.AddKrimetric(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Kri Metric Saved!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }


        [Fact]
        public async Task AddKrimetric_ValidRequest_CalculatedThresholdUnknown_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object,  mockUnitOfWork.Object);
            var input = GenerateAddKriReportMockData();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 


            var ORMKRIMetricMasterData = GenerateORMKRIMetricMasterMockData3();

            mockUnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable())
                         .Returns(ORMKRIMetricMasterData.BuildMock()); 

            //Act
            var response = await kriService.AddKrimetric(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Kri Metric Saved!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }

        [Fact]
        public async Task GetPreviewKriAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object,  mockUnitOfWork.Object);
            var input = new GetPreviewKriMultipleRequest();

            //Act
            var response = await kriService.GetPreviewKriAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }


        [Fact]
        public async Task GetPreviewKriAsync_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            var input = GenerateGetPreviewKriMultipleRequestMockData();

            var data = GenerateORMKRIReportMetricsMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); 

            var ORMKRIReportData = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(ORMKRIReportData.BuildMock()); 

            //Act
            var response = await kriService.GetPreviewKriAsync(input);


            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI master data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task GetPreviewKriAsync_ValidRequest_No_Ids_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);

            var input = new GetPreviewKriMultipleRequest()
            {
                ids = Array.Empty<long>(),
                rids = new long[] { 123 }
            };

            var data = GenerateORMKRIReportMetricsMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            var ORMKRIReportData = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(ORMKRIReportData.BuildMock());


            //Act
            var response = await kriService.GetPreviewKriAsync(input);


            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI master data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task GetDetailKriReportAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user
            var kriService = new KriService(mockLogger.Object, session.Object,  mockUnitOfWork.Object);
            var input = new GetPreviewKriRequest();

            //Act
            var response = await kriService.GetDetailKriReportAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task GetDetailKriReportAsync_ValidRequest_ReturnSucessfulResponse()
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var kriService = new KriService(mockLogger.Object, session.Object,  mockUnitOfWork.Object);

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable()).Returns(data.BuildMock());

            var ORMKRIReportData = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(ORMKRIReportData.BuildMock());

            var ORMUser = new List<ORMUser>
            {
                 new ORMUser
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",
                 }
            };
            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock());


            var locationData = GenerateORMLocationMockData();
            mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable()).Returns(locationData.BuildMock());

            var ORMKRIMetricMasterData = GenerateORMKRIMetricMasterMockData();

            mockUnitOfWork.Setup(x => x.ORMKRIMetricMaster.GetAll().AsQueryable())
                         .Returns(ORMKRIMetricMasterData.BuildMock());


            var input = GenerateGetPreviewKriRequestMockData();

            //Act
            var response = await kriService.GetDetailKriReportAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI Report data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }


        [Fact]
        public async Task updatePreviewKriAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new UpdatePreviewKriRequest();

            //Act
            var response = await kriService.UpdatePreviewKriAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task updatePreviewKriAsync_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateUpdatePreviewKriRequestMockData();

            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            //Act
            var response = await kriService.UpdatePreviewKriAsync(input);

            //Assert
            Assert.NotNull(response);

        }


        [Fact]
        public async Task updateKriApproval_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new FinalKriReport();

            //Act
            var response = await kriService.updateKriApproval(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }


        [Fact]
        public async Task updateKriApproval_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();
            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateFinalKriReportMockData();

            //ORMKRI -Report
            var data = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            //Act
            var response = await kriService.updateKriApproval(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Kri report Approved/Rejected!", response.Description);
        }


        [Fact]
        public async Task GetDetailKriMetricAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new UpdatePreviewKriRequest();

            //Act
            var response = await kriService.GetDetailKriMetricAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task GetDetailKriMetricAsync_ValidSucessful_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateUpdatePreviewKriRequestMockData();

            //Act
            var response = await kriService.GetDetailKriMetricAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI master data", response.Description);
        }

        [Fact]
        public async Task GetEditKriReportAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new EditKriRequest();

            //Act
            var response = await kriService.GetEditKriReportAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task GetEditKriReportAsync_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateEditKriRequestMockData();

            //Act
            var response = await kriService.GetEditKriReportAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved KRI master data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }


        [Fact]
        public async Task DeleteKriReportAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new UpdatePreviewKriRequest();

            //Act
            var response = await kriService.DeleteKriReportAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task DeleteKriReportAsync_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            //ORMKRI -Report
            var ORMKRIReportVM = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(ORMKRIReportVM.BuildMock());

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateUpdatePreviewKriRequestMockData();

            //Act
            var response = await kriService.DeleteKriReportAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Deleted KRI report and Metrics", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }


        [Fact]
        public async Task RemoveKriMetricAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            session.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = new UpdatePreviewKriRequest();

            //Act
            var response = await kriService.RemoveKriMetricAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);
        }

        [Fact]
        public async Task RemoveKriMetricAsync_ValidRequest_ReturnSucessfulResponse()
        {
            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();

            var session = MockSessionService();

            var data = GenerateORMKRIReportMetricsMockData2();
            mockUnitOfWork.Setup(x => x.ORMKRIReportMetrics.GetAll().AsQueryable())
                         .Returns(data.BuildMock());

            //ORMKRI -Report
            var ORMKRIReportVM = GenerateORMKRIReportMockData();
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(ORMKRIReportVM.BuildMock());

            var kriService = new KriService(mockLogger.Object, session.Object, mockUnitOfWork.Object);
            var input = GenerateUpdatePreviewKriRequestMockData();

            //Act
            var response = await kriService.RemoveKriMetricAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully deleted:  KRI metric data", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }


        public static Mock<ISessionService> MockSessionService()
        {
            var mockSessionService = new Mock<ISessionService>();

            mockSessionService.Setup(x => x.GetStaffSession()).Returns(new
                StaffSession(1,
                "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            return mockSessionService;
        }

        public static List<ORMKRIReportMetrics> GenerateORMKRIReportMetricsMockData()
        {
            return new List<ORMKRIReportMetrics>
            {
                new ORMKRIReportMetrics
                {
                    Id = 1,
                    KRIReportId = 1,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1, LocationId = 1, ReportingPeriod = "game",Id = 1, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Now, RefNum = "KRI001",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} },
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1 },
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"
                },
                new ORMKRIReportMetrics
                {
                    Id = 2,
                    KRIReportId = 123,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1, LocationId = 1, ReportingPeriod = "game",Id = 123, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Now, RefNum = "KRI002",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} }, // Example of navigation property
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1 }, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"
                },
                new ORMKRIReportMetrics
                {
                    Id = 3,
                    KRIReportId = 321,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1, LocationId = 1, ReportingPeriod = "05/2024",Id = 321, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Now, RefNum = "KRI003",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} }, // Example of navigation property
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1 }, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"
                },
                new ORMKRIReportMetrics
                {
                    Id = 123,
                    KRIReportId = 123,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1, LocationId = 1, ReportingPeriod = "05/2024",Id = 123, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Now, RefNum = "KRI003",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} }, // Example of navigation property
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1 }, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"
                }
            };
        }

        public static List<ORMKRIReportMetrics> GenerateORMKRIReportMetricsMockData2()
        {
            return new List<ORMKRIReportMetrics>
            {
                new ORMKRIReportMetrics
                {
                    Id = 1,
                    KRIReportId = 1,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1, LocationId = 1, ReportingPeriod = "game",Id = 2, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Parse("2023-01-02"), RefNum = "KRI001",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} }, // Example of navigation property
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1, MetricName = "Sunny" }, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"

                },
                new ORMKRIReportMetrics
                {
                    Id = 1,
                    KRIReportId = 2,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1,  ReportingPeriod = "game",LocationId = 1, Id = 2, CreatedById = 1, ReviewedById = 1 , DateReported = DateTime.Parse("2023-01-02"), RefNum = "KRI001",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} }, // Example of navigation property
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1, MetricName = "Sunny" }, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "Sample Description",
                    AmountInvolved = "1000",
                    Currency = "USD",
                    MitigationPlan = "Sample Mitigation Plan",
                    RiskAppetiteThreshold = "Medium"
                },
                new ORMKRIReportMetrics
                {
                    Id = 1,
                    KRIReportId = 3,
                    ORMKRIReport = new ORMKRIReport { ValidatorILOUserId = 1,  ReportingPeriod = "game",Id = 2, CreatedById = 1, ReviewedById = 1,LocationId = 1, DateReported = DateTime.Parse("2023-01-02"), RefNum = "KRI001",LocationType = "B", Status = "Pending",
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User"} }, // Example of navigation property
                    KRIMetricMasterId = 1,
                    ORMKRIMetricMaster = new ORMKRIMetricMaster { Id = 1, MetricName = "Sunny" }, // Example of navigation property
                    DateOccurance = DateTime.Now,
                    KRIData = "Sample KRI Data",
                    Description = "",
                    AmountInvolved = "",
                    Currency = "USD",
                    MitigationPlan = "",
                    RiskAppetiteThreshold = "Medium"
                }
            };
        }

        public static KriGridRequest GenerateKriGridRequestMockData()
        {
            return new KriGridRequest
            {
                RefNo = "KRI001",
                LocationId = 1,
                Branch = "Branch A",
                //Department = "Department X",
                //Region = "Region 1",
                Status = "Pending",
                MinDate = DateTime.Now.AddDays(-30),
                MaxDate = DateTime.Now.AddDays(+1)
            };
        }

        public static KriGridRequest GenerateKriGridRequestMockData2()
        {
            return new KriGridRequest
            {
                RefNo = "KRI001",
                LocationId = 1,
                Branch = "B",
                Department = "Department X",
                Region = "Region 1",
                Status = "Pending",
                MinDate = DateTime.Now.AddDays(-30),
                MaxDate = DateTime.Now.AddDays(+1)
            };
        }


        public static List<ORMLocation> GenerateORMLocationMockData()
        {
            return new List<ORMLocation>
            {
                new ORMLocation
                {
                    Id = 1,
                    LocationId = "B0001",
                    LocationType = "B",
                    SolId = "SOL001",
                    Branch = "Branch A",
                    Region = "Region 1",
                    Department = "Department X",
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 1,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                },
                new ORMLocation
                {
                    Id = 2,
                    LocationId = "D0001",
                    LocationType = "B",
                    SolId = "SOL002",
                    Branch = "Branch B",
                    Region = "Region 2",
                    Department = "Department X",
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 2,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                },
            };
        }


        public static List<ORMKRIReport> GenerateORMKRIReportMockData()
        {
            return new List<ORMKRIReport>
            {
                new ORMKRIReport
                {
                    Id = 1,
                    RefNum = "KRI001",
                    LocationType = "B",
                    LocationId = 1,
                    ValidatorILOUserId = 1,
                    ReportingPeriod = "202401",
                    ReportingFrequency = "Monthly",
                    DateReported = DateTime.Now.AddDays(-30),
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 1,
                    ReviewedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-30),
                    ReviewedDate = DateTime.Now.AddDays(-30),
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User" },
                    ReviewerComments = "cOl"
                },
                new ORMKRIReport
                {
                    Id = 2,
                    RefNum = "KRI001",
                    LocationType = "B",
                    LocationId = 2,
                    ValidatorILOUserId = 1,
                    ReportingPeriod = "202401",
                    ReportingFrequency = "Monthly",
                    DateReported = DateTime.Now.AddDays(-30),
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 1,
                    ReviewedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-30),
                    ReviewedDate = DateTime.Now.AddDays(-30),
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User" },
                    ReviewerComments = "Sol"
                },
                new ORMKRIReport
                {
                    Id = 123,
                    RefNum = "KRI009",
                    LocationType = "B",
                    LocationId = 1,
                    ValidatorILOUserId = 1,
                    ReportingPeriod = "202406",
                    ReportingFrequency = "Monthly",
                    DateReported = DateTime.Now.AddDays(-30),
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 1,
                    ReviewedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-30),
                    ReviewedDate = DateTime.Now.AddDays(-30),
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User" },
                    ReviewerComments = "cOl1"
                },
                new ORMKRIReport
                {
                    Id = 321,
                    RefNum = "KRI009",
                    LocationType = "B",
                    LocationId = 1,
                    ValidatorILOUserId = 2,
                    ReportingPeriod = "202402",
                    ReportingFrequency = "Monthly",
                    DateReported = DateTime.Now.AddDays(-30),
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 1,
                    ReviewedById = 1,
                    CreatedDate = DateTime.Now.AddDays(-30),
                    ModifiedDate = DateTime.Now.AddDays(-30),
                    ReviewedDate = DateTime.Now.AddDays(-30),
                    ORMUser = new ORMUser { Id = 1, UserName = "Test User" },
                    ReviewerComments = "cOlww1"
                },
            };
        }

        public static ORMKRIReport GenerateORMKRIReportSingleMockData()
        {
            return new ORMKRIReport
            {
                RefNum = "KRI001",
                LocationType = "Department",
                LocationId = 2,
                ValidatorILOUserId = 1,
                ReportingPeriod = "202401",
                ReportingFrequency = "Monthly",
                DateReported = DateTime.Now.AddDays(-30),
                Status = "Pending",
                CreatedById = 1,
                ModifiedById = 1,
                ReviewedById = 1,
                CreatedDate = DateTime.Now.AddDays(-30),
                ModifiedDate = DateTime.Now.AddDays(-30),
                ReviewedDate = DateTime.Now.AddDays(-30),
                ORMUser = new ORMUser { Id = 1, UserName = "Test User" },
                ReviewerComments = null
            };
        }


        public static List<ORMKRIMetricMaster> GenerateORMKRIMetricMasterMockData()
        {
            return new List<ORMKRIMetricMaster>
             {
                  new ORMKRIMetricMaster
                  {
                        Id = 1,
                        KRIMetricId = "KRI-B0001-XXXXXXX",
                        LocationType = "B",
                        LocationId = 1,
                        MetricName = "Metric 1",
                        Frequency = "Monthly",
                        AppetiteLowerBound = "5",
                        AppetiteUpperBound = "5",
                        AppetiteType = "Type A",
                        ToleranceLowerBound = "3",
                        ToleranceUpperBound = "5",
                        ToleranceType = "Type B",
                        EscalationLowerBound = "3",
                        EscalationUpperBound = "4",
                        EscalationType = "Type C",
                        IsActive = true,
                        Status = "Active",
                        ReviewerComments = "Sol",
                        CreatedById = 1,
                        ModifiedById = 1,
                        ApprovedById = 1,
                        CreatedDate = DateTime.Now.AddDays(-30),
                        ModifiedDate = DateTime.Now.AddDays(-30),
                        ApprovedDate = DateTime.Now.AddDays(-30)
                  },
                  new ORMKRIMetricMaster
                  {
                        Id = 1,
                        KRIMetricId = "KRI-D0001-XXXXXXX",
                        LocationType = "B",
                        LocationId = 1,
                        MetricName = "Metric 1",
                        Frequency = "Monthly",
                        AppetiteLowerBound = "7",
                        AppetiteUpperBound = "7",
                        AppetiteType = "Type D",
                        ToleranceLowerBound = "7",
                        ToleranceUpperBound = "7",
                        ToleranceType = "Type B",
                        EscalationLowerBound = "7",
                        EscalationUpperBound = "7",
                        EscalationType = "Type C",
                        IsActive = true,
                        Status = "Active",
                        ReviewerComments = "Sol",
                        CreatedById = 1,
                        ModifiedById = 1,
                        ApprovedById = 1,
                        CreatedDate = DateTime.Now.AddDays(-30),
                        ModifiedDate = DateTime.Now.AddDays(-30),
                        ApprovedDate = DateTime.Now.AddDays(-30)
                  }
             };
        }

        public static List<ORMKRIMetricMaster> GenerateORMKRIMetricMasterMockData2()
        {
            return new List<ORMKRIMetricMaster>
             {
                  new ORMKRIMetricMaster
                  {
                        Id = 1,
                        KRIMetricId = "KRI-D0001-XXXXXXX",
                        LocationType = "Branch",
                        LocationId = 1,
                        MetricName = "Metric 1",
                        Frequency = "Monthly",
                        AppetiteLowerBound = "7",
                        AppetiteUpperBound = "5",
                        AppetiteType = "Type D",
                        ToleranceLowerBound = "6",
                        ToleranceUpperBound = "5",
                        ToleranceType = "Type B",
                        EscalationLowerBound = "7",
                        EscalationUpperBound = "7",
                        EscalationType = "Type C",
                        IsActive = true,
                        Status = "Active",
                        ReviewerComments = "Sol",
                        CreatedById = 1,
                        ModifiedById = 1,
                        ApprovedById = 1,
                        CreatedDate = DateTime.Now.AddDays(-30),
                        ModifiedDate = DateTime.Now.AddDays(-30),
                        ApprovedDate = DateTime.Now.AddDays(-30)
                  }
             };
        }

        public static List<ORMKRIMetricMaster> GenerateORMKRIMetricMasterMockData3()
        {
            return new List<ORMKRIMetricMaster>
             {
                  new ORMKRIMetricMaster
                  {
                        Id = 1,
                        KRIMetricId = "KRI-D0001-XXXXXXX",
                        LocationType = "Branch",
                        LocationId = 1,
                        MetricName = "Metric 1",
                        Frequency = "Monthly",
                        AppetiteLowerBound = "9",
                        AppetiteUpperBound = "9",
                        AppetiteType = "Type D",
                        ToleranceLowerBound = "9",
                        ToleranceUpperBound = "9",
                        ToleranceType = "Type B",
                        EscalationLowerBound = "1",
                        EscalationUpperBound = "1",
                        EscalationType = "Type C",
                        IsActive = true,
                        Status = "Active",
                        ReviewerComments = "Sol",
                        CreatedById = 1,
                        ModifiedById = 1,
                        ApprovedById = 1,
                        CreatedDate = DateTime.Now.AddDays(-30),
                        ModifiedDate = DateTime.Now.AddDays(-30),
                        ApprovedDate = DateTime.Now.AddDays(-30)
                  }
             };
        }
        public static GetNewKriRequest GenerateGetNewKriRequestMockData()
        {
            return new GetNewKriRequest
            {
                locationType = "B",
                locationId = 1,
                frequecy = "Monthly"
            };
        }

        public static AddKriRequest GenerateAddKriRequestMockData()
        {
            return new AddKriRequest
            {
                RefNum = 0,
                ReportingPeriod = "2024-Q1",
                ReportingFrequency = "Monthly",
                ValidatorILOUserId = 987654321,
                DateOfOccurance = DateTime.UtcNow.Date,
                LocationId = 1,
                LocationType = "Branch",
                Status = "Pending",
                CreatedById = 1,
                kris = new long[] { 1, 2, 3 }, // Sample array of KRI IDs to add
                removeKris = new long[] { 4, 5 } // Sample array of KRI IDs to remove
            };
        }

        public static AddKriRequest GenerateAddKriRequestMockData2()
        {
            return new AddKriRequest
            {
                RefNum = 1,
                ReportingPeriod = "2024-Q1",
                ReportingFrequency = "Monthly",
                ValidatorILOUserId = 987654321,
                DateOfOccurance = DateTime.UtcNow.Date,
                LocationId = 1,
                LocationType = "Branch",
                Status = "Pending",
                CreatedById = 1,
                kris = new long[] { 1, 2, 3 }, // Sample array of KRI IDs to add
                removeKris = new long[] { 4, 5 } // Sample array of KRI IDs to remove
            };
        }

        public static AddKriReport GenerateAddKriReportMockData()
        {
            return new AddKriReport
            {
                masterId = 1,
                reportId = 987654321,
                metricId = 1,
                DateOccurance = DateTime.UtcNow.Date,
                Description = "Sample description",
                AmountInvolved = "10000",
                Currency = "USD",
                MitigationPlan = "Sample mitigation plan",
                NumberPercentage = "5",
                RiskAppetiteThreshold = "Low"
            };
        }

        public static GetPreviewKriMultipleRequest GenerateGetPreviewKriMultipleRequestMockData()
        {
            return new GetPreviewKriMultipleRequest
            {
                ids = new long[] { 123, 456, 789 },
                rids = new long[] { 987, 654, 321 }
            };
        }


        public static GetPreviewKriRequest GenerateGetPreviewKriRequestMockData()
        {
            return new GetPreviewKriRequest
            {
                ids = new long[] { 1, 2, 3 }
            };
        }

        public static UpdatePreviewKriRequest GenerateUpdatePreviewKriRequestMockData()
        {
            return new UpdatePreviewKriRequest
            {
                id = 1
            };
        }

        public static FinalKriReport GenerateFinalKriReportMockData()
        {
            return new FinalKriReport
            {
                id = 1, // Sample ID value
                status = "Approved", // Sample status value
                comments = "Final report approved", // Sample comments value
                approvedByid = 987654321 // Sample approved by ID value
            };
        }

        public static EditKriRequest GenerateEditKriRequestMockData()
        {
            return new EditKriRequest
            {
                id = 1, // Sample ID value
            };
        }

    }
}
