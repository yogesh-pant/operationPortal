﻿using ORM.Application.Interfaces.Auth;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;
using ORM.Test.KriMasterTests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace ORM.Test.KRIServiceTestFolder
{
    public class ValidateDuplicateKRIReportTests
    {

        [Theory]
        [InlineData(1, "01/2024", "SessionNull")]           // Session Null - Failed with User Unauthentication
        [InlineData(1, null,        "ReportingPeriodNull")]   // Input ReportingPeriod is null - Failed Validation 
        [InlineData(0, "01/2024", "LocationNull")]          // Input Locationid is 0 - Failed Validation 
        [InlineData(1, "01/2024", "DuplicateFound")]        // Duplicate report found for input locationid/ReportingPeriod
        [InlineData(1, "02/2024", "NoDuplicateFound")]      // No Duplicate report found for input locationid/ReportingPeriod 
        public async Task GetKriGridAsync_ValidRequest_ReturnSucessfulResponse(int LocationId, string ReportingPeriod,string ExpectedResult )
        {

            //Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<KriService>>();
            var mockConfig = new Mock<IConfiguration>();
            var mockSessionService = new Mock<ISessionService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            if (ExpectedResult == "SessionNull")
            {
                mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            };

            //
            // Set up ORMKRI -Report Data 
            //
            var MockKriReportRepository = new Mock<IKriReportRepository>();

            var ORMKRIReportData = new List<ORMKRIReport>
            {
                new ORMKRIReport
                {
                    LocationId = 1,
                    ReportingPeriod = "01/2024" ,
                    Status = "Approved",
                }
            };
            mockUnitOfWork.Setup(x => x.ORMKRIReport.GetAll().AsQueryable())
                         .Returns(ORMKRIReportData.BuildMock());

            var input = new ValidateDuplicateKriReportRequest
            {
                LocationId = LocationId,
                ReportingPeriod = ReportingPeriod,
            };


            var kriService = new KriService(mockLogger.Object, mockSessionService.Object, mockUnitOfWork.Object);

            //Act
            var result = await kriService.ValidateDuplicateKriReportAsync(input);

            //Assert
            if (ExpectedResult == "NoDuplicateFound")
            {
                Assert.Null(result.Data);
                Assert.Equal("No Duplicate KRI Report found for Location id : " + input.LocationId + " and Reporting Period " + input.ReportingPeriod, result.Description);
                Assert.Equal(ResponseCodes.Success, result.Code);
            }
            if (ExpectedResult == "DuplicateFound")
            {
                Assert.Null(result.Data);
                Assert.Equal("KRI report already present for selected reporting period- " + input.ReportingPeriod, result.Description);
                Assert.Equal(ResponseCodes.RequestValidationError, result.Code);
            }
            if (ExpectedResult == "LocationNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("Kri metric data not found for location id : " + input.LocationId, result.Description);
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            }
            if (ExpectedResult == "ReportingPeriodNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("Invalid input provided", result.Description);
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            }
            if (ExpectedResult == "SessionNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("User Is Unauthenticated", result.Description);
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
            }

        }
    }
}
