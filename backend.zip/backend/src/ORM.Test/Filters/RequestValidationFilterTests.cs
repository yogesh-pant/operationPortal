namespace ORM.Test.Filters
{
    using System;
    using System.Collections.Generic;
    using FakeItEasy;
    using FluentAssertions;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Abstractions;
    using Microsoft.AspNetCore.Mvc.ActionConstraints;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.AspNetCore.Mvc.ModelBinding;
    using Microsoft.AspNetCore.Mvc.Routing;
    using Microsoft.AspNetCore.Routing;
    using ORM.Api.Filters;
    using Xunit;

    public class RequestValidationFilterTests
    {
        private readonly RequestValidationFilter _testClass;

        public RequestValidationFilterTests()
        {
            _testClass = new RequestValidationFilter();
        }

        [Fact]
        public void CanCallOnActionExecuting()
        {
            // Arrange
            var context = new ActionExecutingContext(new ActionContext
            {
                ActionDescriptor = new ActionDescriptor
                {
                    RouteValues = A.Fake<IDictionary<string, string?>>(),
                    AttributeRouteInfo = new AttributeRouteInfo
                    {
                        Template = "TestValue3080674",
                        Order = 854672760,
                        Name = "TestValue407319845",
                        SuppressLinkGeneration = false,
                        SuppressPathMatching = true
                    },
                    ActionConstraints = new[] { A.Fake<IActionConstraintMetadata>(), A.Fake<IActionConstraintMetadata>(), A.Fake<IActionConstraintMetadata>() },
                    EndpointMetadata = new[] { new object(), new object(), new object() },
                    Parameters = new[] {
                        new ParameterDescriptor
                        {
                            Name = "TestValue484113622",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue1976247859",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue1404836450",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        }
                    },
                    BoundProperties = new[] {
                        new ParameterDescriptor
                        {
                            Name = "TestValue109617819",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue1138315094",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue1689212399",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        }
                    },
                    FilterDescriptors = new[] { new FilterDescriptor(A.Fake<IFilterMetadata>(), 1605887384), new FilterDescriptor(A.Fake<IFilterMetadata>(), 340789807), new FilterDescriptor(A.Fake<IFilterMetadata>(), 372179592) },
                    DisplayName = "TestValue759839411",
                    Properties = A.Fake<IDictionary<object, object?>>()
                },
                HttpContext = new DefaultHttpContext(),
                RouteData = new RouteData()
            }, new[] { A.Fake<IFilterMetadata>(), A.Fake<IFilterMetadata>(), A.Fake<IFilterMetadata>() }, A.Fake<IDictionary<string, object?>>(), new object());

            // Act
            _testClass.OnActionExecuting(context);

            // Assert
            context.Should().NotBeNull();
        }

        [Fact]
        public void CanCallOnActionExecuted()
        {
            // Arrange
            var context = new ActionExecutedContext(new ActionContext
            {
                ActionDescriptor = new ActionDescriptor
                {
                    RouteValues = A.Fake<IDictionary<string, string?>>(),
                    AttributeRouteInfo = new AttributeRouteInfo
                    {
                        Template = "TestValue1915072280",
                        Order = 865978118,
                        Name = "TestValue1576332577",
                        SuppressLinkGeneration = false,
                        SuppressPathMatching = false
                    },
                    ActionConstraints = new[] { A.Fake<IActionConstraintMetadata>(), A.Fake<IActionConstraintMetadata>(), A.Fake<IActionConstraintMetadata>() },
                    EndpointMetadata = new[] { new object(), new object(), new object() },
                    Parameters = new[] {
                        new ParameterDescriptor
                        {
                            Name = "TestValue290033785",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue1589126690",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue205873469",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        }
                    },
                    BoundProperties = new[] {
                        new ParameterDescriptor
                        {
                            Name = "TestValue246685565",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue964425859",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        },
                        new ParameterDescriptor
                        {
                            Name = "TestValue493697363",
                            ParameterType = typeof(string),
                            BindingInfo = new BindingInfo()
                        }
                    },
                    FilterDescriptors = new[] { new FilterDescriptor(A.Fake<IFilterMetadata>(), 1274526257), new FilterDescriptor(A.Fake<IFilterMetadata>(), 1055213942), new FilterDescriptor(A.Fake<IFilterMetadata>(), 1500606801) },
                    DisplayName = "TestValue14216409",
                    Properties = A.Fake<IDictionary<object, object?>>()
                },
                HttpContext = new DefaultHttpContext(),
                RouteData = new RouteData()
            }, new[] { A.Fake<IFilterMetadata>(), A.Fake<IFilterMetadata>(), A.Fake<IFilterMetadata>() }, new object());

            // Act
            _testClass.OnActionExecuted(context);

            // Assert
            context.Should().NotBeNull();
        }
    }
}