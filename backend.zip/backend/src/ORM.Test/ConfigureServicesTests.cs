namespace ORM.Test
{
    using System;
    using FakeItEasy;
    using FluentAssertions;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using ORM.Api;
    using ORM.Application.Models.Logging;
    using ORM.Infrastructure.Persistance;
    using Xunit;

    public static class ConfigureServicesTests
    {
        [Fact]
        public static void CanCallAddServicesToContainer()
        {
            // Arrange
            var services = new ServiceCollection();
            // Create an in-memory configuration with necessary values
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(new Dictionary<string, string?>
                {
                // Logging configuration
                { "Logging:AzureInstrumentationKey", "your_instrumentation_key" },
                { "Logging:EnableAzureApplicationInsights", "false" },
                { "Logging:EnableConsole", "true" },
                { "Logging:EnableFile", "true" },
                { "Logging:FileSizeLimitBytes", "10485760" },
                { "Logging:LogFilePath", "logs/log.txt" },
                { "Logging:RetainedFileCountLimit", "10" },
                { "Logging:RollOnFileSizeLimit", "true" },

                // Allowed hosts
                { "AllowedHosts", "*" },

                // FCMBConfig
                { "FCMBConfig:BaseUrl", "http://1.2.3.4/" },
                { "FCMBConfig:SecretKey", "deed445ffr4" },
                { "FCMBConfig:AuthBaseUrl", "http://0.0.0.0:121/text.asmx" },
                { "FCMBConfig:AuthClientId", "TD" },
                { "FCMBConfig:AuthSecretKey", "101072ba" },
                { "FCMBConfig:SubscriptionKey", "38689d8ceb7f46b" },
                { "FCMBConfig:EmailConfig:EmailUrl", "https://email/api" },
                { "FCMBConfig:EmailConfig:SenderEmail", "email.com" },
                { "FCMBConfig:EmailConfig:SenderName", "Test" },

                // JWTConfig
                { "JWTConfig:Issuer", "orm-api" },
                { "JWTConfig:Audience", "http://localhost:4200" },

                // AzureBlobSettings
                { "AzureBlobSettings:ContainerName", "ormg" },

                // AzureKeyVault
                { "AzureKeyVault:AzureKeyVaultURL", "https://.azure.net/" },

                // SwaggerOptions
                { "SwaggerOptions:Title", "test API" },
                { "SwaggerOptions:Version", "v1" },
                { "SwaggerOptions:Description", "test Platform" },
                { "SwaggerOptions:ContactName", "test" },
                { "SwaggerOptions:ContactEmail", "info@test.com" },
                { "SwaggerOptions:LicenseName", "MIT License" },
                { "SwaggerOptions:LicenseUrl", "https://en.wikipedia.org/wiki/MIT_License" },

                // Database and other configurations
                { "orm-dbconnection", "Data Source=(LLocalDB;Initial Catalog=test12212;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False" },
                { "orm-encryption-iv", "znQ343StbIgWSZrm" },
                { "orm-encryption-key", "Ps5mzoHtFAmDFpg7" },
                { "orm-blob-connectionstring", "DefaultEndpointsProtocol=https;AccountName=rere;AccountKey=fdfdfd==;EndpointSuffix=core.windows.net" },
                { "orm-fcmbconfig-clientid", "FCMB000000SBSC010793" },
                { "orm-jwt-key", "ewwwe-W3C=n~l%+vdssdds!m9&coBeewwww^" }
                })
                .Build();
            // Act
            services.AddServicesToContainer(configuration);

            // Assert
            using (var serviceProvider = services.BuildServiceProvider())
            {
                // Verify that the logging services are configured and the logger can be resolved
                var logger = serviceProvider.GetService<ILogger<Program>>();
                logger.Should().NotBeNull();

                // Verify other services or configurations as needed
                var dbContext = serviceProvider.GetService<AppDbContext>();
                dbContext.Should().NotBeNull();

                // Add additional asserts for other services or configurations
            }
        }

        [Fact]
        public static void CanCallConfigureLoggingCapability()
        {
            // Arrange
            var services = A.Fake<IServiceCollection>();
            var loggerOptions = new LoggerOptions
            {
                EnableConsole = false,
                EnableFile = true,
                LogFilePath = "TestValue2051713296",
                RetainedFileCountLimit = 95401410,
                FileSizeLimitBytes = 419889752L,
                RollOnFileSizeLimit = false,
                EnableAzureApplicationInsights = false,
                AzureInstrumentationKey = "TestValue951831639"
            };

            // Act
            services.ConfigureLoggingCapability(loggerOptions);

            // Assert
            loggerOptions.Should().NotBeNull();
        }

        [Fact]
        public static void CannotCallConfigureLoggingCapabilityWithNullServices()
        {
            FluentActions.Invoking(() => default(IServiceCollection)!.ConfigureLoggingCapability(new LoggerOptions
            {
                EnableConsole = true,
                EnableFile = false,
                LogFilePath = "TestValue1287261366",
                RetainedFileCountLimit = 140652435,
                FileSizeLimitBytes = 940348960L,
                RollOnFileSizeLimit = false,
                EnableAzureApplicationInsights = false,
                AzureInstrumentationKey = "TestValue1019619387"
            })).Should().Throw<ArgumentNullException>().WithParameterName("services");
        }

       
    }
}