﻿using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.UOW;
using ORM.Test.LocationServiceTests;
using ORM.Application.Models.Requests.Mails;
using Microsoft.Extensions.Configuration;
using ORM.Application.Interfaces.Common;
using ORM.Test.Lossservicetestsfolder;
using Moq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using MockQueryable.Moq;

namespace ORM.Test.Lossservicetestsfolder
{
    public class SendLossRpReviewReminderTests
    {
        private readonly LossServiceFactory _lossServiceFactory;

        public SendLossRpReviewReminderTests()
        {
            _lossServiceFactory = new LossServiceFactory();
        }

        [Theory]
        [InlineData("SessionNull")]  // Session is null - Failed Validation
        [InlineData("InvalidInput")] // Invalid input - Failed Validation
        //[InlineData("DataNotFound")] // Loss report not found - Failed Validation
        [InlineData("EmailSuccess")] // Email sent successfully
        [InlineData("EmailFailed")]  // Email sending failed
        public async Task SendLossRpReviewReminder_ShouldWork(string ExpectedResult)
        {
            // Arrange
            var input = new GetFullLossDataBySingleIdRequest { id = 1 };

            _lossServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns(new StaffSession(1, "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            if (ExpectedResult == "SessionNull")
            {
                _lossServiceFactory.SessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null);
            }

            if (ExpectedResult == "InvalidInput")
            {
                input = null!;
            }

            var mockLossReportRepository = new Mock<IOrmLossReportRepository>();
            var mockUserRepository = new Mock<IOrmUserRepository>();

            var lossReportData = new List<ORMLossReport>
            {
                new ORMLossReport
                {
                    Id = 1,
                    RefNum = "LR001",
                    ValidatorILOUserId = 2
                }
            };

            var userData = new List<ORMUser>
            {
                new ORMUser
                {
                    Id = ExpectedResult == "DataNotFound" ? 1 : 2,
                    UserName = "ValidatorUser",
                    Email = "validator@example.com"
                }
            };
            _lossServiceFactory.UnitOfWork.Setup(x => x.ORMLossReport).Returns(mockLossReportRepository.Object);
            _lossServiceFactory.UnitOfWork.Setup(x => x.ORMUsers).Returns(mockUserRepository.Object);

            var mockLossReportDbSet = lossReportData.AsQueryable().BuildMockDbSet();
            var mockUserDbSet = userData.AsQueryable().BuildMockDbSet();

            mockLossReportRepository.Setup(repo => repo.GetAll()).Returns(mockLossReportDbSet.Object);
            mockUserRepository.Setup(repo => repo.GetAll()).Returns(mockUserDbSet.Object);

            if (ExpectedResult == "DataNotFound")
            {
                var emptyLossReportDbSet = new List<ORMLossReport>().AsQueryable().BuildMockDbSet();
                mockLossReportRepository.Setup(repo => repo.GetAll()).Returns(mockLossReportDbSet.Object);
            }

            // Mock the configuration
            var configurationMock = new Mock<IConfiguration>();
            configurationMock.Setup(x => x.GetSection("FCMBConfig:EmailConfig:SenderEmail").Value).Returns("sender@example.com");
            _lossServiceFactory.UpdateConfiguration(configurationMock);

            if (ExpectedResult == "EmailSuccess")
            {
                _lossServiceFactory.EmailService.Setup(x => x.SendEmailAsync(It.IsAny<SendEmailRequest>())).ReturnsAsync(true);
            }
            else if (ExpectedResult == "EmailFailed")
            {
                _lossServiceFactory.EmailService.Setup(x => x.SendEmailAsync(It.IsAny<SendEmailRequest>())).ReturnsAsync(false);
            }

            // Act
            var result = await _lossServiceFactory.LossService.SendLossRpReviewReminder(input);

            // Assert
            if (ExpectedResult == "SessionNull")
            {
                Assert.Null(result.Data);
                Assert.Equal("User Is Unauthenticated", result.Description);
                Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
            }
            else if (ExpectedResult == "InvalidInput")
            {
                Assert.Null(result.Data);
                Assert.Equal(" invalid input ", result.Description);
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            }
            else if (ExpectedResult == "DataNotFound")
            {
                Assert.Null(result.Data);
                Assert.Equal("Unable to find requested data", result.Description);
                Assert.Equal(ResponseCodes.DataNotFound, result.Code);
            }
            else if (ExpectedResult == "EmailSuccess")
            {
                Assert.Equal("Email Reminder for Loss Report Send Successfully to user", result.Description);
                Assert.Equal(ResponseCodes.Success, result.Code);
            }
            else if (ExpectedResult == "EmailFailed")
            {
                Assert.Null(result.Data);
                Assert.Equal("Email Reminder for Loss Report failed", result.Description);
                Assert.Equal(ResponseCodes.ServiceError, result.Code);
            }
        }
    }
}