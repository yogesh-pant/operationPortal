﻿using Microsoft.AspNetCore.Http;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Common;
using ORM.Application.Models.Auth;
using ORM.Application.Models.Constants;
using ORM.Application.Models.Requests;
using ORM.Application.Models.Responses;
using ORM.Infrastructure.Entities;
using ORM.Infrastructure.IRepositories;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;

namespace ORM.Test.Lossservicetestsfolder
{

    public class LossServiceTests
    {

        [Fact]
        public async Task GetLossGridAsync_UnAuthenticated_ReturnUnauthenticatedReponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


        mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var lossService = new LossService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = new LossGridRequest();

            // Act
            var response = await lossService.GetLossGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task GetLossGridAsync_ValidInput_ReturnSucessfulReponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


            var session = MockSessionService();

            var lossService = new LossService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = GenerateMockLockGridRequestData();

            
            var ORMUser = new List<ORMUser>
            {
                 new ()
                 {
                     Id = 1,
                     CurrentLoginTime = DateTime.Now,
                     Email = "Test@yopmail.com",
                     UserName = "Test User",

                 }
            };

            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable()).Returns(ORMUser.BuildMock()); // Simulating that a user exists with the given ID exists

            
            var data = GetMockORMLossReports();
            mockUnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable()).Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists
           
            var locationMockData = GenerateORMLocationMockData();
            var mockLocationRepository = new Mock<IOrmLocationRepository>();
            
           mockUnitOfWork.Setup(x => x.ORMLocation.GetAll().AsQueryable()).Returns(locationMockData.BuildMock());

            // Act
            var response = await lossService.GetLossGridAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task CreateLossDataAsync_UserAuthenticated_ReturnsSuccessResponse()
        {
            // Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var formFile = new Mock<IFormFile>();
            var mailService = new Mock<IEmailService>();

            var session = MockSessionService();

            var lossService = new LossService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = new CreateLossDataRequest()
            {
                RegistrationDocuments = new List<IFormFile>() { formFile.Object }
            };

            // Act
            var result = await lossService.CreateLossDataAsync(input);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Loss Report Created!", result.Description);
            Assert.Equal(ResponseCodes.Success, result.Code);
        }


        [Fact]
        public async Task CreateLossDataAsync_UserUnauthenticated_ReturnsUnauthenticatedResponse()
        {
            // Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var lossService = new LossService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = CreateMock();

            // Act
            var result = await lossService.CreateLossDataAsync(input);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }


        [Fact]
        public async Task UpdateLossDataRLOAsync_UserUnauthenticated_ReturnsUnauthenticatedResponse()
        {
            // Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();

            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var lossService = new LossService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = UpdateMock();

            // Act
            var result = await lossService.UpdateLossDataRLOAsync(input);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("User Is Unauthenticated", result.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, result.Code);
        }

        [Fact]
        public async Task UpdateLossDataRLOAsync_WithValidInput_ReturnsSuccessResponse()
        {
            // Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


            var input = UpdateMock();
            var data = new List<ORMLossReport>
            {
                new ORMLossReport {
                    Id = 1,
                    ValidatedById = 654
                }
            };

            mockUnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                          .Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists

            var session = MockSessionService(); // Simulating an authenticated session

            var lossService = new LossService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);

            // Act
            var response = await lossService.UpdateLossDataRLOAsync(input);

            // Assert
            Assert.NotNull(response);
            Assert.Equal("Loss Report Updated!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);
        }

        [Fact]
        public async Task UpdateLossDataBORMAsync_UserUnauthenticated_ReturnUnauthenticatedResponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();

            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var lossService = new LossService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = GenerateMockUpdateLossDataBORMRequest();

            // Act
            var response = await lossService.UpdateLossDataBORMAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task UpdateLossDataBORMAsync_WithValidInput_ReturnsSuccessResponse()
        {
            // Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


            var input = GenerateMockUpdateLossDataBORMRequest();
            var ORMUser = new List<ORMUser>
            {
                new ORMUser
                {
                    Id = 1,
                    CurrentLoginTime = DateTime.Now,
                    Email = "Test@yopmail.com"
                }
            };

            var data = GetMockORMLossReports();

            mockUnitOfWork.Setup(x => x.ORMUsers.GetAll().AsQueryable())
                         .Returns(ORMUser.BuildMock()); // Simulating that a user exists with the given ID exists


            mockUnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                          .Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists

            var session = MockSessionService(); // Simulating an authenticated session

            var lossService = new LossService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);

            // Act
            var response = await lossService.UpdateLossDataBORMAsync(input);

            Assert.NotNull(response);
            Assert.Equal("Loss Report Updated by Admin!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        [Fact]
        public async Task ApproveLossDataBORMAsync_Userunathenticated_ReturnUnathenticatedReponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();

            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var lossService = new LossService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = new ApproveLossDataBormRequest();

            // Act
            var response = await lossService.ApproveLossDataBORMAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task ApproveLossDataBORMAsync_ValidInput_ReturnSucessfulReponse()
        {
            // Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


            var session = MockSessionService(); // Simulating an authenticated session

            var lossService = new LossService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);

            var data = new List<ORMLossReport>
            {
                new ORMLossReport {
                    Id = 1,
                    ValidatedById = 654,
                    ModifiedById = 1,
                    ApprovedById = 1,
                    ReportStatus = "UpdatedByBORM"
                }
            };

            var data1 = new List<ORMUser>
            {
                new ORMUser {
                    Id = 123,
                    UserName = "String"
                }
            };

            mockUnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                         .Returns(data.BuildMock()); // Simulating that a loss report with the given ID exists

            mockUnitOfWork.Setup(uow => uow.ORMUsers.GetAll().AsQueryable())
                         .Returns(data1.BuildMock()); // Simulating that a loss report with the given ID exists
            var input = GetMockApproveLossDataBORMRequest();

            var userRepository = new Mock<IOrmUserRepository>();
            mockUnitOfWork.Setup(x => x.ORMUsers).Returns(userRepository.Object);
            userRepository.Setup(repo => repo.GetAll().AsQueryable()).Returns(new List<ORMUser>() { new() { Id = 1 } }.BuildMock());

            // Act
            var response = await lossService.ApproveLossDataBORMAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Loss Report {input.Action!} by Admin!", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);


        }

        [Fact]
        public async Task GetFullLossDataBySingleIdAsync_Userunathenticated_ReturnUnathenticatedReponse()
        {
            //Arrange
            var mockSessionService = new Mock<ISessionService>();
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();


            mockSessionService.Setup(x => x.GetStaffSession()).Returns((StaffSession?)null); // Simulate unauthenticated user

            var lossService = new LossService(mockLogger.Object, mockSessionService.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = new GetFullLossDataBySingleIdRequest()
            {
                id =1,
            };

            // Act
            var response = await lossService.GetFullLossDataBySingleIdAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("User Is Unauthenticated", response.Description);
            Assert.Equal(ResponseCodes.Unauthenticated, response.Code);

        }

        [Fact]
        public async Task GetFullLossDataBySingleIdAsync_ValidRequest_ReturnSucessfulReponse()
        {
            // Arrange
            var mockUnitOfWork = new Mock<IUnitOfWork>();
            var mockLogger = new Mock<ILogger<LossService>>();
            var mockConfig = new Mock<IConfiguration>();
            var session = MockSessionService(); // Simulating an authenticated session
            var azureBlobStorageService = new Mock<IAzueBlobStorageService>();
            var mailService = new Mock<IEmailService>();

            var lossreportdata = GetMockORMLossReports();

            mockUnitOfWork.Setup(uow => uow.ORMLossReport.GetAll().AsQueryable())
                          .Returns(lossreportdata.BuildMock()); // Simulating that a loss report with the given ID exists


            var ormuserdata = new List<ORMUser>()
            { new()
                    {
                    Id = 1,
                    UserName = "testuser",
                    Email = "testemail",
                    StaffId = "Staff",
                    Status = "Active",
                    RoleId = 1,
                    FailedLoginCount = "0",
                    LastLoginTime = DateTime.Now,
                    CurrentLoginTime = DateTime.Now,
                    } 
            };

            mockUnitOfWork.Setup(uow => uow.ORMUsers.GetAll().AsQueryable())
                          .Returns(ormuserdata.BuildMock());

            var ormlocationdata = new List<ORMLocation>()
            { new()
                { 
                    Id = 1,
                    LocationId = "TestLocation",
                    LocationType = "B",
                    SolId = "122",
                    Region = "Lagos",
                    Branch = "BranchName",
                    Department = "DepartmantName",
                    Status = "Active,",                    
                }
            };

            mockUnitOfWork.Setup(uow => uow.ORMLocation.GetAll().AsQueryable())
                          .Returns(ormlocationdata.BuildMock());

            var lossService = new LossService(mockLogger.Object, session.Object, mockConfig.Object, mockUnitOfWork.Object, azureBlobStorageService.Object, mailService.Object);
            var input = new GetFullLossDataBySingleIdRequest()
            {
                id = 1,
            };

            var mockLossResponseData = GenerateMockData();

            // Act
            var response = await lossService.GetFullLossDataBySingleIdAsync(input);

            //Assert
            Assert.NotNull(response);
            Assert.Equal("Successfully Retrieved Loss Data for one id", response.Description);
            Assert.Equal(ResponseCodes.Success, response.Code);

        }

        private static UpdateLossDataRloRequest UpdateMock()
        {
            return new UpdateLossDataRloRequest
            {
                id = 1,
                ValidatorILOUserId = 123,
                DateOccurance = DateTime.Now,
                DateDiscovery = DateTime.Now,
                DateReported = DateTime.Now,
                Description = "Sample Description",
                RootCauseRLO = "Sample Root Cause",
                LossType = "Sample Loss Type",
                CurrencyType = "USD",
                AmountInvolved = 1000,
                NearMissAmount = 100,
                PotentialLossAmount = 500,
                GrossActualAmount = 2000,
                RecoveredAmount = 500,
                FurtherRecoveredAmount = 200,
                RecoveryChannel = "Sample Recovery Channel",
                StaffInvolvement = "Sample Staff Involvement",
                EventStatus = "Sample Event Status",
                ReportStatus = "Sample Report Status",
                ModifiedById = 456
            };
        }

        private static CreateLossDataRequest CreateMock()
        {
            return new CreateLossDataRequest
            {
                LocationType = "Sample Location Type",
                LocationId = "123",
                ValidatorILOUserId = "456",
                DateOccurance = DateTime.Now.ToString(),
                DateDiscovery = DateTime.Now.ToString(),
                DateReported = DateTime.Now.ToString(),
                Description = "Sample Description",
                RootCauseRLO = "Sample Root Cause",
                LossType = "Sample Loss Type",
                CurrencyType = "USD",
                AmountInvolved = "1000",
                NearMissAmount = "100",
                PotentialLossAmount = "500",
                GrossActualAmount = "2000",
                RecoveredAmount = "500",
                FurtherRecoveredAmount = "200",
                RecoveryChannel = "Sample Recovery Channel",
                StaffInvolvement = "Sample Staff Involvement",
                EventStatus = "Sample Event Status",
                ReportStatus = "Sample Report Status",
                CreatedById = "789"
            };
        }

        private static UpdateLossDataBormRequest GenerateMockUpdateLossDataBORMRequest()
        {
            return new UpdateLossDataBormRequest
            {
                id = 1,
                StaffJobRole = "Mock Staff Job Role",
                InternalBusLine = "Mock Internal Bus Line",
                BaselEventTypeI = "Mock Basel Event Type I",
                BaselEventTypeII = "Mock Basel Event Type II",
                BaselEventTypeIII = "Mock Basel Event Type III",
                BaselLevel1BusinessLine = "Mock Basel Level 1 Business Line",
                BaselLevel2BusinessLine = "Mock Basel Level 2 Business Line",
                RootCauseTypeBORM = "Mock Root Cause Type BORM",
                ProcessInvolved = "Mock Process Involved",
                RiskSource = "Mock Risk Source",
                LessonLearnt = "Mock Lesson Learnt",
                ReportStatus = "Mock Report Status",
                ReviewerComments = "Mock Reviewer Comments",
                ModifiedById = 123 // Example value for ModifiedById
            };
        }

        private static ApproveLossDataBormRequest GetMockApproveLossDataBORMRequest()
        {
            return new ApproveLossDataBormRequest
            {
                id = 1,
                Action = "Approve",
                ReviewerComments = "Approved",
                ApprovedById = 1
            };
        }
        public static Mock<ISessionService> MockSessionService()
        {
            var mockSessionService = new Mock<ISessionService>();

            mockSessionService.Setup(x => x.GetStaffSession()).Returns(new
                StaffSession(1,
                "TestValue1384138114", "TestValue349530768", "TestValue1835299848", null));

            return mockSessionService;
        }

        private static List<ORMLossReport> GetMockORMLossReports()
        {
            return new List<ORMLossReport>
            {
              new ORMLossReport {
                Id = 1,
                RefNum = "LOSSRP-202201-B0001-NN",
                LocationType = "B",
                LocationId = 1,
                ValidatorILOUserId = 1,
                DateOccurance = DateTime.Now.AddDays(-5),
                DateDiscovery = DateTime.Now.AddDays(-3),
                DateReported = DateTime.Now.AddDays(-2),
                Description = "Sample description",
                RootCauseRLO = "Sample root cause",
                LossType = "Sample loss type",
                CurrencyType = "USD",
                AmountInvolved = 1000,
                NearMissAmount = 100,
                PotentialLossAmount = 500,
                GrossActualAmount = 2000,
                RecoveredAmount = 500,
                FurtherRecoveredAmount = 200,
                NetActualLossAmount = 1300,
                RecoveryChannel = "Sample recovery channel",
                StaffInvolvement = "Sample staff involvement",
                EventStatus = "Sample Event Status",
                ReportStatus = "Sample Report Status",
                StaffJobRole = "Sample staff job role",
                InternalBusLine = "Sample internal business line",
                BaselEventTypeI = "Type I",
                BaselEventTypeII = "Type II",
                BaselEventTypeIII = "Type III",
                BaselLevel1BusinessLine = "Level 1 business line",
                BaselLevel2BusinessLine = "Level 2 business line",
                RootCauseTypeBORM = "Sample root cause type",
                ProcessInvolved = "Sample process involved",
                RiskSource = "Sample risk source",
                LessonLearnt = "Sample lesson learnt",
                ReviewerComments = "Sample reviewer comments",
                UpdateHistory = "Sample update history",
                CreatedById = 1,
                ModifiedById = 1,
                ValidatedById = 1,
                ApprovedById = 1,
                CreatedDate = DateTime.Now.AddDays(-7),
                ModifiedDate = DateTime.Now.AddDays(-1),
                ValidationDate = DateTime.Now.AddDays(-4),
                ApprovedDate = DateTime.Now,
                Documents  = "testdoc.docx",
                DocumentName = "docname",
    },

              new ORMLossReport {
                Id = 2,
                RefNum = "LOSSRP-202202-B0002-NN",
                LocationType = "B",
                LocationId = 1,
                ValidatorILOUserId = 1,
                DateOccurance = DateTime.Now.AddDays(-5),
                DateDiscovery = DateTime.Now.AddDays(-3),
                DateReported = DateTime.Now.AddDays(-2),
                Description = "Sample description",
                RootCauseRLO = "Sample root cause",
                LossType = "Sample loss type",
                CurrencyType = "USD",
                AmountInvolved = 1000,
                NearMissAmount = 100,
                PotentialLossAmount = 500,
                GrossActualAmount = 2000,
                RecoveredAmount = 500,
                FurtherRecoveredAmount = 200,
                NetActualLossAmount = 1300,
                RecoveryChannel = "Sample recovery channel",
                StaffInvolvement = "Sample staff involvement",
                EventStatus = "Sample Event Status",
                ReportStatus = "Sample Report Status",
                StaffJobRole = "Sample staff job role",
                InternalBusLine = "Sample internal business line",
                BaselEventTypeI = "Type I",
                BaselEventTypeII = "Type II",
                BaselEventTypeIII = "Type III",
                BaselLevel1BusinessLine = "Level 1 business line",
                BaselLevel2BusinessLine = "Level 2 business line",
                RootCauseTypeBORM = "Sample root cause type",
                ProcessInvolved = "Sample process involved",
                RiskSource = "Sample risk source",
                LessonLearnt = "Sample lesson learnt",
                ReviewerComments = "Sample reviewer comments",
                UpdateHistory = "Sample update history",
                CreatedById = 1,
                ModifiedById = 1,
                ValidatedById = 1,
                ApprovedById = 1,
                CreatedDate = DateTime.Now.AddDays(-7),
                ModifiedDate = DateTime.Now.AddDays(-1),
                ValidationDate = DateTime.Now.AddDays(-4),
                ApprovedDate = DateTime.Now,
                Documents  = "testdoc.docx",
                DocumentName = "docname",
              }
            };
        }

        private static LossGridRequest GenerateMockLockGridRequestData()
        {
            return new LossGridRequest
            {
                refNo = "LOSSRP-202201-B0001-NN",
                branch = "Branch A",
                region = "Region 1",
                department = "Department X",
                eventStatus = "Sample Event Status",
                reportStatus = "Sample Report Status",
                minDate = DateTime.Now.AddDays(-7),
                maxDate = DateTime.Now
            };
        }

        private static LossDataGrid GenerateMockData()
        {
            return new LossDataGrid
            {
                Id = 1,
                ValidatorILOid = 1,
                ValidatorILOUserName = "Sample Validator",
                RefNum = "LOSSRP-202201-B0001-NN",
                PrevLossReportId = null,
                InternalBusinessLineId = "SampleBusinessLine",
                LossType = "SampleLossType",
                Currency = "USD",
                DateOfOccurrence = DateTime.Now.AddDays(-7),
                DateDiscovered = DateTime.Now.AddDays(-5),
                ModifiedDate = DateTime.Now.AddDays(-3),
                DateReported = DateTime.Now.AddDays(-2),
                DetailedLossEvent = "SampleDetailedLossEvent",
                NearMiss = 100,
                PotentialLoss = 500,
                GrossActualLoss = 1000,
                AmountRecovered = 300,
                FurtherRecovery = 100,
                NetActualLoss = 600,
                RootCause = "SampleRootCause",
                RiskSourceId = "SampleRiskSource",
                AmountInvolved = 2000,
                Region = "SampleRegion",
                ProcessInvolved = "SampleProcess",
                RecoveryMode = "SampleRecoveryMode",
                EventStatus = "Sample Event Status",
                Department = "Sample Department",
                ReportStatus = "Sample Report Status",
                CreatedBy = 456,
                ModifiedBy = "SampleModifier",
                ApprovedBy = null,
                StaffInvolvement = "Sample Staff Involvement",
                AllCount = 10             
            };
        }
        public static List<ORMLocation> GenerateORMLocationMockData()
        {
            return new List<ORMLocation>
            {
                new ORMLocation
                {
                    Id = 1,
                    LocationId = "B0001",
                    LocationType = "B",
                    SolId = "SOL001",
                    Branch = "Branch A",
                    Region = "Region 1",
                    Department = "Department X",
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 1,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                },
                new ORMLocation
                {
                    Id = 2,
                    LocationId = "D0001",
                    LocationType = "B",
                    SolId = "SOL002",
                    Branch = "Branch B",
                    Region = "Region 2",
                    Department = "Department X",
                    Status = "Pending",
                    CreatedById = 1,
                    ModifiedById = 2,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                },
            };
        }
    }
}
