﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using ORM.Application.Interfaces.Auth;
using ORM.Application.Interfaces.Common;
using ORM.Infrastructure.Services;
using ORM.Infrastructure.UOW;

namespace ORM.Test.Lossservicetestsfolder
{
    public class LossServiceFactory
    {
        public Mock<ILogger<LossService>> Logger { get; }
        public Mock<ISessionService> SessionService { get; }
        public Mock<IConfiguration> Configuration { get; set; }
        public Mock<IUnitOfWork> UnitOfWork { get; }
        public Mock<IAzueBlobStorageService> AzueBlobStorageService { get; }
        public Mock<IEmailService> EmailService { get; }
        public LossService LossService { get; private set; }

        public LossServiceFactory()
        {
            Logger = new Mock<ILogger<LossService>>();
            SessionService = new Mock<ISessionService>();
            Configuration = new Mock<IConfiguration>();
            UnitOfWork = new Mock<IUnitOfWork>();
            AzueBlobStorageService = new Mock<IAzueBlobStorageService>();
            EmailService = new Mock<IEmailService>();

            LossService = CreateLossService();
        }

        private LossService CreateLossService()
        {
            return new LossService(
                Logger.Object,
                SessionService.Object,
                Configuration.Object,
                UnitOfWork.Object,
                AzueBlobStorageService.Object,
                EmailService.Object
            );
        }

        public void UpdateConfiguration(Mock<IConfiguration> newConfiguration)
        {
            Configuration = newConfiguration;
            LossService = CreateLossService();
        }
    }
}